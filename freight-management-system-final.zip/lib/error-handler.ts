// Utilitário para tratamento de erros
export class ErrorHandler {
  static async handle<T>(
    promise: Promise<T>,
    errorMessage = "Ocorreu um erro na operação",
  ): Promise<[T | null, Error | null]> {
    try {
      const data = await promise
      return [data, null]
    } catch (error) {
      console.error(`${errorMessage}:`, error)
      return [null, error instanceof Error ? error : new Error(errorMessage)]
    }
  }

  static formatErrorMessage(error: unknown): string {
    if (error instanceof Error) {
      return error.message
    }
    if (typeof error === "string") {
      return error
    }
    return "Ocorreu um erro desconhecido"
  }
}
