import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Adicionar função de formatação segura para evitar problemas com caracteres especiais
export function safeText(text: string): string {
  // Remove acentos e caracteres especiais
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
}

// Função para formatar valores monetários de forma segura
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
  }).format(value)
}

// Função para formatar datas de forma segura
export function formatDate(date: string | Date): string {
  if (!date) return ""

  try {
    const dateObj = typeof date === "string" ? new Date(date) : date
    return dateObj.toLocaleDateString("pt-BR")
  } catch (error) {
    console.error("Erro ao formatar data:", error)
    return ""
  }
}
