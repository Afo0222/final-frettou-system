import { GoogleMapsService } from "@/lib/services/google-maps"
import { TipoServicoRealService } from "@/lib/services/tipos-servico-real"
import { OrcamentoService } from "@/lib/services/orcamentos"
import { ClienteService } from "@/lib/services/clientes"
import { NotificationService } from "@/lib/services/notifications"
import type { TipoServico, CalculoOrcamento } from "@/lib/types/tipos-servico"
import type { Orcamento } from "@/lib/types/database"

interface ParametrosCalculo {
  tipoServicoId: string
  enderecoOrigem: string
  enderecoDestino: string
  ajudantesAdicionais?: number
  servicosExtrasIds?: string[]
  peso?: number
  volume?: number
}

interface DadosOrcamento {
  clienteId?: string
  tipoServicoId: string
  enderecoOrigem: string
  observacoesOrigem?: string
  enderecoDestino: string
  observacoesDestino?: string
  dataAgendada: string
  horaAgendada: string
  ajudantesAdicionais: number
  servicosExtrasIds: string[]
  itemsDescription?: string
  observacoes?: string
  valorFinal?: number
  motivoAjuste?: string
  status?: string
  novoCliente?: {
    nome: string
    telefone: string
    email?: string
    documento?: string
    endereco?: string
  }
}

export class OrcamentoIntegradoService {
  // Cache para evitar recálculos desnecessários
  private static cache = new Map<string, CalculoOrcamento>()
  private static readonly CACHE_DURATION = 10 * 60 * 1000 // 10 minutos

  static async calcularOrcamentoAutomatico(params: ParametrosCalculo): Promise<CalculoOrcamento> {
    const cacheKey = this.generateCacheKey(params)
    const cached = this.getFromCache(cacheKey)
    if (cached) return cached

    try {
      // 1. Buscar tipo de serviço
      const tipoServico = await TipoServicoRealService.getById(params.tipoServicoId)
      if (!tipoServico) {
        throw new Error("Tipo de serviço não encontrado")
      }

      // 2. Calcular rota usando Google Maps (com fallback)
      let distanciaKm = 0
      let tempoHoras = 0

      try {
        if (GoogleMapsService.isConfigured()) {
          const rota = await GoogleMapsService.calculateRoute(params.enderecoOrigem, params.enderecoDestino)
          if (rota) {
            distanciaKm = Math.round((rota.distance.value / 1000) * 100) / 100
            tempoHoras = Math.round((rota.duration.value / 3600) * 100) / 100
          }
        }
      } catch (error) {
        console.warn("Erro ao calcular rota, usando estimativa:", error)
        // Fallback: estimativa baseada em distância linear
        distanciaKm = this.estimateDistance(params.enderecoOrigem, params.enderecoDestino)
        tempoHoras = Math.max(1, distanciaKm / 30) // ~30km/h média urbana
      }

      // Se ainda não temos distância, usar valores mínimos
      if (distanciaKm === 0) {
        distanciaKm = 5 // 5km mínimo
        tempoHoras = 1 // 1h mínimo
      }

      // 3. Calcular custos
      const calculo = this.calcularCustos({
        tipoServico,
        distanciaKm,
        tempoHoras,
        ajudantesAdicionais: params.ajudantesAdicionais || 0,
        servicosExtrasIds: params.servicosExtrasIds || [],
        peso: params.peso,
        volume: params.volume,
      })

      // 4. Salvar no cache
      this.setCache(cacheKey, calculo)

      return calculo
    } catch (error) {
      console.error("Erro no cálculo de orçamento:", error)
      throw error
    }
  }

  static async criarOrcamentoComCalculo(dados: DadosOrcamento): Promise<{ orcamento: Orcamento }> {
    try {
      console.log("Criando orçamento com dados:", dados)

      // 1. Primeiro, calcular o orçamento se não tiver valor final
      let valorFinal = dados.valorFinal
      let calculo: CalculoOrcamento | null = null

      if (!valorFinal) {
        calculo = await this.calcularOrcamentoAutomatico({
          tipoServicoId: dados.tipoServicoId,
          enderecoOrigem: dados.enderecoOrigem,
          enderecoDestino: dados.enderecoDestino,
          ajudantesAdicionais: dados.ajudantesAdicionais,
          servicosExtrasIds: dados.servicosExtrasIds,
        })
        valorFinal = calculo.valor_total
      }

      // 2. Criar cliente se necessário
      let clienteId = dados.clienteId
      if (!clienteId && dados.novoCliente) {
        try {
          const novoCliente = await ClienteService.create({
            nome: dados.novoCliente.nome,
            telefone: dados.novoCliente.telefone,
            email: dados.novoCliente.email,
            documento: dados.novoCliente.documento,
            endereco: dados.novoCliente.endereco,
          })
          clienteId = novoCliente.id
        } catch (error) {
          console.error("Erro ao criar cliente:", error)
          // Continuar com clienteId undefined
        }
      }

      // 3. Criar orçamento
      const orcamentoData: Partial<Orcamento> = {
        cliente_id: clienteId,
        tipo_servico_id: dados.tipoServicoId,
        endereco_origem: dados.enderecoOrigem,
        endereco_destino: dados.enderecoDestino,
        data_agendada: dados.dataAgendada,
        hora_agendada: dados.horaAgendada,
        descricao_itens: dados.itemsDescription,
        ajudantes_adicionais: dados.ajudantesAdicionais,
        servicos_extras: dados.servicosExtrasIds,
        valor_total: valorFinal,
        status: dados.status || "rascunho",
        observacoes: dados.observacoes,
      }

      const orcamento = await OrcamentoService.create(orcamentoData)

      // 4. Notificar sucesso
      const statusMessage = dados.status === "enviado" ? "criado e enviado" : "criado"
      NotificationService.success(
        "Orçamento criado com sucesso!",
        `Orçamento ${orcamento.numero_orcamento} foi ${statusMessage}.`,
      )

      return { orcamento }
    } catch (error) {
      console.error("Erro ao criar orçamento:", error)
      NotificationService.error("Erro", "Falha ao criar orçamento. Tente novamente.")
      throw error
    }
  }

  static async recalcularOrcamento(id: string): Promise<boolean> {
    try {
      // 1. Buscar orçamento
      const orcamento = await OrcamentoService.getById(id)
      if (!orcamento) {
        throw new Error("Orçamento não encontrado")
      }

      // 2. Recalcular
      const calculo = await this.calcularOrcamentoAutomatico({
        tipoServicoId: orcamento.tipo_servico_id,
        enderecoOrigem: orcamento.endereco_origem,
        enderecoDestino: orcamento.endereco_destino,
        ajudantesAdicionais: orcamento.ajudantes_adicionais,
        servicosExtrasIds: orcamento.servicos_extras as string[],
      })

      // 3. Atualizar orçamento
      await OrcamentoService.update(id, {
        valor_total: calculo.valor_total,
        updated_at: new Date().toISOString(),
      })

      NotificationService.success("Recalculado", "Orçamento recalculado com sucesso!")
      return true
    } catch (error) {
      console.error("Erro ao recalcular orçamento:", error)
      NotificationService.error("Erro", "Falha ao recalcular orçamento.")
      return false
    }
  }

  // Adicione este método à classe OrcamentoIntegradoService

  static async ajustarValorManualmente(
    calculoId: string,
    novoValor: number,
    motivo?: string,
  ): Promise<CalculoOrcamento> {
    try {
      // Buscar cálculo original do cache
      const cacheKey = Object.keys(this.cache).find((key) => this.cache.get(key)?.id === calculoId)

      if (!cacheKey) {
        throw new Error("Cálculo não encontrado")
      }

      const calculoOriginal = this.cache.get(cacheKey)
      if (!calculoOriginal) {
        throw new Error("Cálculo não encontrado")
      }

      // Criar cálculo ajustado
      const calculoAjustado = {
        ...calculoOriginal,
        valor_total: novoValor,
        valor_ajustado_manualmente: true,
        valor_original: calculoOriginal.valor_total,
        motivo_ajuste: motivo || "Ajuste manual",
        diferenca_ajuste: novoValor - calculoOriginal.valor_total,
      }

      // Atualizar cache
      this.cache.set(cacheKey, calculoAjustado)

      return calculoAjustado
    } catch (error) {
      console.error("Erro ao ajustar valor manualmente:", error)
      throw new Error("Falha ao ajustar valor do orçamento")
    }
  }

  private static calcularCustos(params: {
    tipoServico: TipoServico
    distanciaKm: number
    tempoHoras: number
    ajudantesAdicionais: number
    servicosExtrasIds: string[]
    peso?: number
    volume?: number
  }): CalculoOrcamento {
    const { tipoServico, distanciaKm, tempoHoras, ajudantesAdicionais, servicosExtrasIds } = params

    // Cálculos base
    const subtotalBase = tipoServico.preco_base || 50
    const subtotalDistancia = distanciaKm * (tipoServico.preco_por_km || 2.5)
    const subtotalTempo = tempoHoras * (tipoServico.preco_por_hora || 25)
    const subtotalAjudantes = ajudantesAdicionais * (tipoServico.preco_ajudante || 30)

    // Custos variáveis (combustível, pedágio, etc.)
    const subtotalVariaveis = this.calcularCustosVariaveis(distanciaKm, tempoHoras)

    // Serviços extras
    const subtotalExtras = this.calcularServicosExtras(servicosExtrasIds)

    // Total
    const valorTotal =
      subtotalBase + subtotalDistancia + subtotalTempo + subtotalAjudantes + subtotalVariaveis + subtotalExtras

    return {
      id: `calc_${Date.now()}`,
      tipo_servico_id: tipoServico.id,
      distancia_km: distanciaKm,
      tempo_estimado_horas: tempoHoras,
      subtotal_base: subtotalBase,
      subtotal_distancia: subtotalDistancia,
      subtotal_tempo: subtotalTempo,
      subtotal_ajudantes: subtotalAjudantes,
      subtotal_variaveis: subtotalVariaveis,
      subtotal_extras: subtotalExtras,
      valor_total: Math.round(valorTotal * 100) / 100,
      created_at: new Date().toISOString(),
      tipo_servico: tipoServico,
    }
  }

  private static calcularCustosVariaveis(distanciaKm: number, tempoHoras: number): number {
    // Combustível: ~R$ 0.80 por km
    const combustivel = distanciaKm * 0.8

    // Desgaste do veículo: ~R$ 0.30 por km
    const desgaste = distanciaKm * 0.3

    // Tempo do motorista: ~R$ 15 por hora
    const tempoMotorista = tempoHoras * 15

    return combustivel + desgaste + tempoMotorista
  }

  private static calcularServicosExtras(servicosExtrasIds: string[]): number {
    const precos: Record<string, number> = {
      embalagem: 50,
      desmontagem: 80,
      montagem: 80,
      limpeza: 100,
      "guarda-moveis": 150,
    }

    return servicosExtrasIds.reduce((total, servicoId) => {
      return total + (precos[servicoId] || 0)
    }, 0)
  }

  private static estimateDistance(origem: string, destino: string): number {
    // Estimativa muito básica baseada no comprimento dos endereços
    // Em produção, usar uma API de geocoding para coordenadas
    const baseDistance = Math.max(5, Math.min(origem.length + destino.length, 50))
    return Math.round(baseDistance * 0.5 * 100) / 100
  }

  private static generateCacheKey(params: ParametrosCalculo): string {
    return `${params.tipoServicoId}_${params.enderecoOrigem}_${params.enderecoDestino}_${params.ajudantesAdicionais || 0}_${(params.servicosExtrasIds || []).join(",")}`
  }

  private static getFromCache(key: string): CalculoOrcamento | null {
    const cached = this.cache.get(key)
    if (cached && Date.now() - new Date(cached.created_at).getTime() < this.CACHE_DURATION) {
      return cached
    }
    this.cache.delete(key)
    return null
  }

  private static setCache(key: string, calculo: CalculoOrcamento): void {
    this.cache.set(key, calculo)
  }
}
