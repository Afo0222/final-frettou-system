import { supabase } from "@/lib/supabase/client"
import type { TipoServico, VariavelCusto, ServicoExtra, CalculoOrcamento } from "@/lib/types/tipos-servico"

export class TipoServicoRealService {
  // Buscar todos os tipos de serviço ativos
  static async getAll(): Promise<TipoServico[]> {
    const { data, error } = await supabase.from("tipos_servico").select("*").order("nome")

    if (error) throw error
    return data || []
  }

  // Buscar apenas tipos ativos
  static async getAtivos(): Promise<TipoServico[]> {
    const { data, error } = await supabase.from("tipos_servico").select("*").eq("ativo", true).order("nome")

    if (error) throw error
    return data || []
  }

  // Buscar tipo de serviço por ID
  static async getById(id: string): Promise<TipoServico | null> {
    const { data, error } = await supabase.from("tipos_servico").select("*").eq("id", id).single()

    if (error) {
      if (error.code === "PGRST116") return null
      throw error
    }
    return data
  }

  // Buscar variáveis de custo por tipo de serviço
  static async getVariaveisCusto(tipoServicoId: string): Promise<VariavelCusto[]> {
    const { data, error } = await supabase
      .from("variaveis_custo")
      .select("*")
      .eq("tipo_servico_id", tipoServicoId)
      .eq("ativo", true)
      .order("nome")

    if (error) throw error
    return data || []
  }

  // Buscar todas as variáveis de custo (incluindo inativas)
  static async getAllVariaveisCusto(tipoServicoId: string): Promise<VariavelCusto[]> {
    const { data, error } = await supabase
      .from("variaveis_custo")
      .select("*")
      .eq("tipo_servico_id", tipoServicoId)
      .order("nome")

    if (error) throw error
    return data || []
  }

  // Buscar serviços extras disponíveis para um tipo de serviço
  static async getServicosExtras(tipoServicoId?: string): Promise<ServicoExtra[]> {
    let query = supabase.from("servicos_extras").select("*").eq("ativo", true)

    if (tipoServicoId) {
      query = query.or(`tipo_servico_id.eq.${tipoServicoId},disponivel_todos_tipos.eq.true`)
    } else {
      query = query.eq("disponivel_todos_tipos", true)
    }

    const { data, error } = await query.order("nome")

    if (error) throw error
    return data || []
  }

  // Buscar todos os serviços extras (incluindo inativos)
  static async getAllServicosExtras(tipoServicoId?: string): Promise<ServicoExtra[]> {
    let query = supabase.from("servicos_extras").select("*")

    if (tipoServicoId) {
      query = query.or(`tipo_servico_id.eq.${tipoServicoId},disponivel_todos_tipos.eq.true`)
    }

    const { data, error } = await query.order("nome")

    if (error) throw error
    return data || []
  }

  // Criar novo tipo de serviço
  static async create(tipoServico: Omit<TipoServico, "id" | "created_at" | "updated_at">): Promise<TipoServico> {
    const { data, error } = await supabase
      .from("tipos_servico")
      .insert([
        {
          ...tipoServico,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Atualizar tipo de serviço
  static async update(id: string, updates: Partial<TipoServico>): Promise<TipoServico> {
    const { data, error } = await supabase
      .from("tipos_servico")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Deletar tipo de serviço (soft delete)
  static async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from("tipos_servico")
      .update({
        ativo: false,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (error) throw error
  }

  // Reativar tipo de serviço
  static async reativar(id: string): Promise<TipoServico> {
    const { data, error } = await supabase
      .from("tipos_servico")
      .update({
        ativo: true,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Duplicar tipo de serviço
  static async duplicar(id: string, novoNome: string): Promise<TipoServico> {
    const original = await this.getById(id)
    if (!original) throw new Error("Tipo de serviço não encontrado")

    const { id: _, created_at, updated_at, ...dadosParaDuplicar } = original

    const novo = await this.create({
      ...dadosParaDuplicar,
      nome: novoNome,
    })

    // Duplicar variáveis de custo
    const variaveis = await this.getAllVariaveisCusto(id)
    for (const variavel of variaveis) {
      await this.createVariavelCusto({
        tipo_servico_id: novo.id,
        nome: variavel.nome,
        descricao: variavel.descricao,
        valor: variavel.valor,
        unidade: variavel.unidade,
        ativo: variavel.ativo,
      })
    }

    // Duplicar serviços extras específicos
    const extras = await this.getAllServicosExtras(id)
    const extrasEspecificos = extras.filter((e) => e.tipo_servico_id === id)
    for (const extra of extrasEspecificos) {
      await this.createServicoExtra({
        nome: extra.nome,
        descricao: extra.descricao,
        valor: extra.valor,
        tipo_servico_id: novo.id,
        disponivel_todos_tipos: extra.disponivel_todos_tipos,
        ativo: extra.ativo,
      })
    }

    return novo
  }

  // Calcular orçamento baseado no tipo de serviço
  static async calcularOrcamento(
    tipoServicoId: string,
    distanciaKm: number,
    tempoEstimadoHoras: number,
    ajudantesAdicionais = 0,
    servicosExtrasIds: string[] = [],
  ): Promise<CalculoOrcamento> {
    // Buscar dados do tipo de serviço
    const tipoServico = await this.getById(tipoServicoId)
    if (!tipoServico) throw new Error("Tipo de serviço não encontrado")

    // Buscar variáveis de custo
    const variaveisCusto = await this.getVariaveisCusto(tipoServicoId)

    // Buscar serviços extras selecionados
    const servicosExtras: ServicoExtra[] = []
    if (servicosExtrasIds.length > 0) {
      const { data, error } = await supabase
        .from("servicos_extras")
        .select("*")
        .in("id", servicosExtrasIds)
        .eq("ativo", true)

      if (error) throw error
      servicosExtras.push(...(data || []))
    }

    // Calcular subtotais
    const subtotalBase = tipoServico.preco_base || 0
    const subtotalDistancia = (tipoServico.preco_km || 0) * distanciaKm
    const subtotalTempo = (tipoServico.preco_hora || 0) * tempoEstimadoHoras
    const subtotalAjudantes = (tipoServico.preco_ajudante || 0) * ajudantesAdicionais
    const subtotalExtras = servicosExtras.reduce((total, extra) => total + extra.valor, 0)
    const subtotalVariaveis = variaveisCusto.reduce((total, variavel) => total + variavel.valor, 0)

    const valorTotal =
      subtotalBase + subtotalDistancia + subtotalTempo + subtotalAjudantes + subtotalExtras + subtotalVariaveis

    return {
      tipo_servico: tipoServico,
      distancia_km: distanciaKm,
      tempo_estimado_horas: tempoEstimadoHoras,
      ajudantes_adicionais: ajudantesAdicionais,
      servicos_extras: servicosExtras,
      variaveis_custo: variaveisCusto,
      subtotal_base: subtotalBase,
      subtotal_distancia: subtotalDistancia,
      subtotal_tempo: subtotalTempo,
      subtotal_ajudantes: subtotalAjudantes,
      subtotal_extras: subtotalExtras,
      subtotal_variaveis: subtotalVariaveis,
      valor_total: valorTotal,
    }
  }

  // Criar variável de custo
  static async createVariavelCusto(
    variavel: Omit<VariavelCusto, "id" | "created_at" | "updated_at">,
  ): Promise<VariavelCusto> {
    const { data, error } = await supabase
      .from("variaveis_custo")
      .insert([
        {
          ...variavel,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Criar serviço extra
  static async createServicoExtra(
    servico: Omit<ServicoExtra, "id" | "created_at" | "updated_at">,
  ): Promise<ServicoExtra> {
    const { data, error } = await supabase
      .from("servicos_extras")
      .insert([
        {
          ...servico,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Atualizar variável de custo
  static async updateVariavelCusto(id: string, updates: Partial<VariavelCusto>): Promise<VariavelCusto> {
    const { data, error } = await supabase
      .from("variaveis_custo")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Atualizar serviço extra
  static async updateServicoExtra(id: string, updates: Partial<ServicoExtra>): Promise<ServicoExtra> {
    const { data, error } = await supabase
      .from("servicos_extras")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Deletar variável de custo
  static async deleteVariavelCusto(id: string): Promise<void> {
    const { error } = await supabase
      .from("variaveis_custo")
      .update({
        ativo: false,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (error) throw error
  }

  // Deletar serviço extra
  static async deleteServicoExtra(id: string): Promise<void> {
    const { error } = await supabase
      .from("servicos_extras")
      .update({
        ativo: false,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (error) throw error
  }

  // Buscar estatísticas
  static async getEstatisticas() {
    const [tipos, variaveis, extras] = await Promise.all([
      this.getAll(),
      supabase.from("variaveis_custo").select("*"),
      supabase.from("servicos_extras").select("*"),
    ])

    const tiposAtivos = tipos.filter((t) => t.ativo)
    const tiposInativos = tipos.filter((t) => !t.ativo)
    const precoMedio = tipos.reduce((acc, t) => acc + (t.preco_base || 0), 0) / tipos.length || 0

    return {
      total: tipos.length,
      ativos: tiposAtivos.length,
      inativos: tiposInativos.length,
      precoMedio,
      totalVariaveis: variaveis.data?.length || 0,
      totalExtras: extras.data?.length || 0,
      tipoMaisCaro: tipos.reduce((max, t) => ((t.preco_base || 0) > (max.preco_base || 0) ? t : max), tipos[0]),
      tipoMaisBarato: tipos.reduce((min, t) => ((t.preco_base || 0) < (min.preco_base || 0) ? t : min), tipos[0]),
    }
  }

  // Buscar histórico de uso (quantos orçamentos usaram cada tipo)
  static async getHistoricoUso() {
    const { data, error } = await supabase.from("orcamentos").select("tipo_servico, COUNT(*)").group("tipo_servico")

    if (error) throw error
    return data || []
  }
}
