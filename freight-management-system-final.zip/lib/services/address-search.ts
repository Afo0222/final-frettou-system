import { supabase } from "@/lib/supabase/client"

export interface AddressSearchResult {
  id: string
  address: string
  city: string
  state: string
  postal_code: string
  country: string
  latitude: number
  longitude: number
  created_at: string
  search_count: number
}

export class AddressSearchService {
  private static readonly MAX_RESULTS = 10
  private static readonly MIN_SEARCH_LENGTH = 3
  private static readonly CACHE_DURATION = 30 * 60 * 1000 // 30 minutos
  private static readonly SEARCH_CACHE = new Map<string, { results: AddressSearchResult[]; timestamp: number }>()

  // Buscar enderecos no banco de dados
  static async searchAddresses(query: string): Promise<AddressSearchResult[]> {
    if (!query || query.length < this.MIN_SEARCH_LENGTH) {
      return []
    }

    // Verificar cache
    const cached = this.getFromCache(query)
    if (cached) {
      return cached
    }

    try {
      // Buscar no banco de dados
      const { data, error } = await supabase
        .from("address_search_cache")
        .select("*")
        .or(`address.ilike.%${query}%,city.ilike.%${query}%`)
        .order("search_count", { ascending: false })
        .limit(this.MAX_RESULTS)

      if (error) {
        console.error("Erro ao buscar enderecos:", error)
        return []
      }

      // Armazenar no cache
      this.setCache(query, data || [])

      return data || []
    } catch (error) {
      console.error("Erro ao buscar enderecos:", error)
      return []
    }
  }

  // Salvar endereco pesquisado
  static async saveSearchedAddress(address: {
    address: string
    city: string
    state: string
    postal_code: string
    country: string
    latitude: number
    longitude: number
  }): Promise<string | null> {
    try {
      // Verificar se o endereco ja existe
      const { data: existingAddresses, error: searchError } = await supabase
        .from("address_search_cache")
        .select("id, search_count")
        .eq("address", address.address)
        .eq("city", address.city)
        .eq("state", address.state)
        .limit(1)

      if (searchError) {
        console.error("Erro ao verificar endereco existente:", searchError)
        return null
      }

      if (existingAddresses && existingAddresses.length > 0) {
        // Atualizar contador de pesquisas
        const { error: updateError } = await supabase
          .from("address_search_cache")
          .update({ search_count: (existingAddresses[0].search_count || 0) + 1 })
          .eq("id", existingAddresses[0].id)

        if (updateError) {
          console.error("Erro ao atualizar contador de pesquisas:", updateError)
        }

        return existingAddresses[0].id
      }

      // Inserir novo endereco
      const { data, error } = await supabase
        .from("address_search_cache")
        .insert([
          {
            address: address.address,
            city: address.city,
            state: address.state,
            postal_code: address.postal_code,
            country: address.country,
            latitude: address.latitude,
            longitude: address.longitude,
            search_count: 1,
          },
        ])
        .select("id")
        .single()

      if (error) {
        console.error("Erro ao salvar endereco:", error)
        return null
      }

      return data?.id || null
    } catch (error) {
      console.error("Erro ao salvar endereco:", error)
      return null
    }
  }

  // Obter enderecos recentes
  static async getRecentAddresses(limit = 5): Promise<AddressSearchResult[]> {
    try {
      const { data, error } = await supabase
        .from("address_search_cache")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit)

      if (error) {
        console.error("Erro ao obter enderecos recentes:", error)
        return []
      }

      return data || []
    } catch (error) {
      console.error("Erro ao obter enderecos recentes:", error)
      return []
    }
  }

  // Obter enderecos mais pesquisados
  static async getPopularAddresses(limit = 5): Promise<AddressSearchResult[]> {
    try {
      const { data, error } = await supabase
        .from("address_search_cache")
        .select("*")
        .order("search_count", { ascending: false })
        .limit(limit)

      if (error) {
        console.error("Erro ao obter enderecos populares:", error)
        return []
      }

      return data || []
    } catch (error) {
      console.error("Erro ao obter enderecos populares:", error)
      return []
    }
  }

  // Gerenciamento de cache
  private static getFromCache(query: string): AddressSearchResult[] | null {
    const cached = this.SEARCH_CACHE.get(query)
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      return cached.results
    }
    this.SEARCH_CACHE.delete(query)
    return null
  }

  private static setCache(query: string, results: AddressSearchResult[]): void {
    this.SEARCH_CACHE.set(query, {
      results,
      timestamp: Date.now(),
    })
  }

  // Limpar cache
  static clearCache(): void {
    this.SEARCH_CACHE.clear()
  }
}
