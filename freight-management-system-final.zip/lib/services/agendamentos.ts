import { supabase } from "@/lib/supabase/client"

export interface Agendamento {
  id: string
  orcamento_id?: string
  motorista_id?: string
  veiculo_id?: string
  data_agendada: string
  hora_agendada?: string
  hora_inicio?: string
  hora_fim?: string
  duracao_estimada_minutos?: number
  status: "agendado" | "confirmado" | "em_andamento" | "concluido" | "cancelado" | "reagendado"
  endereco_origem?: string
  endereco_destino?: string
  distancia_km?: number
  tempo_viagem_minutos?: number
  observacoes?: string
  cliente_nome?: string
  cliente_telefone?: string
  valor_servico?: number
  tipo_servico?: string
  prioridade?: "baixa" | "normal" | "alta" | "urgente"
  created_by?: string
  created_at: string
  updated_at: string
  motorista?: {
    id: string
    nome: string
    telefone?: string
    email?: string
  }
  veiculo?: {
    id: string
    modelo: string
    placa: string
  }
  orcamento?: {
    id: string
    numero_orcamento: string
    cliente?: {
      nome: string
      telefone?: string
    }
  }
}

export interface Motorista {
  id: string
  nome: string
  cpf?: string
  rg?: string
  cnh?: string
  telefone?: string
  email?: string
  endereco?: string
  status?: string
  ativo?: boolean
  created_at: string
  updated_at: string
}

export interface TimeSlot {
  data: string
  hora_inicio: string
  hora_fim: string
  disponivel: boolean
}

export interface ConflictCheck {
  hasConflict: boolean
  conflictingAppointments?: Agendamento[]
}

export class AgendamentoService {
  static async getAll(): Promise<Agendamento[]> {
    try {
      const { data: agendamentos, error } = await supabase
        .from("agendamentos")
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .order("data_agendada", { ascending: true })
        .order("hora_inicio", { ascending: true })

      if (error) throw error

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return (agendamentos || []).map((agendamento) => ({
        ...agendamento,
        motorista: agendamento.motorista_id ? motoristasData.find((m) => m.id === agendamento.motorista_id) : undefined,
        veiculo: agendamento.veiculo_id ? veiculosData.find((v) => v.id === agendamento.veiculo_id) : undefined,
      }))
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error)
      throw error
    }
  }

  static async getByDateRange(startDate: string, endDate: string): Promise<Agendamento[]> {
    try {
      const { data: agendamentos, error } = await supabase
        .from("agendamentos")
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .gte("data_agendada", startDate)
        .lte("data_agendada", endDate)
        .order("data_agendada", { ascending: true })
        .order("hora_inicio", { ascending: true })

      if (error) throw error

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return (agendamentos || []).map((agendamento) => ({
        ...agendamento,
        motorista: agendamento.motorista_id ? motoristasData.find((m) => m.id === agendamento.motorista_id) : undefined,
        veiculo: agendamento.veiculo_id ? veiculosData.find((v) => v.id === agendamento.veiculo_id) : undefined,
      }))
    } catch (error) {
      console.error("Erro ao carregar agendamentos por data:", error)
      throw error
    }
  }

  static async getByMotorista(motoristaId: string, startDate?: string, endDate?: string): Promise<Agendamento[]> {
    try {
      let query = supabase
        .from("agendamentos")
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .eq("motorista_id", motoristaId)

      if (startDate) query = query.gte("data_agendada", startDate)
      if (endDate) query = query.lte("data_agendada", endDate)

      query = query.order("data_agendada", { ascending: true }).order("hora_inicio", { ascending: true })

      const { data: agendamentos, error } = await query

      if (error) throw error

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return (agendamentos || []).map((agendamento) => ({
        ...agendamento,
        motorista: agendamento.motorista_id ? motoristasData.find((m) => m.id === agendamento.motorista_id) : undefined,
        veiculo: agendamento.veiculo_id ? veiculosData.find((v) => v.id === agendamento.veiculo_id) : undefined,
      }))
    } catch (error) {
      console.error("Erro ao carregar agendamentos do motorista:", error)
      throw error
    }
  }

  static async checkDriverAvailability(
    motoristaId: string,
    data: string,
    horaInicio: string,
    horaFim: string,
    agendamentoId?: string,
  ): Promise<ConflictCheck> {
    try {
      // Verificar conflitos manualmente se a função RPC não existir
      const { data: conflicts, error } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("motorista_id", motoristaId)
        .eq("data_agendada", data)
        .not("status", "in", "(cancelado,reagendado)")
        .not("id", "eq", agendamentoId || "")

      if (error) throw error

      const conflictingAppointments = (conflicts || []).filter((appointment) => {
        if (!appointment.hora_inicio || !appointment.hora_fim) return false
        return appointment.hora_inicio < horaFim && appointment.hora_fim > horaInicio
      })

      return {
        hasConflict: conflictingAppointments.length > 0,
        conflictingAppointments,
      }
    } catch (error) {
      console.error("Erro ao verificar disponibilidade:", error)
      return { hasConflict: false }
    }
  }

  static async getDriverAvailability(motoristaId: string, startDate: string, endDate: string): Promise<TimeSlot[]> {
    // Implementação simplificada - retorna slots de 30 minutos das 8h às 18h
    const slots: TimeSlot[] = []
    const start = new Date(startDate)
    const end = new Date(endDate)

    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split("T")[0]

      // Buscar agendamentos existentes para este dia
      const { data: agendamentos } = await supabase
        .from("agendamentos")
        .select("hora_inicio, hora_fim")
        .eq("motorista_id", motoristaId)
        .eq("data_agendada", dateStr)
        .not("status", "in", "(cancelado,reagendado)")

      // Gerar slots de 30 minutos das 8h às 18h
      for (let hour = 8; hour < 18; hour++) {
        for (let minute = 0; minute < 60; minute += 30) {
          const horaInicio = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`
          const horaFim = `${hour.toString().padStart(2, "0")}:${(minute + 30).toString().padStart(2, "0")}`

          // Verificar se há conflito
          const hasConflict = (agendamentos || []).some((agendamento) => {
            return agendamento.hora_inicio < horaFim && agendamento.hora_fim > horaInicio
          })

          slots.push({
            data: dateStr,
            hora_inicio: horaInicio,
            hora_fim: horaFim,
            disponivel: !hasConflict,
          })
        }
      }
    }

    return slots
  }

  static async create(agendamento: Omit<Agendamento, "id" | "created_at" | "updated_at">): Promise<Agendamento> {
    try {
      // Se há um orcamento_id, verificar se já existe agendamento para este orçamento
      if (agendamento.orcamento_id) {
        const { data: existingAgendamento } = await supabase
          .from("agendamentos")
          .select("id")
          .eq("orcamento_id", agendamento.orcamento_id)
          .single()

        if (existingAgendamento) {
          throw new Error("Já existe um agendamento para este orçamento")
        }
      }

      // Check for conflicts before creating
      if (agendamento.motorista_id && agendamento.hora_inicio && agendamento.hora_fim) {
        const conflictCheck = await this.checkDriverAvailability(
          agendamento.motorista_id,
          agendamento.data_agendada,
          agendamento.hora_inicio,
          agendamento.hora_fim,
        )

        if (conflictCheck.hasConflict) {
          throw new Error(`Conflito de horário detectado. O motorista já possui agendamento(s) no horário solicitado.`)
        }
      }

      // Clean the data - remove undefined values and empty strings for UUID fields
      const cleanedData = Object.fromEntries(
        Object.entries(agendamento).filter(([key, value]) => {
          // Keep all non-UUID fields even if empty
          if (!["motorista_id", "veiculo_id", "orcamento_id", "created_by"].includes(key)) {
            return value !== undefined
          }
          // For UUID fields, only keep if they have actual values
          return value !== undefined && value !== null && value !== ""
        }),
      )

      const { data, error } = await supabase
        .from("agendamentos")
        .insert([cleanedData])
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .single()

      if (error) throw error

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return {
        ...data,
        motorista: data.motorista_id ? motoristasData.find((m) => m.id === data.motorista_id) : undefined,
        veiculo: data.veiculo_id ? veiculosData.find((v) => v.id === data.veiculo_id) : undefined,
      }
    } catch (error) {
      console.error("Erro ao criar agendamento:", error)
      throw error
    }
  }

  static async update(id: string, updates: Partial<Agendamento>): Promise<Agendamento> {
    try {
      // Check for conflicts if updating time or driver
      if (updates.motorista_id || updates.hora_inicio || updates.hora_fim || updates.data_agendada) {
        const current = await this.getById(id)
        if (!current) throw new Error("Agendamento não encontrado")

        const motoristaId = updates.motorista_id || current.motorista_id
        const data = updates.data_agendada || current.data_agendada
        const horaInicio = updates.hora_inicio || current.hora_inicio
        const horaFim = updates.hora_fim || current.hora_fim

        if (motoristaId && horaInicio && horaFim) {
          const conflictCheck = await this.checkDriverAvailability(motoristaId, data, horaInicio, horaFim, id)

          if (conflictCheck.hasConflict) {
            throw new Error(
              `Conflito de horário detectado. O motorista já possui agendamento(s) no horário solicitado.`,
            )
          }
        }
      }

      // Clean the updates - remove undefined values and empty strings for UUID fields
      const cleanedUpdates = Object.fromEntries(
        Object.entries(updates).filter(([key, value]) => {
          // Keep all non-UUID fields even if empty
          if (!["motorista_id", "veiculo_id", "orcamento_id", "created_by"].includes(key)) {
            return value !== undefined
          }
          // For UUID fields, only keep if they have actual values
          return value !== undefined && value !== null && value !== ""
        }),
      )

      const { data, error } = await supabase
        .from("agendamentos")
        .update({ ...cleanedUpdates, updated_at: new Date().toISOString() })
        .eq("id", id)
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .single()

      if (error) throw error

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return {
        ...data,
        motorista: data.motorista_id ? motoristasData.find((m) => m.id === data.motorista_id) : undefined,
        veiculo: data.veiculo_id ? veiculosData.find((v) => v.id === data.veiculo_id) : undefined,
      }
    } catch (error) {
      console.error("Erro ao atualizar agendamento:", error)
      throw error
    }
  }

  static async updateStatus(id: string, status: string): Promise<Agendamento> {
    try {
      const { data, error } = await supabase
        .from("agendamentos")
        .update({
          status: status as any,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .single()

      if (error) throw error

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return {
        ...data,
        motorista: data.motorista_id ? motoristasData.find((m) => m.id === data.motorista_id) : undefined,
        veiculo: data.veiculo_id ? veiculosData.find((v) => v.id === data.veiculo_id) : undefined,
      }
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      throw error
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase.from("agendamentos").delete().eq("id", id)

      if (error) throw error
    } catch (error) {
      console.error("Erro ao excluir agendamento:", error)
      throw error
    }
  }

  static async getById(id: string): Promise<Agendamento | null> {
    try {
      const { data, error } = await supabase
        .from("agendamentos")
        .select(`
          *,
          orcamento:orcamentos(
            id,
            numero_orcamento,
            cliente:clientes(nome, telefone)
          )
        `)
        .eq("id", id)
        .single()

      if (error) throw error

      if (!data) return null

      // Manually fetch related data
      const [motoristasData, veiculosData] = await Promise.all([this.getMotoristas(), this.getVeiculos()])

      // Merge the data
      return {
        ...data,
        motorista: data.motorista_id ? motoristasData.find((m) => m.id === data.motorista_id) : undefined,
        veiculo: data.veiculo_id ? veiculosData.find((v) => v.id === data.veiculo_id) : undefined,
      }
    } catch (error) {
      console.error("Erro ao buscar agendamento:", error)
      return null
    }
  }

  static async getMotoristas(): Promise<Motorista[]> {
    try {
      const { data, error } = await supabase.from("motoristas").select("*").eq("ativo", true).order("nome")

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Erro ao carregar motoristas:", error)
      return []
    }
  }

  static async getVeiculos(): Promise<any[]> {
    try {
      const { data, error } = await supabase.from("veiculos").select("*").eq("ativo", true).order("modelo")

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Erro ao carregar veículos:", error)
      return []
    }
  }

  // Calculate estimated duration based on distance and service type
  static calculateEstimatedDuration(distanceKm?: number, serviceType?: string): number {
    let baseDuration = 120 // 2 hours default

    if (serviceType?.toLowerCase().includes("mudança")) {
      baseDuration = 240 // 4 hours for moving
    } else if (serviceType?.toLowerCase().includes("expresso")) {
      baseDuration = 90 // 1.5 hours for express
    } else if (serviceType?.toLowerCase().includes("frete")) {
      baseDuration = 180 // 3 hours for freight
    }

    if (distanceKm) {
      // Add 5 minutes per km for travel time
      baseDuration += Math.round(distanceKm * 5)
    }

    return Math.max(baseDuration, 60) // Minimum 1 hour
  }

  // Get suggested time slots for a driver on a specific date
  static async getSuggestedTimeSlots(motoristaId: string, data: string, duration = 120): Promise<string[]> {
    try {
      const availability = await this.getDriverAvailability(motoristaId, data, data)
      const slots: string[] = []

      // Group consecutive available slots
      const availableSlots = availability.filter((slot) => slot.disponivel)

      for (let i = 0; i < availableSlots.length; i++) {
        const currentSlot = availableSlots[i]
        const slotsNeeded = Math.ceil(duration / 30) // 30-minute slots

        // Check if we have enough consecutive slots
        let hasEnoughSlots = true
        for (let j = 1; j < slotsNeeded; j++) {
          if (i + j >= availableSlots.length || !availableSlots[i + j].disponivel) {
            hasEnoughSlots = false
            break
          }
        }

        if (hasEnoughSlots) {
          slots.push(currentSlot.hora_inicio)
        }
      }

      return slots
    } catch (error) {
      console.error("Erro ao buscar slots sugeridos:", error)
      return []
    }
  }
}
