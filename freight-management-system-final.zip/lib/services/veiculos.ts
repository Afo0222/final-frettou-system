import { supabase } from "@/lib/supabase/client"
import type { Veiculo } from "@/lib/types/database"

export interface VeiculoFormData {
  modelo: string
  marca: string
  placa: string
  ano: number
  cor?: string
  chassi?: string
  renavam?: string
  capacidade_peso: number
  capacidade_volume: number
  tipo_veiculo: "caminhao" | "van" | "pickup" | "moto" | "bicicleta" | "outro"
  categoria_cnh: "A" | "B" | "C" | "D" | "E"
  combustivel: "gasolina" | "etanol" | "diesel" | "flex" | "gnv" | "eletrico" | "hibrido"
  consumo_medio?: number
  motorista_id?: string
  proprietario: "empresa" | "terceiro" | "motorista"
  valor_fipe?: number
  seguro_vigente: boolean
  vencimento_seguro?: string
  ipva_pago: boolean
  vencimento_ipva?: string
  licenciamento_vigente: boolean
  vencimento_licenciamento?: string
  manutencao_preventiva?: string
  proxima_revisao?: string
  km_atual: number
  observacoes?: string
  ativo: boolean
}

export interface VeiculoStats {
  total: number
  ativos: number
  inativos: number
  porTipo: Record<string, number>
  porCombustivel: Record<string, number>
  capacidadeTotal: {
    peso: number
    volume: number
  }
  vencimentosProximos: {
    seguro: number
    ipva: number
    licenciamento: number
    cnh: number
  }
}

// Mock data for demonstration - replace with real data when database is set up
const mockVeiculos: Veiculo[] = [
  {
    id: "1",
    modelo: "Sprinter 415",
    marca: "Mercedes-Benz",
    placa: "ABC-1234",
    ano: 2022,
    cor: "Branco",
    chassi: "9BM906065NB123456",
    renavam: "12345678901",
    capacidade_peso: 3500,
    capacidade_volume: 15.5,
    tipo_veiculo: "van",
    categoria_cnh: "D",
    combustivel: "diesel",
    consumo_medio: 8.5,
    motorista_id: null,
    proprietario: "empresa",
    valor_fipe: 180000,
    seguro_vigente: true,
    vencimento_seguro: "2024-12-31",
    ipva_pago: true,
    vencimento_ipva: "2024-12-31",
    licenciamento_vigente: true,
    vencimento_licenciamento: "2024-12-31",
    manutencao_preventiva: "A cada 10.000 km",
    proxima_revisao: "2024-08-15",
    km_atual: 45000,
    observacoes: "Veículo em excelente estado",
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "2",
    modelo: "Accelo 815",
    marca: "Mercedes-Benz",
    placa: "DEF-5678",
    ano: 2021,
    cor: "Azul",
    chassi: "9BM958065NB789012",
    renavam: "98765432109",
    capacidade_peso: 5000,
    capacidade_volume: 25.0,
    tipo_veiculo: "caminhao",
    categoria_cnh: "C",
    combustivel: "diesel",
    consumo_medio: 6.2,
    motorista_id: "motorista-1",
    proprietario: "empresa",
    valor_fipe: 220000,
    seguro_vigente: true,
    vencimento_seguro: "2024-11-30",
    ipva_pago: true,
    vencimento_ipva: "2024-11-30",
    licenciamento_vigente: true,
    vencimento_licenciamento: "2024-11-30",
    manutencao_preventiva: "A cada 15.000 km",
    proxima_revisao: "2024-09-20",
    km_atual: 78000,
    observacoes: "Necessita troca de pneus em breve",
    ativo: true,
    created_at: "2024-01-10T14:30:00Z",
    updated_at: "2024-01-10T14:30:00Z",
    motorista: {
      id: "motorista-1",
      nome: "João Silva",
      cnh: "12345678901",
      categoria_cnh: "C",
    },
  },
  {
    id: "3",
    modelo: "Saveiro",
    marca: "Volkswagen",
    placa: "GHI-9012",
    ano: 2020,
    cor: "Prata",
    chassi: "9BWZZZ377LT345678",
    renavam: "11223344556",
    capacidade_peso: 800,
    capacidade_volume: 1.2,
    tipo_veiculo: "pickup",
    categoria_cnh: "B",
    combustivel: "flex",
    consumo_medio: 12.0,
    motorista_id: null,
    proprietario: "empresa",
    valor_fipe: 85000,
    seguro_vigente: false,
    vencimento_seguro: "2024-06-15",
    ipva_pago: true,
    vencimento_ipva: "2024-12-31",
    licenciamento_vigente: true,
    vencimento_licenciamento: "2024-12-31",
    manutencao_preventiva: "A cada 10.000 km",
    proxima_revisao: "2024-07-10",
    km_atual: 65000,
    observacoes: "Seguro vencido - renovar urgente",
    ativo: true,
    created_at: "2024-01-05T09:15:00Z",
    updated_at: "2024-01-05T09:15:00Z",
  },
  {
    id: "4",
    modelo: "CG 160",
    marca: "Honda",
    placa: "JKL-3456",
    ano: 2023,
    cor: "Vermelha",
    chassi: "9C2JC5000PR123456",
    renavam: "55667788990",
    capacidade_peso: 150,
    capacidade_volume: 0.1,
    tipo_veiculo: "moto",
    categoria_cnh: "A",
    combustivel: "flex",
    consumo_medio: 35.0,
    motorista_id: "motorista-2",
    proprietario: "empresa",
    valor_fipe: 12000,
    seguro_vigente: true,
    vencimento_seguro: "2025-01-31",
    ipva_pago: true,
    vencimento_ipva: "2024-12-31",
    licenciamento_vigente: true,
    vencimento_licenciamento: "2024-12-31",
    manutencao_preventiva: "A cada 5.000 km",
    proxima_revisao: "2024-08-01",
    km_atual: 8500,
    observacoes: "Moto nova, ideal para entregas rápidas",
    ativo: true,
    created_at: "2024-02-01T11:00:00Z",
    updated_at: "2024-02-01T11:00:00Z",
    motorista: {
      id: "motorista-2",
      nome: "Maria Santos",
      cnh: "98765432101",
      categoria_cnh: "A",
    },
  },
  {
    id: "5",
    modelo: "Daily 35S14",
    marca: "Iveco",
    placa: "MNO-7890",
    ano: 2019,
    cor: "Branco",
    chassi: "ZCFC135A000123456",
    renavam: "99887766554",
    capacidade_peso: 2800,
    capacidade_volume: 12.0,
    tipo_veiculo: "van",
    categoria_cnh: "B",
    combustivel: "diesel",
    consumo_medio: 9.5,
    motorista_id: null,
    proprietario: "terceiro",
    valor_fipe: 95000,
    seguro_vigente: true,
    vencimento_seguro: "2024-10-15",
    ipva_pago: false,
    vencimento_ipva: "2024-07-31",
    licenciamento_vigente: false,
    vencimento_licenciamento: "2024-07-31",
    manutencao_preventiva: "A cada 12.000 km",
    proxima_revisao: "2024-06-30",
    km_atual: 125000,
    observacoes: "Veículo de terceiro - IPVA em atraso",
    ativo: false,
    created_at: "2023-12-20T16:45:00Z",
    updated_at: "2024-06-01T10:30:00Z",
  },
]

export async function getVeiculos(): Promise<Veiculo[]> {
  try {
    // Try to fetch from database first
    const { data, error } = await supabase.from("veiculos").select("*").order("created_at", { ascending: false })

    if (error) {
      console.warn("Database not available, using mock data:", error.message)
      // Return mock data if database is not available
      return mockVeiculos
    }

    // If we have data from database, return it
    if (data && data.length > 0) {
      return data
    }

    // If database is empty, return mock data
    return mockVeiculos
  } catch (error) {
    console.warn("Error connecting to database, using mock data:", error)
    return mockVeiculos
  }
}

export async function getVeiculoById(id: string): Promise<Veiculo | null> {
  try {
    const { data, error } = await supabase.from("veiculos").select("*").eq("id", id).single()

    if (error) {
      // Fallback to mock data
      return mockVeiculos.find((v) => v.id === id) || null
    }

    return data
  } catch (error) {
    // Fallback to mock data
    return mockVeiculos.find((v) => v.id === id) || null
  }
}

export async function createVeiculo(veiculo: VeiculoFormData): Promise<Veiculo> {
  try {
    const { data, error } = await supabase.from("veiculos").insert([veiculo]).select().single()

    if (error) {
      throw new Error("Erro ao criar veículo")
    }

    return data
  } catch (error) {
    console.error("Erro ao criar veículo:", error)
    throw new Error("Erro ao criar veículo")
  }
}

export async function updateVeiculo(id: string, veiculo: Partial<VeiculoFormData>): Promise<Veiculo> {
  try {
    const { data, error } = await supabase
      .from("veiculos")
      .update({ ...veiculo, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      throw new Error("Erro ao atualizar veículo")
    }

    return data
  } catch (error) {
    console.error("Erro ao atualizar veículo:", error)
    throw new Error("Erro ao atualizar veículo")
  }
}

export async function deleteVeiculo(id: string): Promise<void> {
  try {
    const { error } = await supabase
      .from("veiculos")
      .update({ ativo: false, updated_at: new Date().toISOString() })
      .eq("id", id)

    if (error) {
      throw new Error("Erro ao desativar veículo")
    }
  } catch (error) {
    console.error("Erro ao desativar veículo:", error)
    throw new Error("Erro ao desativar veículo")
  }
}

export async function getVeiculosStats(): Promise<VeiculoStats> {
  const veiculos = await getVeiculos()

  const stats: VeiculoStats = {
    total: veiculos.length,
    ativos: veiculos.filter((v) => v.ativo).length,
    inativos: veiculos.filter((v) => !v.ativo).length,
    porTipo: {},
    porCombustivel: {},
    capacidadeTotal: {
      peso: 0,
      volume: 0,
    },
    vencimentosProximos: {
      seguro: 0,
      ipva: 0,
      licenciamento: 0,
      cnh: 0,
    },
  }

  const hoje = new Date()
  const proximoMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate())

  veiculos.forEach((veiculo) => {
    // Contagem por tipo
    stats.porTipo[veiculo.tipo_veiculo] = (stats.porTipo[veiculo.tipo_veiculo] || 0) + 1

    // Contagem por combustível
    stats.porCombustivel[veiculo.combustivel] = (stats.porCombustivel[veiculo.combustivel] || 0) + 1

    // Capacidade total
    if (veiculo.ativo) {
      stats.capacidadeTotal.peso += veiculo.capacidade_peso
      stats.capacidadeTotal.volume += veiculo.capacidade_volume
    }

    // Vencimentos próximos
    if (veiculo.vencimento_seguro && new Date(veiculo.vencimento_seguro) <= proximoMes) {
      stats.vencimentosProximos.seguro++
    }
    if (veiculo.vencimento_ipva && new Date(veiculo.vencimento_ipva) <= proximoMes) {
      stats.vencimentosProximos.ipva++
    }
    if (veiculo.vencimento_licenciamento && new Date(veiculo.vencimento_licenciamento) <= proximoMes) {
      stats.vencimentosProximos.licenciamento++
    }
  })

  return stats
}

export async function getVeiculosDisponiveis(): Promise<Veiculo[]> {
  try {
    const { data, error } = await supabase
      .from("veiculos")
      .select("*")
      .eq("ativo", true)
      .is("motorista_id", null)
      .order("modelo")

    if (error) {
      // Fallback to mock data
      return mockVeiculos.filter((v) => v.ativo && !v.motorista_id)
    }

    return data || []
  } catch (error) {
    // Fallback to mock data
    return mockVeiculos.filter((v) => v.ativo && !v.motorista_id)
  }
}

export async function associarMotorista(veiculoId: string, motoristaId: string | null): Promise<void> {
  try {
    const { error } = await supabase
      .from("veiculos")
      .update({
        motorista_id: motoristaId,
        updated_at: new Date().toISOString(),
      })
      .eq("id", veiculoId)

    if (error) {
      throw new Error("Erro ao associar motorista ao veículo")
    }
  } catch (error) {
    console.error("Erro ao associar motorista:", error)
    throw new Error("Erro ao associar motorista ao veículo")
  }
}
