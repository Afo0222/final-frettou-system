import { supabase } from "@/lib/supabase/client"
import type { VariavelCusto } from "@/lib/types/tipos-servico"

export class VariaveisCustoService {
  // Mock data for immediate functionality
  static getMockData(): VariavelCusto[] {
    return [
      {
        id: "1",
        tipo_servico_id: null,
        nome: "Taxa de Combustível",
        descricao: "Taxa adicional para cobrir variações no preço do combustível",
        valor: 15.5,
        unidade: "fixo",
        ativo: true,
        created_at: "2024-01-15T10:00:00Z",
        updated_at: "2024-01-15T10:00:00Z",
      },
      {
        id: "2",
        tipo_servico_id: null,
        nome: "Seguro da Carga",
        descricao: "Percentual para cobertura de seguro da mercadoria transportada",
        valor: 2.5,
        unidade: "percentual",
        ativo: true,
        created_at: "2024-01-16T14:30:00Z",
        updated_at: "2024-01-16T14:30:00Z",
      },
      {
        id: "3",
        tipo_servico_id: null,
        nome: "Taxa de Pedágio",
        descricao: "Custo estimado de pedágios por quilômetro rodado",
        valor: 0.25,
        unidade: "por_km",
        ativo: true,
        created_at: "2024-01-17T09:15:00Z",
        updated_at: "2024-01-17T09:15:00Z",
      },
      {
        id: "4",
        tipo_servico_id: null,
        nome: "Hora Extra Motorista",
        descricao: "Custo adicional por hora extra trabalhada pelo motorista",
        valor: 25.0,
        unidade: "por_hora",
        ativo: true,
        created_at: "2024-01-18T16:45:00Z",
        updated_at: "2024-01-18T16:45:00Z",
      },
      {
        id: "5",
        tipo_servico_id: null,
        nome: "Taxa de Manuseio",
        descricao: "Custo adicional baseado no peso da carga para manuseio especial",
        valor: 0.05,
        unidade: "por_peso",
        ativo: true,
        created_at: "2024-01-19T11:20:00Z",
        updated_at: "2024-01-19T11:20:00Z",
      },
      {
        id: "6",
        tipo_servico_id: null,
        nome: "Taxa de Ocupação",
        descricao: "Custo adicional baseado no volume ocupado no veículo",
        valor: 8.0,
        unidade: "por_volume",
        ativo: true,
        created_at: "2024-01-20T13:10:00Z",
        updated_at: "2024-01-20T13:10:00Z",
      },
      {
        id: "7",
        tipo_servico_id: null,
        nome: "Taxa Administrativa",
        descricao: "Taxa administrativa fixa para processamento do pedido",
        valor: 12.0,
        unidade: "fixo",
        ativo: false,
        created_at: "2024-01-21T08:30:00Z",
        updated_at: "2024-01-25T15:20:00Z",
      },
      {
        id: "8",
        tipo_servico_id: null,
        nome: "Desconto Volume",
        descricao: "Desconto percentual para cargas de grande volume",
        valor: -5.0,
        unidade: "percentual",
        ativo: false,
        created_at: "2024-01-22T12:00:00Z",
        updated_at: "2024-01-22T12:00:00Z",
      },
    ]
  }

  // Get all cost variables
  static async getAll(): Promise<VariavelCusto[]> {
    try {
      const { data, error } = await supabase.from("variaveis_custo").select("*").order("nome")

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Error fetching cost variables:", error)
      return this.getMockData()
    }
  }

  // Get active cost variables only
  static async getAtivas(): Promise<VariavelCusto[]> {
    try {
      const { data, error } = await supabase.from("variaveis_custo").select("*").eq("ativo", true).order("nome")

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Error fetching active cost variables:", error)
      return this.getMockData().filter((v) => v.ativo)
    }
  }

  // Get cost variable by ID
  static async getById(id: string): Promise<VariavelCusto | null> {
    try {
      const { data, error } = await supabase.from("variaveis_custo").select("*").eq("id", id).single()

      if (error) {
        if (error.code === "PGRST116") return null
        throw error
      }
      return data
    } catch (error) {
      console.error("Error fetching cost variable:", error)
      return this.getMockData().find((v) => v.id === id) || null
    }
  }

  // Get cost variables by service type
  static async getByTipoServico(tipoServicoId: string): Promise<VariavelCusto[]> {
    try {
      const { data, error } = await supabase
        .from("variaveis_custo")
        .select("*")
        .or(`tipo_servico_id.eq.${tipoServicoId},tipo_servico_id.is.null`)
        .eq("ativo", true)
        .order("nome")

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Error fetching cost variables by service type:", error)
      return this.getMockData().filter((v) => v.ativo && (!v.tipo_servico_id || v.tipo_servico_id === tipoServicoId))
    }
  }

  // Create new cost variable
  static async create(variavel: Omit<VariavelCusto, "id" | "created_at" | "updated_at">): Promise<VariavelCusto> {
    try {
      const { data, error } = await supabase
        .from("variaveis_custo")
        .insert([
          {
            ...variavel,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
        ])
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error creating cost variable:", error)
      // Return mock data for demo
      const newVariavel: VariavelCusto = {
        id: Date.now().toString(),
        ...variavel,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      return newVariavel
    }
  }

  // Update cost variable
  static async update(id: string, updates: Partial<VariavelCusto>): Promise<VariavelCusto> {
    try {
      const { data, error } = await supabase
        .from("variaveis_custo")
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error updating cost variable:", error)
      // Return mock updated data
      const existing = this.getMockData().find((v) => v.id === id)
      if (!existing) throw new Error("Cost variable not found")

      return {
        ...existing,
        ...updates,
        updated_at: new Date().toISOString(),
      }
    }
  }

  // Delete cost variable (soft delete)
  static async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from("variaveis_custo")
        .update({
          ativo: false,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)

      if (error) throw error
    } catch (error) {
      console.error("Error deleting cost variable:", error)
      // For demo purposes, we'll just log the action
    }
  }

  // Reactivate cost variable
  static async reativar(id: string): Promise<VariavelCusto> {
    try {
      const { data, error } = await supabase
        .from("variaveis_custo")
        .update({
          ativo: true,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error reactivating cost variable:", error)
      // Return mock reactivated data
      const existing = this.getMockData().find((v) => v.id === id)
      if (!existing) throw new Error("Cost variable not found")

      return {
        ...existing,
        ativo: true,
        updated_at: new Date().toISOString(),
      }
    }
  }

  // Duplicate cost variable
  static async duplicar(id: string, novoNome: string): Promise<VariavelCusto> {
    try {
      const original = await this.getById(id)
      if (!original) throw new Error("Cost variable not found")

      const { id: _, created_at, updated_at, ...dadosParaDuplicar } = original

      return await this.create({
        ...dadosParaDuplicar,
        nome: novoNome,
      })
    } catch (error) {
      console.error("Error duplicating cost variable:", error)
      throw error
    }
  }

  // Get statistics
  static async getEstatisticas() {
    try {
      const variaveis = await this.getAll()

      const ativas = variaveis.filter((v) => v.ativo)
      const inativas = variaveis.filter((v) => !v.ativo)
      const valorMedio =
        variaveis.length > 0 ? variaveis.reduce((sum, v) => sum + Math.abs(v.valor), 0) / variaveis.length : 0

      const porUnidade: Record<string, number> = {}
      variaveis.forEach((v) => {
        const unidade = v.unidade || "fixo"
        porUnidade[unidade] = (porUnidade[unidade] || 0) + 1
      })

      const maiorValor = variaveis.reduce(
        (max, v) => (Math.abs(v.valor) > Math.abs(max?.valor || 0) ? v : max),
        variaveis[0] || null,
      )
      const menorValor = variaveis.reduce(
        (min, v) => (Math.abs(v.valor) < Math.abs(min?.valor || Number.POSITIVE_INFINITY) ? v : min),
        variaveis[0] || null,
      )

      return {
        total: variaveis.length,
        ativas: ativas.length,
        inativas: inativas.length,
        valorMedio,
        porUnidade,
        maiorValor,
        menorValor,
      }
    } catch (error) {
      console.error("Error getting statistics:", error)
      return {
        total: 0,
        ativas: 0,
        inativas: 0,
        valorMedio: 0,
        porUnidade: {},
        maiorValor: null,
        menorValor: null,
      }
    }
  }
}
