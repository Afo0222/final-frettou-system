export interface Coordinates {
  lat: number
  lng: number
}

export interface Address {
  formatted_address: string
  street_number?: string
  route?: string
  neighborhood?: string
  city?: string
  state?: string
  postal_code?: string
  country?: string
  coordinates: Coordinates
}

export interface RouteInfo {
  distance: {
    text: string
    value: number // em metros
  }
  duration: {
    text: string
    value: number // em segundos
  }
  polyline: string
  steps: RouteStep[]
  bounds?: any
  warnings?: string[]
}

export interface RouteStep {
  distance: { text: string; value: number }
  duration: { text: string; value: number }
  start_location: Coordinates
  end_location: Coordinates
  html_instructions: string
  maneuver?: string
}

export interface OptimizedRoute {
  waypoint_order: number[]
  routes: RouteInfo[]
  total_distance: number
  total_duration: number
  estimated_cost: number
}

// Cache otimizado para Google Maps
class GoogleMapsCache {
  private cache = new Map<string, { data: any; timestamp: number }>()
  private readonly CACHE_DURATION = 24 * 60 * 60 * 1000 // 24 horas

  get(key: string): any {
    const cached = this.cache.get(key)
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      return cached.data
    }
    this.cache.delete(key)
    return null
  }

  set(key: string, data: any): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    })
  }

  clear(): void {
    this.cache.clear()
  }
}

export class GoogleMapsService {
  private static readonly API_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
  private static cache = new GoogleMapsCache()

  // Verificar se a API está configurada
  static isConfigured(): boolean {
    return !!this.API_KEY
  }

  // Geocodificação otimizada
  static async geocodeAddress(address: string): Promise<Address | null> {
    if (!this.isConfigured()) {
      throw new Error("Google Maps API key não configurada")
    }

    const cacheKey = `geocode_${address}`
    const cached = this.cache.get(cacheKey)
    if (cached) return cached

    try {
      const response = await fetch(`/api/maps/geocode?address=${encodeURIComponent(address)}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-cache",
        },
        cache: "no-store",
      })

      if (!response.ok) {
        throw new Error(`Geocoding API error: ${response.status}`)
      }

      const text = await response.text()

      // Verificar se é JSON válido
      if (!text.trim().startsWith("{")) {
        throw new Error(`Resposta inválida: ${text.substring(0, 100)}`)
      }

      const data = JSON.parse(text)

      if (data.error || data.status !== "OK" || !data.results || data.results.length === 0) {
        return null
      }

      const result = data.results[0]
      const location = result.geometry.location

      // Extrair componentes do endereço
      const addressComponents = result.address_components || []
      const parsedAddress: Address = {
        formatted_address: result.formatted_address,
        coordinates: {
          lat: location.lat,
          lng: location.lng,
        },
      }

      // Mapear componentes do endereço
      addressComponents.forEach((component: any) => {
        const types = component.types
        if (types.includes("street_number")) {
          parsedAddress.street_number = component.long_name
        } else if (types.includes("route")) {
          parsedAddress.route = component.long_name
        } else if (types.includes("sublocality") || types.includes("neighborhood")) {
          parsedAddress.neighborhood = component.long_name
        } else if (types.includes("locality") || types.includes("administrative_area_level_2")) {
          parsedAddress.city = component.long_name
        } else if (types.includes("administrative_area_level_1")) {
          parsedAddress.state = component.short_name
        } else if (types.includes("postal_code")) {
          parsedAddress.postal_code = component.long_name
        } else if (types.includes("country")) {
          parsedAddress.country = component.long_name
        }
      })

      this.cache.set(cacheKey, parsedAddress)
      return parsedAddress
    } catch (error) {
      console.error("Erro na geocodificação:", error)
      throw new Error("Falha ao geocodificar endereço")
    }
  }

  // Calcular rota otimizada
  static async calculateRoute(
    origin: string | Coordinates,
    destination: string | Coordinates,
    waypoints?: (string | Coordinates)[],
    optimize = false,
  ): Promise<RouteInfo | null> {
    if (!this.isConfigured()) {
      throw new Error("Google Maps API key não configurada")
    }

    try {
      const originStr = typeof origin === "string" ? origin : `${origin.lat},${origin.lng}`
      const destinationStr = typeof destination === "string" ? destination : `${destination.lat},${destination.lng}`

      const params = new URLSearchParams({
        origin: originStr,
        destination: destinationStr,
        language: "pt-BR",
        region: "BR",
        units: "metric",
      })

      // Adicionar waypoints se fornecidos
      if (waypoints && waypoints.length > 0) {
        const waypointsStr = waypoints.map((wp) => (typeof wp === "string" ? wp : `${wp.lat},${wp.lng}`)).join("|")
        params.set("waypoints", waypointsStr)
        if (optimize) {
          params.set("optimize", "true")
        }
      }

      const response = await fetch(`/api/maps/directions?${params.toString()}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-cache",
        },
        cache: "no-store",
      })

      if (!response.ok) {
        if (response.status === 429) {
          throw new Error("Limite de requisições atingido")
        }
        throw new Error(`Directions API error: ${response.status}`)
      }

      const text = await response.text()

      // Verificar se é JSON válido
      if (!text.trim().startsWith("{")) {
        throw new Error(`Resposta inválida: ${text.substring(0, 100)}`)
      }

      const data = JSON.parse(text)

      if (data.error || data.status !== "OK" || !data.route) {
        return null
      }

      return {
        distance: data.route.distance,
        duration: data.route.duration,
        polyline: data.route.polyline,
        steps: data.route.steps,
        bounds: data.route.bounds,
        warnings: data.route.warnings,
      }
    } catch (error) {
      console.error("Erro no cálculo de rota:", error)
      throw error
    }
  }

  // Validar endereço simplificado
  static async validateAddress(address: string): Promise<{
    isValid: boolean
    suggestions?: string[]
    correctedAddress?: string
  }> {
    try {
      const result = await this.geocodeAddress(address)

      if (!result) {
        return { isValid: false }
      }

      // Verificar se o endereço é preciso
      const similarity = this.calculateAddressSimilarity(address, result.formatted_address)

      return {
        isValid: similarity > 0.7,
        correctedAddress: result.formatted_address,
        suggestions: similarity < 0.7 ? [result.formatted_address] : undefined,
      }
    } catch (error) {
      return { isValid: false }
    }
  }

  // Calcular similaridade entre endereços
  private static calculateAddressSimilarity(addr1: string, addr2: string): number {
    const normalize = (str: string) =>
      str
        .toLowerCase()
        .replace(/[^\w\s]/g, "")
        .trim()
    const words1 = normalize(addr1).split(/\s+/)
    const words2 = normalize(addr2).split(/\s+/)

    const intersection = words1.filter((word) => words2.includes(word))
    const union = [...new Set([...words1, ...words2])]

    return intersection.length / union.length
  }

  // Limpar cache
  static clearCache(): void {
    this.cache.clear()
  }

  // Obter URL para embed do mapa
  static getEmbedMapUrl(
    center: string | Coordinates,
    zoom = 15,
    markers?: { location: string | Coordinates; label?: string }[],
  ): string {
    if (!this.API_KEY) return ""

    const centerStr = typeof center === "string" ? center : `${center.lat},${center.lng}`
    let url = `https://www.google.com/maps/embed/v1/view?key=${this.API_KEY}&center=${encodeURIComponent(centerStr)}&zoom=${zoom}`

    if (markers && markers.length > 0) {
      const markersStr = markers
        .map((marker) => {
          const location =
            typeof marker.location === "string" ? marker.location : `${marker.location.lat},${marker.location.lng}`
          return marker.label ? `${location}|${marker.label}` : location
        })
        .join("|")
      url += `&markers=${encodeURIComponent(markersStr)}`
    }

    return url
  }

  // Obter URL para direções
  static getDirectionsUrl(
    origin: string | Coordinates,
    destination: string | Coordinates,
    waypoints?: (string | Coordinates)[],
  ): string {
    const originStr = typeof origin === "string" ? origin : `${origin.lat},${origin.lng}`
    const destinationStr = typeof destination === "string" ? destination : `${destination.lat},${destination.lng}`

    let url = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(originStr)}&destination=${encodeURIComponent(destinationStr)}&travelmode=driving`

    if (waypoints && waypoints.length > 0) {
      const waypointsStr = waypoints.map((wp) => (typeof wp === "string" ? wp : `${wp.lat},${wp.lng}`)).join("|")
      url += `&waypoints=${encodeURIComponent(waypointsStr)}`
    }

    return url
  }
}
