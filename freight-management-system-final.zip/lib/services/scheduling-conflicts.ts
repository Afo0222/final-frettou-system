import { supabase } from "@/lib/supabase/client"

export interface SchedulingConflict {
  type:
    | "time_overlap"
    | "max_appointments"
    | "outside_working_hours"
    | "break_time_conflict"
    | "travel_time_insufficient"
  severity: "error" | "warning" | "info"
  message: string
  conflicting_appointment?: any
  suggested_times?: string[]
}

export interface AppointmentSlot {
  id?: string
  motorista_id: string
  date: string
  start_time: string
  end_time: string
  estimated_duration: number // minutes
  travel_time_to?: number // minutes to next appointment
  travel_time_from?: number // minutes from previous appointment
}

export interface DriverScheduleConstraints {
  working_hours: {
    [key: string]: { enabled: boolean; start: string; end: string }
  }
  break_times: Array<{
    id: string
    name: string
    start: string
    end: string
    days: string[]
    mandatory: boolean
  }>
  constraints: {
    max_appointments_per_day: number
    min_time_between_appointments: number
    max_working_hours_per_day: number
    allow_overtime: boolean
    travel_time_buffer: number
  }
  exceptions: Array<{
    id: string
    date: string
    type: "unavailable" | "custom_hours" | "holiday"
    start_time?: string
    end_time?: string
    reason: string
  }>
}

export class SchedulingConflictService {
  static async checkConflicts(
    appointment: AppointmentSlot,
    driverConstraints: DriverScheduleConstraints,
    excludeAppointmentId?: string,
  ): Promise<SchedulingConflict[]> {
    const conflicts: SchedulingConflict[] = []

    try {
      // Get existing appointments for the driver on the same date
      const { data: existingAppointments, error } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("motorista_id", appointment.motorista_id)
        .eq("data_agendada", appointment.date)
        .not("status", "in", "(cancelado,reagendado)")
        .not("id", "eq", excludeAppointmentId || "")

      if (error) {
        console.error("Erro ao buscar agendamentos existentes:", error)
        return conflicts
      }

      const appointments = existingAppointments || []

      // Check 1: Time overlap conflicts
      const timeConflicts = this.checkTimeOverlaps(appointment, appointments)
      conflicts.push(...timeConflicts)

      // Check 2: Maximum appointments per day
      const maxAppointmentsConflict = this.checkMaxAppointments(appointments, driverConstraints)
      if (maxAppointmentsConflict) conflicts.push(maxAppointmentsConflict)

      // Check 3: Working hours constraints
      const workingHoursConflict = this.checkWorkingHours(appointment, driverConstraints)
      if (workingHoursConflict) conflicts.push(workingHoursConflict)

      // Check 4: Break time conflicts
      const breakTimeConflicts = this.checkBreakTimeConflicts(appointment, driverConstraints)
      conflicts.push(...breakTimeConflicts)

      // Check 5: Travel time and buffer requirements
      const travelTimeConflicts = this.checkTravelTimeRequirements(appointment, appointments, driverConstraints)
      conflicts.push(...travelTimeConflicts)

      // Check 6: Availability exceptions
      const exceptionConflict = this.checkAvailabilityExceptions(appointment, driverConstraints)
      if (exceptionConflict) conflicts.push(exceptionConflict)

      // Check 7: Maximum working hours per day
      const maxHoursConflict = this.checkMaxWorkingHours(appointment, appointments, driverConstraints)
      if (maxHoursConflict) conflicts.push(maxHoursConflict)

      return conflicts
    } catch (error) {
      console.error("Erro ao verificar conflitos:", error)
      return [
        {
          type: "time_overlap",
          severity: "error",
          message: "Erro ao verificar conflitos de agendamento",
        },
      ]
    }
  }

  private static checkTimeOverlaps(appointment: AppointmentSlot, existingAppointments: any[]): SchedulingConflict[] {
    const conflicts: SchedulingConflict[] = []

    for (const existing of existingAppointments) {
      if (!existing.hora_agendada) continue

      // Calculate end time for existing appointment (assuming 2 hours if not specified)
      const existingStart = existing.hora_agendada
      const existingDuration = existing.duracao_estimada_minutos || 120
      const existingEnd = this.addMinutesToTime(existingStart, existingDuration)

      // Check for overlap
      if (this.timeRangesOverlap(appointment.start_time, appointment.end_time, existingStart, existingEnd)) {
        conflicts.push({
          type: "time_overlap",
          severity: "error",
          message: `Conflito de horário com agendamento existente (${existingStart} - ${existingEnd})`,
          conflicting_appointment: existing,
        })
      }
    }

    return conflicts
  }

  private static checkMaxAppointments(
    existingAppointments: any[],
    constraints: DriverScheduleConstraints,
  ): SchedulingConflict | null {
    if (existingAppointments.length >= constraints.constraints.max_appointments_per_day) {
      return {
        type: "max_appointments",
        severity: "error",
        message: `Máximo de ${constraints.constraints.max_appointments_per_day} agendamentos por dia atingido`,
      }
    }
    return null
  }

  private static checkWorkingHours(
    appointment: AppointmentSlot,
    constraints: DriverScheduleConstraints,
  ): SchedulingConflict | null {
    const dayOfWeek = this.getDayOfWeek(appointment.date)
    const workingHours = constraints.working_hours[dayOfWeek]

    if (!workingHours || !workingHours.enabled) {
      return {
        type: "outside_working_hours",
        severity: "error",
        message: `Motorista não trabalha neste dia (${this.getDayName(dayOfWeek)})`,
      }
    }

    if (appointment.start_time < workingHours.start || appointment.end_time > workingHours.end) {
      return {
        type: "outside_working_hours",
        severity: constraints.constraints.allow_overtime ? "warning" : "error",
        message: `Agendamento fora do horário de trabalho (${workingHours.start} - ${workingHours.end})`,
      }
    }

    return null
  }

  private static checkBreakTimeConflicts(
    appointment: AppointmentSlot,
    constraints: DriverScheduleConstraints,
  ): SchedulingConflict[] {
    const conflicts: SchedulingConflict[] = []
    const dayOfWeek = this.getDayOfWeek(appointment.date)

    for (const breakTime of constraints.break_times) {
      if (!breakTime.days.includes(dayOfWeek)) continue

      if (this.timeRangesOverlap(appointment.start_time, appointment.end_time, breakTime.start, breakTime.end)) {
        conflicts.push({
          type: "break_time_conflict",
          severity: breakTime.mandatory ? "error" : "warning",
          message: `Conflito com horário de ${breakTime.name.toLowerCase()} (${breakTime.start} - ${breakTime.end})`,
        })
      }
    }

    return conflicts
  }

  private static checkTravelTimeRequirements(
    appointment: AppointmentSlot,
    existingAppointments: any[],
    constraints: DriverScheduleConstraints,
  ): SchedulingConflict[] {
    const conflicts: SchedulingConflict[] = []
    const buffer = constraints.constraints.travel_time_buffer
    const minGap = constraints.constraints.min_time_between_appointments

    for (const existing of existingAppointments) {
      if (!existing.hora_agendada) continue

      const existingStart = existing.hora_agendada
      const existingDuration = existing.duracao_estimada_minutos || 120
      const existingEnd = this.addMinutesToTime(existingStart, existingDuration)

      // Check gap before new appointment
      const gapBefore = this.getTimeDifferenceInMinutes(existingEnd, appointment.start_time)
      if (gapBefore >= 0 && gapBefore < minGap + buffer) {
        conflicts.push({
          type: "travel_time_insufficient",
          severity: "warning",
          message: `Tempo insuficiente entre agendamentos (${gapBefore} min, mínimo: ${minGap + buffer} min)`,
          conflicting_appointment: existing,
        })
      }

      // Check gap after new appointment
      const gapAfter = this.getTimeDifferenceInMinutes(appointment.end_time, existingStart)
      if (gapAfter >= 0 && gapAfter < minGap + buffer) {
        conflicts.push({
          type: "travel_time_insufficient",
          severity: "warning",
          message: `Tempo insuficiente entre agendamentos (${gapAfter} min, mínimo: ${minGap + buffer} min)`,
          conflicting_appointment: existing,
        })
      }
    }

    return conflicts
  }

  private static checkAvailabilityExceptions(
    appointment: AppointmentSlot,
    constraints: DriverScheduleConstraints,
  ): SchedulingConflict | null {
    const exception = constraints.exceptions.find((ex) => ex.date === appointment.date)

    if (!exception) return null

    if (exception.type === "unavailable" || exception.type === "holiday") {
      return {
        type: "outside_working_hours",
        severity: "error",
        message: `Motorista indisponível nesta data: ${exception.reason}`,
      }
    }

    if (exception.type === "custom_hours" && exception.start_time && exception.end_time) {
      if (appointment.start_time < exception.start_time || appointment.end_time > exception.end_time) {
        return {
          type: "outside_working_hours",
          severity: "error",
          message: `Fora do horário personalizado (${exception.start_time} - ${exception.end_time}): ${exception.reason}`,
        }
      }
    }

    return null
  }

  private static checkMaxWorkingHours(
    appointment: AppointmentSlot,
    existingAppointments: any[],
    constraints: DriverScheduleConstraints,
  ): SchedulingConflict | null {
    // Calculate total working time for the day
    let totalMinutes = appointment.estimated_duration

    for (const existing of existingAppointments) {
      totalMinutes += existing.duracao_estimada_minutos || 120
    }

    const totalHours = totalMinutes / 60
    const maxHours = constraints.constraints.max_working_hours_per_day

    if (totalHours > maxHours) {
      return {
        type: "outside_working_hours",
        severity: constraints.constraints.allow_overtime ? "warning" : "error",
        message: `Excede o máximo de ${maxHours}h de trabalho por dia (total: ${totalHours.toFixed(1)}h)`,
      }
    }

    return null
  }

  static async suggestAlternativeTimes(
    appointment: AppointmentSlot,
    constraints: DriverScheduleConstraints,
    numberOfSuggestions = 3,
  ): Promise<string[]> {
    const suggestions: string[] = []
    const dayOfWeek = this.getDayOfWeek(appointment.date)
    const workingHours = constraints.working_hours[dayOfWeek]

    if (!workingHours || !workingHours.enabled) {
      return suggestions
    }

    try {
      // Get existing appointments for the day
      const { data: existingAppointments } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("motorista_id", appointment.motorista_id)
        .eq("data_agendada", appointment.date)
        .not("status", "in", "(cancelado,reagendado)")

      const appointments = existingAppointments || []

      // Generate time slots throughout the working day
      const startTime = workingHours.start
      const endTime = workingHours.end
      const slotDuration = appointment.estimated_duration
      const buffer = constraints.constraints.min_time_between_appointments + constraints.constraints.travel_time_buffer

      let currentTime = startTime
      while (suggestions.length < numberOfSuggestions && currentTime < endTime) {
        const slotEnd = this.addMinutesToTime(currentTime, slotDuration)

        if (slotEnd <= endTime) {
          // Check if this slot conflicts with existing appointments
          const testAppointment = {
            ...appointment,
            start_time: currentTime,
            end_time: slotEnd,
          }

          const conflicts = await this.checkConflicts(testAppointment, constraints, appointment.id)
          const hasBlockingConflicts = conflicts.some((c) => c.severity === "error")

          if (!hasBlockingConflicts) {
            suggestions.push(currentTime)
          }
        }

        // Move to next slot
        currentTime = this.addMinutesToTime(currentTime, 30) // 30-minute increments
      }

      return suggestions
    } catch (error) {
      console.error("Erro ao sugerir horários alternativos:", error)
      return suggestions
    }
  }

  // Utility methods
  private static timeRangesOverlap(start1: string, end1: string, start2: string, end2: string): boolean {
    return start1 < end2 && end1 > start2
  }

  private static addMinutesToTime(time: string, minutes: number): string {
    const [hours, mins] = time.split(":").map(Number)
    const totalMinutes = hours * 60 + mins + minutes
    const newHours = Math.floor(totalMinutes / 60) % 24
    const newMins = totalMinutes % 60
    return `${newHours.toString().padStart(2, "0")}:${newMins.toString().padStart(2, "0")}`
  }

  private static getTimeDifferenceInMinutes(time1: string, time2: string): number {
    const [h1, m1] = time1.split(":").map(Number)
    const [h2, m2] = time2.split(":").map(Number)
    const minutes1 = h1 * 60 + m1
    const minutes2 = h2 * 60 + m2
    return minutes2 - minutes1
  }

  private static getDayOfWeek(date: string): string {
    const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
    const dayIndex = new Date(date).getDay()
    return days[dayIndex]
  }

  private static getDayName(dayOfWeek: string): string {
    const dayNames = {
      monday: "Segunda-feira",
      tuesday: "Terça-feira",
      wednesday: "Quarta-feira",
      thursday: "Quinta-feira",
      friday: "Sexta-feira",
      saturday: "Sábado",
      sunday: "Domingo",
    }
    return dayNames[dayOfWeek as keyof typeof dayNames] || dayOfWeek
  }
}
