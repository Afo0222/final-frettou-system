import { supabase } from "@/lib/supabase/client"
import type { Rota } from "@/lib/types/database"

export class RotaService {
  static async getAll(): Promise<Rota[]> {
    const { data, error } = await supabase
      .from("rotas")
      .select(`
        *,
        agendamento:agendamentos(
          *,
          orcamento:orcamentos(
            *,
            cliente:clientes(*)
          )
        )
      `)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data || []
  }

  static async getByMotorista(motoristaId: string): Promise<Rota[]> {
    const { data, error } = await supabase
      .from("rotas")
      .select(`
        *,
        agendamento:agendamentos!inner(
          *,
          orcamento:orcamentos(
            *,
            cliente:clientes(*)
          )
        )
      `)
      .eq("agendamento.motorista_id", motoristaId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data || []
  }

  static async getByStatus(status: string): Promise<Rota[]> {
    const { data, error } = await supabase
      .from("rotas")
      .select(`
        *,
        agendamento:agendamentos(
          *,
          orcamento:orcamentos(
            *,
            cliente:clientes(*)
          )
        )
      `)
      .eq("status", status)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data || []
  }

  static async updateStatus(id: string, status: string, observacoes?: string): Promise<Rota> {
    const updates: any = {
      status,
      updated_at: new Date().toISOString(),
    }

    // Adicionar timestamps baseado no status
    const now = new Date().toISOString()
    switch (status) {
      case "em_coleta":
        updates.hora_inicio = now
        break
      case "em_rota":
        updates.hora_coleta = now
        break
      case "entregue":
        updates.hora_entrega = now
        break
      case "concluida":
        updates.hora_conclusao = now
        break
    }

    if (observacoes) {
      updates.observacoes_motorista = observacoes
    }

    const { data, error } = await supabase
      .from("rotas")
      .update(updates)
      .eq("id", id)
      .select(`
        *,
        agendamento:agendamentos(
          *,
          orcamento:orcamentos(
            *,
            cliente:clientes(*)
          )
        )
      `)
      .single()

    if (error) throw error
    return data
  }

  static async updateLocation(id: string, lat: number, lng: number): Promise<void> {
    const { error } = await supabase
      .from("rotas")
      .update({
        localizacao_atual: {
          lat,
          lng,
          timestamp: new Date().toISOString(),
        },
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (error) throw error
  }
}
