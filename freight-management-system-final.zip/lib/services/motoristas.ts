import { supabase } from "@/lib/supabase/client"
import type { Motorista } from "@/lib/types/database"

export interface MotoristaFormData {
  nome: string
  cpf: string
  rg?: string
  cnh: string
  categoria_cnh: "A" | "B" | "C" | "D" | "E"
  vencimento_cnh: string
  telefone: string
  email?: string
  endereco?: string
  data_nascimento?: string
  data_admissao?: string
  salario?: number
  comissao_percentual?: number
  banco?: string
  agencia?: string
  conta?: string
  pix?: string
  observacoes?: string
  ativo: boolean
}

// Mock data for demonstration
const mockMotoristas: Motorista[] = [
  {
    id: "motorista-1",
    nome: "João Silva",
    cpf: "123.456.789-01",
    rg: "12.345.678-9",
    cnh: "12345678901",
    categoria_cnh: "C",
    vencimento_cnh: "2025-12-31",
    telefone: "(11) 99999-1111",
    email: "joao.silva@email.com",
    endereco: "Rua das Flores, 123 - São Paulo/SP",
    data_nascimento: "1985-03-15",
    data_admissao: "2023-01-15",
    salario: 3500,
    comissao_percentual: 5,
    banco: "Banco do Brasil",
    agencia: "1234-5",
    conta: "12345-6",
    pix: "joao.silva@email.com",
    observacoes: "Motorista experiente, pontual e responsável",
    ativo: true,
    created_at: "2023-01-15T10:00:00Z",
    updated_at: "2023-01-15T10:00:00Z",
  },
  {
    id: "motorista-2",
    nome: "Maria Santos",
    cpf: "987.654.321-09",
    rg: "98.765.432-1",
    cnh: "98765432101",
    categoria_cnh: "A",
    vencimento_cnh: "2026-06-30",
    telefone: "(11) 88888-2222",
    email: "maria.santos@email.com",
    endereco: "Av. Paulista, 456 - São Paulo/SP",
    data_nascimento: "1990-07-22",
    data_admissao: "2023-02-01",
    salario: 2800,
    comissao_percentual: 3,
    banco: "Caixa Econômica",
    agencia: "5678-9",
    conta: "98765-4",
    pix: "(11) 88888-2222",
    observacoes: "Especialista em entregas rápidas com moto",
    ativo: true,
    created_at: "2023-02-01T11:00:00Z",
    updated_at: "2023-02-01T11:00:00Z",
  },
  {
    id: "motorista-3",
    nome: "Carlos Oliveira",
    cpf: "456.789.123-45",
    rg: "45.678.912-3",
    cnh: "45678912345",
    categoria_cnh: "D",
    vencimento_cnh: "2024-09-15",
    telefone: "(11) 77777-3333",
    email: "carlos.oliveira@email.com",
    endereco: "Rua da Liberdade, 789 - São Paulo/SP",
    data_nascimento: "1978-11-10",
    data_admissao: "2022-08-20",
    salario: 4200,
    comissao_percentual: 7,
    banco: "Itaú",
    agencia: "9876-5",
    conta: "54321-0",
    pix: "carlos.oliveira@email.com",
    observacoes: "CNH vencendo em breve - renovar",
    ativo: true,
    created_at: "2022-08-20T14:30:00Z",
    updated_at: "2024-06-01T09:15:00Z",
  },
]

export async function getMotoristas(): Promise<Motorista[]> {
  try {
    const { data, error } = await supabase.from("motoristas").select("*").order("nome")

    if (error) {
      console.warn("Database not available, using mock data:", error.message)
      return mockMotoristas
    }

    if (data && data.length > 0) {
      return data
    }

    return mockMotoristas
  } catch (error) {
    console.warn("Error connecting to database, using mock data:", error)
    return mockMotoristas
  }
}

export async function getMotoristasAtivos(): Promise<Motorista[]> {
  try {
    const { data, error } = await supabase.from("motoristas").select("*").eq("ativo", true).order("nome")

    if (error) {
      return mockMotoristas.filter((m) => m.ativo)
    }

    return data || mockMotoristas.filter((m) => m.ativo)
  } catch (error) {
    return mockMotoristas.filter((m) => m.ativo)
  }
}

export async function getMotoristaById(id: string): Promise<Motorista | null> {
  try {
    const { data, error } = await supabase.from("motoristas").select("*").eq("id", id).single()

    if (error) {
      return mockMotoristas.find((m) => m.id === id) || null
    }

    return data
  } catch (error) {
    return mockMotoristas.find((m) => m.id === id) || null
  }
}

export async function createMotorista(motorista: MotoristaFormData): Promise<Motorista> {
  try {
    const { data, error } = await supabase.from("motoristas").insert([motorista]).select().single()

    if (error) {
      throw new Error("Erro ao criar motorista")
    }

    return data
  } catch (error) {
    console.error("Erro ao criar motorista:", error)
    throw new Error("Erro ao criar motorista")
  }
}

export async function updateMotorista(id: string, motorista: Partial<MotoristaFormData>): Promise<Motorista> {
  try {
    const { data, error } = await supabase
      .from("motoristas")
      .update({ ...motorista, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      throw new Error("Erro ao atualizar motorista")
    }

    return data
  } catch (error) {
    console.error("Erro ao atualizar motorista:", error)
    throw new Error("Erro ao atualizar motorista")
  }
}

export async function deleteMotorista(id: string): Promise<void> {
  try {
    const { error } = await supabase
      .from("motoristas")
      .update({ ativo: false, updated_at: new Date().toISOString() })
      .eq("id", id)

    if (error) {
      throw new Error("Erro ao desativar motorista")
    }
  } catch (error) {
    console.error("Erro ao desativar motorista:", error)
    throw new Error("Erro ao desativar motorista")
  }
}
