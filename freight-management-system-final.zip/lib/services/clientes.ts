import { createClient } from "@/lib/supabase/client"
import type { Cliente } from "@/lib/types/database"
import { ErrorHandler } from "@/lib/error-handler"

export class ClienteService {
  static async getAll(): Promise<Cliente[]> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("clientes").select("*").order("nome", { ascending: true }),
      "Erro ao buscar clientes",
    )

    if (error || !data) {
      return []
    }

    return data.data as Cliente[]
  }

  static async getById(id: string): Promise<Cliente | null> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("clientes").select("*").eq("id", id).single(),
      `Erro ao buscar cliente com ID ${id}`,
    )

    if (error || !data) {
      return null
    }

    return data.data as Cliente
  }

  static async create(cliente: Partial<Cliente>): Promise<Cliente> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("clientes").insert([cliente]).select().single(),
      "Erro ao criar cliente",
    )

    if (error || !data) {
      throw new Error("Falha ao criar cliente")
    }

    return data.data as Cliente
  }

  static async update(id: string, cliente: Partial<Cliente>): Promise<Cliente> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("clientes").update(cliente).eq("id", id).select().single(),
      `Erro ao atualizar cliente com ID ${id}`,
    )

    if (error || !data) {
      throw new Error("Falha ao atualizar cliente")
    }

    return data.data as Cliente
  }

  static async delete(id: string): Promise<boolean> {
    const supabase = createClient()

    const [_, error] = await ErrorHandler.handle(
      supabase.from("clientes").delete().eq("id", id),
      `Erro ao excluir cliente com ID ${id}`,
    )

    return !error
  }

  static async search(query: string): Promise<Cliente[]> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase
        .from("clientes")
        .select("*")
        .or(`nome.ilike.%${query}%,telefone.ilike.%${query}%,email.ilike.%${query}%`)
        .order("nome", { ascending: true }),
      "Erro ao pesquisar clientes",
    )

    if (error || !data) {
      return []
    }

    return data.data as Cliente[]
  }
}
