import { supabase } from "@/lib/supabase/client"
import { AgendamentoIntegradoService, type AgendamentoCompleto } from "./agendamentos-integrado"

export interface CancellationReason {
  id: string
  reason: string
  category: "client" | "driver" | "company" | "weather" | "vehicle" | "other"
  requires_note: boolean
  affects_billing: boolean
}

export interface CancellationData {
  appointment_id: string
  reason_id: string
  reason_category: string
  reason_text: string
  cancellation_notes?: string
  cancelled_by: string
  cancelled_at: string
  refund_amount?: number
  reschedule_requested: boolean
  client_notified: boolean
  driver_notified: boolean
}

export class AppointmentCancellationService {
  // Predefined cancellation reasons
  static readonly CANCELLATION_REASONS: CancellationReason[] = [
    {
      id: "client-request",
      reason: "Solicitação do cliente",
      category: "client",
      requires_note: false,
      affects_billing: true,
    },
    {
      id: "client-no-show",
      reason: "Cliente não compareceu",
      category: "client",
      requires_note: true,
      affects_billing: false,
    },
    {
      id: "driver-unavailable",
      reason: "Motorista indisponível",
      category: "driver",
      requires_note: true,
      affects_billing: true,
    },
    {
      id: "vehicle-breakdown",
      reason: "Problema no veículo",
      category: "vehicle",
      requires_note: true,
      affects_billing: true,
    },
    {
      id: "weather-conditions",
      reason: "Condições climáticas",
      category: "weather",
      requires_note: false,
      affects_billing: true,
    },
    {
      id: "company-decision",
      reason: "Decisão da empresa",
      category: "company",
      requires_note: true,
      affects_billing: true,
    },
    {
      id: "emergency",
      reason: "Emergência",
      category: "other",
      requires_note: true,
      affects_billing: true,
    },
    {
      id: "duplicate-booking",
      reason: "Agendamento duplicado",
      category: "company",
      requires_note: false,
      affects_billing: false,
    },
  ]

  /**
   * Cancel an appointment with proper data preservation and schedule updates
   */
  static async cancelAppointment(
    appointmentId: string,
    cancellationData: Partial<CancellationData>,
    cancelledBy = "system",
  ): Promise<{
    success: boolean
    appointment: AgendamentoCompleto | null
    message: string
    scheduleFreed: boolean
  }> {
    try {
      console.log(`🔄 Iniciando cancelamento do agendamento ${appointmentId}`)

      // 1. Get the current appointment data
      const appointment = await AgendamentoIntegradoService.getById(appointmentId)
      if (!appointment) {
        throw new Error("Agendamento não encontrado")
      }

      // Prevent cancellation of already completed or cancelled appointments
      if (appointment.status === "concluido") {
        throw new Error("Não é possível cancelar um agendamento já concluído")
      }

      if (appointment.status === "cancelado") {
        return {
          success: true,
          appointment,
          message: "Agendamento já estava cancelado",
          scheduleFreed: false,
        }
      }

      console.log(`📋 Agendamento encontrado: ${appointment.cliente_nome} - ${appointment.data_agendada}`)

      // 2. Prepare cancellation record for historical tracking
      const cancellationRecord: CancellationData = {
        appointment_id: appointmentId,
        reason_id: cancellationData.reason_id || "company-decision",
        reason_category: cancellationData.reason_category || "company",
        reason_text: cancellationData.reason_text || "Cancelamento sem motivo especificado",
        cancellation_notes: cancellationData.cancellation_notes,
        cancelled_by: cancelledBy,
        cancelled_at: new Date().toISOString(),
        refund_amount: cancellationData.refund_amount,
        reschedule_requested: cancellationData.reschedule_requested || false,
        client_notified: cancellationData.client_notified || false,
        driver_notified: cancellationData.driver_notified || false,
      }

      // 3. Store cancellation data for historical tracking
      await this.storeCancellationRecord(cancellationRecord)

      // 4. Update appointment status to 'cancelado'
      const updatedAppointment = await AgendamentoIntegradoService.updateStatus(appointmentId, "cancelado")

      // 5. Add cancellation information to appointment notes
      const cancellationNote = `CANCELADO em ${new Date().toLocaleString("pt-BR")}\nMotivo: ${cancellationRecord.reason_text}\nCancelado por: ${cancelledBy}${cancellationRecord.cancellation_notes ? `\nObservações: ${cancellationRecord.cancellation_notes}` : ""}`

      await this.updateAppointmentWithCancellationInfo(appointmentId, cancellationNote)

      // 6. Free up the driver's schedule
      const scheduleFreed = await this.freeDriverSchedule(appointment)

      // 7. Send notifications if required
      await this.sendCancellationNotifications(appointment, cancellationRecord)

      // 8. Update related systems
      await this.updateRelatedSystems(appointment, cancellationRecord)

      console.log(`✅ Agendamento cancelado com sucesso: ${appointmentId}`)

      return {
        success: true,
        appointment: updatedAppointment,
        message: "Agendamento cancelado com sucesso. O horário foi liberado para novos agendamentos.",
        scheduleFreed,
      }
    } catch (error) {
      console.error("❌ Erro ao cancelar agendamento:", error)
      throw new Error(`Falha ao cancelar agendamento: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  /**
   * Store cancellation record for historical tracking
   */
  private static async storeCancellationRecord(cancellationData: CancellationData): Promise<void> {
    try {
      // Try to store in a dedicated cancellations table
      const { error } = await supabase.from("appointment_cancellations").insert([cancellationData])

      if (error) {
        console.warn("⚠️ Tabela de cancelamentos não existe, armazenando em logs:", error)
        // Fallback: store in a general logs table or as JSON in appointment
        await this.storeCancellationInLogs(cancellationData)
      } else {
        console.log("✅ Registro de cancelamento armazenado com sucesso")
      }
    } catch (error) {
      console.error("❌ Erro ao armazenar registro de cancelamento:", error)
      // Continue with cancellation even if logging fails
    }
  }

  /**
   * Fallback method to store cancellation data
   */
  private static async storeCancellationInLogs(cancellationData: CancellationData): Promise<void> {
    try {
      const logEntry = {
        event_type: "appointment_cancellation",
        appointment_id: cancellationData.appointment_id,
        event_data: JSON.stringify(cancellationData),
        created_at: new Date().toISOString(),
      }

      // Try to store in system logs
      const { error } = await supabase.from("system_logs").insert([logEntry])

      if (error) {
        console.warn("⚠️ Não foi possível armazenar em logs do sistema:", error)
      }
    } catch (error) {
      console.error("❌ Erro no fallback de armazenamento:", error)
    }
  }

  /**
   * Update appointment with cancellation information
   */
  private static async updateAppointmentWithCancellationInfo(
    appointmentId: string,
    cancellationNote: string,
  ): Promise<void> {
    try {
      // Get current appointment to preserve existing notes
      const { data: currentAppointment } = await supabase
        .from("agendamentos")
        .select("observacoes")
        .eq("id", appointmentId)
        .single()

      const existingNotes = currentAppointment?.observacoes || ""
      const updatedNotes = existingNotes
        ? `${existingNotes}\n\n--- CANCELAMENTO ---\n${cancellationNote}`
        : `--- CANCELAMENTO ---\n${cancellationNote}`

      const { error } = await supabase
        .from("agendamentos")
        .update({
          observacoes: updatedNotes,
          updated_at: new Date().toISOString(),
        })
        .eq("id", appointmentId)

      if (error) {
        console.warn("⚠️ Erro ao atualizar observações do agendamento:", error)
      } else {
        console.log("✅ Informações de cancelamento adicionadas ao agendamento")
      }
    } catch (error) {
      console.error("❌ Erro ao atualizar agendamento com info de cancelamento:", error)
    }
  }

  /**
   * Free up the driver's schedule by removing the appointment from active scheduling
   */
  private static async freeDriverSchedule(appointment: AgendamentoCompleto): Promise<boolean> {
    try {
      console.log(`🔄 Liberando horário do motorista: ${appointment.motorista?.nome || "N/A"}`)

      // The appointment status is already updated to 'cancelado'
      // This makes it automatically excluded from active scheduling queries
      // No additional action needed as the scheduling system filters by status

      // Optional: Clear any cached schedule data
      await this.clearScheduleCache(appointment)

      console.log("✅ Horário do motorista liberado com sucesso")
      return true
    } catch (error) {
      console.error("❌ Erro ao liberar horário do motorista:", error)
      return false
    }
  }

  /**
   * Clear any cached schedule data
   */
  private static async clearScheduleCache(appointment: AgendamentoCompleto): Promise<void> {
    try {
      // Clear any driver schedule cache if implemented
      // This is a placeholder for future caching implementation
      console.log("🔄 Limpando cache de horários (se implementado)")
    } catch (error) {
      console.error("❌ Erro ao limpar cache:", error)
    }
  }

  /**
   * Send cancellation notifications
   */
  private static async sendCancellationNotifications(
    appointment: AgendamentoCompleto,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      console.log("🔄 Enviando notificações de cancelamento...")

      // Notify client if required
      if (cancellationData.client_notified && appointment.cliente_telefone) {
        await this.notifyClient(appointment, cancellationData)
      }

      // Notify driver if required
      if (cancellationData.driver_notified && appointment.motorista) {
        await this.notifyDriver(appointment, cancellationData)
      }

      console.log("✅ Notificações enviadas")
    } catch (error) {
      console.error("❌ Erro ao enviar notificações:", error)
      // Don't fail the cancellation if notifications fail
    }
  }

  /**
   * Notify client about cancellation
   */
  private static async notifyClient(
    appointment: AgendamentoCompleto,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      const message = `Olá ${appointment.cliente_nome}, seu agendamento para ${new Date(appointment.data_agendada).toLocaleDateString("pt-BR")} às ${appointment.hora_agendada} foi cancelado. Motivo: ${cancellationData.reason_text}. Entre em contato conosco para reagendar.`

      // Here you would integrate with your notification service (WhatsApp, SMS, Email)
      console.log("📱 Notificação para cliente:", message)
    } catch (error) {
      console.error("❌ Erro ao notificar cliente:", error)
    }
  }

  /**
   * Notify driver about cancellation
   */
  private static async notifyDriver(
    appointment: AgendamentoCompleto,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      const message = `Agendamento cancelado: ${appointment.cliente_nome} - ${new Date(appointment.data_agendada).toLocaleDateString("pt-BR")} às ${appointment.hora_agendada}. Motivo: ${cancellationData.reason_text}`

      // Here you would integrate with your notification service
      console.log("🚗 Notificação para motorista:", message)
    } catch (error) {
      console.error("❌ Erro ao notificar motorista:", error)
    }
  }

  /**
   * Update related systems (billing, inventory, etc.)
   */
  private static async updateRelatedSystems(
    appointment: AgendamentoCompleto,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      console.log("🔄 Atualizando sistemas relacionados...")

      // Update billing system if cancellation affects billing
      if (cancellationData.affects_billing) {
        await this.updateBillingSystem(appointment, cancellationData)
      }

      // Update inventory/resource allocation
      await this.updateResourceAllocation(appointment)

      // Update analytics/reporting
      await this.updateAnalytics(appointment, cancellationData)

      console.log("✅ Sistemas relacionados atualizados")
    } catch (error) {
      console.error("❌ Erro ao atualizar sistemas relacionados:", error)
      // Don't fail the cancellation if related system updates fail
    }
  }

  /**
   * Update billing system for cancellation
   */
  private static async updateBillingSystem(
    appointment: AgendamentoCompleto,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      // Handle refunds, billing adjustments, etc.
      console.log("💰 Atualizando sistema de faturamento...")

      if (cancellationData.refund_amount && cancellationData.refund_amount > 0) {
        // Process refund
        console.log(`💸 Processando reembolso: R$ ${cancellationData.refund_amount}`)
      }
    } catch (error) {
      console.error("❌ Erro ao atualizar sistema de faturamento:", error)
    }
  }

  /**
   * Update resource allocation
   */
  private static async updateResourceAllocation(appointment: AgendamentoCompleto): Promise<void> {
    try {
      // Free up vehicle, equipment, etc.
      console.log("🚛 Liberando recursos alocados...")
    } catch (error) {
      console.error("❌ Erro ao atualizar alocação de recursos:", error)
    }
  }

  /**
   * Update analytics and reporting
   */
  private static async updateAnalytics(
    appointment: AgendamentoCompleto,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      // Update cancellation statistics, trends, etc.
      console.log("📊 Atualizando analytics...")
    } catch (error) {
      console.error("❌ Erro ao atualizar analytics:", error)
    }
  }

  /**
   * Get cancellation history for an appointment
   */
  static async getCancellationHistory(appointmentId: string): Promise<CancellationData[]> {
    try {
      const { data, error } = await supabase
        .from("appointment_cancellations")
        .select("*")
        .eq("appointment_id", appointmentId)
        .order("cancelled_at", { ascending: false })

      if (error) {
        console.warn("⚠️ Erro ao buscar histórico de cancelamentos:", error)
        return []
      }

      return data || []
    } catch (error) {
      console.error("❌ Erro ao buscar histórico de cancelamentos:", error)
      return []
    }
  }

  /**
   * Get cancellation statistics
   */
  static async getCancellationStats(
    startDate?: string,
    endDate?: string,
  ): Promise<{
    total: number
    byReason: Record<string, number>
    byCategory: Record<string, number>
    refundTotal: number
  }> {
    try {
      let query = supabase.from("appointment_cancellations").select("*")

      if (startDate) {
        query = query.gte("cancelled_at", startDate)
      }
      if (endDate) {
        query = query.lte("cancelled_at", endDate)
      }

      const { data, error } = await query

      if (error) {
        console.warn("⚠️ Erro ao buscar estatísticas de cancelamento:", error)
        return { total: 0, byReason: {}, byCategory: {}, refundTotal: 0 }
      }

      const stats = {
        total: data?.length || 0,
        byReason: {} as Record<string, number>,
        byCategory: {} as Record<string, number>,
        refundTotal: 0,
      }

      data?.forEach((cancellation) => {
        // Count by reason
        stats.byReason[cancellation.reason_text] = (stats.byReason[cancellation.reason_text] || 0) + 1

        // Count by category
        stats.byCategory[cancellation.reason_category] = (stats.byCategory[cancellation.reason_category] || 0) + 1

        // Sum refunds
        if (cancellation.refund_amount) {
          stats.refundTotal += cancellation.refund_amount
        }
      })

      return stats
    } catch (error) {
      console.error("❌ Erro ao calcular estatísticas de cancelamento:", error)
      return { total: 0, byReason: {}, byCategory: {}, refundTotal: 0 }
    }
  }

  /**
   * Check if an appointment can be cancelled
   */
  static canCancelAppointment(appointment: AgendamentoCompleto): {
    canCancel: boolean
    reason?: string
  } {
    if (appointment.status === "concluido") {
      return {
        canCancel: false,
        reason: "Não é possível cancelar um agendamento já concluído",
      }
    }

    if (appointment.status === "cancelado") {
      return {
        canCancel: false,
        reason: "Este agendamento já foi cancelado",
      }
    }

    // Check if appointment is too close to start time
    const appointmentDateTime = new Date(`${appointment.data_agendada}T${appointment.hora_agendada}`)
    const now = new Date()
    const timeDiff = appointmentDateTime.getTime() - now.getTime()
    const hoursUntilAppointment = timeDiff / (1000 * 60 * 60)

    if (hoursUntilAppointment < 2 && appointment.status === "em_andamento") {
      return {
        canCancel: false,
        reason: "Não é possível cancelar um agendamento que já está em andamento",
      }
    }

    return { canCancel: true }
  }
}
