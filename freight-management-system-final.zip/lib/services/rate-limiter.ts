// Sistema de Rate Limiting Inteligente
export class RateLimiter {
  private requests: number[] = []
  private readonly maxRequests: number
  private readonly windowMs: number
  private readonly cooldownMs: number
  private isInCooldown = false
  private cooldownUntil = 0

  constructor(maxRequests = 10, windowMs = 60000, cooldownMs = 30000) {
    this.maxRequests = maxRequests
    this.windowMs = windowMs
    this.cooldownMs = cooldownMs
  }

  canMakeRequest(): { allowed: boolean; waitTime?: number; reason?: string } {
    const now = Date.now()

    // Verificar se está em cooldown
    if (this.isInCooldown && now < this.cooldownUntil) {
      return {
        allowed: false,
        waitTime: this.cooldownUntil - now,
        reason: "Em período de cooldown",
      }
    }

    // Sair do cooldown se o tempo passou
    if (this.isInCooldown && now >= this.cooldownUntil) {
      this.isInCooldown = false
      this.cooldownUntil = 0
      this.requests = [] // Limpar histórico após cooldown
    }

    // Limpar requisições antigas
    this.requests = this.requests.filter((time) => now - time < this.windowMs)

    // Verificar limite
    if (this.requests.length >= this.maxRequests) {
      // Entrar em cooldown
      this.isInCooldown = true
      this.cooldownUntil = now + this.cooldownMs

      return {
        allowed: false,
        waitTime: this.cooldownMs,
        reason: "Limite de requisições atingido",
      }
    }

    return { allowed: true }
  }

  recordRequest(): void {
    if (!this.isInCooldown) {
      this.requests.push(Date.now())
    }
  }

  getRemainingRequests(): number {
    if (this.isInCooldown) return 0
    return Math.max(0, this.maxRequests - this.requests.length)
  }

  getResetTime(): number {
    if (this.isInCooldown) return this.cooldownUntil
    if (this.requests.length === 0) return 0
    return this.requests[0] + this.windowMs
  }

  reset(): void {
    this.requests = []
    this.isInCooldown = false
    this.cooldownUntil = 0
  }
}

// Rate Limiter Global
export const globalRateLimiter = new RateLimiter(8, 60000, 45000) // 8 req/min, cooldown 45s
