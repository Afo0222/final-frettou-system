import { supabase } from "@/lib/supabase/client"
import type { AgendamentoCompleto } from "./agendamentos-integrado"

export interface CancellationData {
  reason: string
  notes?: string
  cancelledBy: string
  preserveData?: boolean
}

export interface CancellationResult {
  success: boolean
  appointment: AgendamentoCompleto
  freedTimeSlot: {
    date: string
    time: string
    driverName: string
  }
  message: string
}

export interface ScheduleAvailability {
  date: string
  timeSlots: Array<{
    time: string
    available: boolean
    appointmentId?: string
    clientName?: string
  }>
}

export interface ConflictCheck {
  hasConflict: boolean
  conflictingAppointments: Array<{
    id: string
    clientName: string
    time: string
    status: string
  }>
}

export class AppointmentCancellationService {
  /**
   * Cancel an appointment with full data preservation and schedule liberation
   */
  static async cancelAppointment(
    appointmentId: string,
    cancellationData: CancellationData,
  ): Promise<CancellationResult> {
    try {
      console.log(`🔄 Starting cancellation process for appointment ${appointmentId}`)

      // 1. Get current appointment data
      const { data: currentAppointment, error: fetchError } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("id", appointmentId)
        .single()

      if (fetchError || !currentAppointment) {
        throw new Error("Appointment not found")
      }

      // 2. Validate cancellation eligibility
      if (currentAppointment.status === "cancelado") {
        throw new Error("Appointment is already cancelled")
      }

      if (currentAppointment.status === "concluido") {
        throw new Error("Cannot cancel a completed appointment")
      }

      // 3. Prepare cancellation update
      const cancellationUpdate = {
        status: "cancelado",
        cancelled_at: new Date().toISOString(),
        cancelled_by: cancellationData.cancelledBy,
        cancellation_reason: cancellationData.reason,
        cancellation_notes: cancellationData.notes || null,
        original_status: currentAppointment.status,
        updated_at: new Date().toISOString(),
        // Preserve original data in observacoes
        observacoes: this.buildCancellationObservations(currentAppointment, cancellationData),
      }

      // 4. Update appointment status
      const { data: updatedAppointment, error: updateError } = await supabase
        .from("agendamentos")
        .update(cancellationUpdate)
        .eq("id", appointmentId)
        .select("*")
        .single()

      if (updateError) {
        throw new Error(`Failed to update appointment: ${updateError.message}`)
      }

      // 5. Log cancellation for audit trail
      await this.logCancellation(appointmentId, currentAppointment, cancellationData)

      // 6. Prepare freed time slot information
      const freedTimeSlot = {
        date: currentAppointment.data_agendada,
        time: currentAppointment.hora_agendada,
        driverName: currentAppointment.motorista_nome || "Unknown Driver",
      }

      console.log(`✅ Appointment cancelled successfully`)
      console.log(`📅 Freed time slot: ${freedTimeSlot.date} at ${freedTimeSlot.time} for ${freedTimeSlot.driverName}`)

      return {
        success: true,
        appointment: updatedAppointment as AgendamentoCompleto,
        freedTimeSlot,
        message: "Appointment cancelled successfully. Time slot is now available for new bookings.",
      }
    } catch (error) {
      console.error("❌ Cancellation failed:", error)
      throw error
    }
  }

  /**
   * Check schedule availability for a specific driver and date
   */
  static async checkScheduleAvailability(
    driverName: string,
    date: string,
    startTime = "08:00",
    endTime = "18:00",
    intervalMinutes = 60,
  ): Promise<ScheduleAvailability> {
    try {
      const timeSlots: Array<{
        time: string
        available: boolean
        appointmentId?: string
        clientName?: string
      }> = []

      // Generate time slots
      const start = new Date(`2000-01-01T${startTime}:00`)
      const end = new Date(`2000-01-01T${endTime}:00`)
      const interval = intervalMinutes * 60 * 1000 // Convert to milliseconds

      for (let time = start.getTime(); time < end.getTime(); time += interval) {
        const slotTime = new Date(time).toTimeString().slice(0, 5)

        // Check if slot is occupied by non-cancelled appointment
        const { data: existingAppointment } = await supabase
          .from("agendamentos")
          .select("id, cliente_nome, status")
          .eq("motorista_nome", driverName)
          .eq("data_agendada", date)
          .eq("hora_agendada", slotTime)
          .neq("status", "cancelado")
          .single()

        timeSlots.push({
          time: slotTime,
          available: !existingAppointment,
          appointmentId: existingAppointment?.id,
          clientName: existingAppointment?.cliente_nome,
        })
      }

      return {
        date,
        timeSlots,
      }
    } catch (error) {
      console.error("Error checking schedule availability:", error)
      throw error
    }
  }

  /**
   * Check for scheduling conflicts
   */
  static async checkScheduleConflicts(
    driverName: string,
    date: string,
    time: string,
    durationMinutes = 60,
    excludeAppointmentId?: string,
  ): Promise<ConflictCheck> {
    try {
      // Calculate time range
      const startTime = new Date(`2000-01-01T${time}:00`)
      const endTime = new Date(startTime.getTime() + durationMinutes * 60 * 1000)

      // Query for conflicting appointments
      let query = supabase
        .from("agendamentos")
        .select("id, cliente_nome, hora_agendada, status")
        .eq("motorista_nome", driverName)
        .eq("data_agendada", date)
        .neq("status", "cancelado")

      if (excludeAppointmentId) {
        query = query.neq("id", excludeAppointmentId)
      }

      const { data: appointments, error } = await query

      if (error) {
        throw error
      }

      // Check for time overlaps
      const conflictingAppointments = (appointments || []).filter((apt) => {
        const aptTime = new Date(`2000-01-01T${apt.hora_agendada}:00`)
        const aptEndTime = new Date(aptTime.getTime() + 60 * 60 * 1000) // Assume 1 hour duration

        // Check if times overlap
        return (
          (startTime < aptEndTime && endTime > aptTime) || // New appointment overlaps existing
          (aptTime < endTime && aptEndTime > startTime) // Existing overlaps new
        )
      })

      return {
        hasConflict: conflictingAppointments.length > 0,
        conflictingAppointments: conflictingAppointments.map((apt) => ({
          id: apt.id,
          clientName: apt.cliente_nome,
          time: apt.hora_agendada,
          status: apt.status,
        })),
      }
    } catch (error) {
      console.error("Error checking schedule conflicts:", error)
      throw error
    }
  }

  /**
   * Get cancelled appointments for historical tracking
   */
  static async getCancelledAppointments(filters?: {
    driverName?: string
    dateFrom?: string
    dateTo?: string
    reason?: string
  }): Promise<AgendamentoCompleto[]> {
    try {
      let query = supabase
        .from("agendamentos")
        .select("*")
        .eq("status", "cancelado")
        .order("cancelled_at", { ascending: false })

      if (filters?.driverName) {
        query = query.eq("motorista_nome", filters.driverName)
      }

      if (filters?.dateFrom) {
        query = query.gte("data_agendada", filters.dateFrom)
      }

      if (filters?.dateTo) {
        query = query.lte("data_agendada", filters.dateTo)
      }

      if (filters?.reason) {
        query = query.ilike("cancellation_reason", `%${filters.reason}%`)
      }

      const { data, error } = await query

      if (error) {
        throw error
      }

      return data || []
    } catch (error) {
      console.error("Error fetching cancelled appointments:", error)
      throw error
    }
  }

  /**
   * Restore a cancelled appointment (if needed)
   */
  static async restoreAppointment(appointmentId: string, restoredBy: string): Promise<AgendamentoCompleto> {
    try {
      const { data: appointment, error: fetchError } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("id", appointmentId)
        .single()

      if (fetchError || !appointment) {
        throw new Error("Appointment not found")
      }

      if (appointment.status !== "cancelado") {
        throw new Error("Only cancelled appointments can be restored")
      }

      // Check if time slot is still available
      const conflicts = await this.checkScheduleConflicts(
        appointment.motorista_nome,
        appointment.data_agendada,
        appointment.hora_agendada,
        60,
        appointmentId,
      )

      if (conflicts.hasConflict) {
        throw new Error("Cannot restore: time slot is no longer available")
      }

      // Restore to original status
      const { data: restoredAppointment, error: updateError } = await supabase
        .from("agendamentos")
        .update({
          status: appointment.original_status || "agendado",
          cancelled_at: null,
          cancelled_by: null,
          cancellation_reason: null,
          cancellation_notes: null,
          original_status: null,
          updated_at: new Date().toISOString(),
          observacoes: `${appointment.observacoes || ""}\n\n--- RESTAURADO ---\nData: ${new Date().toLocaleString("pt-BR")}\nRestaurado por: ${restoredBy}`,
        })
        .eq("id", appointmentId)
        .select("*")
        .single()

      if (updateError) {
        throw updateError
      }

      return restoredAppointment as AgendamentoCompleto
    } catch (error) {
      console.error("Error restoring appointment:", error)
      throw error
    }
  }

  /**
   * Build comprehensive cancellation observations
   */
  private static buildCancellationObservations(appointment: any, cancellationData: CancellationData): string {
    const originalObs = appointment.observacoes || ""
    const timestamp = new Date().toLocaleString("pt-BR")

    const cancellationInfo = [
      "\n\n--- AGENDAMENTO CANCELADO ---",
      `Data do cancelamento: ${timestamp}`,
      `Cancelado por: ${cancellationData.cancelledBy}`,
      `Motivo: ${cancellationData.reason}`,
      `Status original: ${appointment.status}`,
    ]

    if (cancellationData.notes) {
      cancellationInfo.push(`Observações: ${cancellationData.notes}`)
    }

    cancellationInfo.push(`Horário liberado: ${appointment.data_agendada} às ${appointment.hora_agendada}`)

    return originalObs + cancellationInfo.join("\n")
  }

  /**
   * Log cancellation for audit trail
   */
  private static async logCancellation(
    appointmentId: string,
    appointment: any,
    cancellationData: CancellationData,
  ): Promise<void> {
    try {
      // This could be expanded to write to a separate audit log table
      console.log("📝 Logging cancellation:", {
        appointmentId,
        clientName: appointment.cliente_nome,
        originalStatus: appointment.status,
        cancelledBy: cancellationData.cancelledBy,
        reason: cancellationData.reason,
        freedSlot: `${appointment.data_agendada} ${appointment.hora_agendada}`,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.warn("Failed to log cancellation:", error)
      // Don't throw error as this is not critical
    }
  }
}
