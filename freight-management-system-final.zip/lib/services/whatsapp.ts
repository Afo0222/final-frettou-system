interface MessageData {
  nomeMotorista: string
  nomeEmpresa: string
  enderecoRetirada: string
  enderecoEntrega: string
  tipoServico: string
  tempoEstimado?: number
  atraso?: number
}

export class WhatsAppService {
  static sendMessage(phoneNumber: string | null | undefined, message: string) {
    // Validação de entrada
    if (!phoneNumber || typeof phoneNumber !== "string") {
      console.warn("Número de telefone inválido:", phoneNumber)
      throw new Error("Número de telefone é obrigatório")
    }

    if (!message || typeof message !== "string") {
      console.warn("Mensagem inválida:", message)
      throw new Error("Mensagem é obrigatória")
    }

    try {
      // Limpar o número de telefone
      const cleanPhone = phoneNumber.replace(/\D/g, "")

      // Validar se o número tem pelo menos 10 dígitos
      if (cleanPhone.length < 10) {
        throw new Error("Número de telefone deve ter pelo menos 10 dígitos")
      }

      // Codificar a mensagem
      const encodedMessage = encodeURIComponent(message)

      // Construir URL do WhatsApp
      const url = `https://wa.me/55${cleanPhone}?text=${encodedMessage}`

      // Abrir WhatsApp
      window.open(url, "_blank")
    } catch (error) {
      console.error("Erro ao enviar mensagem WhatsApp:", error)
      throw error
    }
  }

  static getChegandoRetiradaMessage(data: MessageData): string {
    return `Oi! Sou ${data.nomeMotorista} da ${data.nomeEmpresa}. Já estou chegando no endereço ${data.enderecoRetirada} para a ${data.tipoServico}. Estarei aí em aproximadamente ${data.tempoEstimado || 5} minutos!`
  }

  static getChegandoEntregaMessage(data: MessageData): string {
    return `Olá! Estou chegando no endereço ${data.enderecoEntrega} para entrega da sua ${data.tipoServico}. Estarei aí em breve!`
  }

  static getAtrasoMessage(data: MessageData): string {
    return `Olá! Devido ao trânsito, vou me atrasar aproximadamente ${data.atraso || 15} minutos. Peço desculpas pelo inconveniente!`
  }

  static getInicioColetaMessage(data: MessageData): string {
    return `Olá! Acabei de chegar no endereço ${data.enderecoRetirada} e estou iniciando a coleta da sua ${data.tipoServico}. Em breve seguiremos para a entrega!`
  }

  static getSaindoParaEntregaMessage(data: MessageData): string {
    return `Oi! Coleta finalizada com sucesso! Estou saindo agora para a entrega no endereço ${data.enderecoEntrega}. Previsão de chegada em aproximadamente ${data.tempoEstimado || 30} minutos.`
  }

  static getEntregaConcluidaMessage(data: MessageData): string {
    return `Entrega da sua ${data.tipoServico} concluída com sucesso! Obrigado por escolher a ${data.nomeEmpresa}. Esperamos atendê-lo novamente em breve!`
  }
}
