import { createClient } from "@/lib/supabase/client"
import type { TipoServico } from "@/lib/types/database"
import { ErrorHandler } from "@/lib/error-handler"

export class TipoServicoService {
  static async getAll(): Promise<TipoServico[]> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("tipos_servico").select("*").order("nome", { ascending: true }),
      "Erro ao buscar tipos de servico",
    )

    if (error || !data) {
      return []
    }

    return data.data as TipoServico[]
  }

  static async getById(id: string): Promise<TipoServico | null> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("tipos_servico").select("*").eq("id", id).single(),
      `Erro ao buscar tipo de servico com ID ${id}`,
    )

    if (error || !data) {
      return null
    }

    return data.data as TipoServico
  }

  static async create(tipoServico: Partial<TipoServico>): Promise<TipoServico> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("tipos_servico").insert([tipoServico]).select().single(),
      "Erro ao criar tipo de servico",
    )

    if (error || !data) {
      throw new Error("Falha ao criar tipo de servico")
    }

    return data.data as TipoServico
  }

  static async update(id: string, tipoServico: Partial<TipoServico>): Promise<TipoServico> {
    const supabase = createClient()

    const [data, error] = await ErrorHandler.handle(
      supabase.from("tipos_servico").update(tipoServico).eq("id", id).select().single(),
      `Erro ao atualizar tipo de servico com ID ${id}`,
    )

    if (error || !data) {
      throw new Error("Falha ao atualizar tipo de servico")
    }

    return data.data as TipoServico
  }

  static async delete(id: string): Promise<boolean> {
    const supabase = createClient()

    const [_, error] = await ErrorHandler.handle(
      supabase.from("tipos_servico").delete().eq("id", id),
      `Erro ao excluir tipo de servico com ID ${id}`,
    )

    return !error
  }
}
