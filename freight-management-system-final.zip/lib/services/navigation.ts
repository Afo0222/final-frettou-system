export class NavigationService {
  static openGoogleMaps(address: string) {
    const encodedAddress = encodeURIComponent(address)
    const url = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`
    window.open(url, "_blank")
  }

  static openGoogleMapsWithWaypoints(origin: string, destination: string) {
    const encodedOrigin = encodeURIComponent(origin)
    const encodedDestination = encodeURIComponent(destination)
    const url = `https://www.google.com/maps/dir/?api=1&origin=${encodedOrigin}&destination=${encodedDestination}&travelmode=driving`
    window.open(url, "_blank")
  }

  static openGoogleMapsFromCurrentLocation(destination: string) {
    const encodedDestination = encodeURIComponent(destination)
    const url = `https://www.google.com/maps/dir/?api=1&destination=${encodedDestination}&travelmode=driving`
    window.open(url, "_blank")
  }

  static makePhoneCall(phoneNumber: string) {
    window.location.href = `tel:${phoneNumber}`
  }
}
