import { toast } from "@/hooks/use-toast"

export class NotificationService {
  static success(title: string, description?: string) {
    toast({
      title,
      description,
      variant: "default",
    })
  }

  static error(title: string, description?: string) {
    toast({
      title,
      description,
      variant: "destructive",
    })
  }

  static warning(title: string, description?: string) {
    toast({
      title,
      description,
      variant: "warning",
    })
  }

  static info(title: string, description?: string) {
    toast({
      title,
      description,
      variant: "info",
    })
  }
}
