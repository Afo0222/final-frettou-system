import { supabase } from "@/lib/supabase/client"

export interface RotaMotorista {
  id: string
  cliente_nome: string
  cliente_telefone: string
  tipo_servico: string
  endereco_origem: string
  endereco_destino: string
  data_agendada: string
  hora_agendada: string
  hora_inicio?: string
  hora_fim?: string
  status: string
  valor_servico?: number
  observacoes?: string
  distancia_km?: number
  tempo_viagem_minutos?: number
  duracao_estimada_minutos?: number
  motorista_id: string
  veiculo_id?: string
}

export class MotoristaRotasService {
  static async buscarRotasPorMotorista(motoristaId: string): Promise<RotaMotorista[]> {
    try {
      const { data, error } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("motorista_id", motoristaId)
        .order("data_agendada", { ascending: true })
        .order("hora_agendada", { ascending: true })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Erro ao buscar rotas do motorista:", error)
      throw error
    }
  }

  static async atualizarStatusRota(
    rotaId: string,
    novoStatus: string,
    horaInicio?: string,
    horaFim?: string,
  ): Promise<void> {
    try {
      const updateData: any = {
        status: novoStatus,
        updated_at: new Date().toISOString(),
      }

      if (horaInicio) {
        updateData.hora_inicio = horaInicio
      }

      if (horaFim) {
        updateData.hora_fim = horaFim
      }

      const { error } = await supabase.from("agendamentos").update(updateData).eq("id", rotaId)

      if (error) throw error
    } catch (error) {
      console.error("Erro ao atualizar status da rota:", error)
      throw error
    }
  }

  static async buscarRotasPorStatus(motoristaId: string, status: string[]): Promise<RotaMotorista[]> {
    try {
      const { data, error } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("motorista_id", motoristaId)
        .in("status", status)
        .order("data_agendada", { ascending: true })
        .order("hora_agendada", { ascending: true })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Erro ao buscar rotas por status:", error)
      throw error
    }
  }

  static async buscarRotasHoje(motoristaId: string): Promise<RotaMotorista[]> {
    try {
      const hoje = new Date().toISOString().split("T")[0]

      const { data, error } = await supabase
        .from("agendamentos")
        .select("*")
        .eq("motorista_id", motoristaId)
        .eq("data_agendada", hoje)
        .order("hora_agendada", { ascending: true })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Erro ao buscar rotas de hoje:", error)
      throw error
    }
  }

  static async verificarConflitosHorario(
    motoristaId: string,
    data: string,
    horaInicio: string,
    horaFim: string,
    rotaIdExcluir?: string,
  ): Promise<boolean> {
    try {
      let query = supabase
        .from("agendamentos")
        .select("id")
        .eq("motorista_id", motoristaId)
        .eq("data_agendada", data)
        .neq("status", "cancelado")
        .or(`and(hora_agendada.lte.${horaFim},hora_fim.gte.${horaInicio})`)

      if (rotaIdExcluir) {
        query = query.neq("id", rotaIdExcluir)
      }

      const { data: conflitos, error } = await query

      if (error) throw error
      return (conflitos?.length || 0) > 0
    } catch (error) {
      console.error("Erro ao verificar conflitos de horário:", error)
      return false
    }
  }
}
