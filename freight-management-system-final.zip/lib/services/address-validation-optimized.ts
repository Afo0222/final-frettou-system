import type { Address, Coordinates } from "./google-maps"

export interface AddressValidationResult {
  isValid: boolean
  confidence: "high" | "medium" | "low"
  originalAddress: string
  validatedAddress?: string
  coordinates?: Coordinates
  components?: {
    street_number?: string
    route?: string
    neighborhood?: string
    city?: string
    state?: string
    postal_code?: string
    country?: string
  }
  suggestions?: string[]
  warnings?: string[]
  errors?: string[]
}

export interface AddressSuggestion {
  address: string
  confidence: number
  type: "exact" | "partial" | "approximate"
  components: Address
}

// Request queue para evitar requisicoes concorrentes
class RequestQueue {
  private queue: Map<string, Promise<any>> = new Map()
  private cache: Map<string, { data: any; timestamp: number }> = new Map()
  private readonly CACHE_DURATION = 30 * 60 * 1000 // 30 minutos

  async execute<T>(key: string, requestFn: () => Promise<T>): Promise<T> {
    // Verificar cache primeiro
    const cached = this.getFromCache(key)
    if (cached) return cached

    // Se ja existe uma requisicao em andamento para esta chave, retornar a Promise existente
    if (this.queue.has(key)) {
      return this.queue.get(key)!
    }

    // Criar nova requisicao
    const promise = requestFn()
      .then((result) => {
        this.setCache(key, result)
        return result
      })
      .finally(() => {
        this.queue.delete(key)
      })

    this.queue.set(key, promise)
    return promise
  }

  private getFromCache(key: string): any {
    const cached = this.cache.get(key)
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      return cached.data
    }
    this.cache.delete(key)
    return null
  }

  private setCache(key: string, data: any): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    })
  }

  clearCache(): void {
    this.cache.clear()
    this.queue.clear()
  }
}

// Throttle para limitar frequencia de requisicoes
class RequestThrottle {
  private lastRequestTime = 0
  private readonly MIN_INTERVAL = 500 // 500ms entre requisicoes

  async throttle<T>(requestFn: () => Promise<T>): Promise<T> {
    const now = Date.now()
    const timeSinceLastRequest = now - this.lastRequestTime

    if (timeSinceLastRequest < this.MIN_INTERVAL) {
      await new Promise((resolve) => setTimeout(resolve, this.MIN_INTERVAL - timeSinceLastRequest))
    }

    this.lastRequestTime = Date.now()
    return requestFn()
  }
}

export class OptimizedAddressValidationService {
  private static readonly MIN_ADDRESS_LENGTH = 10
  private static readonly MAX_RETRIES = 2
  private static readonly RETRY_DELAY = 1000 // 1 segundo
  private static readonly requestQueue = new RequestQueue()
  private static readonly requestThrottle = new RequestThrottle()

  // Validar endereco completo
  static async validateAddress(address: string): Promise<AddressValidationResult> {
    return this.requestQueue.execute(`validate:${address}`, async () => {
      // Validacoes basicas
      const basicValidation = this.performBasicValidation(address)
      if (!basicValidation.isValid) return basicValidation

      try {
        // Usar Google Maps para validacao
        if (this.isGoogleMapsConfigured()) {
          return await this.validateWithGoogleMaps(address)
        }

        // Fallback para validacao offline
        return this.validateOffline(address)
      } catch (error) {
        console.error("Erro na validacao de endereco:", error)
        // Retornar validacao offline em caso de erro
        const offlineResult = this.validateOffline(address)
        offlineResult.warnings = [...(offlineResult.warnings || []), "Validacao online indisponivel"]
        return offlineResult
      }
    })
  }

  // Verificar se Google Maps esta configurado
  private static isGoogleMapsConfigured(): boolean {
    return typeof window !== "undefined" && !!process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
  }

  // Validacao com Google Maps via API route com retries
  private static async validateWithGoogleMaps(address: string, retryCount = 0): Promise<AddressValidationResult> {
    return this.requestThrottle.throttle(async () => {
      try {
        const response = await fetch(`/api/maps/geocode?address=${encodeURIComponent(address)}`)

        if (!response.ok) {
          throw new Error(`API error: ${response.status}`)
        }

        const data = await response.json()

        if (data.error) {
          if (retryCount < this.MAX_RETRIES && ["OVER_QUERY_LIMIT", "UNKNOWN_ERROR"].includes(data.status)) {
            await new Promise((resolve) => setTimeout(resolve, this.RETRY_DELAY))
            return this.validateWithGoogleMaps(address, retryCount + 1)
          }

          return this.validateOffline(address)
        }

        if (data.status !== "OK" || !data.results || data.results.length === 0) {
          return {
            isValid: false,
            confidence: "low",
            originalAddress: address,
            errors: [data.status === "ZERO_RESULTS" ? "Endereco nao encontrado" : `Erro na API: ${data.status}`],
            suggestions: await this.generateSuggestions(address),
          }
        }

        const result = data.results[0]
        const geocoded = this.parseGeocodingResult(result)

        const confidence = this.calculateConfidence(address, geocoded.formatted_address)
        const missingComponents = this.checkRequiredComponents(geocoded)

        return {
          isValid: confidence !== "low" && missingComponents.length === 0,
          confidence,
          originalAddress: address,
          validatedAddress: geocoded.formatted_address,
          coordinates: geocoded.coordinates,
          components: {
            street_number: geocoded.street_number,
            route: geocoded.route,
            neighborhood: geocoded.neighborhood,
            city: geocoded.city,
            state: geocoded.state,
            postal_code: geocoded.postal_code,
            country: geocoded.country,
          },
          warnings:
            missingComponents.length > 0 ? [`Componentes faltando: ${missingComponents.join(", ")}`] : undefined,
          suggestions: confidence === "low" ? [geocoded.formatted_address] : undefined,
        }
      } catch (error) {
        console.error("Erro na validacao com Google Maps:", error)
        if (retryCount < this.MAX_RETRIES) {
          await new Promise((resolve) => setTimeout(resolve, this.RETRY_DELAY))
          return this.validateWithGoogleMaps(address, retryCount + 1)
        }

        return this.validateOffline(address)
      }
    })
  }

  // Converter resultado da geocodificacao para formato interno
  private static parseGeocodingResult(result: any): Address {
    const components: { [key: string]: string } = {}

    result.address_components?.forEach((component: any) => {
      const types = component.types
      if (types.includes("street_number")) {
        components.street_number = component.long_name
      }
      if (types.includes("route")) {
        components.route = component.long_name
      }
      if (types.includes("sublocality") || types.includes("neighborhood")) {
        components.neighborhood = component.long_name
      }
      if (types.includes("locality") || types.includes("administrative_area_level_2")) {
        components.city = component.long_name
      }
      if (types.includes("administrative_area_level_1")) {
        components.state = component.short_name
      }
      if (types.includes("postal_code")) {
        components.postal_code = component.long_name
      }
      if (types.includes("country")) {
        components.country = component.long_name
      }
    })

    return {
      formatted_address: result.formatted_address,
      coordinates: {
        lat: result.geometry.location.lat,
        lng: result.geometry.location.lng,
      },
      street_number: components.street_number,
      route: components.route,
      neighborhood: components.neighborhood,
      city: components.city,
      state: components.state,
      postal_code: components.postal_code,
      country: components.country,
    }
  }

  // Validacao offline (fallback)
  private static validateOffline(address: string): AddressValidationResult {
    const patterns = {
      cep: /\d{5}-?\d{3}/,
      numero: /\d+/,
      estado: /(AC|AL|AP|AM|BA|CE|DF|ES|GO|MA|MT|MS|MG|PA|PB|PR|PE|PI|RJ|RN|RS|RO|RR|SC|SP|SE|TO)/i,
    }

    const warnings: string[] = []
    const suggestions: string[] = []

    // Verificar CEP
    if (!patterns.cep.test(address)) {
      warnings.push("CEP nao encontrado ou invalido")
    }

    // Verificar numero
    if (!patterns.numero.test(address)) {
      warnings.push("Numero do endereco nao encontrado")
    }

    // Verificar estado
    if (!patterns.estado.test(address)) {
      warnings.push("Estado nao identificado")
    }

    // Sugerir melhorias
    if (address.length < 30) {
      suggestions.push("Inclua mais detalhes como bairro, cidade e CEP")
    }

    return {
      isValid: warnings.length === 0,
      confidence: warnings.length === 0 ? "medium" : "low",
      originalAddress: address,
      validatedAddress: address,
      warnings: warnings.length > 0 ? warnings : undefined,
      suggestions: suggestions.length > 0 ? suggestions : undefined,
    }
  }

  // Validacoes basicas
  private static performBasicValidation(address: string): AddressValidationResult {
    const trimmed = address.trim()

    if (!trimmed) {
      return {
        isValid: false,
        confidence: "low",
        originalAddress: address,
        errors: ["Endereco e obrigatorio"],
      }
    }

    if (trimmed.length < this.MIN_ADDRESS_LENGTH) {
      return {
        isValid: false,
        confidence: "low",
        originalAddress: address,
        errors: ["Endereco muito curto. Inclua rua, numero, bairro e cidade"],
      }
    }

    return {
      isValid: true,
      confidence: "medium",
      originalAddress: address,
    }
  }

  // Calcular confianca baseada na similaridade
  private static calculateConfidence(original: string, validated: string): "high" | "medium" | "low" {
    const similarity = this.calculateSimilarity(original.toLowerCase(), validated.toLowerCase())

    if (similarity > 0.8) return "high"
    if (similarity > 0.5) return "medium"
    return "low"
  }

  // Calcular similaridade entre strings
  private static calculateSimilarity(str1: string, str2: string): number {
    const normalize = (str: string) =>
      str
        .replace(/[^\w\s]/g, "")
        .replace(/\s+/g, " ")
        .trim()

    const words1 = normalize(str1).split(" ")
    const words2 = normalize(str2).split(" ")

    const intersection = words1.filter((word) => words2.some((w) => w.includes(word) || word.includes(w)))
    const union = [...new Set([...words1, ...words2])]

    return intersection.length / union.length
  }

  // Verificar componentes obrigatorios
  private static checkRequiredComponents(address: Address): string[] {
    const missing: string[] = []

    if (!address.route && !address.street_number) {
      missing.push("rua/logradouro")
    }

    if (!address.city) {
      missing.push("cidade")
    }

    if (!address.state) {
      missing.push("estado")
    }

    return missing
  }

  // Gerar sugestoes baseadas no endereco
  private static async generateSuggestions(address: string): Promise<string[]> {
    const suggestions: string[] = []

    // Sugestoes baseadas em padroes comuns
    const words = address.toLowerCase().split(/\s+/)

    // Verificar se tem CEP
    if (!words.some((word) => /\d{5}-?\d{3}/.test(word))) {
      suggestions.push("Inclua o CEP para maior precisao")
    }

    // Verificar se tem numero
    if (!words.some((word) => /^\d+$/.test(word))) {
      suggestions.push("Inclua o numero do endereco")
    }

    // Verificar se tem cidade
    const commonCities = ["sao paulo", "rio de janeiro", "belo horizonte", "brasilia", "salvador"]
    if (!commonCities.some((city) => address.toLowerCase().includes(city))) {
      suggestions.push("Inclua o nome da cidade")
    }

    return suggestions
  }

  // Limpar cache
  static clearCache(): void {
    this.requestQueue.clearCache()
  }
}
