interface OfflineData {
  id: string
  type: "orcamento" | "agendamento" | "cliente"
  data: any
  timestamp: number
  synced: boolean
}

class OfflineStorageService {
  private dbName = "FreteSystemOffline"
  private version = 1
  private db: IDBDatabase | null = null

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version)

      request.onerror = () => reject(request.error)
      request.onsuccess = () => {
        this.db = request.result
        resolve()
      }

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result

        // Create object stores
        if (!db.objectStoreNames.contains("offlineData")) {
          const store = db.createObjectStore("offlineData", { keyPath: "id" })
          store.createIndex("type", "type", { unique: false })
          store.createIndex("timestamp", "timestamp", { unique: false })
          store.createIndex("synced", "synced", { unique: false })
        }

        if (!db.objectStoreNames.contains("cachedData")) {
          const cacheStore = db.createObjectStore("cachedData", { keyPath: "key" })
          cacheStore.createIndex("timestamp", "timestamp", { unique: false })
        }
      }
    })
  }

  async saveOfflineData(type: OfflineData["type"], data: any): Promise<string> {
    if (!this.db) await this.init()

    const id = `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const offlineData: OfflineData = {
      id,
      type,
      data,
      timestamp: Date.now(),
      synced: false,
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["offlineData"], "readwrite")
      const store = transaction.objectStore("offlineData")
      const request = store.add(offlineData)

      request.onsuccess = () => resolve(id)
      request.onerror = () => reject(request.error)
    })
  }

  async getOfflineData(type?: OfflineData["type"]): Promise<OfflineData[]> {
    if (!this.db) await this.init()

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["offlineData"], "readonly")
      const store = transaction.objectStore("offlineData")

      let request: IDBRequest
      if (type) {
        const index = store.index("type")
        request = index.getAll(type)
      } else {
        request = store.getAll()
      }

      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  }

  async markAsSynced(id: string): Promise<void> {
    if (!this.db) await this.init()

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["offlineData"], "readwrite")
      const store = transaction.objectStore("offlineData")
      const getRequest = store.get(id)

      getRequest.onsuccess = () => {
        const data = getRequest.result
        if (data) {
          data.synced = true
          const updateRequest = store.put(data)
          updateRequest.onsuccess = () => resolve()
          updateRequest.onerror = () => reject(updateRequest.error)
        } else {
          resolve()
        }
      }
      getRequest.onerror = () => reject(getRequest.error)
    })
  }

  async clearSyncedData(): Promise<void> {
    if (!this.db) await this.init()

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["offlineData"], "readwrite")
      const store = transaction.objectStore("offlineData")
      const index = store.index("synced")
      const request = index.openCursor(IDBKeyRange.only(true))

      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result
        if (cursor) {
          cursor.delete()
          cursor.continue()
        } else {
          resolve()
        }
      }
      request.onerror = () => reject(request.error)
    })
  }

  async cacheData(key: string, data: any, ttl = 3600000): Promise<void> {
    if (!this.db) await this.init()

    const cachedItem = {
      key,
      data,
      timestamp: Date.now(),
      ttl,
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["cachedData"], "readwrite")
      const store = transaction.objectStore("cachedData")
      const request = store.put(cachedItem)

      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  async getCachedData(key: string): Promise<any | null> {
    if (!this.db) await this.init()

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["cachedData"], "readonly")
      const store = transaction.objectStore("cachedData")
      const request = store.get(key)

      request.onsuccess = () => {
        const result = request.result
        if (result) {
          const now = Date.now()
          if (now - result.timestamp < result.ttl) {
            resolve(result.data)
          } else {
            // Data expired, remove it
            this.removeCachedData(key)
            resolve(null)
          }
        } else {
          resolve(null)
        }
      }
      request.onerror = () => reject(request.error)
    })
  }

  async removeCachedData(key: string): Promise<void> {
    if (!this.db) await this.init()

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["cachedData"], "readwrite")
      const store = transaction.objectStore("cachedData")
      const request = store.delete(key)

      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  async clearExpiredCache(): Promise<void> {
    if (!this.db) await this.init()

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(["cachedData"], "readwrite")
      const store = transaction.objectStore("cachedData")
      const request = store.openCursor()
      const now = Date.now()

      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result
        if (cursor) {
          const item = cursor.value
          if (now - item.timestamp >= item.ttl) {
            cursor.delete()
          }
          cursor.continue()
        } else {
          resolve()
        }
      }
      request.onerror = () => reject(request.error)
    })
  }
}

export const offlineStorage = new OfflineStorageService()
