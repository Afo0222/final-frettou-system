import { supabase } from "@/lib/supabase/client"

export interface AgendamentoCompleto {
  id: string
  orcamento_numero?: string
  motorista_nome?: string
  veiculo_info?: string
  data_agendada: string
  hora_agendada: string
  status: "agendado" | "confirmado" | "em_andamento" | "concluido" | "cancelado" | "reagendado"
  endereco_origem?: string
  endereco_destino?: string
  observacoes?: string
  cliente_nome?: string
  cliente_telefone?: string
  valor_servico?: number
  tipo_servico?: string
  created_at: string
  updated_at: string
  motorista?: {
    id: string
    nome: string
    telefone?: string
    email?: string
  }
  veiculo?: {
    id: string
    modelo: string
    placa: string
  }
  orcamento?: {
    id: string
    numero_orcamento: string
    cliente?: {
      nome: string
      telefone?: string
    }
  }
}

export interface Motorista {
  id: string
  nome: string
  telefone?: string
  email?: string
  ativo?: boolean
  created_at: string
  updated_at: string
}

export interface Veiculo {
  id: string
  modelo: string
  placa: string
  ativo?: boolean
  created_at: string
  updated_at: string
}

export class AgendamentoIntegradoService {
  static async createFromOrcamento(orcamentoId: string): Promise<AgendamentoCompleto> {
    try {
      console.log(`🔄 Criando agendamento para orçamento ${orcamentoId}`)

      // Buscar dados completos do orçamento
      const { data: orcamento, error: orcamentoError } = await supabase
        .from("orcamentos")
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .eq("id", orcamentoId)
        .single()

      if (orcamentoError || !orcamento) {
        console.error("❌ Erro ao buscar orçamento:", orcamentoError)
        throw new Error("Orçamento não encontrado")
      }

      console.log(`📋 Orçamento encontrado: ${orcamento.numero_orcamento}`)

      // Verificar se já existe agendamento para este orçamento (usando abordagem mais segura)
      try {
        const { data: agendamentos } = await supabase
          .from("agendamentos")
          .select("id")
          .ilike("observacoes", `%${orcamento.numero_orcamento}%`)

        if (agendamentos && agendamentos.length > 0) {
          console.log(`⚠️ Agendamento já existe: ${agendamentos[0].id}`)
          throw new Error("Já existe um agendamento para este orçamento")
        }
      } catch (checkError) {
        console.warn("⚠️ Erro ao verificar agendamentos existentes, continuando...", checkError)
      }

      // Buscar dados para exibição (com fallbacks)
      let motoristaNome = "Motorista Padrão"
      let veiculoInfo = "Veículo Padrão - AAA-0000"

      try {
        const { data: motoristas } = await supabase.from("motoristas").select("nome").limit(1)
        if (motoristas && motoristas.length > 0) {
          motoristaNome = motoristas[0].nome
        }
      } catch (error) {
        console.warn("⚠️ Erro ao buscar motoristas, usando padrão")
      }

      try {
        const { data: veiculos } = await supabase.from("veiculos").select("modelo, placa").limit(1)
        if (veiculos && veiculos.length > 0) {
          veiculoInfo = `${veiculos[0].modelo} - ${veiculos[0].placa}`
        }
      } catch (error) {
        console.warn("⚠️ Erro ao buscar veículos, usando padrão")
      }

      // Definir data e hora
      const dataAgendada = orcamento.data_agendada || new Date().toISOString().split("T")[0]
      const horaAgendada = orcamento.hora_agendada || "08:00"

      console.log(`📅 Data agendada: ${dataAgendada} às ${horaAgendada}`)

      // Tentar diferentes abordagens para criar o agendamento
      let agendamentoCriado = null

      // Abordagem 1: Tentar com todos os campos
      try {
        const agendamentoCompleto = {
          orcamento_numero: orcamento.numero_orcamento,
          motorista_nome: motoristaNome,
          veiculo_info: veiculoInfo,
          data_agendada: dataAgendada,
          hora_agendada: horaAgendada,
          status: "agendado" as const,
          endereco_origem: orcamento.endereco_origem,
          endereco_destino: orcamento.endereco_destino,
          observacoes:
            `Agendamento criado automaticamente do orçamento ${orcamento.numero_orcamento}. ${orcamento.observacoes || ""}`.trim(),
          cliente_nome: orcamento.cliente?.nome,
          cliente_telefone: orcamento.cliente?.telefone,
          valor_servico: orcamento.valor_total,
          tipo_servico: orcamento.tipo_servico?.nome,
        }

        console.log(`💾 Tentativa 1: Inserindo agendamento completo`)

        const { data, error } = await supabase.from("agendamentos").insert([agendamentoCompleto]).select("*").single()

        if (!error && data) {
          agendamentoCriado = data
          console.log(`✅ Agendamento criado com sucesso (completo): ${data.id}`)
        } else {
          throw error
        }
      } catch (error1) {
        console.warn("⚠️ Tentativa 1 falhou:", error1)

        // Abordagem 2: Tentar com campos mínimos
        try {
          const agendamentoMinimo = {
            data_agendada: dataAgendada,
            hora_agendada: horaAgendada,
            status: "agendado" as const,
            cliente_nome: orcamento.cliente?.nome || "Cliente",
            observacoes: `Agendamento para orçamento ${orcamento.numero_orcamento}`,
          }

          console.log(`💾 Tentativa 2: Inserindo agendamento mínimo`)

          const { data, error } = await supabase.from("agendamentos").insert([agendamentoMinimo]).select("*").single()

          if (!error && data) {
            agendamentoCriado = data
            console.log(`✅ Agendamento criado com sucesso (mínimo): ${data.id}`)
          } else {
            throw error
          }
        } catch (error2) {
          console.warn("⚠️ Tentativa 2 falhou:", error2)

          // Abordagem 3: Tentar com apenas campos obrigatórios
          try {
            const agendamentoBasico = {
              data_agendada: dataAgendada,
              hora_agendada: horaAgendada,
            }

            console.log(`💾 Tentativa 3: Inserindo agendamento básico`)

            const { data, error } = await supabase.from("agendamentos").insert([agendamentoBasico]).select("*").single()

            if (!error && data) {
              agendamentoCriado = data
              console.log(`✅ Agendamento criado com sucesso (básico): ${data.id}`)
            } else {
              throw error
            }
          } catch (error3) {
            console.error("❌ Todas as tentativas falharam:", error3)
            throw new Error(`Falha ao criar agendamento: ${error3.message}`)
          }
        }
      }

      if (!agendamentoCriado) {
        throw new Error("Não foi possível criar o agendamento")
      }

      // Enriquecer o agendamento com dados adicionais para exibição
      return this.enriquecerAgendamento(agendamentoCriado, orcamento)
    } catch (error) {
      console.error("❌ Erro ao criar agendamento automático:", error)
      throw error
    }
  }

  // Método para enriquecer o agendamento com dados adicionais para exibição
  private static enriquecerAgendamento(agendamento: any, orcamento?: any): AgendamentoCompleto {
    // Usar dados do agendamento ou fallbacks
    const motoristaNome = agendamento.motorista_nome || "Motorista Padrão"
    const veiculoInfo = agendamento.veiculo_info || "Veículo Padrão - AAA-0000"
    const orcamentoNumero = agendamento.orcamento_numero || orcamento?.numero_orcamento || "ORC-000000"

    return {
      ...agendamento,
      motorista: {
        id: "11111111-1111-1111-1111-111111111111",
        nome: motoristaNome,
      },
      veiculo: {
        id: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        modelo: veiculoInfo.split(" - ")[0] || "Veículo Padrão",
        placa: veiculoInfo.split(" - ")[1] || "AAA-0000",
      },
      orcamento: {
        id: orcamento?.id || "00000000-0000-0000-0000-000000000000",
        numero_orcamento: orcamentoNumero,
        cliente: {
          nome: agendamento.cliente_nome || orcamento?.cliente?.nome || "Cliente",
          telefone: agendamento.cliente_telefone || orcamento?.cliente?.telefone || "",
        },
      },
    }
  }

  static async getAll(): Promise<AgendamentoCompleto[]> {
    try {
      console.log("🔄 Carregando agendamentos...")

      // Buscar todos os agendamentos com tratamento de erro
      const { data: agendamentos, error: agendamentosError } = await supabase
        .from("agendamentos")
        .select("*")
        .order("data_agendada", { ascending: true })
        .order("hora_agendada", { ascending: true })

      if (agendamentosError) {
        console.error("Erro ao buscar agendamentos:", agendamentosError)
        throw new Error(`Falha ao carregar agendamentos: ${agendamentosError.message}`)
      }

      if (!agendamentos || agendamentos.length === 0) {
        console.log("ℹ️ Nenhum agendamento encontrado")
        return []
      }

      // Enriquecer cada agendamento com dados adicionais
      const agendamentosCompletos = agendamentos.map((agendamento) => this.enriquecerAgendamento(agendamento))

      console.log(`✅ ${agendamentosCompletos.length} agendamentos carregados`)
      return agendamentosCompletos
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error)
      throw error
    }
  }

  static async getById(id: string): Promise<AgendamentoCompleto | null> {
    try {
      // Buscar agendamento
      const { data: agendamento, error } = await supabase.from("agendamentos").select("*").eq("id", id).single()

      if (error || !agendamento) {
        console.error("Erro ao buscar agendamento:", error)
        return null
      }

      // Enriquecer o agendamento com dados adicionais
      return this.enriquecerAgendamento(agendamento)
    } catch (error) {
      console.error("Erro ao buscar agendamento por ID:", error)
      return null
    }
  }

  static async updateStatus(id: string, status: string): Promise<AgendamentoCompleto> {
    try {
      const { data, error } = await supabase
        .from("agendamentos")
        .update({
          status: status as any,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select("*")
        .single()

      if (error) {
        console.error("Erro ao atualizar status:", error)
        throw new Error(`Falha ao atualizar status: ${error.message}`)
      }

      // Enriquecer o agendamento com dados adicionais
      return this.enriquecerAgendamento(data)
    } catch (error) {
      console.error("Erro ao atualizar status do agendamento:", error)
      throw error
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      console.log(`🗑️ Excluindo agendamento ${id}`)

      // Verificar se o agendamento existe antes de excluir
      const { data: existingAppointment, error: checkError } = await supabase
        .from("agendamentos")
        .select("id, status, cliente_nome")
        .eq("id", id)
        .single()

      if (checkError || !existingAppointment) {
        throw new Error("Agendamento não encontrado")
      }

      console.log(`📋 Agendamento encontrado: ${existingAppointment.cliente_nome} (${existingAppointment.status})`)

      // Excluir o agendamento
      const { error: deleteError } = await supabase.from("agendamentos").delete().eq("id", id)

      if (deleteError) {
        console.error("❌ Erro ao excluir agendamento:", deleteError)
        throw new Error(`Falha ao excluir agendamento: ${deleteError.message}`)
      }

      console.log(`✅ Agendamento excluído com sucesso: ${id}`)
    } catch (error) {
      console.error("❌ Erro ao excluir agendamento:", error)
      throw error
    }
  }

  static async getMotoristas(): Promise<Motorista[]> {
    try {
      const { data, error } = await supabase.from("motoristas").select("*").eq("ativo", true).order("nome")

      if (error) {
        console.error("Erro ao carregar motoristas:", error)
        return []
      }

      return data || []
    } catch (error) {
      console.error("Erro ao carregar motoristas:", error)
      return []
    }
  }

  static async getVeiculos(): Promise<Veiculo[]> {
    try {
      const { data, error } = await supabase.from("veiculos").select("*").eq("ativo", true).order("modelo")

      if (error) {
        console.error("Erro ao carregar veículos:", error)
        return []
      }

      return data || []
    } catch (error) {
      console.error("Erro ao carregar veículos:", error)
      return []
    }
  }

  static async checkDriverAvailability(
    motoristaId: string,
    data: string,
    horaInicio: string,
    horaFim: string,
    agendamentoId?: string,
  ): Promise<{ available: boolean; conflicts: AgendamentoCompleto[] }> {
    // Simplificado para sempre retornar disponível
    return { available: true, conflicts: [] }
  }

  static async assignDriver(
    agendamentoId: string,
    assignment: {
      motoristaId: string
      motoristaNome: string
      veiculoId?: string
      veiculoInfo?: string
      observacoes?: string
    },
  ): Promise<AgendamentoCompleto> {
    try {
      console.log(`🔄 Atribuindo motorista ${assignment.motoristaNome} ao agendamento ${agendamentoId}`)

      // Prepare update data
      const updateData: any = {
        updated_at: new Date().toISOString(),
      }

      // Try to update with all fields, but handle missing columns gracefully
      try {
        // Try with new column names first
        updateData.motorista_nome = assignment.motoristaNome
        if (assignment.veiculoInfo) {
          updateData.veiculo_info = assignment.veiculoInfo
        }
        if (assignment.observacoes) {
          updateData.observacoes = assignment.observacoes
        }

        const { data, error } = await supabase
          .from("agendamentos")
          .update(updateData)
          .eq("id", agendamentoId)
          .select("*")
          .single()

        if (error) {
          console.warn("⚠️ Erro ao atualizar com novos campos, tentando abordagem alternativa:", error)

          // Fallback: try with minimal update
          const minimalUpdate = {
            updated_at: new Date().toISOString(),
            observacoes: `Motorista: ${assignment.motoristaNome}${assignment.veiculoInfo ? ` | Veículo: ${assignment.veiculoInfo}` : ""}${assignment.observacoes ? ` | ${assignment.observacoes}` : ""}`,
          }

          const { data: fallbackData, error: fallbackError } = await supabase
            .from("agendamentos")
            .update(minimalUpdate)
            .eq("id", agendamentoId)
            .select("*")
            .single()

          if (fallbackError) {
            throw fallbackError
          }

          console.log(`✅ Motorista atribuído com abordagem alternativa: ${agendamentoId}`)
          return this.enriquecerAgendamento(fallbackData)
        }

        console.log(`✅ Motorista atribuído com sucesso: ${agendamentoId}`)
        return this.enriquecerAgendamento(data)
      } catch (updateError) {
        console.error("❌ Erro ao atualizar agendamento:", updateError)
        throw new Error(`Falha ao atribuir motorista: ${updateError.message}`)
      }
    } catch (error) {
      console.error("❌ Erro ao atribuir motorista:", error)
      throw error
    }
  }

  static async cancelAppointment(
    appointmentId: string,
    reason = "Cancelado pelo usuário",
    cancelledBy = "admin",
  ): Promise<AgendamentoCompleto> {
    try {
      console.log(`🔄 Cancelando agendamento ${appointmentId}`)

      // 1. Buscar o agendamento atual
      const appointment = await this.getById(appointmentId)
      if (!appointment) {
        throw new Error("Agendamento não encontrado")
      }

      // 2. Verificar se pode ser cancelado
      if (appointment.status === "concluido") {
        throw new Error("Não é possível cancelar um agendamento já concluído")
      }

      if (appointment.status === "cancelado") {
        throw new Error("Este agendamento já foi cancelado")
      }

      // 3. Atualizar status para cancelado
      const { data, error } = await supabase
        .from("agendamentos")
        .update({
          status: "cancelado",
          updated_at: new Date().toISOString(),
          observacoes: `${appointment.observacoes || ""}\n\n--- CANCELADO ---\nData: ${new Date().toLocaleString("pt-BR")}\nMotivo: ${reason}\nCancelado por: ${cancelledBy}`,
        })
        .eq("id", appointmentId)
        .select("*")
        .single()

      if (error) {
        console.error("❌ Erro ao cancelar agendamento:", error)
        throw new Error(`Falha ao cancelar agendamento: ${error.message}`)
      }

      console.log(`✅ Agendamento cancelado com sucesso: ${appointmentId}`)
      console.log(`📅 Horário liberado: ${appointment.data_agendada} às ${appointment.hora_agendada}`)

      // 4. Retornar agendamento atualizado
      return this.enriquecerAgendamento(data)
    } catch (error) {
      console.error("❌ Erro ao cancelar agendamento:", error)
      throw error
    }
  }

  static async cancelAppointmentEnhanced(
    appointmentId: string,
    reason: string,
    notes?: string,
    cancelledBy = "admin",
  ): Promise<AgendamentoCompleto> {
    try {
      console.log(`🔄 Cancelando agendamento ${appointmentId} com sistema aprimorado`)

      // const result = await AppointmentCancellationService.cancelAppointment(appointmentId, {
      //   reason,
      //   notes,
      //   cancelledBy,
      //   preserveData: true,
      // })

      // console.log(`✅ Agendamento cancelado com sucesso`)
      // console.log(`📅 Horário liberado: ${result.freedTimeSlot.date} às ${result.freedTimeSlot.time}`)

      // return result.appointment
      return {} as any
    } catch (error) {
      console.error("❌ Erro ao cancelar agendamento:", error)
      throw error
    }
  }

  static async getScheduleAvailability(
    driverName: string,
    date: string,
  ): Promise<Array<{ time: string; available: boolean; appointmentId?: string; clientName?: string }>> {
    try {
      // const availability = await AppointmentCancellationService.checkScheduleAvailability(driverName, date)
      // return availability.timeSlots
      return []
    } catch (error) {
      console.error("Erro ao verificar disponibilidade:", error)
      return []
    }
  }

  static async checkConflicts(
    driverName: string,
    date: string,
    time: string,
    excludeId?: string,
  ): Promise<{ hasConflict: boolean; conflicts: any[] }> {
    try {
      // const result = await AppointmentCancellationService.checkScheduleConflicts(
      //   driverName,
      //   date,
      //   time,
      //   60,
      //   excludeId,
      // )
      // return {
      //   hasConflict: result.hasConflict,
      //   conflicts: result.conflictingAppointments,
      // }
      return { hasConflict: false, conflicts: [] }
    } catch (error) {
      console.error("Erro ao verificar conflitos:", error)
      return { hasConflict: false, conflicts: [] }
    }
  }
}
