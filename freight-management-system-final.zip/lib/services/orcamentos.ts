import { supabase } from "@/lib/supabase/client"
import { FinanceiroService } from "./financeiro"
import { AgendamentoIntegradoService } from "./agendamentos-integrado"
import type { Orcamento } from "@/lib/types/database"

export class OrcamentoService {
  static async getAll(): Promise<Orcamento[]> {
    try {
      const { data, error } = await supabase
        .from("orcamentos")
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Erro ao buscar orçamentos:", error)
        throw new Error(`Falha ao carregar orçamentos: ${error.message}`)
      }

      return data || []
    } catch (error) {
      console.error("Erro no serviço de orçamentos:", error)
      // Fallback para dados locais se houver erro
      const localData = this.getLocalOrcamentos()
      if (localData.length > 0) {
        return localData
      }
      throw error
    }
  }

  static async getById(id: string): Promise<Orcamento | null> {
    try {
      const { data, error } = await supabase
        .from("orcamentos")
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .eq("id", id)
        .single()

      if (error) {
        console.error("Erro ao buscar orçamento:", error)
        throw new Error(`Falha ao carregar orçamento: ${error.message}`)
      }

      return data
    } catch (error) {
      console.error("Erro ao buscar orçamento por ID:", error)
      // Tentar buscar do localStorage
      const localData = this.getLocalOrcamentos().find((o) => o.id === id)
      return localData || null
    }
  }

  static async create(orcamento: Partial<Orcamento>): Promise<Orcamento> {
    try {
      // Gerar número do orçamento se não fornecido
      if (!orcamento.numero_orcamento) {
        const timestamp = Date.now()
        const randomSuffix = Math.floor(Math.random() * 1000)
          .toString()
          .padStart(3, "0")
        orcamento.numero_orcamento = `ORC-${timestamp}-${randomSuffix}`
      }

      const { data, error } = await supabase
        .from("orcamentos")
        .insert([orcamento])
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .single()

      if (error) {
        console.error("Erro ao criar orçamento:", error)
        throw new Error(`Falha ao criar orçamento: ${error.message}`)
      }

      // Se for aprovado, criar receita e agendamento automaticamente
      if (data.status === "aprovado") {
        await this.processApproval(data)
      }

      return data
    } catch (error) {
      console.error("Erro ao criar orçamento:", error)

      // Fallback: salvar localmente se falhar no banco
      const localOrcamento = this.createLocalOrcamento(orcamento)
      return localOrcamento
    }
  }

  static async update(id: string, updates: Partial<Orcamento>): Promise<Orcamento> {
    try {
      const { data, error } = await supabase
        .from("orcamentos")
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq("id", id)
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .single()

      if (error) {
        console.error("Erro ao atualizar orçamento:", error)
        throw new Error(`Falha ao atualizar orçamento: ${error.message}`)
      }

      return data
    } catch (error) {
      console.error("Erro ao atualizar orçamento:", error)

      // Fallback: atualizar localmente
      const localOrcamentos = this.getLocalOrcamentos()
      const index = localOrcamentos.findIndex((o) => o.id === id)

      if (index >= 0) {
        localOrcamentos[index] = {
          ...localOrcamentos[index],
          ...updates,
          updated_at: new Date().toISOString(),
        }
        localStorage.setItem("orcamentos", JSON.stringify(localOrcamentos))
        return localOrcamentos[index]
      }

      throw error
    }
  }

  static async updateStatus(
    id: string,
    status: string,
  ): Promise<{ success: boolean; data?: Orcamento; agendamento?: any; error?: string }> {
    try {
      console.log(`🔄 Atualizando status do orçamento ${id} para ${status}`)

      // Buscar o orçamento atual
      const orcamentoAtual = await this.getById(id)
      if (!orcamentoAtual) {
        throw new Error("Orçamento não encontrado")
      }

      // Atualizar status no banco
      const { data, error } = await supabase
        .from("orcamentos")
        .update({
          status: status as any,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .single()

      if (error) {
        console.error("❌ Erro ao atualizar status:", error)
        throw new Error(`Falha ao atualizar status: ${error.message}`)
      }

      console.log(`✅ Status atualizado com sucesso para ${status}`)

      // Se o status mudou para "aprovado", processar aprovação
      if (status === "aprovado" && orcamentoAtual.status !== "aprovado") {
        console.log(`🚀 Processando aprovação do orçamento ${data.numero_orcamento}`)
        const agendamento = await this.processApproval(data)

        return {
          success: true,
          data,
          agendamento,
        }
      }

      return {
        success: true,
        data,
      }
    } catch (error) {
      console.error("❌ Erro ao atualizar status:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Erro desconhecido",
      }
    }
  }

  private static async processApproval(orcamento: Orcamento): Promise<any> {
    try {
      console.log(`📋 Processando aprovação do orçamento ${orcamento.numero_orcamento}`)

      // 1. Criar receita no financeiro
      console.log(`💰 Criando receita...`)
      await this.createReceitaFromOrcamento(orcamento)

      // 2. Criar agendamento
      console.log(`📅 Criando agendamento...`)
      const agendamento = await AgendamentoIntegradoService.createFromOrcamento(orcamento.id)

      console.log(`✅ Aprovação processada com sucesso!`)
      console.log(`   - Receita criada no financeiro`)
      console.log(`   - Agendamento criado: ${agendamento.id}`)
      console.log(`   - Motorista: ${agendamento.motorista?.nome}`)
      console.log(`   - Data: ${agendamento.data_agendada} às ${agendamento.hora_agendada}`)

      return agendamento
    } catch (error) {
      console.error("❌ Erro ao processar aprovação:", error)
      // Não propagar o erro para não impedir a aprovação do orçamento
      throw error
    }
  }

  static async createReceitaFromOrcamento(orcamento: Orcamento): Promise<void> {
    try {
      // Verificar se já existe uma receita para este orçamento
      const { data: receitaExistente } = await supabase
        .from("financeiro")
        .select("id")
        .eq("orcamento_id", orcamento.id)
        .eq("tipo", "receita")
        .single()

      if (receitaExistente) {
        console.log("💰 Receita já existe para este orçamento")
        return
      }

      // Calcular data de vencimento (7 dias após a data agendada ou 15 dias a partir de hoje)
      let dataVencimento: string
      if (orcamento.data_agendada) {
        const dataAgendada = new Date(orcamento.data_agendada)
        dataAgendada.setDate(dataAgendada.getDate() + 7)
        dataVencimento = dataAgendada.toISOString().split("T")[0]
      } else {
        const hoje = new Date()
        hoje.setDate(hoje.getDate() + 15)
        dataVencimento = hoje.toISOString().split("T")[0]
      }

      // Criar descrição da receita
      const descricao = `${orcamento.tipo_servico?.nome || "Serviço"} - ${orcamento.cliente?.nome || "Cliente"}`
      const detalhes =
        orcamento.endereco_origem && orcamento.endereco_destino
          ? ` (${orcamento.endereco_origem} → ${orcamento.endereco_destino})`
          : ""

      // Criar a receita
      await FinanceiroService.createReceita({
        orcamento_id: orcamento.id,
        categoria: this.mapTipoServicoToCategoria(orcamento.tipo_servico?.nome || ""),
        descricao: descricao + detalhes,
        valor: orcamento.valor_total,
        data_vencimento: dataVencimento,
        status_pagamento: "pendente",
        observacoes: `Receita gerada automaticamente do orçamento ${orcamento.numero_orcamento}`,
      })

      console.log(`💰 Receita criada automaticamente para o orçamento ${orcamento.numero_orcamento}`)
    } catch (error) {
      console.error("❌ Erro ao criar receita automática:", error)
      // Não propagar o erro para não impedir a aprovação do orçamento
    }
  }

  private static mapTipoServicoToCategoria(tipoServico: string): string {
    const mapping: { [key: string]: string } = {
      "Frete Padrão": "frete",
      "Frete Expresso": "frete",
      "Mudança Residencial": "mudanca",
      "Mudança Comercial": "mudanca",
      "Transporte de Cargas": "frete",
      "Serviços Extras": "servico_extra",
    }

    return mapping[tipoServico] || "outros"
  }

  static async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase.from("orcamentos").delete().eq("id", id)

      if (error) {
        console.error("Erro ao excluir orçamento:", error)
        throw new Error(`Falha ao excluir orçamento: ${error.message}`)
      }
    } catch (error) {
      console.error("Erro ao excluir orçamento:", error)

      // Fallback: excluir localmente
      const localOrcamentos = this.getLocalOrcamentos().filter((o) => o.id !== id)
      localStorage.setItem("orcamentos", JSON.stringify(localOrcamentos))
    }
  }

  static async getByStatus(status: string): Promise<Orcamento[]> {
    try {
      const { data, error } = await supabase
        .from("orcamentos")
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .eq("status", status)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Erro ao buscar orçamentos por status:", error)
        throw new Error(`Falha ao carregar orçamentos: ${error.message}`)
      }

      return data || []
    } catch (error) {
      console.error("Erro ao buscar orçamentos por status:", error)

      // Fallback: filtrar localmente
      const localOrcamentos = this.getLocalOrcamentos().filter((o) => o.status === status)
      return localOrcamentos
    }
  }

  static async getRecent(limit = 10): Promise<Orcamento[]> {
    try {
      const { data, error } = await supabase
        .from("orcamentos")
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        `)
        .order("created_at", { ascending: false })
        .limit(limit)

      if (error) {
        console.error("Erro ao buscar orçamentos recentes:", error)
        throw new Error(`Falha ao carregar orçamentos recentes: ${error.message}`)
      }

      return data || []
    } catch (error) {
      console.error("Erro ao buscar orçamentos recentes:", error)

      // Fallback: usar dados locais
      const localOrcamentos = this.getLocalOrcamentos().slice(0, limit)
      return localOrcamentos
    }
  }

  static async getOrcamentosWithReceitas(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from("orcamentos")
        .select(`
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*),
          receitas:financeiro!orcamento_id(*)
        `)
        .eq("status", "aprovado")
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Erro ao buscar orçamentos com receitas:", error)
        throw new Error(`Falha ao carregar orçamentos com receitas: ${error.message}`)
      }

      return data || []
    } catch (error) {
      console.error("Erro ao buscar orçamentos com receitas:", error)
      return []
    }
  }

  // Métodos para fallback local
  private static getLocalOrcamentos(): Orcamento[] {
    try {
      const stored = localStorage.getItem("orcamentos")
      return stored ? JSON.parse(stored) : []
    } catch (error) {
      console.error("Erro ao ler orçamentos locais:", error)
      return []
    }
  }

  private static createLocalOrcamento(orcamento: Partial<Orcamento>): Orcamento {
    const timestamp = Date.now()
    const id = `local_${timestamp}`
    const numeroOrcamento = orcamento.numero_orcamento || `ORC-LOCAL-${timestamp}`

    const novoOrcamento: Orcamento = {
      id,
      numero_orcamento: numeroOrcamento,
      cliente_id: orcamento.cliente_id || "",
      tipo_servico_id: orcamento.tipo_servico_id || "",
      endereco_origem: orcamento.endereco_origem || "",
      endereco_destino: orcamento.endereco_destino || "",
      data_agendada: orcamento.data_agendada || null,
      hora_agendada: orcamento.hora_agendada || null,
      descricao_itens: orcamento.descricao_itens || "",
      ajudantes_adicionais: orcamento.ajudantes_adicionais || 0,
      servicos_extras: orcamento.servicos_extras || [],
      valor_total: orcamento.valor_total || 0,
      status: orcamento.status || "rascunho",
      observacoes: orcamento.observacoes || "",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      cliente: orcamento.cliente || null,
      tipo_servico: orcamento.tipo_servico || null,
    }

    const localOrcamentos = this.getLocalOrcamentos()
    localOrcamentos.unshift(novoOrcamento)
    localStorage.setItem("orcamentos", JSON.stringify(localOrcamentos))

    return novoOrcamento
  }
}

// Garantir que a exportação está correta
export { OrcamentoService as default }
