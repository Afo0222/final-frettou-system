export interface ProdutoServico {
  id: string
  nome: string
  codigo?: string
  descricao?: string
  tipo: "produto" | "servico"
  categoria: string
  preco_base?: number
  unidade_preco?: string
  tempo_estimado?: number
  peso_maximo?: number
  volume_maximo?: number
  requer_veiculo_especifico?: boolean
  tipos_veiculo_aceitos?: string[]
  requer_ajudantes?: boolean
  numero_ajudantes?: number
  disponivel_fins_semana?: boolean
  disponivel_feriados?: boolean
  preco_tiers?: Array<{
    quantidade_min: number
    preco: number
  }>
  servicos_extras?: Array<{
    nome: string
    preco: number
    unidade: string
  }>
  observacoes?: string
  ativo: boolean
  created_at: string
  updated_at: string
}

// Mock data para desenvolvimento
const mockProdutosServicos: ProdutoServico[] = [
  {
    id: "1",
    nome: "Transporte de Mudança Residencial",
    codigo: "TMR001",
    descricao: "Serviço completo de mudança residencial incluindo embalagem, transporte e montagem",
    tipo: "servico",
    categoria: "mudanca",
    preco_base: 150.0,
    unidade_preco: "hora",
    tempo_estimado: 240,
    peso_maximo: 2000,
    volume_maximo: 15,
    requer_veiculo_especifico: true,
    tipos_veiculo_aceitos: ["caminhao", "van"],
    requer_ajudantes: true,
    numero_ajudantes: 2,
    disponivel_fins_semana: true,
    disponivel_feriados: false,
    preco_tiers: [
      { quantidade_min: 4, preco: 140.0 },
      { quantidade_min: 8, preco: 130.0 },
    ],
    servicos_extras: [
      { nome: "Embalagem de móveis", preco: 50.0, unidade: "unidade" },
      { nome: "Montagem/Desmontagem", preco: 80.0, unidade: "hora" },
      { nome: "Seguro adicional", preco: 25.0, unidade: "viagem" },
    ],
    observacoes: "Inclui proteção para móveis e eletrodomésticos",
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "2",
    nome: "Entrega Expressa Urbana",
    codigo: "EEU002",
    descricao: "Entrega rápida dentro da cidade com prazo de até 2 horas",
    tipo: "servico",
    categoria: "entrega",
    preco_base: 25.0,
    unidade_preco: "viagem",
    tempo_estimado: 60,
    peso_maximo: 50,
    volume_maximo: 0.5,
    requer_veiculo_especifico: false,
    requer_ajudantes: false,
    disponivel_fins_semana: true,
    disponivel_feriados: true,
    preco_tiers: [
      { quantidade_min: 5, preco: 22.0 },
      { quantidade_min: 10, preco: 20.0 },
    ],
    servicos_extras: [
      { nome: "Entrega agendada", preco: 10.0, unidade: "viagem" },
      { nome: "Coleta no local", preco: 15.0, unidade: "viagem" },
    ],
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "3",
    nome: "Transporte de Carga Pesada",
    codigo: "TCP003",
    descricao: "Transporte especializado para cargas pesadas e equipamentos industriais",
    tipo: "servico",
    categoria: "transporte",
    preco_base: 5.5,
    unidade_preco: "km",
    tempo_estimado: 480,
    peso_maximo: 10000,
    volume_maximo: 50,
    requer_veiculo_especifico: true,
    tipos_veiculo_aceitos: ["caminhao"],
    requer_ajudantes: true,
    numero_ajudantes: 1,
    disponivel_fins_semana: false,
    disponivel_feriados: false,
    preco_tiers: [
      { quantidade_min: 100, preco: 5.0 },
      { quantidade_min: 500, preco: 4.5 },
    ],
    servicos_extras: [
      { nome: "Escolta especializada", preco: 200.0, unidade: "viagem" },
      { nome: "Seguro para carga especial", preco: 100.0, unidade: "viagem" },
    ],
    observacoes: "Requer autorização especial para cargas acima de 5 toneladas",
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "4",
    nome: "Armazenagem Temporária",
    codigo: "AT004",
    descricao: "Serviço de armazenagem temporária em galpão climatizado",
    tipo: "servico",
    categoria: "armazenagem",
    preco_base: 15.0,
    unidade_preco: "m3",
    peso_maximo: 1000,
    requer_veiculo_especifico: false,
    requer_ajudantes: false,
    disponivel_fins_semana: true,
    disponivel_feriados: true,
    preco_tiers: [
      { quantidade_min: 10, preco: 12.0 },
      { quantidade_min: 50, preco: 10.0 },
    ],
    servicos_extras: [
      { nome: "Climatização especial", preco: 5.0, unidade: "m3" },
      { nome: "Segurança 24h", preco: 50.0, unidade: "dia" },
    ],
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "5",
    nome: "Consultoria Logística",
    codigo: "CL005",
    descricao: "Consultoria especializada em otimização de processos logísticos",
    tipo: "servico",
    categoria: "consultoria",
    preco_base: 200.0,
    unidade_preco: "hora",
    tempo_estimado: 120,
    requer_veiculo_especifico: false,
    requer_ajudantes: false,
    disponivel_fins_semana: false,
    disponivel_feriados: false,
    preco_tiers: [
      { quantidade_min: 8, preco: 180.0 },
      { quantidade_min: 20, preco: 160.0 },
    ],
    servicos_extras: [
      { nome: "Relatório detalhado", preco: 300.0, unidade: "unidade" },
      { nome: "Acompanhamento mensal", preco: 500.0, unidade: "mes" },
    ],
    observacoes: "Inclui análise completa e plano de ação",
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "6",
    nome: "Caixas de Papelão Reforçado",
    codigo: "CPR006",
    descricao: "Caixas de papelão ondulado duplo para mudanças e transporte",
    tipo: "produto",
    categoria: "mudanca",
    preco_base: 8.5,
    unidade_preco: "unidade",
    peso_maximo: 30,
    volume_maximo: 0.1,
    requer_veiculo_especifico: false,
    requer_ajudantes: false,
    disponivel_fins_semana: true,
    disponivel_feriados: true,
    preco_tiers: [
      { quantidade_min: 10, preco: 7.5 },
      { quantidade_min: 50, preco: 6.5 },
      { quantidade_min: 100, preco: 5.5 },
    ],
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "7",
    nome: "Filme Plástico Protetor",
    codigo: "FPP007",
    descricao: "Filme plástico stretch para proteção de móveis e eletrodomésticos",
    tipo: "produto",
    categoria: "mudanca",
    preco_base: 25.0,
    unidade_preco: "unidade",
    requer_veiculo_especifico: false,
    requer_ajudantes: false,
    disponivel_fins_semana: true,
    disponivel_feriados: true,
    preco_tiers: [
      { quantidade_min: 5, preco: 22.0 },
      { quantidade_min: 10, preco: 20.0 },
    ],
    ativo: true,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "8",
    nome: "Entrega Noturna Especial",
    codigo: "ENE008",
    descricao: "Serviço de entrega em horário noturno (20h às 6h)",
    tipo: "servico",
    categoria: "entrega",
    preco_base: 45.0,
    unidade_preco: "viagem",
    tempo_estimado: 90,
    peso_maximo: 100,
    volume_maximo: 2,
    requer_veiculo_especifico: false,
    requer_ajudantes: false,
    disponivel_fins_semana: true,
    disponivel_feriados: false,
    servicos_extras: [
      { nome: "Entrega silenciosa", preco: 20.0, unidade: "viagem" },
      { nome: "Confirmação por SMS", preco: 5.0, unidade: "viagem" },
    ],
    observacoes: "Disponível apenas para regiões centrais",
    ativo: false,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
]

class ProdutoServicoService {
  private produtos: ProdutoServico[] = [...mockProdutosServicos]

  async getAll(): Promise<ProdutoServico[]> {
    // Simular delay de rede
    await new Promise((resolve) => setTimeout(resolve, 500))
    return this.produtos
  }

  async getById(id: string): Promise<ProdutoServico | null> {
    await new Promise((resolve) => setTimeout(resolve, 200))
    return this.produtos.find((p) => p.id === id) || null
  }

  async create(data: Omit<ProdutoServico, "id" | "created_at" | "updated_at">): Promise<ProdutoServico> {
    await new Promise((resolve) => setTimeout(resolve, 300))

    const newProduto: ProdutoServico = {
      ...data,
      id: Math.random().toString(36).substr(2, 9),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    this.produtos.push(newProduto)
    return newProduto
  }

  async update(id: string, data: Partial<ProdutoServico>): Promise<ProdutoServico> {
    await new Promise((resolve) => setTimeout(resolve, 300))

    const index = this.produtos.findIndex((p) => p.id === id)
    if (index === -1) {
      throw new Error("Produto/serviço não encontrado")
    }

    this.produtos[index] = {
      ...this.produtos[index],
      ...data,
      updated_at: new Date().toISOString(),
    }

    return this.produtos[index]
  }

  async delete(id: string): Promise<void> {
    await new Promise((resolve) => setTimeout(resolve, 300))

    const index = this.produtos.findIndex((p) => p.id === id)
    if (index === -1) {
      throw new Error("Produto/serviço não encontrado")
    }

    this.produtos.splice(index, 1)
  }

  async getByCategory(categoria: string): Promise<ProdutoServico[]> {
    await new Promise((resolve) => setTimeout(resolve, 200))
    return this.produtos.filter((p) => p.categoria === categoria && p.ativo)
  }

  async getByType(tipo: "produto" | "servico"): Promise<ProdutoServico[]> {
    await new Promise((resolve) => setTimeout(resolve, 200))
    return this.produtos.filter((p) => p.tipo === tipo && p.ativo)
  }

  async search(term: string): Promise<ProdutoServico[]> {
    await new Promise((resolve) => setTimeout(resolve, 200))
    const searchTerm = term.toLowerCase()
    return this.produtos.filter(
      (p) =>
        p.nome.toLowerCase().includes(searchTerm) ||
        p.descricao?.toLowerCase().includes(searchTerm) ||
        p.codigo?.toLowerCase().includes(searchTerm),
    )
  }
}

export const produtoServicoService = new ProdutoServicoService()
