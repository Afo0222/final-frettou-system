import { supabase } from "@/lib/supabase/client"

interface ComprovanteData {
  rotaId: string
  clienteNome: string
  enderecoRetirada: string
  enderecoEntrega: string
  tipoServico: string
  dataEntrega: string
  horaEntrega: string
  motoristaId?: string
  motoristaNome: string
  assinaturaCliente?: string
  fotos?: any[]
  observacoes?: string
  avaliacaoCliente?: number
  comentarioCliente?: string
  valorTotal?: number
}

export class ComprovanteService {
  static async gerarComprovante(data: ComprovanteData): Promise<string> {
    try {
      // Validar dados obrigatorios
      if (
        !data.rotaId ||
        !data.clienteNome ||
        !data.enderecoRetirada ||
        !data.enderecoEntrega ||
        !data.tipoServico ||
        !data.dataEntrega ||
        !data.horaEntrega ||
        !data.motoristaNome
      ) {
        throw new Error("Dados obrigatorios nao fornecidos para gerar comprovante")
      }

      // Validar e converter data
      let dataFormatada: string
      try {
        // Se a data esta no formato DD/MM/YYYY, converter para YYYY-MM-DD
        if (data.dataEntrega.includes("/")) {
          const [dia, mes, ano] = data.dataEntrega.split("/")
          dataFormatada = `${ano}-${mes.padStart(2, "0")}-${dia.padStart(2, "0")}`
        } else {
          dataFormatada = data.dataEntrega
        }

        // Validar se a data e valida
        const dataTest = new Date(dataFormatada)
        if (isNaN(dataTest.getTime())) {
          throw new Error("Data invalida")
        }
      } catch (error) {
        console.error("Erro ao processar data:", error)
        // Usar data atual como fallback
        dataFormatada = new Date().toISOString().split("T")[0]
      }

      // Validar e formatar hora
      let horaFormatada: string
      try {
        // Se a hora tem segundos, remover
        if (data.horaEntrega.split(":").length === 3) {
          horaFormatada = data.horaEntrega.substring(0, 5)
        } else {
          horaFormatada = data.horaEntrega
        }

        // Validar formato HH:MM
        if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(horaFormatada)) {
          throw new Error("Hora invalida")
        }
      } catch (error) {
        console.error("Erro ao processar hora:", error)
        // Usar hora atual como fallback
        horaFormatada = new Date().toTimeString().substring(0, 5)
      }

      const comprovanteData = {
        rota_id: data.rotaId.toString(),
        cliente_nome: data.clienteNome.toString(),
        endereco_retirada: data.enderecoRetirada.toString(),
        endereco_entrega: data.enderecoEntrega.toString(),
        tipo_servico: data.tipoServico.toString(),
        data_entrega: dataFormatada,
        hora_entrega: horaFormatada,
        motorista_id: data.motoristaId || null,
        motorista_nome: data.motoristaNome.toString(),
        assinatura_cliente: data.assinaturaCliente || null,
        fotos: data.fotos ? JSON.stringify(data.fotos) : null,
        observacoes: data.observacoes || null,
        avaliacao_cliente: data.avaliacaoCliente || null,
        comentario_cliente: data.comentarioCliente || null,
        valor_total: data.valorTotal || null,
      }

      console.log("Dados do comprovante a serem inseridos:", comprovanteData)

      const { data: comprovante, error } = await supabase
        .from("comprovantes_entrega")
        .insert([comprovanteData])
        .select("id")
        .single()

      if (error) {
        console.error("Erro detalhado do Supabase:", error)
        throw new Error(`Erro ao inserir comprovante: ${error.message}`)
      }

      if (!comprovante || !comprovante.id) {
        throw new Error("Comprovante criado mas ID nao retornado")
      }

      console.log("Comprovante gerado com sucesso:", comprovante.id)
      return comprovante.id
    } catch (error) {
      console.error("Erro ao gerar comprovante:", error)
      throw error
    }
  }

  static async enviarParaFinanceiro(rotaId: string, valorTotal: number): Promise<void> {
    try {
      // Validar dados obrigatorios
      if (!rotaId || !valorTotal || valorTotal <= 0) {
        throw new Error("Dados invalidos para enviar ao financeiro")
      }

      const financeiroData = {
        rota_id: rotaId.toString(),
        valor_total: Number(valorTotal),
        status: "pendente",
        data_conclusao: new Date().toISOString().split("T")[0],
      }

      console.log("Dados financeiros a serem inseridos:", financeiroData)

      const { error } = await supabase.from("financeiro_rotas").insert([financeiroData])

      if (error) {
        console.error("Erro detalhado do Supabase (financeiro):", error)
        throw new Error(`Erro ao inserir dados financeiros: ${error.message}`)
      }

      console.log("Dados enviados para financeiro com sucesso")
    } catch (error) {
      console.error("Erro ao enviar para financeiro:", error)
      throw error
    }
  }

  static async gerarPDF(data: ComprovanteData): Promise<void> {
    try {
      // Validar dados minimos para PDF
      if (!data.rotaId || !data.clienteNome || !data.motoristaNome) {
        throw new Error("Dados insuficientes para gerar PDF")
      }

      // Simular geracao de PDF - removendo caracteres especiais
      const pdfContent = `
COMPROVANTE DE ENTREGA
======================

Cliente: ${data.clienteNome}
Servico: ${data.tipoServico || "Nao especificado"}

Retirada: ${data.enderecoRetirada || "Nao especificado"}
Entrega: ${data.enderecoEntrega || "Nao especificado"}

Data: ${data.dataEntrega || "Nao especificado"}
Hora: ${data.horaEntrega || "Nao especificado"}

Motorista: ${data.motoristaNome}

${data.valorTotal ? `Valor: R$ ${data.valorTotal.toFixed(2)}` : ""}

${data.avaliacaoCliente ? `Avaliacao: ${data.avaliacaoCliente}/5 estrelas` : ""}
${data.comentarioCliente ? `Comentario: ${data.comentarioCliente}` : ""}

${data.observacoes ? `Observacoes: ${data.observacoes}` : ""}

Gerado em: ${new Date().toLocaleString("pt-BR").replace(/[^\x00-\x7F]/g, "")}
    `

      // Create and download PDF (simplified version)
      const blob = new Blob([pdfContent], { type: "text/plain;charset=utf-8" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `comprovante-${data.rotaId}-${new Date().toISOString().split("T")[0]}.txt`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      console.log("PDF gerado e baixado com sucesso")
    } catch (error) {
      console.error("Erro ao gerar PDF:", error)
      throw error
    }
  }

  static async buscarComprovante(rotaId: string): Promise<any> {
    try {
      if (!rotaId) {
        throw new Error("ID da rota e obrigatorio")
      }

      const { data, error } = await supabase.from("comprovantes_entrega").select("*").eq("rota_id", rotaId).single()

      if (error && error.code !== "PGRST116") {
        // PGRST116 = not found
        throw error
      }

      return data
    } catch (error) {
      console.error("Erro ao buscar comprovante:", error)
      throw error
    }
  }

  static async listarComprovantes(filtros?: { dataInicio?: string; dataFim?: string; motorista?: string }): Promise<
    any[]
  > {
    try {
      let query = supabase.from("comprovantes_entrega").select("*").order("data_entrega", { ascending: false })

      if (filtros?.dataInicio) {
        query = query.gte("data_entrega", filtros.dataInicio)
      }

      if (filtros?.dataFim) {
        query = query.lte("data_entrega", filtros.dataFim)
      }

      if (filtros?.motorista) {
        query = query.eq("motorista_nome", filtros.motorista)
      }

      const { data, error } = await query

      if (error) {
        throw error
      }

      return data || []
    } catch (error) {
      console.error("Erro ao listar comprovantes:", error)
      throw error
    }
  }
}
