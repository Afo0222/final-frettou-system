export interface AddressResult {
  place_id: string
  formatted_address: string
  address_components: any[]
  geometry: {
    location?: { lat: number; lng: number }
    location_type?: string
  }
  types: string[]
  partial_match: boolean
  confidence: number
}

export interface GeocodeSearchResponse {
  results: AddressResult[]
  status: "OK" | "ERROR" | "ZERO_RESULTS" | "RATE_LIMITED" | "API_ERROR"
  error?: string
  rateLimitInfo?: {
    remaining?: number
    resetTime?: number
    waitTime?: number
    reason?: string
    type?: string
  }
  cached?: boolean
  cacheAge?: number
  debug?: any
}

// Cache local otimizado
class OptimizedCache {
  private cache = new Map<string, { data: GeocodeSearchResponse; timestamp: number; accessCount: number }>()
  private readonly CACHE_DURATION = 60 * 60 * 1000 // 1 hora local
  private readonly MAX_SIZE = 50

  get(key: string): GeocodeSearchResponse | null {
    const cached = this.cache.get(key)
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      cached.accessCount++
      return cached.data
    }
    this.cache.delete(key)
    return null
  }

  set(key: string, data: GeocodeSearchResponse): void {
    if (this.cache.size >= this.MAX_SIZE) {
      // Remover entrada menos acessada
      let leastUsed = { key: "", accessCount: Number.POSITIVE_INFINITY }
      for (const [k, v] of this.cache.entries()) {
        if (v.accessCount < leastUsed.accessCount) {
          leastUsed = { key: k, accessCount: v.accessCount }
        }
      }
      if (leastUsed.key) {
        this.cache.delete(leastUsed.key)
      }
    }

    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      accessCount: 1,
    })
  }

  clear(): void {
    this.cache.clear()
  }

  size(): number {
    return this.cache.size
  }
}

// Histórico inteligente de consultas
class SmartSearchHistory {
  private searches: Array<{ query: string; timestamp: number }> = []
  private readonly MAX_HISTORY = 10
  private readonly MIN_INTERVAL = 3000 // 3 segundos entre buscas similares

  shouldSearch(query: string): boolean {
    const now = Date.now()
    const normalizedQuery = query.toLowerCase().trim()

    // Limpar histórico antigo
    this.searches = this.searches.filter((s) => now - s.timestamp < 60000) // 1 minuto

    // Verificar se já foi pesquisado recentemente
    const recentSearch = this.searches.find((s) => s.query === normalizedQuery && now - s.timestamp < this.MIN_INTERVAL)

    if (recentSearch) {
      return false
    }

    // Verificar se é uma extensão significativa da última busca
    if (this.searches.length > 0) {
      const lastSearch = this.searches[this.searches.length - 1]

      // Se é uma extensão da última busca e muito recente, não buscar
      if (
        normalizedQuery.startsWith(lastSearch.query) &&
        normalizedQuery.length < lastSearch.query.length + 4 &&
        now - lastSearch.timestamp < 2000
      ) {
        return false
      }
    }

    this.addSearch(normalizedQuery, now)
    return true
  }

  private addSearch(query: string, timestamp: number): void {
    this.searches.push({ query, timestamp })
    if (this.searches.length > this.MAX_HISTORY) {
      this.searches.shift()
    }
  }

  clear(): void {
    this.searches = []
  }
}

// Controle de requisições otimizado
class SmartRequestController {
  private lastRequestTime = 0
  private activeRequests = 0
  private readonly MIN_REQUEST_INTERVAL = 2000 // 2 segundos
  private readonly MAX_CONCURRENT_REQUESTS = 1
  private backoffMultiplier = 1
  private consecutiveErrors = 0

  canMakeRequest(): { allowed: boolean; waitTime?: number; reason?: string } {
    const now = Date.now()
    const timeSinceLastRequest = now - this.lastRequestTime
    const requiredInterval = this.MIN_REQUEST_INTERVAL * this.backoffMultiplier

    if (timeSinceLastRequest < requiredInterval) {
      return {
        allowed: false,
        waitTime: requiredInterval - timeSinceLastRequest,
        reason: "Aguardando intervalo mínimo",
      }
    }

    if (this.activeRequests >= this.MAX_CONCURRENT_REQUESTS) {
      return {
        allowed: false,
        reason: "Requisição em andamento",
      }
    }

    return { allowed: true }
  }

  startRequest(): void {
    this.lastRequestTime = Date.now()
    this.activeRequests++
  }

  endRequest(success = true): void {
    this.activeRequests = Math.max(0, this.activeRequests - 1)

    if (success) {
      this.consecutiveErrors = 0
      this.backoffMultiplier = Math.max(1, this.backoffMultiplier * 0.8) // Reduzir backoff
    } else {
      this.consecutiveErrors++
      this.backoffMultiplier = Math.min(4, this.backoffMultiplier * 1.5) // Aumentar backoff
    }
  }

  reset(): void {
    this.lastRequestTime = 0
    this.activeRequests = 0
    this.backoffMultiplier = 1
    this.consecutiveErrors = 0
  }

  getBackoffInfo(): { multiplier: number; errors: number } {
    return {
      multiplier: this.backoffMultiplier,
      errors: this.consecutiveErrors,
    }
  }
}

export class AddressGeocodeSearchService {
  private static cache = new OptimizedCache()
  private static searchHistory = new SmartSearchHistory()
  private static requestController = new SmartRequestController()
  private static readonly MIN_QUERY_LENGTH = 4 // Aumentado
  private static isInitialized = false
  private static pendingRequests = new Map<string, Promise<GeocodeSearchResponse>>()

  private static initialize(): void {
    if (this.isInitialized) return

    this.isInitialized = true
    this.cache.clear()
    this.searchHistory.clear()
    this.requestController.reset()
    this.pendingRequests.clear()

    console.log("[GEOCODE_SEARCH_SERVICE] Serviço inicializado com otimizações")
  }

  static async searchAddresses(query: string): Promise<GeocodeSearchResponse> {
    if (!this.isInitialized) {
      this.initialize()
    }

    console.log(`[GEOCODE_SEARCH_SERVICE] Solicitação de busca: "${query}"`)

    // Validações
    if (!query || query.trim().length < this.MIN_QUERY_LENGTH) {
      return {
        results: [],
        status: "ZERO_RESULTS",
        error: "Digite pelo menos 4 caracteres para buscar",
      }
    }

    const normalizedQuery = query.trim().toLowerCase()
    const cacheKey = `geocode_search_${normalizedQuery}`

    // Verificar cache local
    const cached = this.cache.get(cacheKey)
    if (cached) {
      console.log(`[GEOCODE_SEARCH_SERVICE] Cache local hit: "${query}"`)
      return { ...cached, cached: true }
    }

    // Verificar histórico de buscas
    if (!this.searchHistory.shouldSearch(normalizedQuery)) {
      console.log(`[GEOCODE_SEARCH_SERVICE] Busca ignorada por histórico: "${query}"`)
      return {
        results: [],
        status: "ZERO_RESULTS",
        error: "Continue digitando para refinar a busca",
      }
    }

    // Verificar requisições pendentes
    if (this.pendingRequests.has(cacheKey)) {
      console.log(`[GEOCODE_SEARCH_SERVICE] Aguardando requisição pendente: "${query}"`)
      return this.pendingRequests.get(cacheKey)!
    }

    // Verificar controle de requisições
    const canRequest = this.requestController.canMakeRequest()
    if (!canRequest.allowed) {
      console.log(`[GEOCODE_SEARCH_SERVICE] Requisição bloqueada: ${canRequest.reason}`)
      return {
        results: [],
        status: "RATE_LIMITED",
        error: canRequest.reason || "Aguarde antes de fazer nova busca",
        rateLimitInfo: {
          waitTime: canRequest.waitTime,
          reason: canRequest.reason,
        },
      }
    }

    // Iniciar requisição
    this.requestController.startRequest()

    const requestPromise = this.fetchAddresses(normalizedQuery)
      .then((result) => {
        this.requestController.endRequest(result.status === "OK")
        return result
      })
      .catch((error) => {
        this.requestController.endRequest(false)
        throw error
      })
      .finally(() => {
        this.pendingRequests.delete(cacheKey)
      })

    this.pendingRequests.set(cacheKey, requestPromise)
    return requestPromise
  }

  private static async fetchAddresses(query: string): Promise<GeocodeSearchResponse> {
    try {
      console.log(`[GEOCODE_SEARCH_SERVICE] Fazendo requisição HTTP: "${query}"`)

      const response = await fetch(
        `/api/maps/geocode-search?input=${encodeURIComponent(query)}&language=pt-BR&region=br`,
        {
          headers: {
            "Cache-Control": "no-cache, no-store, must-revalidate",
            Pragma: "no-cache",
            Expires: "0",
          },
        },
      )

      console.log(`[GEOCODE_SEARCH_SERVICE] Resposta HTTP: ${response.status}`)

      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`)
      }

      const data = await response.json()
      console.log(`[GEOCODE_SEARCH_SERVICE] Dados recebidos:`, {
        status: data.status,
        results_count: data.results?.length || 0,
        cached: data.cached,
        rateLimitInfo: data.rateLimitInfo,
      })

      const result = this.processApiResponse(data, query)

      // Cache apenas resultados bem-sucedidos
      if (result.status === "OK" && result.results.length > 0) {
        this.cache.set(`geocode_search_${query}`, result)
      }

      return result
    } catch (error) {
      console.error("[GEOCODE_SEARCH_SERVICE] Erro na requisição:", error)

      return {
        results: [],
        status: "ERROR",
        error: "Erro de conexão. Verifique sua internet e tente novamente.",
        debug: {
          error: error instanceof Error ? error.message : "Unknown error",
          timestamp: new Date().toISOString(),
          backoffInfo: this.requestController.getBackoffInfo(),
        },
      }
    }
  }

  private static processApiResponse(data: any, originalQuery: string): GeocodeSearchResponse {
    if (!data) {
      return {
        results: [],
        status: "ERROR",
        error: "Resposta inválida da API",
      }
    }

    // Tratar rate limiting
    if (data.status === "OVER_QUERY_LIMIT") {
      return {
        results: [],
        status: "RATE_LIMITED",
        error: data.error || "Limite de consultas atingido",
        rateLimitInfo: data.rateLimitInfo,
      }
    }

    if (data.status !== "OK") {
      const errorMessages = {
        ZERO_RESULTS: "Nenhum endereço encontrado. Tente ser mais específico.",
        REQUEST_DENIED: "Acesso negado à API",
        INVALID_REQUEST: "Consulta inválida",
        SERVER_ERROR: "Erro interno do servidor",
      }

      return {
        results: [],
        status: "API_ERROR",
        error: errorMessages[data.status as keyof typeof errorMessages] || data.error || "Erro desconhecido",
        rateLimitInfo: data.rateLimitInfo,
        debug: data?.debug,
      }
    }

    if (!Array.isArray(data.results)) {
      return {
        results: [],
        status: "ZERO_RESULTS",
        rateLimitInfo: data.rateLimitInfo,
        debug: data?.debug,
      }
    }

    const results: AddressResult[] = data.results.map((result: any) => ({
      place_id: result.place_id,
      formatted_address: result.formatted_address,
      address_components: result.address_components || [],
      geometry: result.geometry || {},
      types: result.types || [],
      partial_match: result.partial_match || false,
      confidence: result.confidence || 0,
    }))

    return {
      results,
      status: results.length > 0 ? "OK" : "ZERO_RESULTS",
      cached: data.cached,
      cacheAge: data.cacheAge,
      rateLimitInfo: data.rateLimitInfo,
      debug: data?.debug,
    }
  }

  static reset(): void {
    this.cache.clear()
    this.searchHistory.clear()
    this.requestController.reset()
    this.pendingRequests.clear()
    this.isInitialized = true
    console.log("[GEOCODE_SEARCH_SERVICE] Serviço resetado completamente")
  }

  static getStats(): any {
    return {
      cacheSize: this.cache.size(),
      pendingRequests: this.pendingRequests.size,
      backoffInfo: this.requestController.getBackoffInfo(),
      isInitialized: this.isInitialized,
    }
  }
}
