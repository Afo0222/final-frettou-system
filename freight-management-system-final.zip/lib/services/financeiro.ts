import { supabase } from "@/lib/supabase/client"

export interface FinanceiroItem {
  id: string
  rota_id?: string
  orcamento_id?: string
  agendamento_id?: string
  tipo: "receita" | "despesa"
  categoria: string
  descricao: string
  valor: number
  data_vencimento?: string
  data_pagamento?: string
  status_pagamento: "pendente" | "pago" | "em_atraso" | "cancelado"
  metodo_pagamento?: string
  comprovante_url?: string
  observacoes?: string
  created_by?: string
  created_at: string
  updated_at: string
}

export interface FinanceiroDashboard {
  receitaMes: number
  receitaCrescimento: number
  despesaMes: number
  despesaCategorias: { categoria: string; valor: number }[]
  lucroLiquido: number
  margemLucro: number
  contasReceber: number
  prazoMedio: number
  receitaVsDespesas: { mes: string; receita: number; despesa: number }[]
  receitaPorServico: { servico: string; valor: number }[]
  metodosPagamento: { metodo: string; valor: number }[]
  pagamentosAtraso: FinanceiroItem[]
  vencimentosSemana: FinanceiroItem[]
}

export class FinanceiroService {
  static async getDashboard(): Promise<FinanceiroDashboard> {
    const hoje = new Date()
    const mesAtual = hoje.getMonth() + 1
    const anoAtual = hoje.getFullYear()
    const mesPassado = mesAtual === 1 ? 12 : mesAtual - 1
    const anoMesPassado = mesAtual === 1 ? anoAtual - 1 : anoAtual

    // Receita do mês atual
    const { data: receitaMesData } = await supabase
      .from("financeiro")
      .select("valor")
      .eq("tipo", "receita")
      .eq("status_pagamento", "pago")
      .gte("data_pagamento", `${anoAtual}-${mesAtual.toString().padStart(2, "0")}-01`)
      .lt("data_pagamento", `${anoAtual}-${(mesAtual + 1).toString().padStart(2, "0")}-01`)

    const receitaMes = receitaMesData?.reduce((sum, item) => sum + item.valor, 0) || 0

    // Receita do mês passado para calcular crescimento
    const { data: receitaMesPassadoData } = await supabase
      .from("financeiro")
      .select("valor")
      .eq("tipo", "receita")
      .eq("status_pagamento", "pago")
      .gte("data_pagamento", `${anoMesPassado}-${mesPassado.toString().padStart(2, "0")}-01`)
      .lt("data_pagamento", `${anoMesPassado}-${mesAtual.toString().padStart(2, "0")}-01`)

    const receitaMesPassado = receitaMesPassadoData?.reduce((sum, item) => sum + item.valor, 0) || 0
    const receitaCrescimento = receitaMesPassado > 0 ? ((receitaMes - receitaMesPassado) / receitaMesPassado) * 100 : 0

    // Despesas do mês atual
    const { data: despesaMesData } = await supabase
      .from("financeiro")
      .select("valor, categoria")
      .eq("tipo", "despesa")
      .eq("status_pagamento", "pago")
      .gte("data_pagamento", `${anoAtual}-${mesAtual.toString().padStart(2, "0")}-01`)
      .lt("data_pagamento", `${anoAtual}-${(mesAtual + 1).toString().padStart(2, "0")}-01`)

    const despesaMes = despesaMesData?.reduce((sum, item) => sum + item.valor, 0) || 0
    const despesaCategorias =
      despesaMesData?.reduce((acc: any[], item) => {
        const existing = acc.find((cat) => cat.categoria === item.categoria)
        if (existing) {
          existing.valor += item.valor
        } else {
          acc.push({ categoria: item.categoria, valor: item.valor })
        }
        return acc
      }, []) || []

    // Lucro líquido e margem
    const lucroLiquido = receitaMes - despesaMes
    const margemLucro = receitaMes > 0 ? (lucroLiquido / receitaMes) * 100 : 0

    // Contas a receber
    const { data: contasReceberData } = await supabase
      .from("financeiro")
      .select("valor, data_vencimento")
      .eq("tipo", "receita")
      .in("status_pagamento", ["pendente", "em_atraso"])

    const contasReceber = contasReceberData?.reduce((sum, item) => sum + item.valor, 0) || 0

    // Receita vs Despesas (últimos 12 meses)
    const { data: receitaVsDespesasData } = await supabase
      .from("financeiro")
      .select("tipo, valor, data_pagamento")
      .eq("status_pagamento", "pago")
      .gte("data_pagamento", `${anoAtual - 1}-${mesAtual.toString().padStart(2, "0")}-01`)
      .order("data_pagamento")

    const receitaVsDespesas = Array.from({ length: 12 }, (_, i) => {
      const mes = new Date(anoAtual - 1, mesAtual - 1 + i, 1)
      const mesStr = mes.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" })
      const mesAno = `${mes.getFullYear()}-${(mes.getMonth() + 1).toString().padStart(2, "0")}`

      const receita =
        receitaVsDespesasData
          ?.filter((item) => item.tipo === "receita" && item.data_pagamento?.startsWith(mesAno))
          .reduce((sum, item) => sum + item.valor, 0) || 0

      const despesa =
        receitaVsDespesasData
          ?.filter((item) => item.tipo === "despesa" && item.data_pagamento?.startsWith(mesAno))
          .reduce((sum, item) => sum + item.valor, 0) || 0

      return { mes: mesStr, receita, despesa }
    })

    // Métodos de pagamento
    const { data: metodosPagamentoData } = await supabase
      .from("financeiro")
      .select("metodo_pagamento, valor")
      .eq("tipo", "receita")
      .eq("status_pagamento", "pago")
      .gte("data_pagamento", `${anoAtual}-${mesAtual.toString().padStart(2, "0")}-01`)

    const metodosPagamento =
      metodosPagamentoData?.reduce((acc: any[], item) => {
        const existing = acc.find((metodo) => metodo.metodo === item.metodo_pagamento)
        if (existing) {
          existing.valor += item.valor
        } else {
          acc.push({ metodo: item.metodo_pagamento || "Não informado", valor: item.valor })
        }
        return acc
      }, []) || []

    // Pagamentos em atraso
    const { data: pagamentosAtraso } = await supabase
      .from("financeiro")
      .select("*")
      .eq("tipo", "receita")
      .eq("status_pagamento", "em_atraso")
      .order("data_vencimento")
      .limit(10)

    // Vencimentos da semana
    const proximaSemana = new Date()
    proximaSemana.setDate(proximaSemana.getDate() + 7)

    const { data: vencimentosSemana } = await supabase
      .from("financeiro")
      .select("*")
      .eq("status_pagamento", "pendente")
      .gte("data_vencimento", hoje.toISOString().split("T")[0])
      .lte("data_vencimento", proximaSemana.toISOString().split("T")[0])
      .order("data_vencimento")
      .limit(10)

    return {
      receitaMes,
      receitaCrescimento,
      despesaMes,
      despesaCategorias,
      lucroLiquido,
      margemLucro,
      contasReceber,
      prazoMedio: 15, // Simulado
      receitaVsDespesas,
      receitaPorServico: [
        { servico: "Frete Padrão", valor: receitaMes * 0.4 },
        { servico: "Mudança Residencial", valor: receitaMes * 0.35 },
        { servico: "Frete Expresso", valor: receitaMes * 0.15 },
        { servico: "Mudança Comercial", valor: receitaMes * 0.1 },
      ],
      metodosPagamento,
      pagamentosAtraso: pagamentosAtraso || [],
      vencimentosSemana: vencimentosSemana || [],
    }
  }

  static async getReceitas(filters?: {
    periodo?: { inicio: string; fim: string }
    status?: string
    cliente?: string
    metodo?: string
  }): Promise<FinanceiroItem[]> {
    let query = supabase.from("financeiro").select("*").eq("tipo", "receita").order("created_at", { ascending: false })

    if (filters?.periodo) {
      // Só aplicar o filtro de data se as datas estiverem preenchidas
      if (filters.periodo.inicio) {
        query = query.gte("data_vencimento", filters.periodo.inicio)
      }
      if (filters.periodo.fim) {
        query = query.lte("data_vencimento", filters.periodo.fim)
      }
    }

    if (filters?.status && filters.status !== "todos") {
      query = query.eq("status_pagamento", filters.status)
    }

    if (filters?.metodo && filters.metodo !== "todos") {
      query = query.eq("metodo_pagamento", filters.metodo)
    }

    const { data, error } = await query

    if (error) throw error
    return data || []
  }

  static async getDespesas(filters?: {
    periodo?: { inicio: string; fim: string }
    categoria?: string
    status?: string
  }): Promise<FinanceiroItem[]> {
    let query = supabase.from("financeiro").select("*").eq("tipo", "despesa").order("created_at", { ascending: false })

    if (filters?.periodo) {
      // Só aplicar o filtro de data se as datas estiverem preenchidas
      if (filters.periodo.inicio) {
        query = query.gte("data_vencimento", filters.periodo.inicio)
      }
      if (filters.periodo.fim) {
        query = query.lte("data_vencimento", filters.periodo.fim)
      }
    }

    if (filters?.categoria && filters.categoria !== "all") {
      query = query.eq("categoria", filters.categoria)
    }

    if (filters?.status && filters.status !== "todos") {
      query = query.eq("status_pagamento", filters.status)
    }

    const { data, error } = await query

    if (error) throw error
    return data || []
  }

  // Adicionar método para buscar receitas vinculadas a orçamentos
  static async getReceitasComOrcamentos(): Promise<any[]> {
    const { data, error } = await supabase
      .from("financeiro")
      .select(`
        *,
        orcamento:orcamentos(
          *,
          cliente:clientes(*),
          tipo_servico:tipos_servico(*)
        )
      `)
      .eq("tipo", "receita")
      .not("orcamento_id", "is", null)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data || []
  }

  // Atualizar método createReceita para aceitar orcamento_id
  static async createReceita(
    receita: Omit<FinanceiroItem, "id" | "created_at" | "updated_at" | "tipo">,
  ): Promise<FinanceiroItem> {
    const { data, error } = await supabase
      .from("financeiro")
      .insert([{ ...receita, tipo: "receita" }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async createDespesa(
    despesa: Omit<FinanceiroItem, "id" | "created_at" | "updated_at" | "tipo">,
  ): Promise<FinanceiroItem> {
    const { data, error } = await supabase
      .from("financeiro")
      .insert([{ ...despesa, tipo: "despesa" }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async updateItem(id: string, updates: Partial<FinanceiroItem>): Promise<FinanceiroItem> {
    const { data, error } = await supabase
      .from("financeiro")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async updateItemOptimized(id: string, updates: Partial<FinanceiroItem>): Promise<FinanceiroItem> {
    // Usar upsert para melhor performance
    const { data, error } = await supabase
      .from("financeiro")
      .upsert(
        {
          id,
          ...updates,
          updated_at: new Date().toISOString(),
        },
        {
          onConflict: "id",
          ignoreDuplicates: false,
        },
      )
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async updateStatus(id: string, status: string, dataPagamento?: string): Promise<FinanceiroItem> {
    const updates: any = {
      status_pagamento: status,
      updated_at: new Date().toISOString(),
    }

    if (dataPagamento) {
      updates.data_pagamento = dataPagamento
    }

    const { data, error } = await supabase.from("financeiro").update(updates).eq("id", id).select().single()

    if (error) throw error
    return data
  }

  static async deleteItem(id: string): Promise<void> {
    // Usar delete simples sem select para melhor performance
    const { error } = await supabase.from("financeiro").delete().eq("id", id)

    if (error) throw error
  }

  static async duplicateItem(id: string): Promise<FinanceiroItem> {
    // Primeiro, buscar o item original
    const { data: original, error: fetchError } = await supabase.from("financeiro").select("*").eq("id", id).single()

    if (fetchError) throw fetchError

    // Remover campos que não devem ser duplicados
    const { id: _, created_at, updated_at, ...itemToDuplicate } = original

    // Inserir o novo item
    const { data, error } = await supabase
      .from("financeiro")
      .insert([{ ...itemToDuplicate, status_pagamento: "pendente", data_pagamento: null }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async getById(id: string): Promise<FinanceiroItem | null> {
    const { data, error } = await supabase.from("financeiro").select("*").eq("id", id).single()

    if (error) throw error
    return data
  }

  static async getReceitasOptimized(filters?: {
    periodo?: { inicio: string; fim: string }
    status?: string
    cliente?: string
    metodo?: string
    limit?: number
  }): Promise<FinanceiroItem[]> {
    let query = supabase
      .from("financeiro")
      .select(
        "id, descricao, categoria, valor, data_vencimento, status_pagamento, metodo_pagamento, orcamento_id, created_at",
      )
      .eq("tipo", "receita")
      .order("created_at", { ascending: false })

    // Aplicar limite para melhor performance
    if (filters?.limit) {
      query = query.limit(filters.limit)
    }

    if (filters?.periodo) {
      if (filters.periodo.inicio) {
        query = query.gte("data_vencimento", filters.periodo.inicio)
      }
      if (filters.periodo.fim) {
        query = query.lte("data_vencimento", filters.periodo.fim)
      }
    }

    if (filters?.status && filters.status !== "todos") {
      query = query.eq("status_pagamento", filters.status)
    }

    if (filters?.metodo && filters.metodo !== "todos") {
      query = query.eq("metodo_pagamento", filters.metodo)
    }

    const { data, error } = await query

    if (error) throw error
    return data || []
  }
}
