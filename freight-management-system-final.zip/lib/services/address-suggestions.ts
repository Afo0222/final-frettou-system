export interface AddressSuggestion {
  place_id: string
  description: string
  main_text: string
  secondary_text: string
  types: string[]
  confidence: number
}

export interface SuggestionResponse {
  suggestions: AddressSuggestion[]
  status: "OK" | "ERROR" | "NO_RESULTS" | "RATE_LIMITED" | "API_ERROR"
  error?: string
  hasMore?: boolean
  debug?: any
}

// Cache otimizado para sugestões
class SuggestionsCache {
  private cache = new Map<string, { data: SuggestionResponse; timestamp: number }>()
  private readonly CACHE_DURATION = 30 * 60 * 1000 // 30 minutos para sugestões

  get(key: string): SuggestionResponse | null {
    const cached = this.cache.get(key)
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      return cached.data
    }
    this.cache.delete(key)
    return null
  }

  set(key: string, data: SuggestionResponse): void {
    // Limitar tamanho do cache
    if (this.cache.size > 100) {
      const firstKey = this.cache.keys().next().value
      this.cache.delete(firstKey)
    }

    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    })
  }

  clear(): void {
    this.cache.clear()
  }
}

// Histórico de consultas para evitar chamadas repetidas
class QueryHistory {
  private queries: string[] = []
  private readonly MAX_HISTORY = 20

  // Verifica se uma consulta é significativamente diferente das anteriores
  isSignificantlyDifferent(query: string): boolean {
    // Sempre permitir a primeira consulta
    if (this.queries.length === 0) {
      this.addQuery(query)
      return true
    }

    // Verificar se a consulta é uma extensão significativa da anterior
    const lastQuery = this.queries[this.queries.length - 1]

    // Se a consulta for menor que a anterior, é uma nova consulta
    if (query.length < lastQuery.length) {
      this.addQuery(query)
      return true
    }

    // Se a consulta for igual, não é significativa
    if (query === lastQuery) {
      return false
    }

    // Se a consulta for uma extensão da anterior com pelo menos 3 caracteres novos
    // ou se adicionar uma nova palavra/número
    if (
      query.startsWith(lastQuery) &&
      (query.length >= lastQuery.length + 3 || this.containsNewWordOrNumber(query, lastQuery))
    ) {
      this.addQuery(query)
      return true
    }

    // Se a consulta contiver palavras-chave novas (rua, avenida, número, etc)
    const keywords = ["rua", "av", "avenida", "n°", "número", "alameda", "travessa", "praça", "rodovia", "estrada"]
    for (const keyword of keywords) {
      if (query.toLowerCase().includes(keyword) && !lastQuery.toLowerCase().includes(keyword)) {
        this.addQuery(query)
        return true
      }
    }

    return false
  }

  // Verifica se a nova consulta adiciona uma nova palavra ou número
  private containsNewWordOrNumber(newQuery: string, oldQuery: string): boolean {
    // Verificar se adicionou um novo número
    const oldNumbers = oldQuery.match(/\d+/g) || []
    const newNumbers = newQuery.match(/\d+/g) || []

    if (newNumbers.length > oldNumbers.length) {
      return true
    }

    // Verificar se adicionou uma nova palavra
    const oldWords = oldQuery.split(/\s+/)
    const newWords = newQuery.split(/\s+/)

    return newWords.length > oldWords.length
  }

  private addQuery(query: string): void {
    this.queries.push(query)

    // Manter o histórico limitado
    if (this.queries.length > this.MAX_HISTORY) {
      this.queries.shift()
    }
  }

  clear(): void {
    this.queries = []
  }
}

// Controle de requisições para evitar chamadas excessivas
class RequestController {
  private lastRequestTime = 0
  private readonly MIN_REQUEST_INTERVAL = 2000 // 2 segundos entre requisições
  private activeRequests = 0
  private readonly MAX_CONCURRENT_REQUESTS = 1

  canMakeRequest(): boolean {
    const now = Date.now()

    // Verificar intervalo mínimo
    if (now - this.lastRequestTime < this.MIN_REQUEST_INTERVAL) {
      return false
    }

    // Verificar requisições concorrentes
    if (this.activeRequests >= this.MAX_CONCURRENT_REQUESTS) {
      return false
    }

    return true
  }

  startRequest(): void {
    this.lastRequestTime = Date.now()
    this.activeRequests++
  }

  endRequest(): void {
    this.activeRequests = Math.max(0, this.activeRequests - 1)
  }

  reset(): void {
    this.lastRequestTime = 0
    this.activeRequests = 0
  }
}

export class AddressSuggestionsService {
  private static cache = new SuggestionsCache()
  private static queryHistory = new QueryHistory()
  private static requestController = new RequestController()
  private static readonly MIN_QUERY_LENGTH = 3
  private static isInitialized = false
  private static pendingRequests = new Map<string, Promise<SuggestionResponse>>()

  // Inicializar serviço
  private static initialize(): void {
    if (this.isInitialized) return

    this.isInitialized = true
    this.cache.clear()
    this.queryHistory.clear()
    this.requestController.reset()
    this.pendingRequests.clear()

    console.log("[ADDRESS_SUGGESTIONS] Serviço inicializado")
  }

  // Buscar sugestões de endereço
  static async getSuggestions(query: string): Promise<SuggestionResponse> {
    // Inicializar se necessário
    if (!this.isInitialized) {
      this.initialize()
    }

    console.log(`[ADDRESS_SUGGESTIONS] Buscando sugestões para: "${query}"`)

    // Validações básicas
    if (!query || query.trim().length < this.MIN_QUERY_LENGTH) {
      return {
        suggestions: [],
        status: "NO_RESULTS",
        error: "Consulta muito curta",
      }
    }

    const normalizedQuery = query.trim().toLowerCase()
    const cacheKey = `suggestions_${normalizedQuery}`

    // Verificar cache primeiro
    const cached = this.cache.get(cacheKey)
    if (cached) {
      console.log(`[ADDRESS_SUGGESTIONS] Cache hit para: "${query}"`)
      return cached
    }

    // Verificar se já existe uma requisição pendente para esta consulta
    if (this.pendingRequests.has(cacheKey)) {
      console.log(`[ADDRESS_SUGGESTIONS] Requisição pendente para: "${query}"`)
      return this.pendingRequests.get(cacheKey)!
    }

    // Verificar se a consulta é significativamente diferente
    if (!this.queryHistory.isSignificantlyDifferent(normalizedQuery)) {
      return {
        suggestions: [],
        status: "NO_RESULTS",
        error: "Continue digitando para obter sugestões",
      }
    }

    // Verificar se pode fazer nova requisição
    if (!this.requestController.canMakeRequest()) {
      return {
        suggestions: [],
        status: "RATE_LIMITED",
        error: "Aguarde um momento antes de buscar novas sugestões",
      }
    }

    // Iniciar requisição
    this.requestController.startRequest()

    // Criar promessa para a requisição
    const requestPromise = this.fetchSuggestions(normalizedQuery).finally(() => {
      // Remover da lista de requisições pendentes
      this.pendingRequests.delete(cacheKey)
      // Finalizar requisição
      this.requestController.endRequest()
    })

    // Armazenar promessa para evitar requisições duplicadas
    this.pendingRequests.set(cacheKey, requestPromise)

    return requestPromise
  }

  // Função interna para buscar sugestões
  private static async fetchSuggestions(query: string): Promise<SuggestionResponse> {
    try {
      console.log(`[ADDRESS_SUGGESTIONS] Fazendo requisição HTTP para: "${query}"`)

      // Fazer requisição para a API
      const response = await fetch(
        `/api/maps/autocomplete?input=${encodeURIComponent(query)}&types=address&language=pt-BR&components=country:br`,
        {
          // Adicionar cabeçalhos para evitar cache do navegador
          headers: {
            "Cache-Control": "no-cache, no-store, must-revalidate",
            Pragma: "no-cache",
            Expires: "0",
          },
        },
      )

      console.log(`[ADDRESS_SUGGESTIONS] Resposta HTTP: ${response.status} ${response.statusText}`)

      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()
      console.log(`[ADDRESS_SUGGESTIONS] Dados recebidos:`, {
        status: data.status,
        predictions_count: data.predictions?.length || 0,
        error: data.error,
        debug: data.debug,
      })

      // Processar resposta
      const result = this.processApiResponse(data, query)

      // Cachear apenas resultados bem-sucedidos
      if (result.status === "OK") {
        this.cache.set(`suggestions_${query}`, result)
      }

      return result
    } catch (error) {
      console.error("[ADDRESS_SUGGESTIONS] Erro ao buscar sugestões:", error)

      return {
        suggestions: [],
        status: "ERROR",
        error: "Erro ao buscar sugestões. Tente novamente.",
        debug: {
          error: error instanceof Error ? error.message : "Unknown error",
          timestamp: new Date().toISOString(),
        },
      }
    }
  }

  // Processar resposta da API
  private static processApiResponse(data: any, originalQuery: string): SuggestionResponse {
    if (!data) {
      return {
        suggestions: [],
        status: "ERROR",
        error: "Resposta inválida da API",
        debug: data?.debug,
      }
    }

    // Verificar status da API
    if (data.status !== "OK") {
      const errorMessages = {
        ZERO_RESULTS: "Nenhum endereço encontrado",
        OVER_QUERY_LIMIT: "Limite de consultas excedido",
        REQUEST_DENIED: "Acesso negado à API - verifique a configuração",
        INVALID_REQUEST: "Consulta inválida",
        TIMEOUT: "Timeout na consulta",
        NETWORK_ERROR: "Erro de rede",
        UNKNOWN_ERROR: "Erro desconhecido",
        SERVER_ERROR: "Erro interno do servidor",
      }

      return {
        suggestions: [],
        status: "API_ERROR",
        error: errorMessages[data.status as keyof typeof errorMessages] || data.error || "Erro desconhecido",
        debug: data?.debug,
      }
    }

    // Processar predictions
    if (!Array.isArray(data.predictions)) {
      return {
        suggestions: [],
        status: "NO_RESULTS",
        debug: data?.debug,
      }
    }

    const suggestions: AddressSuggestion[] = data.predictions
      .filter((prediction: any) => prediction && prediction.description)
      .map((prediction: any) => {
        const structured = prediction.structured_formatting || {}

        return {
          place_id: prediction.place_id,
          description: prediction.description,
          main_text: structured.main_text || prediction.description,
          secondary_text: structured.secondary_text || "",
          types: prediction.types || [],
          confidence: this.calculateConfidence(originalQuery, prediction.description),
        }
      })
      .sort((a, b) => b.confidence - a.confidence) // Ordenar por confiança
      .slice(0, 5) // Limitar a 5 sugestões

    return {
      suggestions,
      status: suggestions.length > 0 ? "OK" : "NO_RESULTS",
      hasMore: data.predictions.length > 5,
      debug: data?.debug,
    }
  }

  // Calcular confiança da sugestão
  private static calculateConfidence(query: string, suggestion: string): number {
    const queryWords = query.toLowerCase().split(/\s+/)
    const suggestionWords = suggestion.toLowerCase().split(/\s+/)

    let matches = 0
    queryWords.forEach((queryWord) => {
      if (
        suggestionWords.some(
          (suggestionWord) => suggestionWord.includes(queryWord) || queryWord.includes(suggestionWord),
        )
      ) {
        matches++
      }
    })

    return matches / queryWords.length
  }

  // Verificar se o serviço está disponível
  static async isServiceAvailable(): Promise<boolean> {
    try {
      const response = await fetch("/api/maps/autocomplete?input=test")
      return response.ok
    } catch {
      return false
    }
  }

  // Limpar cache e histórico
  static reset(): void {
    this.cache.clear()
    this.queryHistory.clear()
    this.requestController.reset()
    this.pendingRequests.clear()
    this.isInitialized = true
    console.log("[ADDRESS_SUGGESTIONS] Serviço resetado")
  }
}
