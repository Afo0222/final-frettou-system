import type { TipoServico } from "./database"

export interface CalculoOrcamento {
  id: string
  tipo_servico_id: string
  tipo_servico?: TipoServico
  distancia_km: number
  tempo_estimado_horas: number
  valor_base: number
  valor_distancia: number
  valor_tempo: number
  valor_ajudantes: number
  valor_servicos_extras: number
  valor_total: number
  created_at: string
  servicos_extras?: any[]
  // Campos para ajuste manual
  valor_ajustado_manualmente?: boolean
  valor_original?: number
  motivo_ajuste?: string
  diferenca_ajuste?: number
}
