// Definição básica dos tipos para o banco de dados
export interface Database {
  public: {
    Tables: {
      clientes: {
        Row: Cliente
        Insert: Omit<Cliente, "id" | "created_at" | "updated_at">
        Update: Partial<Omit<Cliente, "id" | "created_at" | "updated_at">>
      }
      tipos_servico: {
        Row: TipoServico
        Insert: Omit<TipoServico, "id" | "created_at">
        Update: Partial<Omit<TipoServico, "id" | "created_at">>
      }
      orcamentos: {
        Row: Orcamento
        Insert: Omit<Orcamento, "id" | "created_at" | "updated_at">
        Update: Partial<Omit<Orcamento, "id" | "created_at" | "updated_at">>
      }
      // Adicione outras tabelas conforme necessário
    }
  }
}

export interface Cliente {
  id: string
  nome: string
  telefone: string
  email?: string
  documento?: string
  endereco?: string
  observacoes?: string
  created_at?: string
  updated_at?: string
}

export interface TipoServico {
  id: string
  nome: string
  descricao?: string
  valor_base: number
  valor_km?: number
  valor_hora?: number
  ativo: boolean
  created_at?: string
}

export interface Veiculo {
  id: string
  modelo: string
  marca: string
  placa: string
  ano: number
  cor?: string
  chassi?: string
  renavam?: string
  capacidade_peso: number
  capacidade_volume: number
  tipo_veiculo: "caminhao" | "van" | "pickup" | "moto" | "bicicleta" | "outro"
  categoria_cnh: "A" | "B" | "C" | "D" | "E"
  combustivel: "gasolina" | "etanol" | "diesel" | "flex" | "gnv" | "eletrico" | "hibrido"
  consumo_medio?: number
  motorista_id?: string
  proprietario: "empresa" | "terceiro" | "motorista"
  valor_fipe?: number
  seguro_vigente: boolean
  vencimento_seguro?: string
  ipva_pago: boolean
  vencimento_ipva?: string
  licenciamento_vigente: boolean
  vencimento_licenciamento?: string
  manutencao_preventiva?: string
  proxima_revisao?: string
  km_atual: number
  observacoes?: string
  ativo: boolean
  created_at: string
  updated_at: string
  motorista?: {
    id: string
    nome: string
    cnh: string
    categoria_cnh: string
  }
}

export interface VariavelCusto {
  id: string
  tipo_servico_id: string
  nome: string
  valor: number
  unidade?: string
  descricao?: string
  ativo: boolean
  created_at: string
  updated_at: string
}

export interface Orcamento {
  id: string
  cliente_id?: string
  tipo_servico_id: string
  endereco_origem: string
  observacoes_origem?: string
  endereco_destino: string
  observacoes_destino?: string
  data_agendada: string
  hora_agendada: string
  ajudantes_adicionais: number
  servicos_extras?: string[]
  observacoes?: string
  valor_final: number
  status: "rascunho" | "enviado" | "aprovado" | "rejeitado" | "cancelado"
  created_at?: string
  updated_at?: string
}

export interface Agendamento {
  id: string
  orcamento_id: string
  motorista_id?: string
  veiculo_id?: string
  data_agendada: string
  hora_agendada: string
  status: "agendado" | "confirmado" | "em_andamento" | "concluido" | "cancelado"
  observacoes?: string
  created_at: string
  updated_at: string
  orcamento?: Orcamento
}

export interface Rota {
  id: string
  agendamento_id: string
  numero_rota: string
  status: "pendente" | "em_coleta" | "em_rota" | "entregue" | "concluida" | "cancelada"
  distancia_km?: number
  tempo_real_minutos?: number
  hora_inicio?: string
  hora_coleta?: string
  hora_entrega?: string
  hora_conclusao?: string
  localizacao_atual?: any
  observacoes_motorista?: string
  assinatura_cliente?: string
  fotos?: any[]
  avaliacao_cliente?: number
  comentario_cliente?: string
  created_at: string
  updated_at: string
  agendamento?: Agendamento
}

export interface Profile {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  role: "admin" | "operador" | "motorista"
  phone?: string
  created_at: string
  updated_at: string
}

export interface Motorista {
  id: string
  nome: string
  cpf: string
  rg?: string
  cnh: string
  categoria_cnh: "A" | "B" | "C" | "D" | "E"
  vencimento_cnh: string
  telefone: string
  email?: string
  endereco?: string
  data_nascimento?: string
  data_admissao?: string
  salario?: number
  comissao_percentual?: number
  banco?: string
  agencia?: string
  conta?: string
  pix?: string
  observacoes?: string
  ativo: boolean
  created_at: string
  updated_at: string
}

export interface CalculoOrcamento {
  tipo_servico?: TipoServico
  distancia_km: number
  tempo_estimado_horas: number
  valor_base: number
  valor_distancia: number
  valor_tempo: number
  valor_ajudantes: number
  valor_servicos_extras: number
  valor_total: number
}
