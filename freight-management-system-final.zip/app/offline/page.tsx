"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { WifiOff, RefreshCw } from "lucide-react"
import Link from "next/link"

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <WifiOff className="h-8 w-8 mx-auto mb-2 text-gray-500" />
          <CardTitle>You are offline</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={() => window.location.reload()} className="w-full">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try again
          </Button>

          <Link href="/" className="block w-full">
            <Button variant="outline" className="w-full">
              Home
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
