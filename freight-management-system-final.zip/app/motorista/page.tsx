"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/layout/header"
import { Sidebar } from "@/components/layout/sidebar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { useGeolocation } from "@/hooks/use-geolocation"
import { NavigationService } from "@/lib/services/navigation"
import { WhatsAppService } from "@/lib/services/whatsapp"
import { ComprovanteService } from "@/lib/services/comprovantes"
import { CustomerRating } from "@/components/driver/customer-rating"
import { SignatureCapture } from "@/components/driver/signature-capture"
import { supabase } from "@/lib/supabase/client"
import {
  Truck,
  MapPin,
  Clock,
  Phone,
  MessageSquare,
  Navigation,
  CheckCircle,
  Package,
  Calendar,
  AlertTriangle,
  PlayCircle,
  FileText,
  RefreshCw,
} from "lucide-react"

// Tipos para as rotas
interface RouteItem {
  id: string
  cliente_nome: string
  cliente_telefone: string | null
  tipo_servico: string
  endereco_origem: string
  endereco_destino: string
  data_agendada: string
  hora_agendada: string
  hora_inicio?: string
  hora_fim?: string
  status: string
  valor_servico?: number
  observacoes?: string
  distancia_km?: number
  tempo_viagem_minutos?: number
  duracao_estimada_minutos?: number
  prioridade?: string
}

// Interface para armazenar os tempos localmente
interface TimeTracking {
  [routeId: string]: {
    hora_inicio?: string
    hora_fim?: string
  }
}

export default function DriverDashboard() {
  const { toast } = useToast()
  const geolocation = useGeolocation()

  // Estados
  const [routes, setRoutes] = useState<RouteItem[]>([])
  const [loading, setLoading] = useState(true)
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [showSignatureDialog, setShowSignatureDialog] = useState(false)
  const [currentRoute, setCurrentRoute] = useState<RouteItem | null>(null)
  const [currentSignature, setCurrentSignature] = useState<string>("")
  const [timeTracking, setTimeTracking] = useState<TimeTracking>({})
  const [driverInfo] = useState({
    name: "Carlos Motorista",
    company: "FreteSystem",
  })

  // Carregar agendamentos do banco
  const loadAgendamentos = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from("agendamentos")
        .select("*")
        .order("data_agendada", { ascending: true })
        .order("hora_agendada", { ascending: true })

      if (error) throw error

      setRoutes(data || [])
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error)
      toast({
        title: "Erro",
        description: "Nao foi possivel carregar os agendamentos",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAgendamentos()
  }, [])

  // Funcao para atualizar o status de uma rota - versao simplificada que so atualiza o status
  const updateRouteStatus = async (routeId: string, newStatus: string) => {
    try {
      // Apenas atualizamos o status e o timestamp - campos que sabemos que existem
      const updateData = {
        status: newStatus,
        updated_at: new Date().toISOString(),
      }

      // Atualizar o banco de dados apenas com os campos seguros
      const { error } = await supabase.from("agendamentos").update(updateData).eq("id", routeId)

      if (error) throw error

      // Obter o horario atual para rastreamento local
      const now = new Date().toTimeString().split(" ")[0]

      // Atualizar o rastreamento de tempo local
      if (newStatus === "em_andamento") {
        setTimeTracking((prev) => ({
          ...prev,
          [routeId]: {
            ...prev[routeId],
            hora_inicio: now,
          },
        }))
      } else if (newStatus === "concluido") {
        setTimeTracking((prev) => ({
          ...prev,
          [routeId]: {
            ...prev[routeId],
            hora_fim: now,
          },
        }))
      }

      // Atualizar estado local
      setRoutes((prevRoutes) =>
        prevRoutes.map((route) => {
          if (route.id === routeId) {
            // Combinar os dados da rota com os dados de atualizacao e os tempos rastreados localmente
            return {
              ...route,
              ...updateData,
              hora_inicio: timeTracking[routeId]?.hora_inicio || route.hora_inicio,
              hora_fim: timeTracking[routeId]?.hora_fim || route.hora_fim,
            }
          }
          return route
        }),
      )

      // Enviar mensagem WhatsApp automatica
      const route = routes.find((r) => r.id === routeId)
      if (route && route.cliente_telefone) {
        const messageData = {
          nomeMotorista: driverInfo.name,
          nomeEmpresa: driverInfo.company,
          enderecoRetirada: route.endereco_origem,
          enderecoEntrega: route.endereco_destino,
          tipoServico: route.tipo_servico,
          tempoEstimado: 30,
        }

        let message = ""
        switch (newStatus) {
          case "em_andamento":
            message = WhatsAppService.getInicioColetaMessage(messageData)
            break
          case "concluido":
            message = WhatsAppService.getEntregaConcluidaMessage(messageData)
            break
        }

        if (message) {
          toast({
            title: "Mensagem preparada",
            description: "Clique em WhatsApp para enviar a mensagem automatica",
          })
        }
      }

      toast({
        title: "Status atualizado",
        description: `Rota atualizada para ${newStatus}`,
      })
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      toast({
        title: "Erro",
        description: "Nao foi possivel atualizar o status",
        variant: "destructive",
      })
    }
  }

  // Funcao para navegar ate o endereco
  const navigateToAddress = (address: string, isRoute = false, origin?: string) => {
    try {
      if (isRoute && origin) {
        NavigationService.openGoogleMapsWithWaypoints(origin, address)
      } else if (geolocation.latitude && geolocation.longitude) {
        NavigationService.openGoogleMapsFromCurrentLocation(address)
      } else {
        NavigationService.openGoogleMaps(address)
      }

      toast({
        title: "Navegacao iniciada",
        description: "Google Maps foi aberto com a rota",
      })
    } catch (error) {
      toast({
        title: "Erro",
        description: "Nao foi possivel abrir o Google Maps",
        variant: "destructive",
      })
    }
  }

  // Funcao para fazer ligacao
  const makePhoneCall = (phoneNumber: string | null) => {
    try {
      if (!phoneNumber) {
        toast({
          title: "Telefone nao disponivel",
          description: "Este cliente nao possui telefone cadastrado",
          variant: "destructive",
        })
        return
      }
      NavigationService.makePhoneCall(phoneNumber)
    } catch (error) {
      toast({
        title: "Erro",
        description: "Nao foi possivel fazer a ligacao",
        variant: "destructive",
      })
    }
  }

  // Funcao para enviar WhatsApp
  const sendWhatsApp = (route: RouteItem, messageType: "chegando_retirada" | "chegando_entrega" | "atraso") => {
    try {
      // Validar se o telefone existe
      if (!route.cliente_telefone) {
        toast({
          title: "WhatsApp nao disponivel",
          description: "Este cliente nao possui telefone cadastrado",
          variant: "destructive",
        })
        return
      }

      const messageData = {
        nomeMotorista: driverInfo.name,
        nomeEmpresa: driverInfo.company,
        enderecoRetirada: route.endereco_origem,
        enderecoEntrega: route.endereco_destino,
        tipoServico: route.tipo_servico,
        tempoEstimado: 5,
        atraso: 15,
      }

      let message = ""
      switch (messageType) {
        case "chegando_retirada":
          message = WhatsAppService.getChegandoRetiradaMessage(messageData)
          break
        case "chegando_entrega":
          message = WhatsAppService.getChegandoEntregaMessage(messageData)
          break
        case "atraso":
          message = WhatsAppService.getAtrasoMessage(messageData)
          break
      }

      WhatsAppService.sendMessage(route.cliente_telefone, message)

      toast({
        title: "WhatsApp aberto",
        description: "Mensagem preparada para envio",
      })
    } catch (error) {
      console.error("Erro ao enviar WhatsApp:", error)
      toast({
        title: "Erro no WhatsApp",
        description: error instanceof Error ? error.message : "Nao foi possivel abrir o WhatsApp",
        variant: "destructive",
      })
    }
  }

  // Funcao para finalizar rota
  const finalizeRoute = (route: RouteItem) => {
    setCurrentRoute(route)
    setShowSignatureDialog(true)
  }

  // Funcao para salvar assinatura
  const handleSignatureSave = (signature: string) => {
    setCurrentSignature(signature)
    setShowSignatureDialog(false)
    setShowRatingDialog(true)
  }

  // Funcao para salvar avaliacao
  const handleRatingSave = async (rating: number, comment: string) => {
    if (!currentRoute) {
      toast({
        title: "Erro",
        description: "Nenhuma rota selecionada",
        variant: "destructive",
      })
      return
    }

    try {
      // Validar dados obrigatorios da rota
      if (
        !currentRoute.cliente_nome ||
        !currentRoute.endereco_origem ||
        !currentRoute.endereco_destino ||
        !currentRoute.tipo_servico
      ) {
        toast({
          title: "Dados incompletos",
          description: "A rota nao possui todos os dados necessarios para gerar o comprovante",
          variant: "destructive",
        })
        return
      }

      // Gerar comprovante com dados validados
      const comprovanteData = {
        rotaId: currentRoute.id,
        clienteNome: currentRoute.cliente_nome,
        enderecoRetirada: currentRoute.endereco_origem,
        enderecoEntrega: currentRoute.endereco_destino,
        tipoServico: currentRoute.tipo_servico,
        dataEntrega: new Date().toLocaleDateString("pt-BR").replace(/[^\x00-\x7F]/g, ""),
        horaEntrega: new Date().toLocaleTimeString("pt-BR").replace(/[^\x00-\x7F]/g, ""),
        motoristaNome: driverInfo.name,
        assinaturaCliente: currentSignature,
        avaliacaoCliente: rating > 0 ? rating : undefined,
        comentarioCliente: comment || undefined,
        valorTotal: currentRoute.valor_servico,
        observacoes: currentRoute.observacoes,
      }

      console.log("Gerando comprovante com dados:", comprovanteData)

      await ComprovanteService.gerarComprovante(comprovanteData)

      // Enviar para financeiro apenas se houver valor
      if (currentRoute.valor_servico && currentRoute.valor_servico > 0) {
        await ComprovanteService.enviarParaFinanceiro(currentRoute.id, currentRoute.valor_servico)
      }

      // Atualizar status para concluido
      await updateRouteStatus(currentRoute.id, "concluido")

      setShowRatingDialog(false)
      setCurrentRoute(null)
      setCurrentSignature("")

      toast({
        title: "Rota finalizada",
        description: "Comprovante gerado e dados enviados para o financeiro",
      })
    } catch (error) {
      console.error("Erro ao finalizar rota:", error)
      toast({
        title: "Erro ao finalizar",
        description: error instanceof Error ? error.message : "Erro desconhecido ao finalizar rota",
        variant: "destructive",
      })
    }
  }

  // Calcular progresso baseado no status e tempos rastreados
  const getProgress = (route: RouteItem) => {
    const routeTimes = timeTracking[route.id] || {}

    switch (route.status) {
      case "agendado":
      case "confirmado":
        return 0
      case "em_andamento":
        return routeTimes.hora_inicio || route.hora_inicio ? 50 : 25
      case "concluido":
        return 100
      default:
        return 0
    }
  }

  // Filtrar rotas por status
  const pendingRoutes = routes.filter((route) => ["agendado", "confirmado"].includes(route.status))
  const activeRoutes = routes.filter((route) => route.status === "em_andamento")
  const completedRoutes = routes.filter((route) => route.status === "concluido")

  // Funcao para renderizar o status da rota
  const renderRouteStatus = (status: string) => {
    switch (status) {
      case "agendado":
        return <Badge variant="secondary">Agendado</Badge>
      case "confirmado":
        return <Badge className="bg-blue-500">Confirmado</Badge>
      case "em_andamento":
        return <Badge className="bg-orange-500">Em Andamento</Badge>
      case "concluido":
        return <Badge className="bg-green-500">Concluido</Badge>
      case "cancelado":
        return <Badge variant="destructive">Cancelado</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Funcao para renderizar as acoes disponiveis com base no status
  const renderRouteActions = (route: RouteItem) => {
    switch (route.status) {
      case "agendado":
      case "confirmado":
        return (
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={() => updateRouteStatus(route.id, "em_andamento")}
            >
              <PlayCircle className="mr-1 h-4 w-4" />
              Iniciar Coleta
            </Button>
          </div>
        )
      case "em_andamento":
        return (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" className="flex-1" onClick={() => finalizeRoute(route)}>
              <CheckCircle className="mr-1 h-4 w-4" />
              Finalizar Rota
            </Button>
            <Button size="sm" variant="destructive" className="flex-1" onClick={() => sendWhatsApp(route, "atraso")}>
              <AlertTriangle className="mr-1 h-4 w-4" />
              Reportar Atraso
            </Button>
          </div>
        )
      case "concluido":
        return (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" className="flex-1" disabled>
              <CheckCircle className="mr-1 h-4 w-4" />
              Concluido
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={() =>
                ComprovanteService.gerarPDF({
                  rotaId: route.id,
                  clienteNome: route.cliente_nome,
                  enderecoRetirada: route.endereco_origem,
                  enderecoEntrega: route.endereco_destino,
                  tipoServico: route.tipo_servico,
                  dataEntrega: new Date().toLocaleDateString("pt-BR").replace(/[^\x00-\x7F]/g, ""),
                  horaEntrega: new Date().toLocaleTimeString("pt-BR").replace(/[^\x00-\x7F]/g, ""),
                  motoristaNome: driverInfo.name,
                  valorTotal: route.valor_servico,
                })
              }
            >
              <FileText className="mr-1 h-4 w-4" />
              Comprovante
            </Button>
          </div>
        )
      default:
        return null
    }
  }

  // Componente para renderizar um cartao de rota
  const RouteCard = ({ route }: { route: RouteItem }) => {
    const progress = getProgress(route)
    const routeTimes = timeTracking[route.id] || {}
    const hasPhone = route.cliente_telefone && route.cliente_telefone.trim() !== ""

    return (
      <Card className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{route.cliente_nome.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-base">{route.cliente_nome}</CardTitle>
                <p className="text-xs text-muted-foreground">{route.tipo_servico}</p>
              </div>
            </div>
            <div className="flex flex-col items-end">
              {renderRouteStatus(route.status)}
              <p className="text-xs text-muted-foreground mt-1">#{route.id.slice(-8)}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pb-2">
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
              <div className="space-y-1">
                <p className="text-sm font-medium">Retirada:</p>
                <p className="text-sm">{route.endereco_origem}</p>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <MapPin className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
              <div className="space-y-1">
                <p className="text-sm font-medium">Entrega:</p>
                <p className="text-sm">{route.endereco_destino}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <p className="text-sm">
                  {new Date(route.data_agendada).toLocaleDateString("pt-BR").replace(/[^\x00-\x7F]/g, "")}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <p className="text-sm">{route.hora_agendada}</p>
              </div>
            </div>

            {/* Indicador de telefone */}
            <div className="flex items-center gap-2">
              <Phone className={`h-4 w-4 ${hasPhone ? "text-green-500" : "text-muted-foreground"}`} />
              <p className="text-sm">{hasPhone ? route.cliente_telefone : "Telefone nao cadastrado"}</p>
            </div>

            {route.distancia_km && route.tempo_viagem_minutos && (
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2">
                  <Truck className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm">{route.distancia_km} km</p>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm">{route.tempo_viagem_minutos} min</p>
                </div>
              </div>
            )}

            {route.observacoes && (
              <div className="flex items-start gap-2">
                <Package className="h-4 w-4 text-muted-foreground mt-0.5" />
                <p className="text-sm">{route.observacoes}</p>
              </div>
            )}

            {route.valor_servico && (
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Valor: R$ {route.valor_servico.toFixed(2)}</span>
              </div>
            )}

            {route.status === "em_andamento" && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>Progresso</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}
          </div>
        </CardContent>

        <CardFooter className="flex flex-col gap-3 pt-2">
          {/* Botoes de comunicacao e navegacao */}
          <div className="grid grid-cols-2 gap-2 w-full">
            <Button
              size="sm"
              variant="outline"
              onClick={() => makePhoneCall(route.cliente_telefone)}
              disabled={!hasPhone}
            >
              <Phone className="mr-1 h-4 w-4" />
              Ligar
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                const messageType = route.status === "em_andamento" ? "chegando_entrega" : "chegando_retirada"
                sendWhatsApp(route, messageType)
              }}
              disabled={!hasPhone}
            >
              <MessageSquare className="mr-1 h-4 w-4" />
              WhatsApp
            </Button>
          </div>

          {/* Botoes de navegacao */}
          <div className="grid grid-cols-2 gap-2 w-full">
            <Button size="sm" variant="outline" onClick={() => navigateToAddress(route.endereco_origem)}>
              <Navigation className="mr-1 h-4 w-4" />
              Como Chegar
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => navigateToAddress(route.endereco_destino, true, route.endereco_origem)}
            >
              <Truck className="mr-1 h-4 w-4" />
              Iniciar Rota
            </Button>
          </div>

          {/* Acoes especificas do status */}
          {renderRouteActions(route)}
        </CardFooter>
      </Card>
    )
  }

  if (loading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 lg:ml-64">
          <Header />
          <main className="flex-1 p-4 lg:p-6">
            <div className="flex items-center justify-center h-64">
              <RefreshCw className="h-8 w-8 animate-spin" />
            </div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />

      <div className="flex-1 lg:ml-64">
        <Header />

        <main className="flex-1 p-4 lg:p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Painel do Motorista</h1>
              <p className="text-muted-foreground">
                Gerencie suas rotas e entregas
                {geolocation.latitude && geolocation.longitude && (
                  <span className="ml-2 text-green-600">Localizacao ativa</span>
                )}
              </p>
            </div>
            <Button variant="outline" onClick={loadAgendamentos}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Atualizar
            </Button>
          </div>

          <Tabs defaultValue="active" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="active" className="flex gap-2 items-center">
                <Truck className="h-4 w-4" />
                <span className="hidden sm:inline">Ativas</span>
                <Badge variant="secondary" className="ml-1">
                  {activeRoutes.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="scheduled" className="flex gap-2 items-center">
                <Calendar className="h-4 w-4" />
                <span className="hidden sm:inline">Agendadas</span>
                <Badge variant="secondary" className="ml-1">
                  {pendingRoutes.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="completed" className="flex gap-2 items-center">
                <CheckCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Concluidas</span>
                <Badge variant="secondary" className="ml-1">
                  {completedRoutes.length}
                </Badge>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="space-y-4">
              {activeRoutes.length > 0 ? (
                activeRoutes.map((route) => <RouteCard key={route.id} route={route} />)
              ) : (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <Truck className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Nenhuma rota ativa</h3>
                  <p className="text-muted-foreground mt-1">Voce nao possui rotas em andamento no momento.</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="scheduled" className="space-y-4">
              {pendingRoutes.length > 0 ? (
                pendingRoutes.map((route) => <RouteCard key={route.id} route={route} />)
              ) : (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Nenhuma rota agendada</h3>
                  <p className="text-muted-foreground mt-1">Voce nao possui rotas agendadas no momento.</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="completed" className="space-y-4">
              {completedRoutes.length > 0 ? (
                completedRoutes.map((route) => <RouteCard key={route.id} route={route} />)
              ) : (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <CheckCircle className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Nenhuma rota concluida</h3>
                  <p className="text-muted-foreground mt-1">Voce ainda nao concluiu nenhuma rota.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* Dialog para captura de assinatura */}
      <Dialog open={showSignatureDialog} onOpenChange={setShowSignatureDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Capturar Assinatura</DialogTitle>
          </DialogHeader>
          <SignatureCapture onSave={handleSignatureSave} onCancel={() => setShowSignatureDialog(false)} />
        </DialogContent>
      </Dialog>

      {/* Dialog para avaliacao do cliente */}
      <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Finalizar Entrega</DialogTitle>
          </DialogHeader>
          <CustomerRating onSubmit={handleRatingSave} onSkip={() => handleRatingSave(0, "")} />
        </DialogContent>
      </Dialog>
    </div>
  )
}
