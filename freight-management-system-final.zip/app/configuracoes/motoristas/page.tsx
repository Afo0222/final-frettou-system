"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import {
  Plus,
  Search,
  UserCog,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Car,
  AlertTriangle,
  CheckCircle,
  Edit,
  Trash2,
  Eye,
  FileText,
} from "lucide-react"
import { getMotoristas, createMotorista, updateMotorista, deleteMotorista } from "@/lib/services/motoristas"
import type { Motorista } from "@/lib/types/database"
import { DriverScheduleConfig } from "@/components/motoristas/driver-schedule-config"

// Mock data for immediate functionality
const mockMotoristas: Motorista[] = [
  {
    id: "1",
    nome: "Carlos Silva",
    telefone: "(11) 99999-1111",
    email: "carlos.silva@email.com",
    cnh: "12345678901",
    categoria_cnh: "D",
    vencimento_cnh: "2025-06-15",
    endereco: "Rua das Palmeiras, 123 - São Paulo, SP",
    data_nascimento: "1985-03-20",
    data_admissao: "2023-01-15",
    salario: 3500.0,
    observacoes: "Motorista experiente, especialista em cargas pesadas",
    ativo: true,
    veiculo_id: "veiculo-1",
    created_at: "2023-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "2",
    nome: "Ana Santos",
    telefone: "(11) 98888-2222",
    email: "ana.santos@email.com",
    cnh: "98765432109",
    categoria_cnh: "B",
    vencimento_cnh: "2024-12-30",
    endereco: "Av. Paulista, 456 - São Paulo, SP",
    data_nascimento: "1990-07-10",
    data_admissao: "2023-03-01",
    salario: 2800.0,
    observacoes: "Ótima para entregas urbanas, muito pontual",
    ativo: true,
    veiculo_id: null,
    created_at: "2023-03-01T14:30:00Z",
    updated_at: "2024-01-10T09:15:00Z",
  },
  {
    id: "3",
    nome: "Roberto Oliveira",
    telefone: "(11) 97777-3333",
    email: "roberto.oliveira@email.com",
    cnh: "11223344556",
    categoria_cnh: "E",
    vencimento_cnh: "2024-03-15",
    endereco: "Rua dos Caminhoneiros, 789 - Guarulhos, SP",
    data_nascimento: "1978-11-25",
    data_admissao: "2022-08-10",
    salario: 4200.0,
    observacoes: "Especialista em longas distâncias, CNH vencendo em breve",
    ativo: true,
    veiculo_id: "veiculo-2",
    created_at: "2022-08-10T16:45:00Z",
    updated_at: "2024-01-05T11:20:00Z",
  },
  {
    id: "4",
    nome: "Mariana Costa",
    telefone: "(11) 96666-4444",
    email: "mariana.costa@email.com",
    cnh: "55667788990",
    categoria_cnh: "C",
    vencimento_cnh: "2025-09-20",
    endereco: "Rua das Flores, 321 - Osasco, SP",
    data_nascimento: "1988-05-14",
    data_admissao: "2023-06-01",
    salario: 3200.0,
    observacoes: "Excelente para mudanças residenciais",
    ativo: false,
    veiculo_id: null,
    created_at: "2023-06-01T08:00:00Z",
    updated_at: "2024-01-20T15:30:00Z",
  },
]

interface MotoristaFormData {
  nome: string
  telefone: string
  email: string
  cnh: string
  categoria_cnh: string
  vencimento_cnh: string
  endereco: string
  data_nascimento: string
  data_admissao: string
  salario: number
  observacoes: string
  ativo: boolean
  veiculo_id: string | null
}

export default function MotoristasPage() {
  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [filteredMotoristas, setFilteredMotoristas] = useState<Motorista[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [cnhFilter, setCnhFilter] = useState<string>("all")
  const [selectedMotorista, setSelectedMotorista] = useState<Motorista | null>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [editingMotorista, setEditingMotorista] = useState<Motorista | null>(null)
  const { toast } = useToast()

  // Form state
  const [formData, setFormData] = useState<MotoristaFormData>({
    nome: "",
    telefone: "",
    email: "",
    cnh: "",
    categoria_cnh: "B",
    vencimento_cnh: "",
    endereco: "",
    data_nascimento: "",
    data_admissao: "",
    salario: 0,
    observacoes: "",
    ativo: true,
    veiculo_id: null,
  })

  useEffect(() => {
    loadMotoristas()
  }, [])

  useEffect(() => {
    filterMotoristas()
  }, [motoristas, searchTerm, statusFilter, cnhFilter])

  const loadMotoristas = async () => {
    try {
      setLoading(true)
      const data = await getMotoristas()
      setMotoristas(data.length > 0 ? data : mockMotoristas)
    } catch (error) {
      console.error("Erro ao carregar motoristas:", error)
      setMotoristas(mockMotoristas)
      toast({
        title: "Aviso",
        description: "Carregando dados de exemplo. Configure a integração com o banco de dados.",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterMotoristas = () => {
    let filtered = motoristas

    // Filtro por termo de busca
    if (searchTerm) {
      filtered = filtered.filter(
        (motorista) =>
          motorista.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
          motorista.telefone.includes(searchTerm) ||
          motorista.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          motorista.cnh.includes(searchTerm),
      )
    }

    // Filtro por status
    if (statusFilter !== "all") {
      if (statusFilter === "active") {
        filtered = filtered.filter((motorista) => motorista.ativo)
      } else if (statusFilter === "inactive") {
        filtered = filtered.filter((motorista) => !motorista.ativo)
      } else if (statusFilter === "available") {
        filtered = filtered.filter((motorista) => motorista.ativo && !motorista.veiculo_id)
      } else if (statusFilter === "assigned") {
        filtered = filtered.filter((motorista) => motorista.ativo && motorista.veiculo_id)
      } else if (statusFilter === "expiring") {
        const proximoMes = new Date()
        proximoMes.setMonth(proximoMes.getMonth() + 1)
        filtered = filtered.filter(
          (motorista) => motorista.vencimento_cnh && new Date(motorista.vencimento_cnh) <= proximoMes,
        )
      }
    }

    // Filtro por categoria CNH
    if (cnhFilter !== "all") {
      filtered = filtered.filter((motorista) => motorista.categoria_cnh === cnhFilter)
    }

    setFilteredMotoristas(filtered)
  }

  const resetForm = () => {
    setFormData({
      nome: "",
      telefone: "",
      email: "",
      cnh: "",
      categoria_cnh: "B",
      vencimento_cnh: "",
      endereco: "",
      data_nascimento: "",
      data_admissao: "",
      salario: 0,
      observacoes: "",
      ativo: true,
      veiculo_id: null,
    })
    setEditingMotorista(null)
  }

  const handleNewMotorista = () => {
    resetForm()
    setIsFormOpen(true)
  }

  const handleEditMotorista = (motorista: Motorista) => {
    setFormData({
      nome: motorista.nome,
      telefone: motorista.telefone,
      email: motorista.email,
      cnh: motorista.cnh,
      categoria_cnh: motorista.categoria_cnh,
      vencimento_cnh: motorista.vencimento_cnh,
      endereco: motorista.endereco,
      data_nascimento: motorista.data_nascimento,
      data_admissao: motorista.data_admissao,
      salario: motorista.salario,
      observacoes: motorista.observacoes || "",
      ativo: motorista.ativo,
      veiculo_id: motorista.veiculo_id,
    })
    setEditingMotorista(motorista)
    setIsFormOpen(true)
  }

  const handleViewMotorista = (motorista: Motorista) => {
    setSelectedMotorista(motorista)
    setIsDetailsOpen(true)
  }

  const handleSaveMotorista = async () => {
    try {
      if (editingMotorista) {
        await updateMotorista(editingMotorista.id, formData)
        toast({
          title: "Sucesso",
          description: "Motorista atualizado com sucesso!",
        })
      } else {
        await createMotorista(formData)
        toast({
          title: "Sucesso",
          description: "Motorista criado com sucesso!",
        })
      }
      await loadMotoristas()
      setIsFormOpen(false)
      resetForm()
    } catch (error) {
      console.error("Erro ao salvar motorista:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar o motorista.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteMotorista = async () => {
    if (!deleteId) return

    try {
      await deleteMotorista(deleteId)
      await loadMotoristas()
      setDeleteId(null)
      toast({
        title: "Sucesso",
        description: "Motorista removido com sucesso!",
      })
    } catch (error) {
      console.error("Erro ao remover motorista:", error)
      toast({
        title: "Erro",
        description: "Não foi possível remover o motorista.",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (motorista: Motorista) => {
    if (!motorista.ativo) {
      return <Badge variant="secondary">Inativo</Badge>
    }

    const hoje = new Date()
    const proximoMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate())
    const vencimentoCnh = new Date(motorista.vencimento_cnh)

    if (vencimentoCnh <= hoje) {
      return <Badge variant="destructive">CNH Vencida</Badge>
    }

    if (vencimentoCnh <= proximoMes) {
      return <Badge variant="destructive">CNH Vencendo</Badge>
    }

    if (motorista.veiculo_id) {
      return <Badge variant="default">Com Veículo</Badge>
    }

    return <Badge variant="outline">Disponível</Badge>
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const calculateAge = (birthDate: string) => {
    const today = new Date()
    const birth = new Date(birthDate)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return age
  }

  // Statistics
  const stats = {
    total: motoristas.length,
    ativos: motoristas.filter((m) => m.ativo).length,
    inativos: motoristas.filter((m) => !m.ativo).length,
    disponiveis: motoristas.filter((m) => m.ativo && !m.veiculo_id).length,
    comVeiculo: motoristas.filter((m) => m.ativo && m.veiculo_id).length,
    cnhVencendo: motoristas.filter((m) => {
      const proximoMes = new Date()
      proximoMes.setMonth(proximoMes.getMonth() + 1)
      return m.vencimento_cnh && new Date(m.vencimento_cnh) <= proximoMes
    }).length,
    salarioMedio:
      motoristas.length > 0
        ? motoristas.reduce((sum, m) => sum + m.salario, 0) / motoristas.filter((m) => m.ativo).length
        : 0,
  }

  if (loading) {
    return (
      <main className="flex-1 p-4 lg:p-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="h-8 w-48 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-96 bg-gray-200 rounded animate-pulse mt-2"></div>
            </div>
            <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"></div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-8 w-16 bg-gray-200 rounded animate-pulse"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="flex-1 p-4 lg:p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Motoristas</h1>
            <p className="text-muted-foreground">Gerencie a equipe de motoristas da empresa</p>
          </div>
          <Button onClick={handleNewMotorista}>
            <Plus className="mr-2 h-4 w-4" />
            Novo Motorista
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Motoristas</CardTitle>
              <UserCog className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">
                {stats.ativos} ativos, {stats.inativos} inativos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Disponíveis</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.disponiveis}</div>
              <p className="text-xs text-muted-foreground">Sem veículo designado</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Com Veículo</CardTitle>
              <Car className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.comVeiculo}</div>
              <p className="text-xs text-muted-foreground">Veículo designado</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">CNH Vencendo</CardTitle>
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{stats.cnhVencendo}</div>
              <p className="text-xs text-muted-foreground">Próximo mês</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Filtros e Busca</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nome, telefone, email ou CNH..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="active">Ativos</SelectItem>
                  <SelectItem value="inactive">Inativos</SelectItem>
                  <SelectItem value="available">Disponíveis</SelectItem>
                  <SelectItem value="assigned">Com veículo</SelectItem>
                  <SelectItem value="expiring">CNH vencendo</SelectItem>
                </SelectContent>
              </Select>

              <Select value={cnhFilter} onValueChange={setCnhFilter}>
                <SelectTrigger className="w-full sm:w-32">
                  <SelectValue placeholder="CNH" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                  <SelectItem value="E">E</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{filteredMotoristas.length} motorista(s) encontrado(s)</p>
        </div>

        {/* Motoristas Grid */}
        {filteredMotoristas.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <UserCog className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum motorista encontrado</h3>
              <p className="text-muted-foreground text-center mb-4">
                {searchTerm || statusFilter !== "all" || cnhFilter !== "all"
                  ? "Tente ajustar os filtros de busca"
                  : "Comece adicionando o primeiro motorista à equipe"}
              </p>
              {!searchTerm && statusFilter === "all" && cnhFilter === "all" && (
                <Button onClick={handleNewMotorista}>
                  <Plus className="mr-2 h-4 w-4" />
                  Adicionar Primeiro Motorista
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredMotoristas.map((motorista) => (
              <Card key={motorista.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${motorista.nome}`} />
                        <AvatarFallback>
                          {motorista.nome
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{motorista.nome}</CardTitle>
                        <CardDescription>CNH {motorista.categoria_cnh}</CardDescription>
                      </div>
                    </div>
                    {getStatusBadge(motorista)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{motorista.telefone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate">{motorista.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>CNH vence em {formatDate(motorista.vencimento_cnh)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span>Salário: {formatCurrency(motorista.salario)}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" onClick={() => handleViewMotorista(motorista)}>
                      <Eye className="h-4 w-4 mr-1" />
                      Ver
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleEditMotorista(motorista)}>
                      <Edit className="h-4 w-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDeleteId(motorista.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Excluir
                    </Button>
                    <DriverScheduleConfig motorista={motorista} onConfigUpdated={loadMotoristas} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingMotorista ? "Editar Motorista" : "Novo Motorista"}</DialogTitle>
            <DialogDescription>
              {editingMotorista ? "Atualize as informações do motorista" : "Adicione um novo motorista à equipe"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome Completo *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  placeholder="Nome completo do motorista"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone *</Label>
                <Input
                  id="telefone"
                  value={formData.telefone}
                  onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                  placeholder="(11) 99999-9999"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="email@exemplo.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cnh">CNH *</Label>
                <Input
                  id="cnh"
                  value={formData.cnh}
                  onChange={(e) => setFormData({ ...formData, cnh: e.target.value })}
                  placeholder="Número da CNH"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="categoria_cnh">Categoria CNH *</Label>
                <Select
                  value={formData.categoria_cnh}
                  onValueChange={(value) => setFormData({ ...formData, categoria_cnh: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">A - Motocicleta</SelectItem>
                    <SelectItem value="B">B - Carro</SelectItem>
                    <SelectItem value="C">C - Caminhão</SelectItem>
                    <SelectItem value="D">D - Ônibus</SelectItem>
                    <SelectItem value="E">E - Carreta</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="vencimento_cnh">Vencimento CNH *</Label>
                <Input
                  id="vencimento_cnh"
                  type="date"
                  value={formData.vencimento_cnh}
                  onChange={(e) => setFormData({ ...formData, vencimento_cnh: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="endereco">Endereço</Label>
              <Input
                id="endereco"
                value={formData.endereco}
                onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                placeholder="Endereço completo"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="data_nascimento">Data de Nascimento</Label>
                <Input
                  id="data_nascimento"
                  type="date"
                  value={formData.data_nascimento}
                  onChange={(e) => setFormData({ ...formData, data_nascimento: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="data_admissao">Data de Admissão</Label>
                <Input
                  id="data_admissao"
                  type="date"
                  value={formData.data_admissao}
                  onChange={(e) => setFormData({ ...formData, data_admissao: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="salario">Salário</Label>
              <Input
                id="salario"
                type="number"
                step="0.01"
                value={formData.salario}
                onChange={(e) => setFormData({ ...formData, salario: Number(e.target.value) })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes}
                onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                placeholder="Observações sobre o motorista..."
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="ativo"
                checked={formData.ativo}
                onCheckedChange={(checked) => setFormData({ ...formData, ativo: checked })}
              />
              <Label htmlFor="ativo">Motorista ativo</Label>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setIsFormOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveMotorista} disabled={!formData.nome || !formData.telefone || !formData.email}>
              {editingMotorista ? "Atualizar" : "Criar"} Motorista
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Motorista</DialogTitle>
            <DialogDescription>Informações completas do motorista</DialogDescription>
          </DialogHeader>

          {selectedMotorista && (
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${selectedMotorista.nome}`} />
                  <AvatarFallback className="text-lg">
                    {selectedMotorista.nome
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-xl font-semibold">{selectedMotorista.nome}</h3>
                  <p className="text-muted-foreground">CNH Categoria {selectedMotorista.categoria_cnh}</p>
                  {getStatusBadge(selectedMotorista)}
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-3">
                  <h4 className="font-medium">Informações de Contato</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedMotorista.telefone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedMotorista.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedMotorista.endereco}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Informações Pessoais</h4>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Data de Nascimento:</span>
                      <br />
                      <span>
                        {formatDate(selectedMotorista.data_nascimento)} (
                        {calculateAge(selectedMotorista.data_nascimento)} anos)
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Data de Admissão:</span>
                      <br />
                      <span>{formatDate(selectedMotorista.data_admissao)}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Salário:</span>
                      <br />
                      <span className="font-medium">{formatCurrency(selectedMotorista.salario)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-medium">Informações da CNH</h4>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <span className="text-muted-foreground text-sm">Número da CNH:</span>
                    <br />
                    <span className="font-mono">{selectedMotorista.cnh}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground text-sm">Vencimento:</span>
                    <br />
                    <span>{formatDate(selectedMotorista.vencimento_cnh)}</span>
                  </div>
                </div>
              </div>

              {selectedMotorista.observacoes && (
                <div className="space-y-3">
                  <h4 className="font-medium">Observações</h4>
                  <p className="text-sm text-muted-foreground">{selectedMotorista.observacoes}</p>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
                  Fechar
                </Button>
                <Button onClick={() => handleEditMotorista(selectedMotorista)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este motorista? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteMotorista} className="bg-red-600 hover:bg-red-700">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  )
}
