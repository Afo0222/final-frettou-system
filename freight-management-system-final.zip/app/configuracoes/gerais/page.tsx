"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Building, Save, RefreshCw, AlertTriangle, Bell, DollarSign, Settings, Shield, Database } from "lucide-react"

interface ConfiguracaoGeral {
  // Empresa
  nomeEmpresa: string
  cnpj: string
  endereco: string
  telefone: string
  email: string
  website: string
  logo: string

  // Notificações
  notificacoesEmail: boolean
  notificacoesSms: boolean
  notificacoesPush: boolean
  notificarVencimentos: boolean
  diasAntecedenciaVencimento: number

  // Financeiro
  moedaPadrao: string
  taxaJuros: number
  diasVencimentoPadrao: number
  descontoMaximo: number

  // Sistema
  fusoHorario: string
  formatoData: string
  formatoHora: string
  idioma: string
  tema: string

  // Backup
  backupAutomatico: boolean
  frequenciaBackup: string
  manterBackups: number

  // Segurança
  sessaoExpira: number
  tentativasLogin: number
  senhaComplexidade: boolean
  autenticacaoDoisFatores: boolean
}

const configuracaoInicial: ConfiguracaoGeral = {
  nomeEmpresa: "Transportes Silva Ltda",
  cnpj: "12.345.678/0001-90",
  endereco: "Rua das Flores, 123 - São Paulo, SP",
  telefone: "(11) 99999-9999",
  email: "contato@transportessilva.com.br",
  website: "www.transportessilva.com.br",
  logo: "",
  notificacoesEmail: true,
  notificacoesSms: false,
  notificacoesPush: true,
  notificarVencimentos: true,
  diasAntecedenciaVencimento: 30,
  moedaPadrao: "BRL",
  taxaJuros: 2.5,
  diasVencimentoPadrao: 30,
  descontoMaximo: 10,
  fusoHorario: "America/Sao_Paulo",
  formatoData: "DD/MM/YYYY",
  formatoHora: "24h",
  idioma: "pt-BR",
  tema: "light",
  backupAutomatico: true,
  frequenciaBackup: "daily",
  manterBackups: 30,
  sessaoExpira: 480,
  tentativasLogin: 3,
  senhaComplexidade: true,
  autenticacaoDoisFatores: false,
}

export default function ConfiguracoesGeraisPage() {
  const [config, setConfig] = useState<ConfiguracaoGeral>(configuracaoInicial)
  const [loading, setLoading] = useState(false)
  const [hasChanges, setHasChanges] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadConfiguracoes()
  }, [])

  const loadConfiguracoes = async () => {
    try {
      setLoading(true)
      // Simular carregamento das configurações
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setConfig(configuracaoInicial)
    } catch (error) {
      console.error("Erro ao carregar configurações:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar as configurações.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleConfigChange = (key: keyof ConfiguracaoGeral, value: any) => {
    setConfig((prev) => ({ ...prev, [key]: value }))
    setHasChanges(true)
  }

  const handleSave = async () => {
    try {
      setLoading(true)
      // Simular salvamento das configurações
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setHasChanges(false)
      toast({
        title: "Sucesso",
        description: "Configurações salvas com sucesso!",
      })
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    setConfig(configuracaoInicial)
    setHasChanges(false)
    toast({
      title: "Configurações Restauradas",
      description: "As configurações foram restauradas para os valores padrão.",
    })
  }

  const testNotification = (type: string) => {
    toast({
      title: "Teste de Notificação",
      description: `Teste de notificação por ${type} enviado com sucesso!`,
    })
  }

  if (loading && !hasChanges) {
    return (
      <main className="flex-1 p-4 lg:p-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="h-8 w-64 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-96 bg-gray-200 rounded animate-pulse mt-2"></div>
            </div>
          </div>
          <div className="h-96 bg-gray-200 rounded animate-pulse"></div>
        </div>
      </main>
    )
  }

  return (
    <main className="flex-1 p-4 lg:p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Configurações Gerais</h1>
            <p className="text-muted-foreground">Configure as preferências gerais do sistema</p>
          </div>
          <div className="flex items-center gap-2">
            {hasChanges && (
              <Badge variant="outline" className="text-orange-600">
                <AlertTriangle className="h-3 w-3 mr-1" />
                Alterações não salvas
              </Badge>
            )}
            <Button variant="outline" onClick={handleReset} disabled={loading}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Restaurar
            </Button>
            <Button onClick={handleSave} disabled={loading || !hasChanges}>
              {loading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Configuration Tabs */}
        <Tabs defaultValue="empresa" className="space-y-4">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="empresa">Empresa</TabsTrigger>
            <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
            <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
            <TabsTrigger value="sistema">Sistema</TabsTrigger>
            <TabsTrigger value="backup">Backup</TabsTrigger>
            <TabsTrigger value="seguranca">Segurança</TabsTrigger>
          </TabsList>

          {/* Empresa Tab */}
          <TabsContent value="empresa" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  Informações da Empresa
                </CardTitle>
                <CardDescription>Configure as informações básicas da sua empresa</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="nomeEmpresa">Nome da Empresa *</Label>
                    <Input
                      id="nomeEmpresa"
                      value={config.nomeEmpresa}
                      onChange={(e) => handleConfigChange("nomeEmpresa", e.target.value)}
                      placeholder="Nome da empresa"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cnpj">CNPJ *</Label>
                    <Input
                      id="cnpj"
                      value={config.cnpj}
                      onChange={(e) => handleConfigChange("cnpj", e.target.value)}
                      placeholder="00.000.000/0000-00"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endereco">Endereço</Label>
                  <Input
                    id="endereco"
                    value={config.endereco}
                    onChange={(e) => handleConfigChange("endereco", e.target.value)}
                    placeholder="Endereço completo da empresa"
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="telefone">Telefone</Label>
                    <Input
                      id="telefone"
                      value={config.telefone}
                      onChange={(e) => handleConfigChange("telefone", e.target.value)}
                      placeholder="(00) 00000-0000"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      type="email"
                      value={config.email}
                      onChange={(e) => handleConfigChange("email", e.target.value)}
                      placeholder="contato@empresa.com.br"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input
                      id="website"
                      value={config.website}
                      onChange={(e) => handleConfigChange("website", e.target.value)}
                      placeholder="www.empresa.com.br"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notificações Tab */}
          <TabsContent value="notificacoes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Configurações de Notificações
                </CardTitle>
                <CardDescription>Configure como e quando receber notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notificações por E-mail</Label>
                      <p className="text-sm text-muted-foreground">Receber notificações por e-mail</p>
                    </div>
                    <Switch
                      checked={config.notificacoesEmail}
                      onCheckedChange={(checked) => handleConfigChange("notificacoesEmail", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notificações por SMS</Label>
                      <p className="text-sm text-muted-foreground">Receber notificações por SMS</p>
                    </div>
                    <Switch
                      checked={config.notificacoesSms}
                      onCheckedChange={(checked) => handleConfigChange("notificacoesSms", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notificações Push</Label>
                      <p className="text-sm text-muted-foreground">Receber notificações push no navegador</p>
                    </div>
                    <Switch
                      checked={config.notificacoesPush}
                      onCheckedChange={(checked) => handleConfigChange("notificacoesPush", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notificar Vencimentos</Label>
                      <p className="text-sm text-muted-foreground">Notificar sobre vencimentos próximos</p>
                    </div>
                    <Switch
                      checked={config.notificarVencimentos}
                      onCheckedChange={(checked) => handleConfigChange("notificarVencimentos", checked)}
                    />
                  </div>

                  {config.notificarVencimentos && (
                    <div className="space-y-2">
                      <Label htmlFor="diasAntecedencia">Dias de Antecedência</Label>
                      <Input
                        id="diasAntecedencia"
                        type="number"
                        value={config.diasAntecedenciaVencimento}
                        onChange={(e) =>
                          handleConfigChange("diasAntecedenciaVencimento", Number.parseInt(e.target.value))
                        }
                        placeholder="30"
                        min="1"
                        max="365"
                      />
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => testNotification("E-mail")}>
                    Testar E-mail
                  </Button>
                  <Button variant="outline" onClick={() => testNotification("SMS")}>
                    Testar SMS
                  </Button>
                  <Button variant="outline" onClick={() => testNotification("Push")}>
                    Testar Push
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Financeiro Tab */}
          <TabsContent value="financeiro" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Configurações Financeiras
                </CardTitle>
                <CardDescription>Configure as preferências financeiras do sistema</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="moedaPadrao">Moeda Padrão</Label>
                    <Select
                      value={config.moedaPadrao}
                      onValueChange={(value) => handleConfigChange("moedaPadrao", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a moeda" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BRL">Real (R$)</SelectItem>
                        <SelectItem value="USD">Dólar ($)</SelectItem>
                        <SelectItem value="EUR">Euro (€)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="taxaJuros">Taxa de Juros (%)</Label>
                    <Input
                      id="taxaJuros"
                      type="number"
                      step="0.1"
                      value={config.taxaJuros}
                      onChange={(e) => handleConfigChange("taxaJuros", Number.parseFloat(e.target.value))}
                      placeholder="2.5"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="diasVencimento">Dias para Vencimento Padrão</Label>
                    <Input
                      id="diasVencimento"
                      type="number"
                      value={config.diasVencimentoPadrao}
                      onChange={(e) => handleConfigChange("diasVencimentoPadrao", Number.parseInt(e.target.value))}
                      placeholder="30"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="descontoMaximo">Desconto Máximo (%)</Label>
                    <Input
                      id="descontoMaximo"
                      type="number"
                      step="0.1"
                      value={config.descontoMaximo}
                      onChange={(e) => handleConfigChange("descontoMaximo", Number.parseFloat(e.target.value))}
                      placeholder="10"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sistema Tab */}
          <TabsContent value="sistema" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Configurações do Sistema
                </CardTitle>
                <CardDescription>Configure as preferências de interface e localização</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="fusoHorario">Fuso Horário</Label>
                    <Select
                      value={config.fusoHorario}
                      onValueChange={(value) => handleConfigChange("fusoHorario", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o fuso horário" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="America/Sao_Paulo">São Paulo (GMT-3)</SelectItem>
                        <SelectItem value="America/Manaus">Manaus (GMT-4)</SelectItem>
                        <SelectItem value="America/Rio_Branco">Rio Branco (GMT-5)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="formatoData">Formato de Data</Label>
                    <Select
                      value={config.formatoData}
                      onValueChange={(value) => handleConfigChange("formatoData", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="formatoHora">Formato de Hora</Label>
                    <Select
                      value={config.formatoHora}
                      onValueChange={(value) => handleConfigChange("formatoHora", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24h">24 horas</SelectItem>
                        <SelectItem value="12h">12 horas (AM/PM)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="idioma">Idioma</Label>
                    <Select value={config.idioma} onValueChange={(value) => handleConfigChange("idioma", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o idioma" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="es-ES">Español</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tema">Tema</Label>
                  <Select value={config.tema} onValueChange={(value) => handleConfigChange("tema", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tema" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Claro</SelectItem>
                      <SelectItem value="dark">Escuro</SelectItem>
                      <SelectItem value="system">Sistema</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Backup Tab */}
          <TabsContent value="backup" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  Configurações de Backup
                </CardTitle>
                <CardDescription>Configure as preferências de backup automático</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Backup Automático</Label>
                    <p className="text-sm text-muted-foreground">Realizar backup automático dos dados</p>
                  </div>
                  <Switch
                    checked={config.backupAutomatico}
                    onCheckedChange={(checked) => handleConfigChange("backupAutomatico", checked)}
                  />
                </div>

                {config.backupAutomatico && (
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="frequenciaBackup">Frequência do Backup</Label>
                      <Select
                        value={config.frequenciaBackup}
                        onValueChange={(value) => handleConfigChange("frequenciaBackup", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a frequência" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hourly">A cada hora</SelectItem>
                          <SelectItem value="daily">Diário</SelectItem>
                          <SelectItem value="weekly">Semanal</SelectItem>
                          <SelectItem value="monthly">Mensal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="manterBackups">Manter Backups (dias)</Label>
                      <Input
                        id="manterBackups"
                        type="number"
                        value={config.manterBackups}
                        onChange={(e) => handleConfigChange("manterBackups", Number.parseInt(e.target.value))}
                        placeholder="30"
                        min="1"
                        max="365"
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button variant="outline">Fazer Backup Agora</Button>
                  <Button variant="outline">Restaurar Backup</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Segurança Tab */}
          <TabsContent value="seguranca" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Configurações de Segurança
                </CardTitle>
                <CardDescription>Configure as preferências de segurança e autenticação</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="sessaoExpira">Sessão Expira (minutos)</Label>
                    <Input
                      id="sessaoExpira"
                      type="number"
                      value={config.sessaoExpira}
                      onChange={(e) => handleConfigChange("sessaoExpira", Number.parseInt(e.target.value))}
                      placeholder="480"
                      min="30"
                      max="1440"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tentativasLogin">Tentativas de Login</Label>
                    <Input
                      id="tentativasLogin"
                      type="number"
                      value={config.tentativasLogin}
                      onChange={(e) => handleConfigChange("tentativasLogin", Number.parseInt(e.target.value))}
                      placeholder="3"
                      min="1"
                      max="10"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Senha Complexa</Label>
                      <p className="text-sm text-muted-foreground">Exigir senhas com maiúsculas, números e símbolos</p>
                    </div>
                    <Switch
                      checked={config.senhaComplexidade}
                      onCheckedChange={(checked) => handleConfigChange("senhaComplexidade", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Autenticação de Dois Fatores</Label>
                      <p className="text-sm text-muted-foreground">Exigir código adicional no login</p>
                    </div>
                    <Switch
                      checked={config.autenticacaoDoisFatores}
                      onCheckedChange={(checked) => handleConfigChange("autenticacaoDoisFatores", checked)}
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline">Alterar Senha</Button>
                  <Button variant="outline">Configurar 2FA</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
