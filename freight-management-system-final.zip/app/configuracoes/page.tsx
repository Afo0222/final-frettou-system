import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Package, Car, Users, DollarSign, Wrench, UserCog, Cog, ArrowRight } from "lucide-react"
import Link from "next/link"

const configSections = [
  {
    title: "Tipos de Serviço",
    description: "Configure os tipos de serviços oferecidos, preços e variáveis de custo",
    icon: Package,
    href: "/configuracoes/tipos-servico",
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    title: "Veículos",
    description: "Gerencie a frota de veículos disponíveis para os serviços",
    icon: Car,
    href: "/configuracoes/veiculos",
    color: "text-green-600",
    bgColor: "bg-green-100",
  },
  {
    title: "Clientes",
    description: "Cadastro e gestão de clientes do sistema",
    icon: Users,
    href: "/configuracoes/clientes",
    color: "text-purple-600",
    bgColor: "bg-purple-100",
  },
  {
    title: "Variáveis de Custo",
    description: "Configure custos adicionais aplicados aos serviços",
    icon: DollarSign,
    href: "/configuracoes/variaveis-custo",
    color: "text-yellow-600",
    bgColor: "bg-yellow-100",
  },
  {
    title: "Produtos/Serviços",
    description: "Catálogo de produtos e serviços extras disponíveis",
    icon: Wrench,
    href: "/configuracoes/produtos-servicos",
    color: "text-orange-600",
    bgColor: "bg-orange-100",
  },
  {
    title: "Motoristas",
    description: "Cadastro e gestão da equipe de motoristas",
    icon: UserCog,
    href: "/configuracoes/motoristas",
    color: "text-indigo-600",
    bgColor: "bg-indigo-100",
  },
  {
    title: "Configurações Gerais",
    description: "Configurações gerais do sistema e preferências",
    icon: Cog,
    href: "/configuracoes/gerais",
    color: "text-gray-600",
    bgColor: "bg-gray-100",
  },
]

export default function ConfiguracoesPage() {
  return (
    <main className="flex-1 p-4 lg:p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-muted-foreground">Gerencie todas as configurações do sistema de gestão de fretes</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {configSections.map((section) => {
          const IconComponent = section.icon
          return (
            <Card key={section.href} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${section.bgColor}`}>
                    <IconComponent className={`h-6 w-6 ${section.color}`} />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{section.title}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="mb-4">{section.description}</CardDescription>
                <Link href={section.href}>
                  <Button variant="outline" className="w-full">
                    Acessar
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </main>
  )
}
