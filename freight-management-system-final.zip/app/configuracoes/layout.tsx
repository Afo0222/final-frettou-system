import { Header } from "@/components/layout/header"
import { Sidebar } from "@/components/layout/sidebar"
import type { ReactNode } from "react"

export default function ConfiguracoesLayout({
  children,
}: {
  children: ReactNode
}) {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col lg:ml-64">
        <Header />
        <div className="flex-1 overflow-auto">{children}</div>
      </div>
    </div>
  )
}
