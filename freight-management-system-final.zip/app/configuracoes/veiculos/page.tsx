"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Skeleton } from "@/components/ui/skeleton"
import { Plus, Search, Car, Truck, AlertTriangle, CheckCircle, Grid3X3, List } from "lucide-react"
import { VehicleForm } from "@/components/veiculos/vehicle-form"
import { VehicleCard } from "@/components/veiculos/vehicle-card"
import { VehicleDetails } from "@/components/veiculos/vehicle-details"
import { getVeiculos, getVeiculosStats, type VeiculoStats } from "@/lib/services/veiculos"
import { useToast } from "@/hooks/use-toast"
import type { Veiculo } from "@/lib/types/database"

export default function VeiculosPage() {
  const [vehicles, setVehicles] = useState<Veiculo[]>([])
  const [stats, setStats] = useState<VeiculoStats | null>(null)
  const [filteredVehicles, setFilteredVehicles] = useState<Veiculo[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedVehicle, setSelectedVehicle] = useState<Veiculo | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [showDetails, setShowDetails] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadVehicles()
    loadStats()
  }, [])

  useEffect(() => {
    filterVehicles()
  }, [vehicles, searchTerm, statusFilter, typeFilter])

  const loadVehicles = async () => {
    try {
      setIsLoading(true)
      const data = await getVeiculos()
      setVehicles(data)
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível carregar os veículos.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const loadStats = async () => {
    try {
      const data = await getVeiculosStats()
      setStats(data)
    } catch (error) {
      console.error("Erro ao carregar estatísticas:", error)
    }
  }

  const filterVehicles = () => {
    let filtered = vehicles

    // Filtro por termo de busca
    if (searchTerm) {
      filtered = filtered.filter(
        (vehicle) =>
          vehicle.modelo.toLowerCase().includes(searchTerm.toLowerCase()) ||
          vehicle.marca.toLowerCase().includes(searchTerm.toLowerCase()) ||
          vehicle.placa.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filtro por status
    if (statusFilter !== "all") {
      if (statusFilter === "active") {
        filtered = filtered.filter((vehicle) => vehicle.ativo)
      } else if (statusFilter === "inactive") {
        filtered = filtered.filter((vehicle) => !vehicle.ativo)
      } else if (statusFilter === "available") {
        filtered = filtered.filter((vehicle) => vehicle.ativo && !vehicle.motorista_id)
      } else if (statusFilter === "assigned") {
        filtered = filtered.filter((vehicle) => vehicle.ativo && vehicle.motorista_id)
      } else if (statusFilter === "expiring") {
        const proximoMes = new Date()
        proximoMes.setMonth(proximoMes.getMonth() + 1)
        filtered = filtered.filter((vehicle) => {
          const vencimentos = [
            vehicle.vencimento_seguro,
            vehicle.vencimento_ipva,
            vehicle.vencimento_licenciamento,
          ].filter(Boolean)
          return vencimentos.some((vencimento) => vencimento && new Date(vencimento) <= proximoMes)
        })
      }
    }

    // Filtro por tipo
    if (typeFilter !== "all") {
      filtered = filtered.filter((vehicle) => vehicle.tipo_veiculo === typeFilter)
    }

    setFilteredVehicles(filtered)
  }

  const handleEdit = (vehicle: Veiculo) => {
    setSelectedVehicle(vehicle)
    setShowForm(true)
  }

  const handleView = (vehicle: Veiculo) => {
    setSelectedVehicle(vehicle)
    setShowDetails(true)
  }

  const handleFormSuccess = () => {
    setShowForm(false)
    setSelectedVehicle(null)
    loadVehicles()
    loadStats()
  }

  const getStatusBadgeVariant = (vehicle: Veiculo) => {
    if (!vehicle.ativo) return "secondary"

    const hoje = new Date()
    const proximoMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate())

    const vencimentos = [vehicle.vencimento_seguro, vehicle.vencimento_ipva, vehicle.vencimento_licenciamento].filter(
      Boolean,
    )

    const temVencimentoProximo = vencimentos.some((vencimento) => vencimento && new Date(vencimento) <= proximoMes)

    if (temVencimentoProximo) return "destructive"
    if (!vehicle.seguro_vigente || !vehicle.ipva_pago || !vehicle.licenciamento_vigente) return "destructive"

    return "default"
  }

  if (isLoading) {
    return (
      <main className="flex-1 p-4 lg:p-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-4 w-96 mt-2" />
            </div>
            <Skeleton className="h-10 w-32" />
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16" />
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="flex-1 p-4 lg:p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Veículos</h1>
            <p className="text-muted-foreground">Gerencie a frota de veículos da empresa</p>
          </div>
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogTrigger asChild>
              <Button onClick={() => setSelectedVehicle(null)}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Veículo
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{selectedVehicle ? "Editar Veículo" : "Novo Veículo"}</DialogTitle>
                <DialogDescription>
                  {selectedVehicle ? "Atualize as informações do veículo" : "Adicione um novo veículo à frota"}
                </DialogDescription>
              </DialogHeader>
              <VehicleForm
                vehicle={selectedVehicle || undefined}
                onSuccess={handleFormSuccess}
                onCancel={() => setShowForm(false)}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Veículos</CardTitle>
                <Car className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.ativos} ativos, {stats.inativos} inativos
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Capacidade Total</CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.capacidadeTotal.peso}kg</div>
                <p className="text-xs text-muted-foreground">{stats.capacidadeTotal.volume}m³ de volume</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Disponíveis</CardTitle>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {vehicles.filter((v) => v.ativo && !v.motorista_id).length}
                </div>
                <p className="text-xs text-muted-foreground">Sem motorista designado</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vencimentos</CardTitle>
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  {stats.vencimentosProximos.seguro +
                    stats.vencimentosProximos.ipva +
                    stats.vencimentosProximos.licenciamento}
                </div>
                <p className="text-xs text-muted-foreground">Documentos vencendo</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Filters and Search */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por modelo, marca ou placa..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="active">Ativos</SelectItem>
                  <SelectItem value="inactive">Inativos</SelectItem>
                  <SelectItem value="available">Disponíveis</SelectItem>
                  <SelectItem value="assigned">Com motorista</SelectItem>
                  <SelectItem value="expiring">Vencimentos próximos</SelectItem>
                </SelectContent>
              </Select>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os tipos</SelectItem>
                  <SelectItem value="caminhao">Caminhão</SelectItem>
                  <SelectItem value="van">Van</SelectItem>
                  <SelectItem value="pickup">Pickup</SelectItem>
                  <SelectItem value="moto">Motocicleta</SelectItem>
                  <SelectItem value="bicicleta">Bicicleta</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{filteredVehicles.length} veículo(s) encontrado(s)</p>
        </div>

        {/* Vehicles Grid/List */}
        {filteredVehicles.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Car className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum veículo encontrado</h3>
              <p className="text-muted-foreground text-center mb-4">
                {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                  ? "Tente ajustar os filtros de busca"
                  : "Comece adicionando o primeiro veículo à frota"}
              </p>
              {!searchTerm && statusFilter === "all" && typeFilter === "all" && (
                <Button onClick={() => setShowForm(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Adicionar Primeiro Veículo
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className={viewMode === "grid" ? "grid gap-6 md:grid-cols-2 lg:grid-cols-3" : "space-y-4"}>
            {filteredVehicles.map((vehicle) => (
              <VehicleCard
                key={vehicle.id}
                vehicle={vehicle}
                onEdit={handleEdit}
                onView={handleView}
                onRefresh={loadVehicles}
              />
            ))}
          </div>
        )}
      </div>

      {/* Vehicle Details Sheet */}
      <Sheet open={showDetails} onOpenChange={setShowDetails}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{selectedVehicle && `${selectedVehicle.marca} ${selectedVehicle.modelo}`}</SheetTitle>
            <SheetDescription>Detalhes completos do veículo</SheetDescription>
          </SheetHeader>
          {selectedVehicle && (
            <div className="mt-6">
              <VehicleDetails vehicle={selectedVehicle} />
            </div>
          )}
        </SheetContent>
      </Sheet>
    </main>
  )
}
