"use client"

import { useState, useEffect, useMemo } from "react"
import { Plus, Search, Filter, Grid, List, Package, Wrench, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { ProductServiceCard } from "@/components/produtos-servicos/product-service-card"
import { ProductServiceForm } from "@/components/produtos-servicos/product-service-form"
import { ProductServiceDetails } from "@/components/produtos-servicos/product-service-details"
import { ProductServiceCalculator } from "@/components/produtos-servicos/product-service-calculator"
import { produtoServicoService, type ProdutoServico } from "@/lib/services/produtos-servicos"
import { useToast } from "@/hooks/use-toast"

export default function ProdutosServicosPage() {
  const [produtos, setProdutos] = useState<ProdutoServico[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("")
  const [selectedStatus, setSelectedStatus] = useState<string>("")
  const [selectedType, setSelectedType] = useState<string>("")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedProduct, setSelectedProduct] = useState<ProdutoServico | null>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<ProdutoServico | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    loadProdutos()
  }, [])

  const loadProdutos = async () => {
    try {
      setLoading(true)
      const data = await produtoServicoService.getAll()
      setProdutos(data)
    } catch (error) {
      console.error("Erro ao carregar produtos/serviços:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os produtos/serviços.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredProdutos = useMemo(() => {
    return produtos.filter((produto) => {
      const matchesSearch =
        produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        produto.descricao?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        produto.codigo?.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = !selectedCategory || produto.categoria === selectedCategory
      const matchesStatus =
        !selectedStatus ||
        (selectedStatus === "ativo" && produto.ativo) ||
        (selectedStatus === "inativo" && !produto.ativo)
      const matchesType = !selectedType || produto.tipo === selectedType

      return matchesSearch && matchesCategory && matchesStatus && matchesType
    })
  }, [produtos, searchTerm, selectedCategory, selectedStatus, selectedType])

  const statistics = useMemo(() => {
    const total = produtos.length
    const ativos = produtos.filter((p) => p.ativo).length
    const produtos_count = produtos.filter((p) => p.tipo === "produto").length
    const servicos_count = produtos.filter((p) => p.tipo === "servico").length
    const valor_medio =
      produtos.length > 0 ? produtos.reduce((sum, p) => sum + (p.preco_base || 0), 0) / produtos.length : 0

    return {
      total,
      ativos,
      inativos: total - ativos,
      produtos: produtos_count,
      servicos: servicos_count,
      valor_medio,
      categorias: [...new Set(produtos.map((p) => p.categoria))].length,
    }
  }, [produtos])

  const handleCreate = () => {
    setEditingProduct(null)
    setIsFormOpen(true)
  }

  const handleEdit = (produto: ProdutoServico) => {
    setEditingProduct(produto)
    setIsFormOpen(true)
  }

  const handleView = (produto: ProdutoServico) => {
    setSelectedProduct(produto)
    setIsDetailsOpen(true)
  }

  const handleCalculate = (produto: ProdutoServico) => {
    setSelectedProduct(produto)
    setIsCalculatorOpen(true)
  }

  const handleDuplicate = async (produto: ProdutoServico) => {
    try {
      const duplicated = {
        ...produto,
        id: undefined,
        nome: `${produto.nome} (Cópia)`,
        codigo: produto.codigo ? `${produto.codigo}_COPY` : undefined,
      }
      await produtoServicoService.create(duplicated)
      await loadProdutos()
      toast({
        title: "Sucesso",
        description: "Produto/serviço duplicado com sucesso.",
      })
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível duplicar o produto/serviço.",
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (produto: ProdutoServico) => {
    if (!confirm("Tem certeza que deseja excluir este produto/serviço?")) return

    try {
      await produtoServicoService.delete(produto.id)
      await loadProdutos()
      toast({
        title: "Sucesso",
        description: "Produto/serviço excluído com sucesso.",
      })
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível excluir o produto/serviço.",
        variant: "destructive",
      })
    }
  }

  const handleToggleStatus = async (produto: ProdutoServico) => {
    try {
      await produtoServicoService.update(produto.id, { ativo: !produto.ativo })
      await loadProdutos()
      toast({
        title: "Sucesso",
        description: `Produto/serviço ${produto.ativo ? "desativado" : "ativado"} com sucesso.`,
      })
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível alterar o status do produto/serviço.",
        variant: "destructive",
      })
    }
  }

  const handleFormSuccess = async () => {
    setIsFormOpen(false)
    setEditingProduct(null)
    await loadProdutos()
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="h-8 w-64 bg-gray-200 rounded animate-pulse" />
            <div className="h-4 w-96 bg-gray-200 rounded animate-pulse mt-2" />
          </div>
          <div className="h-10 w-32 bg-gray-200 rounded animate-pulse" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded animate-pulse" />
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-64 bg-gray-200 rounded animate-pulse" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Produtos & Serviços</h1>
          <p className="text-muted-foreground">Gerencie produtos e serviços oferecidos pela empresa</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setIsCalculatorOpen(true)}>
            <TrendingUp className="h-4 w-4 mr-2" />
            Calculadora
          </Button>
          <Button onClick={handleCreate}>
            <Plus className="h-4 w-4 mr-2" />
            Novo Produto/Serviço
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statistics.total}</div>
            <p className="text-xs text-muted-foreground">
              {statistics.produtos} produtos, {statistics.servicos} serviços
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ativos</CardTitle>
            <Wrench className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{statistics.ativos}</div>
            <div className="flex items-center gap-2">
              <Progress value={(statistics.ativos / statistics.total) * 100} className="flex-1 h-2" />
              <span className="text-xs text-muted-foreground">
                {Math.round((statistics.ativos / statistics.total) * 100)}%
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Médio</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              R$ {statistics.valor_medio.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">Preço base médio</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Categorias</CardTitle>
            <Filter className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{statistics.categorias}</div>
            <p className="text-xs text-muted-foreground">Categorias diferentes</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar por nome, descrição ou código..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="produto">Produtos</SelectItem>
                <SelectItem value="servico">Serviços</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as categorias</SelectItem>
                <SelectItem value="transporte">Transporte</SelectItem>
                <SelectItem value="mudanca">Mudança</SelectItem>
                <SelectItem value="entrega">Entrega</SelectItem>
                <SelectItem value="logistica">Logística</SelectItem>
                <SelectItem value="armazenagem">Armazenagem</SelectItem>
                <SelectItem value="consultoria">Consultoria</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="ativo">Ativos</SelectItem>
                <SelectItem value="inativo">Inativos</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Mostrando {filteredProdutos.length} de {produtos.length} produtos/serviços
        </p>
      </div>

      {/* Products/Services Grid */}
      {filteredProdutos.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Package className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Nenhum produto/serviço encontrado</h3>
            <p className="text-gray-600 text-center mb-4">
              {produtos.length === 0
                ? "Comece criando seu primeiro produto ou serviço."
                : "Tente ajustar os filtros para encontrar o que procura."}
            </p>
            {produtos.length === 0 && (
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Criar Primeiro Produto/Serviço
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
          {filteredProdutos.map((produto) => (
            <ProductServiceCard
              key={produto.id}
              produto={produto}
              viewMode={viewMode}
              onView={() => handleView(produto)}
              onEdit={() => handleEdit(produto)}
              onDelete={() => handleDelete(produto)}
              onDuplicate={() => handleDuplicate(produto)}
              onToggleStatus={() => handleToggleStatus(produto)}
              onCalculate={() => handleCalculate(produto)}
            />
          ))}
        </div>
      )}

      {/* Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "Editar Produto/Serviço" : "Novo Produto/Serviço"}</DialogTitle>
          </DialogHeader>
          <ProductServiceForm
            produto={editingProduct}
            onSuccess={handleFormSuccess}
            onCancel={() => setIsFormOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Produto/Serviço</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <ProductServiceDetails
              produto={selectedProduct}
              onEdit={() => {
                setIsDetailsOpen(false)
                handleEdit(selectedProduct)
              }}
              onClose={() => setIsDetailsOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Calculator Dialog */}
      <Dialog open={isCalculatorOpen} onOpenChange={setIsCalculatorOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Calculadora de Preços</DialogTitle>
          </DialogHeader>
          <ProductServiceCalculator
            produto={selectedProduct}
            produtos={produtos.filter((p) => p.ativo)}
            onClose={() => setIsCalculatorOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}
