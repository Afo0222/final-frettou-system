"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ClienteForm } from "@/components/clientes/client-form"
import { ClientCard } from "@/components/clientes/client-card"
import { ClientDetails } from "@/components/clientes/client-details"
import { ClienteService } from "@/lib/services/clientes"
import { useToast } from "@/hooks/use-toast"
import { Users, Plus, Search, Download, Grid3X3, List, Mail, FileText } from "lucide-react"
import type { Cliente } from "@/lib/types/database"

// Mock data for immediate functionality
const mockClientes: Cliente[] = [
  {
    id: "1",
    nome: "João Silva Transportes Ltda",
    telefone: "(11) 99999-1234",
    email: "joao@silvatransportes.com.br",
    documento: "12.345.678/0001-90",
    endereco: "Rua das Flores, 123 - São Paulo, SP",
    observacoes: "Cliente preferencial, sempre pontual nos pagamentos",
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
  },
  {
    id: "2",
    nome: "Maria Santos",
    telefone: "(11) 98888-5678",
    email: "maria.santos@email.com",
    documento: "123.456.789-00",
    endereco: "Av. Paulista, 1000 - São Paulo, SP",
    observacoes: "Mudanças residenciais frequentes",
    created_at: "2024-01-10T14:30:00Z",
    updated_at: "2024-01-20T09:15:00Z",
  },
  {
    id: "3",
    nome: "Construtora ABC S.A.",
    telefone: "(11) 97777-9999",
    email: "contato@construtorabc.com.br",
    documento: "98.765.432/0001-10",
    endereco: "Rua da Construção, 456 - Guarulhos, SP",
    observacoes: "Transportes de materiais de construção, carga pesada",
    created_at: "2024-01-05T16:45:00Z",
    updated_at: "2024-01-25T11:20:00Z",
  },
  {
    id: "4",
    nome: "Pedro Oliveira",
    telefone: "(11) 96666-7777",
    email: "pedro.oliveira@gmail.com",
    documento: "987.654.321-00",
    endereco: "Rua dos Pinheiros, 789 - São Paulo, SP",
    observacoes: "Cliente eventual, mudanças de escritório",
    created_at: "2024-01-12T08:00:00Z",
    updated_at: "2024-01-12T08:00:00Z",
  },
  {
    id: "5",
    nome: "Loja do Móvel Ltda",
    telefone: "(11) 95555-4444",
    email: "vendas@lojademovel.com.br",
    documento: "11.222.333/0001-44",
    endereco: "Av. dos Móveis, 321 - Osasco, SP",
    observacoes: "Entregas de móveis, necessita cuidado especial",
    created_at: "2024-01-08T13:30:00Z",
    updated_at: "2024-01-22T15:45:00Z",
  },
]

export default function ClientesPage() {
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState<"nome" | "created_at" | "updated_at">("nome")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedClient, setSelectedClient] = useState<Cliente | null>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [editingClient, setEditingClient] = useState<Cliente | null>(null)
  const { toast } = useToast()

  // Load clients
  const loadClients = async () => {
    try {
      setLoading(true)
      const data = await ClienteService.getAll()
      setClientes(data.length > 0 ? data : mockClientes)
    } catch (error) {
      console.error("Erro ao carregar clientes:", error)
      setClientes(mockClientes)
      toast({
        title: "Aviso",
        description: "Carregando dados de exemplo. Configure a integração com o banco de dados.",
        variant: "default",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadClients()
  }, [])

  // Filtered and sorted clients
  const filteredClientes = useMemo(() => {
    const filtered = clientes.filter(
      (cliente) =>
        cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.telefone.includes(searchTerm) ||
        (cliente.email && cliente.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (cliente.documento && cliente.documento.includes(searchTerm)),
    )

    filtered.sort((a, b) => {
      let aValue: string | Date
      let bValue: string | Date

      switch (sortBy) {
        case "nome":
          aValue = a.nome
          bValue = b.nome
          break
        case "created_at":
          aValue = new Date(a.created_at)
          bValue = new Date(b.created_at)
          break
        case "updated_at":
          aValue = new Date(a.updated_at)
          bValue = new Date(b.updated_at)
          break
        default:
          aValue = a.nome
          bValue = b.nome
      }

      if (aValue < bValue) return sortOrder === "asc" ? -1 : 1
      if (aValue > bValue) return sortOrder === "asc" ? 1 : -1
      return 0
    })

    return filtered
  }, [clientes, searchTerm, sortBy, sortOrder])

  // Statistics
  const stats = useMemo(() => {
    const total = clientes.length
    const withEmail = clientes.filter((c) => c.email).length
    const companies = clientes.filter((c) => c.documento && c.documento.includes("/")).length
    const individuals = total - companies

    return {
      total,
      withEmail,
      companies,
      individuals,
      emailPercentage: total > 0 ? Math.round((withEmail / total) * 100) : 0,
    }
  }, [clientes])

  // Event handlers
  const handleNewClient = () => {
    setEditingClient(null)
    setIsFormOpen(true)
  }

  const handleEditClient = (client: Cliente) => {
    setEditingClient(client)
    setIsFormOpen(true)
  }

  const handleViewClient = (client: Cliente) => {
    setSelectedClient(client)
    setIsDetailsOpen(true)
  }

  const handleFormSuccess = async (client: Cliente) => {
    await loadClients()
    setIsFormOpen(false)
    setEditingClient(null)
    toast({
      title: "Sucesso",
      description: `Cliente ${editingClient ? "atualizado" : "criado"} com sucesso!`,
    })
  }

  const handleDeleteClient = async (clientId: string) => {
    try {
      await ClienteService.delete(clientId)
      await loadClients()
      toast({
        title: "Sucesso",
        description: "Cliente removido com sucesso!",
      })
    } catch (error) {
      console.error("Erro ao remover cliente:", error)
      toast({
        title: "Erro",
        description: "Não foi possível remover o cliente.",
        variant: "destructive",
      })
    }
  }

  const exportClients = () => {
    const csvContent = [
      ["Nome", "Telefone", "Email", "Documento", "Endereço", "Observações"].join(","),
      ...filteredClientes.map((cliente) =>
        [
          `"${cliente.nome}"`,
          `"${cliente.telefone}"`,
          `"${cliente.email || ""}"`,
          `"${cliente.documento || ""}"`,
          `"${cliente.endereco || ""}"`,
          `"${cliente.observacoes || ""}"`,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `clientes_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  if (loading) {
    return (
      <main className="flex-1 p-4 lg:p-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="h-8 w-48 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-96 bg-gray-200 rounded animate-pulse mt-2"></div>
            </div>
            <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"></div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-8 w-16 bg-gray-200 rounded animate-pulse"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="flex-1 p-4 lg:p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Clientes</h1>
            <p className="text-muted-foreground">Gerencie o cadastro de clientes do sistema</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={exportClients} disabled={filteredClientes.length === 0}>
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
            <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
              <DialogTrigger asChild>
                <Button onClick={handleNewClient}>
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Cliente
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingClient ? "Editar Cliente" : "Novo Cliente"}</DialogTitle>
                </DialogHeader>
                <ClienteForm
                  cliente={editingClient || undefined}
                  onSuccess={handleFormSuccess}
                  onCancel={() => setIsFormOpen(false)}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">Cadastrados no sistema</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pessoas Jurídicas</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.companies}</div>
              <p className="text-xs text-muted-foreground">Empresas cadastradas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pessoas Físicas</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.individuals}</div>
              <p className="text-xs text-muted-foreground">Indivíduos cadastrados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Com Email</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.emailPercentage}%</div>
              <p className="text-xs text-muted-foreground">
                {stats.withEmail} de {stats.total} clientes
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Filtros e Busca</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nome, telefone, email ou documento..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select value={sortBy} onValueChange={(value: "nome" | "created_at" | "updated_at") => setSortBy(value)}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nome">Nome</SelectItem>
                  <SelectItem value="created_at">Data de Criação</SelectItem>
                  <SelectItem value="updated_at">Última Atualização</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortOrder} onValueChange={(value: "asc" | "desc") => setSortOrder(value)}>
                <SelectTrigger className="w-full sm:w-32">
                  <SelectValue placeholder="Ordem" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asc">A-Z</SelectItem>
                  <SelectItem value="desc">Z-A</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{filteredClientes.length} cliente(s) encontrado(s)</p>
        </div>

        {/* Clients Grid/List */}
        {filteredClientes.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum cliente encontrado</h3>
              <p className="text-muted-foreground text-center mb-4">
                {searchTerm ? "Tente ajustar os termos de busca" : "Comece adicionando o primeiro cliente ao sistema"}
              </p>
              {!searchTerm && (
                <Button onClick={handleNewClient}>
                  <Plus className="mr-2 h-4 w-4" />
                  Adicionar Primeiro Cliente
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className={viewMode === "grid" ? "grid gap-6 md:grid-cols-2 lg:grid-cols-3" : "space-y-4"}>
            {filteredClientes.map((cliente) => (
              <ClientCard
                key={cliente.id}
                cliente={cliente}
                onEdit={handleEditClient}
                onView={handleViewClient}
                onDelete={handleDeleteClient}
                viewMode={viewMode}
              />
            ))}
          </div>
        )}
      </div>

      {/* Client Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Cliente</DialogTitle>
          </DialogHeader>
          {selectedClient && (
            <ClientDetails
              cliente={selectedClient}
              onEdit={(client) => {
                setIsDetailsOpen(false)
                handleEditClient(client)
              }}
              onClose={() => setIsDetailsOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </main>
  )
}
