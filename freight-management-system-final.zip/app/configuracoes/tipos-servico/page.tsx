"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { toast } from "@/hooks/use-toast"
import { Plus, Search, BarChart3, Package, DollarSign, TrendingUp, Users, Calculator, RefreshCw } from "lucide-react"
import { ServiceTypeCard } from "@/components/tipos-servico/service-type-card"
import { ServiceTypeForm } from "@/components/tipos-servico/service-type-form"
import { ServiceTypeDetails } from "@/components/tipos-servico/service-type-details"
import { TipoServicoRealService } from "@/lib/services/tipos-servico-real"
import type { TipoServico, CalculoOrcamento } from "@/lib/types/tipos-servico"

export default function TiposServicoPage() {
  // State management
  const [tiposServico, setTiposServico] = useState<TipoServico[]>([])
  const [filteredTipos, setFilteredTipos] = useState<TipoServico[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [selectedTipo, setSelectedTipo] = useState<TipoServico | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [duplicateDialog, setDuplicateDialog] = useState<{ isOpen: boolean; tipo: TipoServico | null }>({
    isOpen: false,
    tipo: null,
  })
  const [duplicateName, setDuplicateName] = useState("")
  const [stats, setStats] = useState({
    total: 0,
    ativos: 0,
    inativos: 0,
    precoMedio: 0,
    totalVariaveis: 0,
    totalExtras: 0,
    tipoMaisCaro: null as TipoServico | null,
    tipoMaisBarato: null as TipoServico | null,
  })

  // Calculator state
  const [calculoData, setCalculoData] = useState({
    tipoServicoId: "",
    distanciaKm: 10,
    tempoHoras: 2,
    ajudantes: 0,
  })
  const [orcamentoCalculado, setOrcamentoCalculado] = useState<CalculoOrcamento | null>(null)
  const [isCalculating, setIsCalculating] = useState(false)

  // Load data on component mount
  useEffect(() => {
    loadTiposServico()
    loadStats()
  }, [])

  // Filter tipos based on search and status
  useEffect(() => {
    let filtered = tiposServico.filter(
      (tipo) =>
        tipo.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (tipo.descricao && tipo.descricao.toLowerCase().includes(searchTerm.toLowerCase())),
    )

    if (statusFilter !== "all") {
      filtered = filtered.filter((tipo) => (statusFilter === "ativo" ? tipo.ativo : !tipo.ativo))
    }

    setFilteredTipos(filtered)
  }, [tiposServico, searchTerm, statusFilter])

  // Data loading functions
  const loadTiposServico = async () => {
    try {
      setIsLoading(true)
      const data = await TipoServicoRealService.getAll()
      setTiposServico(data)
      toast({
        title: "Dados carregados",
        description: `${data.length} tipos de serviço encontrados`,
      })
    } catch (error) {
      console.error("Erro ao carregar tipos de serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os tipos de serviço",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const loadStats = async () => {
    try {
      const statsData = await TipoServicoRealService.getEstatisticas()
      setStats(statsData)
    } catch (error) {
      console.error("Erro ao carregar estatísticas:", error)
    }
  }

  // CRUD operations
  const handleNewTipo = () => {
    setSelectedTipo(null)
    setIsFormOpen(true)
  }

  const handleEditTipo = (tipo: TipoServico) => {
    setSelectedTipo(tipo)
    setIsFormOpen(true)
  }

  const handleViewTipo = (tipo: TipoServico) => {
    setSelectedTipo(tipo)
    setIsDetailsOpen(true)
  }

  const handleDeleteTipo = async () => {
    if (!deleteId) return

    try {
      await TipoServicoRealService.delete(deleteId)
      await loadTiposServico()
      await loadStats()
      setDeleteId(null)
      toast({
        title: "Sucesso",
        description: "Tipo de serviço desativado com sucesso",
      })
    } catch (error) {
      console.error("Erro ao excluir tipo de serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível desativar o tipo de serviço",
        variant: "destructive",
      })
    }
  }

  const handleReactivateTipo = async (id: string) => {
    try {
      await TipoServicoRealService.reativar(id)
      await loadTiposServico()
      await loadStats()
      toast({
        title: "Sucesso",
        description: "Tipo de serviço reativado com sucesso",
      })
    } catch (error) {
      console.error("Erro ao reativar tipo de serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível reativar o tipo de serviço",
        variant: "destructive",
      })
    }
  }

  const handleDuplicateTipo = (tipo: TipoServico) => {
    setDuplicateDialog({ isOpen: true, tipo })
    setDuplicateName(`${tipo.nome} - Cópia`)
  }

  const confirmDuplicate = async () => {
    if (!duplicateDialog.tipo || !duplicateName.trim()) return

    try {
      await TipoServicoRealService.duplicar(duplicateDialog.tipo.id, duplicateName.trim())
      await loadTiposServico()
      await loadStats()
      setDuplicateDialog({ isOpen: false, tipo: null })
      setDuplicateName("")
      toast({
        title: "Sucesso",
        description: "Tipo de serviço duplicado com sucesso",
      })
    } catch (error) {
      console.error("Erro ao duplicar tipo de serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível duplicar o tipo de serviço",
        variant: "destructive",
      })
    }
  }

  const handleCalculateTipo = (tipo: TipoServico) => {
    setCalculoData({ ...calculoData, tipoServicoId: tipo.id })
    // Switch to calculator tab
    const calculadoraTab = document.querySelector('[data-value="calculadora"]') as HTMLElement
    if (calculadoraTab) {
      calculadoraTab.click()
    }
  }

  const handleSaveTipo = async (savedTipo: TipoServico) => {
    await loadTiposServico()
    await loadStats()
    setIsFormOpen(false)
    toast({
      title: "Sucesso",
      description: `Tipo de serviço ${selectedTipo ? "atualizado" : "criado"} com sucesso`,
    })
  }

  // Calculator functions
  const calcularOrcamento = async () => {
    if (!calculoData.tipoServicoId) {
      toast({
        title: "Erro",
        description: "Selecione um tipo de serviço",
        variant: "destructive",
      })
      return
    }

    try {
      setIsCalculating(true)
      const resultado = await TipoServicoRealService.calcularOrcamento(
        calculoData.tipoServicoId,
        calculoData.distanciaKm,
        calculoData.tempoHoras,
        calculoData.ajudantes,
      )
      setOrcamentoCalculado(resultado)
      toast({
        title: "Cálculo realizado",
        description: `Valor total: ${formatCurrency(resultado.valor_total)}`,
      })
    } catch (error) {
      console.error("Erro ao calcular orçamento:", error)
      toast({
        title: "Erro",
        description: "Não foi possível calcular o orçamento",
        variant: "destructive",
      })
    } finally {
      setIsCalculating(false)
    }
  }

  // Utility functions
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const refreshData = async () => {
    await loadTiposServico()
    await loadStats()
  }

  return (
    <main className="flex-1 p-4 lg:p-6 space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tipos de Serviço</h1>
          <p className="text-muted-foreground">Gerencie os tipos de serviço, preços e custos do sistema</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={refreshData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          <Button onClick={handleNewTipo} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Novo Tipo de Serviço
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Tipos</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">
              {stats.ativos} ativos, {stats.inativos} inativos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Preço Médio</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.precoMedio)}</div>
            <p className="text-xs text-muted-foreground">Preço base médio</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Variáveis de Custo</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalVariaveis}</div>
            <p className="text-xs text-muted-foreground">Total configuradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Serviços Extras</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalExtras}</div>
            <p className="text-xs text-muted-foreground">Disponíveis</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="lista" className="space-y-4">
        <TabsList>
          <TabsTrigger value="lista">Lista de Tipos</TabsTrigger>
          <TabsTrigger value="calculadora">Calculadora de Preços</TabsTrigger>
          <TabsTrigger value="estatisticas">Estatísticas</TabsTrigger>
        </TabsList>

        {/* Service Types List Tab */}
        <TabsContent value="lista" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar tipos de serviço..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="ativo">Ativos</SelectItem>
                    <SelectItem value="inativo">Inativos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Service Types Grid */}
          {isLoading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredTipos.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredTipos.map((tipo) => (
                <ServiceTypeCard
                  key={tipo.id}
                  tipoServico={tipo}
                  onEdit={handleEditTipo}
                  onDelete={(id) => setDeleteId(id)}
                  onView={handleViewTipo}
                  onDuplicate={handleDuplicateTipo}
                  onReactivate={handleReactivateTipo}
                  onCalculate={handleCalculateTipo}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Package className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum tipo de serviço encontrado</h3>
                <p className="text-muted-foreground text-center mb-4">
                  {searchTerm || statusFilter !== "all"
                    ? "Tente ajustar os filtros ou criar um novo tipo de serviço"
                    : "Comece criando seu primeiro tipo de serviço"}
                </p>
                <Button onClick={handleNewTipo}>
                  <Plus className="h-4 w-4 mr-2" />
                  Criar Tipo de Serviço
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Price Calculator Tab */}
        <TabsContent value="calculadora" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Calculadora de Preços
                </CardTitle>
                <CardDescription>Simule o cálculo de preços para diferentes cenários</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="tipo-servico">Tipo de Serviço</Label>
                  <Select
                    value={calculoData.tipoServicoId}
                    onValueChange={(value) => setCalculoData({ ...calculoData, tipoServicoId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um tipo de serviço" />
                    </SelectTrigger>
                    <SelectContent>
                      {tiposServico
                        .filter((t) => t.ativo)
                        .map((tipo) => (
                          <SelectItem key={tipo.id} value={tipo.id}>
                            {tipo.nome}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="distancia">Distância (km)</Label>
                    <Input
                      id="distancia"
                      type="number"
                      min="0"
                      step="0.1"
                      value={calculoData.distanciaKm}
                      onChange={(e) => setCalculoData({ ...calculoData, distanciaKm: Number(e.target.value) })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tempo">Tempo (horas)</Label>
                    <Input
                      id="tempo"
                      type="number"
                      min="0"
                      step="0.5"
                      value={calculoData.tempoHoras}
                      onChange={(e) => setCalculoData({ ...calculoData, tempoHoras: Number(e.target.value) })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ajudantes">Ajudantes Adicionais</Label>
                  <Input
                    id="ajudantes"
                    type="number"
                    min="0"
                    value={calculoData.ajudantes}
                    onChange={(e) => setCalculoData({ ...calculoData, ajudantes: Number(e.target.value) })}
                  />
                </div>

                <Button onClick={calcularOrcamento} disabled={isCalculating} className="w-full">
                  {isCalculating ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Calculando...
                    </>
                  ) : (
                    <>
                      <Calculator className="h-4 w-4 mr-2" />
                      Calcular Preço
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Calculation Result */}
            {orcamentoCalculado && (
              <Card>
                <CardHeader>
                  <CardTitle>Resultado do Cálculo</CardTitle>
                  <CardDescription>Breakdown detalhado dos custos</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Preço Base:</span>
                      <span className="font-medium">{formatCurrency(orcamentoCalculado.subtotal_base)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Distância ({orcamentoCalculado.distancia_km} km):</span>
                      <span className="font-medium">{formatCurrency(orcamentoCalculado.subtotal_distancia)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tempo ({orcamentoCalculado.tempo_estimado_horas}h):</span>
                      <span className="font-medium">{formatCurrency(orcamentoCalculado.subtotal_tempo)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ajudantes ({orcamentoCalculado.ajudantes_adicionais}):</span>
                      <span className="font-medium">{formatCurrency(orcamentoCalculado.subtotal_ajudantes)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Variáveis de Custo:</span>
                      <span className="font-medium">{formatCurrency(orcamentoCalculado.subtotal_variaveis)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Serviços Extras:</span>
                      <span className="font-medium">{formatCurrency(orcamentoCalculado.subtotal_extras)}</span>
                    </div>
                    <div className="border-t pt-3">
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total:</span>
                        <span className="text-green-600">{formatCurrency(orcamentoCalculado.valor_total)}</span>
                      </div>
                    </div>
                  </div>

                  {orcamentoCalculado.variaveis_custo.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Variáveis de Custo Aplicadas:</h4>
                      <div className="space-y-1">
                        {orcamentoCalculado.variaveis_custo.map((variavel) => (
                          <div key={variavel.id} className="flex justify-between text-sm">
                            <span>{variavel.nome}</span>
                            <span>{formatCurrency(variavel.valor)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Statistics Tab */}
        <TabsContent value="estatisticas" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Análise de Preços
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {stats.tipoMaisCaro && (
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium text-green-600 mb-2">Tipo Mais Caro</h4>
                    <p className="font-semibold">{stats.tipoMaisCaro.nome}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatCurrency(stats.tipoMaisCaro.preco_base || 0)}
                    </p>
                  </div>
                )}

                {stats.tipoMaisBarato && (
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium text-blue-600 mb-2">Tipo Mais Barato</h4>
                    <p className="font-semibold">{stats.tipoMaisBarato.nome}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatCurrency(stats.tipoMaisBarato.preco_base || 0)}
                    </p>
                  </div>
                )}

                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-orange-600 mb-2">Preço Médio</h4>
                  <p className="text-2xl font-bold">{formatCurrency(stats.precoMedio)}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span>Ativos</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{stats.ativos}</span>
                      <Badge variant="outline">
                        {stats.total > 0 ? ((stats.ativos / stats.total) * 100).toFixed(1) : 0}%
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                      <span>Inativos</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{stats.inativos}</span>
                      <Badge variant="outline">
                        {stats.total > 0 ? ((stats.inativos / stats.total) * 100).toFixed(1) : 0}%
                      </Badge>
                    </div>
                  </div>

                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-500 h-2 rounded-full"
                      style={{ width: `${stats.total > 0 ? (stats.ativos / stats.total) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Dialogs and Modals */}
      <ServiceTypeForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveTipo}
        tipoServico={selectedTipo}
      />

      <ServiceTypeDetails
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        tipoServico={selectedTipo}
        onEdit={handleEditTipo}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Desativação</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja desativar este tipo de serviço? Esta ação pode ser revertida posteriormente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTipo}>Desativar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Duplicate Dialog */}
      <Dialog open={duplicateDialog.isOpen} onOpenChange={() => setDuplicateDialog({ isOpen: false, tipo: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Duplicar Tipo de Serviço</DialogTitle>
            <DialogDescription>
              Digite um nome para o novo tipo de serviço. Todas as configurações serão copiadas.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="duplicate-name">Nome do Novo Tipo</Label>
              <Input
                id="duplicate-name"
                value={duplicateName}
                onChange={(e) => setDuplicateName(e.target.value)}
                placeholder="Nome do tipo de serviço"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDuplicateDialog({ isOpen: false, tipo: null })}>
              Cancelar
            </Button>
            <Button onClick={confirmDuplicate} disabled={!duplicateName.trim()}>
              Duplicar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}
