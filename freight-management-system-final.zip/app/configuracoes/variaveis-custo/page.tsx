"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { toast } from "@/hooks/use-toast"
import {
  Plus,
  Search,
  BarChart3,
  Calculator,
  DollarSign,
  TrendingUp,
  Settings,
  RefreshCw,
  Download,
  Filter,
  Eye,
  EyeOff,
} from "lucide-react"
import { CostVariableCard } from "@/components/variaveis-custo/cost-variable-card"
import { CostVariableForm } from "@/components/variaveis-custo/cost-variable-form"
import { CostVariableDetails } from "@/components/variaveis-custo/cost-variable-details"
import { CostVariableCalculator } from "@/components/variaveis-custo/cost-variable-calculator"
import { VariaveisCustoService } from "@/lib/services/variaveis-custo"
import { TipoServicoRealService } from "@/lib/services/tipos-servico-real"
import type { VariavelCusto, TipoServico } from "@/lib/types/tipos-servico"

interface CostVariableStats {
  total: number
  ativas: number
  inativas: number
  valorMedio: number
  totalPorTipo: Record<string, number>
  maiorValor: VariavelCusto | null
  menorValor: VariavelCusto | null
  porUnidade: Record<string, number>
}

export default function VariaveisCustoPage() {
  // State management
  const [variaveis, setVariaveis] = useState<VariavelCusto[]>([])
  const [tiposServico, setTiposServico] = useState<TipoServico[]>([])
  const [filteredVariaveis, setFilteredVariaveis] = useState<VariavelCusto[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [selectedVariavel, setSelectedVariavel] = useState<VariavelCusto | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [tipoFilter, setTipoFilter] = useState<string>("all")
  const [unidadeFilter, setUnidadeFilter] = useState<string>("all")
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [duplicateDialog, setDuplicateDialog] = useState<{ isOpen: boolean; variavel: VariavelCusto | null }>({
    isOpen: false,
    variavel: null,
  })
  const [duplicateName, setDuplicateName] = useState("")
  const [showInactive, setShowInactive] = useState(false)

  // Statistics
  const [stats, setStats] = useState<CostVariableStats>({
    total: 0,
    ativas: 0,
    inativas: 0,
    valorMedio: 0,
    totalPorTipo: {},
    maiorValor: null,
    menorValor: null,
    porUnidade: {},
  })

  // Load data on component mount
  useEffect(() => {
    loadData()
  }, [])

  // Filter variables based on search and filters
  const filteredData = useMemo(() => {
    const filtered = variaveis.filter((variavel) => {
      const matchesSearch =
        variavel.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (variavel.descricao && variavel.descricao.toLowerCase().includes(searchTerm.toLowerCase()))

      const matchesStatus = statusFilter === "all" || (statusFilter === "ativa" ? variavel.ativo : !variavel.ativo)

      const matchesTipo = tipoFilter === "all" || variavel.tipo_servico_id === tipoFilter

      const matchesUnidade = unidadeFilter === "all" || variavel.unidade === unidadeFilter

      const matchesVisibility = showInactive || variavel.ativo

      return matchesSearch && matchesStatus && matchesTipo && matchesUnidade && matchesVisibility
    })

    return filtered.sort((a, b) => {
      if (a.ativo !== b.ativo) return a.ativo ? -1 : 1
      return a.nome.localeCompare(b.nome)
    })
  }, [variaveis, searchTerm, statusFilter, tipoFilter, unidadeFilter, showInactive])

  useEffect(() => {
    setFilteredVariaveis(filteredData)
  }, [filteredData])

  // Data loading functions
  const loadData = async () => {
    try {
      setIsLoading(true)
      const [variaveisData, tiposData] = await Promise.all([
        VariaveisCustoService.getAll(),
        TipoServicoRealService.getAtivos(),
      ])

      setVariaveis(variaveisData)
      setTiposServico(tiposData)
      calculateStats(variaveisData)

      toast({
        title: "Dados carregados",
        description: `${variaveisData.length} variáveis de custo encontradas`,
      })
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
      // Fallback to mock data
      const mockData = VariaveisCustoService.getMockData()
      setVariaveis(mockData)
      calculateStats(mockData)

      toast({
        title: "Modo offline",
        description: "Usando dados de exemplo. Conecte-se ao banco para dados reais.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const calculateStats = (data: VariavelCusto[]) => {
    const ativas = data.filter((v) => v.ativo)
    const inativas = data.filter((v) => !v.ativo)

    const valorMedio = data.length > 0 ? data.reduce((sum, v) => sum + v.valor, 0) / data.length : 0

    const totalPorTipo: Record<string, number> = {}
    const porUnidade: Record<string, number> = {}

    data.forEach((variavel) => {
      if (variavel.tipo_servico_id) {
        totalPorTipo[variavel.tipo_servico_id] = (totalPorTipo[variavel.tipo_servico_id] || 0) + 1
      }
      porUnidade[variavel.unidade || "fixo"] = (porUnidade[variavel.unidade || "fixo"] || 0) + 1
    })

    const maiorValor = data.reduce((max, v) => (v.valor > (max?.valor || 0) ? v : max), data[0] || null)
    const menorValor = data.reduce(
      (min, v) => (v.valor < (min?.valor || Number.POSITIVE_INFINITY) ? v : min),
      data[0] || null,
    )

    setStats({
      total: data.length,
      ativas: ativas.length,
      inativas: inativas.length,
      valorMedio,
      totalPorTipo,
      maiorValor,
      menorValor,
      porUnidade,
    })
  }

  // CRUD operations
  const handleNewVariavel = () => {
    setSelectedVariavel(null)
    setIsFormOpen(true)
  }

  const handleEditVariavel = (variavel: VariavelCusto) => {
    setSelectedVariavel(variavel)
    setIsFormOpen(true)
  }

  const handleViewVariavel = (variavel: VariavelCusto) => {
    setSelectedVariavel(variavel)
    setIsDetailsOpen(true)
  }

  const handleDeleteVariavel = async () => {
    if (!deleteId) return

    try {
      await VariaveisCustoService.delete(deleteId)
      await loadData()
      setDeleteId(null)
      toast({
        title: "Sucesso",
        description: "Variável de custo desativada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao excluir variável:", error)
      toast({
        title: "Erro",
        description: "Não foi possível desativar a variável de custo",
        variant: "destructive",
      })
    }
  }

  const handleReactivateVariavel = async (id: string) => {
    try {
      await VariaveisCustoService.reativar(id)
      await loadData()
      toast({
        title: "Sucesso",
        description: "Variável de custo reativada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao reativar variável:", error)
      toast({
        title: "Erro",
        description: "Não foi possível reativar a variável de custo",
        variant: "destructive",
      })
    }
  }

  const handleDuplicateVariavel = (variavel: VariavelCusto) => {
    setDuplicateDialog({ isOpen: true, variavel })
    setDuplicateName(`${variavel.nome} - Cópia`)
  }

  const confirmDuplicate = async () => {
    if (!duplicateDialog.variavel || !duplicateName.trim()) return

    try {
      await VariaveisCustoService.duplicar(duplicateDialog.variavel.id, duplicateName.trim())
      await loadData()
      setDuplicateDialog({ isOpen: false, variavel: null })
      setDuplicateName("")
      toast({
        title: "Sucesso",
        description: "Variável de custo duplicada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao duplicar variável:", error)
      toast({
        title: "Erro",
        description: "Não foi possível duplicar a variável de custo",
        variant: "destructive",
      })
    }
  }

  const handleSaveVariavel = async () => {
    await loadData()
    setIsFormOpen(false)
    toast({
      title: "Sucesso",
      description: `Variável de custo ${selectedVariavel ? "atualizada" : "criada"} com sucesso`,
    })
  }

  // Export functionality
  const exportToCSV = () => {
    const headers = ["Nome", "Descrição", "Valor", "Unidade", "Tipo de Serviço", "Status", "Criado em"]
    const csvData = filteredVariaveis.map((variavel) => [
      variavel.nome,
      variavel.descricao || "",
      variavel.valor.toString(),
      variavel.unidade || "fixo",
      tiposServico.find((t) => t.id === variavel.tipo_servico_id)?.nome || "Todos",
      variavel.ativo ? "Ativo" : "Inativo",
      new Date(variavel.created_at).toLocaleDateString("pt-BR"),
    ])

    const csvContent = [headers, ...csvData].map((row) => row.map((field) => `"${field}"`).join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `variaveis-custo-${new Date().toISOString().split("T")[0]}.csv`
    link.click()

    toast({
      title: "Exportação concluída",
      description: `${filteredVariaveis.length} variáveis exportadas`,
    })
  }

  // Utility functions
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const refreshData = async () => {
    await loadData()
  }

  const clearFilters = () => {
    setSearchTerm("")
    setStatusFilter("all")
    setTipoFilter("all")
    setUnidadeFilter("all")
    setShowInactive(false)
  }

  const uniqueUnidades = Array.from(new Set(variaveis.map((v) => v.unidade || "fixo")))

  return (
    <main className="flex-1 p-4 lg:p-6 space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Variáveis de Custo</h1>
          <p className="text-muted-foreground">Gerencie variáveis de custo aplicadas aos tipos de serviço</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={exportToCSV} disabled={isLoading}>
            <Download className="h-4 w-4 mr-2" />
            Exportar CSV
          </Button>
          <Button variant="outline" onClick={refreshData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          <Button onClick={handleNewVariavel} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Nova Variável
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Variáveis</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">
              {stats.ativas} ativas, {stats.inativas} inativas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Médio</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.valorMedio)}</div>
            <p className="text-xs text-muted-foreground">Por variável</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Maior Valor</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.maiorValor ? formatCurrency(stats.maiorValor.valor) : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">{stats.maiorValor?.nome || "Nenhuma variável"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tipos de Unidade</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.keys(stats.porUnidade).length}</div>
            <p className="text-xs text-muted-foreground">Unidades diferentes</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="lista" className="space-y-4">
        <TabsList>
          <TabsTrigger value="lista">Lista de Variáveis</TabsTrigger>
          <TabsTrigger value="calculadora">Calculadora</TabsTrigger>
          <TabsTrigger value="estatisticas">Estatísticas</TabsTrigger>
        </TabsList>

        {/* Variables List Tab */}
        <TabsContent value="lista" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Filtros</CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={clearFilters}>
                    <Filter className="h-4 w-4 mr-1" />
                    Limpar
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setShowInactive(!showInactive)}>
                    {showInactive ? (
                      <>
                        <EyeOff className="h-4 w-4 mr-1" />
                        Ocultar Inativas
                      </>
                    ) : (
                      <>
                        <Eye className="h-4 w-4 mr-1" />
                        Mostrar Inativas
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar variáveis..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>

                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Status</SelectItem>
                    <SelectItem value="ativa">Ativas</SelectItem>
                    <SelectItem value="inativa">Inativas</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={tipoFilter} onValueChange={setTipoFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Tipo de Serviço" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Tipos</SelectItem>
                    {tiposServico.map((tipo) => (
                      <SelectItem key={tipo.id} value={tipo.id}>
                        {tipo.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={unidadeFilter} onValueChange={setUnidadeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Unidade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as Unidades</SelectItem>
                    {uniqueUnidades.map((unidade) => (
                      <SelectItem key={unidade} value={unidade}>
                        {unidade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex items-center justify-center">
                  <Badge variant="outline" className="text-sm">
                    {filteredVariaveis.length} resultado{filteredVariaveis.length !== 1 ? "s" : ""}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Variables Grid */}
          {isLoading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredVariaveis.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredVariaveis.map((variavel) => (
                <CostVariableCard
                  key={variavel.id}
                  variavel={variavel}
                  tipoServico={tiposServico.find((t) => t.id === variavel.tipo_servico_id)}
                  onEdit={handleEditVariavel}
                  onDelete={(id) => setDeleteId(id)}
                  onView={handleViewVariavel}
                  onDuplicate={handleDuplicateVariavel}
                  onReactivate={handleReactivateVariavel}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calculator className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma variável encontrada</h3>
                <p className="text-muted-foreground text-center mb-4">
                  {searchTerm || statusFilter !== "all" || tipoFilter !== "all" || unidadeFilter !== "all"
                    ? "Tente ajustar os filtros ou criar uma nova variável"
                    : "Comece criando sua primeira variável de custo"}
                </p>
                <Button onClick={handleNewVariavel}>
                  <Plus className="h-4 w-4 mr-2" />
                  Criar Variável de Custo
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Calculator Tab */}
        <TabsContent value="calculadora" className="space-y-4">
          <CostVariableCalculator variaveis={variaveis.filter((v) => v.ativo)} tiposServico={tiposServico} />
        </TabsContent>

        {/* Statistics Tab */}
        <TabsContent value="estatisticas" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Distribuição por Unidade
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(stats.porUnidade).map(([unidade, count]) => (
                  <div key={unidade} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="capitalize">{unidade}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{count}</span>
                      <Badge variant="outline">{((count / stats.total) * 100).toFixed(1)}%</Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Análise de Valores</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {stats.maiorValor && (
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium text-green-600 mb-2">Maior Valor</h4>
                    <p className="font-semibold">{stats.maiorValor.nome}</p>
                    <p className="text-sm text-muted-foreground">{formatCurrency(stats.maiorValor.valor)}</p>
                  </div>
                )}

                {stats.menorValor && (
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium text-blue-600 mb-2">Menor Valor</h4>
                    <p className="font-semibold">{stats.menorValor.nome}</p>
                    <p className="text-sm text-muted-foreground">{formatCurrency(stats.menorValor.valor)}</p>
                  </div>
                )}

                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-orange-600 mb-2">Valor Médio</h4>
                  <p className="text-2xl font-bold">{formatCurrency(stats.valorMedio)}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Distribuição por Tipo de Serviço</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {Object.entries(stats.totalPorTipo).map(([tipoId, count]) => {
                    const tipo = tiposServico.find((t) => t.id === tipoId)
                    return (
                      <div key={tipoId} className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{tipo?.nome || "Tipo não encontrado"}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Dialogs and Modals */}
      <CostVariableForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveVariavel}
        variavel={selectedVariavel}
        tiposServico={tiposServico}
      />

      <CostVariableDetails
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        variavel={selectedVariavel}
        tipoServico={selectedVariavel ? tiposServico.find((t) => t.id === selectedVariavel.tipo_servico_id) : undefined}
        onEdit={handleEditVariavel}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Desativação</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja desativar esta variável de custo? Esta ação pode ser revertida posteriormente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteVariavel}>Desativar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Duplicate Dialog */}
      <Dialog open={duplicateDialog.isOpen} onOpenChange={() => setDuplicateDialog({ isOpen: false, variavel: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Duplicar Variável de Custo</DialogTitle>
            <DialogDescription>
              Digite um nome para a nova variável de custo. Todas as configurações serão copiadas.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="duplicate-name">Nome da Nova Variável</Label>
              <Input
                id="duplicate-name"
                value={duplicateName}
                onChange={(e) => setDuplicateName(e.target.value)}
                placeholder="Nome da variável de custo"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDuplicateDialog({ isOpen: false, variavel: null })}>
              Cancelar
            </Button>
            <Button onClick={confirmDuplicate} disabled={!duplicateName.trim()}>
              Duplicar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}
