import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { SimpleInstallButton } from "@/components/pwa/simple-install-button"
import { SimpleStatus } from "@/components/pwa/simple-status"
import { Truck, FileText, Calendar, DollarSign, Users, TrendingUp, Clock, MapPin } from "lucide-react"
import Link from "next/link"

const quickActions = [
  {
    title: "Novo Orcamento",
    description: "Criar orcamento para cliente",
    href: "/orcamentos",
    icon: FileText,
    color: "bg-blue-500",
  },
  {
    title: "Agendamentos",
    description: "Gerenciar agenda de entregas",
    href: "/agendamentos",
    icon: Calendar,
    color: "bg-green-500",
  },
  {
    title: "Painel Motorista",
    description: "Acesso para motoristas",
    href: "/motorista",
    icon: Truck,
    color: "bg-orange-500",
  },
  {
    title: "Financeiro",
    description: "Controle financeiro",
    href: "/financeiro",
    icon: DollarSign,
    color: "bg-purple-500",
  },
]

const stats = [
  {
    title: "Orcamentos Ativos",
    value: "24",
    change: "+12%",
    icon: FileText,
  },
  {
    title: "Entregas Hoje",
    value: "8",
    change: "+5%",
    icon: Truck,
  },
  {
    title: "Receita Mensal",
    value: "R$ 45.2k",
    change: "+18%",
    icon: TrendingUp,
  },
  {
    title: "Clientes Ativos",
    value: "156",
    change: "+8%",
    icon: Users,
  },
]

export default function HomePage() {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
                <p className="text-gray-600">Bem-vindo ao FreteSystem</p>
              </div>
              <div className="flex items-center gap-2">
                <SimpleStatus />
                <SimpleInstallButton />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                        <p className="text-sm text-green-600">{stat.change}</p>
                      </div>
                      <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <stat.icon className="h-6 w-6 text-blue-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {quickActions.map((action, index) => (
                <Link key={index} href={action.href}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader className="pb-3">
                      <div className={`h-12 w-12 ${action.color} rounded-lg flex items-center justify-center mb-3`}>
                        <action.icon className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle className="text-lg">{action.title}</CardTitle>
                      <CardDescription>{action.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="h-5 w-5 mr-2" />
                    Atividades Recentes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Orcamento #1234 aprovado</p>
                        <p className="text-xs text-gray-500">ha 2 horas</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Nova entrega agendada</p>
                        <p className="text-xs text-gray-500">ha 4 horas</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="h-2 w-2 bg-orange-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Motorista Joao em rota</p>
                        <p className="text-xs text-gray-500">ha 6 horas</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    Entregas de Hoje
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Centro - SP</p>
                        <p className="text-xs text-gray-500">Entregue as 09:30</p>
                      </div>
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Vila Madalena - SP</p>
                        <p className="text-xs text-gray-500">Em andamento</p>
                      </div>
                      <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Brooklin - SP</p>
                        <p className="text-xs text-gray-500">Agendado para 14:00</p>
                      </div>
                      <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
