"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { useOrcamentos } from "@/hooks/use-orcamentos"
import { QuickClientModal } from "@/components/clientes/quick-client-modal"
import { TipoServicoService } from "@/lib/services/tipos-servico"
import { ClienteService } from "@/lib/services/clientes"
import { safeText } from "@/lib/utils"
import type { Cliente, TipoServico } from "@/lib/types/database"

export default function OrcamentosPage() {
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [tiposServico, setTiposServico] = useState<TipoServico[]>([])
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [showClienteModal, setShowClienteModal] = useState(false)
  const [formData, setFormData] = useState({
    clienteId: "",
    tipoServicoId: "",
    enderecoOrigem: "",
    observacoesOrigem: "",
    enderecoDestino: "",
    observacoesDestino: "",
    dataAgendada: "",
    horaAgendada: "",
    ajudantesAdicionais: 0,
    observacoes: "",
    valorFinal: 0,
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const { toast } = useToast()
  const router = useRouter()
  const { createOrcamento } = useOrcamentos()

  // Carregar dados iniciais
  useState(() => {
    const loadData = async () => {
      setIsLoading(true)
      try {
        const [tiposServicoData, clientesData] = await Promise.all([
          TipoServicoService.getAll(),
          ClienteService.getAll(),
        ])
        setTiposServico(tiposServicoData)
        setClientes(clientesData)
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        toast({
          title: "Erro",
          description: "Falha ao carregar dados iniciais",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }
    loadData()
  })

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const validateStep = (currentStep: number) => {
    const newErrors: Record<string, string> = {}

    if (currentStep === 1) {
      if (!formData.tipoServicoId) {
        newErrors.tipoServicoId = "Selecione um tipo de servico"
      }
      if (!formData.clienteId) {
        newErrors.clienteId = "Selecione um cliente ou adicione um novo"
      }
    } else if (currentStep === 2) {
      if (!formData.enderecoOrigem) {
        newErrors.enderecoOrigem = "Endereco de origem e obrigatorio"
      }
      if (!formData.enderecoDestino) {
        newErrors.enderecoDestino = "Endereco de destino e obrigatorio"
      }
    } else if (currentStep === 3) {
      if (!formData.dataAgendada) {
        newErrors.dataAgendada = "Data e obrigatoria"
      }
      if (!formData.horaAgendada) {
        newErrors.horaAgendada = "Hora e obrigatoria"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (validateStep(step)) {
      setStep((prev) => prev + 1)
    }
  }

  const handleBack = () => {
    setStep((prev) => prev - 1)
  }

  const handleSubmit = async () => {
    if (!validateStep(step)) {
      return
    }

    setIsLoading(true)
    try {
      const result = await createOrcamento({
        clienteId: formData.clienteId,
        tipoServicoId: formData.tipoServicoId,
        enderecoOrigem: formData.enderecoOrigem,
        observacoesOrigem: formData.observacoesOrigem,
        enderecoDestino: formData.enderecoDestino,
        observacoesDestino: formData.observacoesDestino,
        dataAgendada: formData.dataAgendada,
        horaAgendada: formData.horaAgendada,
        ajudantesAdicionais: formData.ajudantesAdicionais,
        observacoes: formData.observacoes,
        valorFinal: formData.valorFinal || 0,
        status: "rascunho",
      })

      if (result) {
        toast({
          title: "Orcamento criado",
          description: "Orcamento criado com sucesso!",
        })
        router.push(`/orcamentos/${result.id}`)
      }
    } catch (error) {
      console.error("Erro ao criar orcamento:", error)
      toast({
        title: "Erro",
        description: "Falha ao criar orcamento. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleClienteCreated = (cliente: Cliente) => {
    setClientes((prev) => [...prev, cliente])
    setFormData((prev) => ({ ...prev, clienteId: cliente.id }))
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Novo Orcamento</h1>

      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle>
            {step === 1 && "Informacoes Basicas"}
            {step === 2 && "Enderecos"}
            {step === 3 && "Agendamento e Detalhes"}
            {step === 4 && "Revisao e Confirmacao"}
          </CardTitle>
          <CardDescription>
            {step === 1 && "Selecione o cliente e o tipo de servico"}
            {step === 2 && "Informe os enderecos de origem e destino"}
            {step === 3 && "Defina a data, hora e detalhes adicionais"}
            {step === 4 && "Revise todas as informacoes antes de finalizar"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          {step === 1 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="tipoServico">Tipo de Servico</Label>
                <Select
                  value={formData.tipoServicoId}
                  onValueChange={(value) => handleInputChange("tipoServicoId", value)}
                >
                  <SelectTrigger id="tipoServico" className={errors.tipoServicoId ? "border-red-500" : ""}>
                    <SelectValue placeholder="Selecione o tipo de servico" />
                  </SelectTrigger>
                  <SelectContent>
                    {tiposServico.map((tipo) => (
                      <SelectItem key={tipo.id} value={tipo.id}>
                        {safeText(tipo.nome)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.tipoServicoId && <p className="text-sm text-red-500">{errors.tipoServicoId}</p>}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="cliente">Cliente</Label>
                  <Button type="button" variant="outline" size="sm" onClick={() => setShowClienteModal(true)}>
                    Novo Cliente
                  </Button>
                </div>
                <Select value={formData.clienteId} onValueChange={(value) => handleInputChange("clienteId", value)}>
                  <SelectTrigger id="cliente" className={errors.clienteId ? "border-red-500" : ""}>
                    <SelectValue placeholder="Selecione o cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientes.map((cliente) => (
                      <SelectItem key={cliente.id} value={cliente.id}>
                        {safeText(cliente.nome)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.clienteId && <p className="text-sm text-red-500">{errors.clienteId}</p>}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="enderecoOrigem">Endereco de Origem</Label>
                <Textarea
                  id="enderecoOrigem"
                  value={formData.enderecoOrigem}
                  onChange={(e) => handleInputChange("enderecoOrigem", e.target.value)}
                  placeholder="Rua, numero, bairro, cidade, estado, CEP"
                  className={errors.enderecoOrigem ? "border-red-500" : ""}
                />
                {errors.enderecoOrigem && <p className="text-sm text-red-500">{errors.enderecoOrigem}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoesOrigem">Observacoes (Origem)</Label>
                <Textarea
                  id="observacoesOrigem"
                  value={formData.observacoesOrigem}
                  onChange={(e) => handleInputChange("observacoesOrigem", e.target.value)}
                  placeholder="Informacoes adicionais sobre o local de origem"
                />
              </div>

              <Separator className="my-4" />

              <div className="space-y-2">
                <Label htmlFor="enderecoDestino">Endereco de Destino</Label>
                <Textarea
                  id="enderecoDestino"
                  value={formData.enderecoDestino}
                  onChange={(e) => handleInputChange("enderecoDestino", e.target.value)}
                  placeholder="Rua, numero, bairro, cidade, estado, CEP"
                  className={errors.enderecoDestino ? "border-red-500" : ""}
                />
                {errors.enderecoDestino && <p className="text-sm text-red-500">{errors.enderecoDestino}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoesDestino">Observacoes (Destino)</Label>
                <Textarea
                  id="observacoesDestino"
                  value={formData.observacoesDestino}
                  onChange={(e) => handleInputChange("observacoesDestino", e.target.value)}
                  placeholder="Informacoes adicionais sobre o local de destino"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dataAgendada">Data</Label>
                  <Input
                    id="dataAgendada"
                    type="date"
                    value={formData.dataAgendada}
                    onChange={(e) => handleInputChange("dataAgendada", e.target.value)}
                    className={errors.dataAgendada ? "border-red-500" : ""}
                  />
                  {errors.dataAgendada && <p className="text-sm text-red-500">{errors.dataAgendada}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="horaAgendada">Hora</Label>
                  <Input
                    id="horaAgendada"
                    type="time"
                    value={formData.horaAgendada}
                    onChange={(e) => handleInputChange("horaAgendada", e.target.value)}
                    className={errors.horaAgendada ? "border-red-500" : ""}
                  />
                  {errors.horaAgendada && <p className="text-sm text-red-500">{errors.horaAgendada}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="ajudantesAdicionais">Ajudantes Adicionais</Label>
                <Input
                  id="ajudantesAdicionais"
                  type="number"
                  min="0"
                  max="5"
                  value={formData.ajudantesAdicionais}
                  onChange={(e) => handleInputChange("ajudantesAdicionais", Number.parseInt(e.target.value) || 0)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observacoes Gerais</Label>
                <Textarea
                  id="observacoes"
                  value={formData.observacoes}
                  onChange={(e) => handleInputChange("observacoes", e.target.value)}
                  placeholder="Informacoes adicionais sobre o servico"
                />
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-md">
                <h3 className="font-medium mb-2">Resumo do Orcamento</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="font-medium">Cliente:</div>
                  <div>{clientes.find((c) => c.id === formData.clienteId)?.nome || "N/A"}</div>

                  <div className="font-medium">Tipo de Servico:</div>
                  <div>{tiposServico.find((t) => t.id === formData.tipoServicoId)?.nome || "N/A"}</div>

                  <div className="font-medium">Origem:</div>
                  <div>{formData.enderecoOrigem}</div>

                  <div className="font-medium">Destino:</div>
                  <div>{formData.enderecoDestino}</div>

                  <div className="font-medium">Data/Hora:</div>
                  <div>
                    {formData.dataAgendada} às {formData.horaAgendada}
                  </div>

                  <div className="font-medium">Ajudantes:</div>
                  <div>{formData.ajudantesAdicionais}</div>

                  {formData.observacoes && (
                    <>
                      <div className="font-medium">Observacoes:</div>
                      <div>{formData.observacoes}</div>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-md">
                <h3 className="font-medium mb-2 text-blue-800">Valor Estimado</h3>
                <div className="text-2xl font-bold text-blue-700">
                  {new Intl.NumberFormat("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  }).format(formData.valorFinal || 0)}
                </div>
                <p className="text-xs text-blue-600 mt-1">
                  Este valor é uma estimativa e pode sofrer alterações conforme detalhes do serviço.
                </p>
              </div>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex justify-between">
          {step > 1 ? (
            <Button type="button" variant="outline" onClick={handleBack} disabled={isLoading}>
              Voltar
            </Button>
          ) : (
            <div></div>
          )}

          {step < 4 ? (
            <Button type="button" onClick={handleNext} disabled={isLoading}>
              Proximo
            </Button>
          ) : (
            <Button type="button" onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? "Salvando..." : "Finalizar Orcamento"}
            </Button>
          )}
        </CardFooter>
      </Card>

      <QuickClientModal
        open={showClienteModal}
        onOpenChange={setShowClienteModal}
        onClientCreated={handleClienteCreated}
      />
    </div>
  )
}
