"use client"

import { useEffect, useState } from "react"
import { Header } from "@/components/layout/header"
import { Sidebar } from "@/components/layout/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Plus,
  Search,
  Filter,
  MoreVertical,
  Eye,
  Edit,
  Send,
  Check,
  X,
  Clock,
  DollarSign,
  Calendar,
  MapPin,
  User,
  FileText,
  Download,
  Trash2,
  RefreshCw,
} from "lucide-react"
import { OrcamentoFilters } from "@/components/orcamentos/orcamento-filters"
import { OrcamentoExport } from "@/components/orcamentos/orcamento-export"
import { AprovacaoNotification } from "@/components/orcamentos/aprovacao-notification"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { useOrcamentos } from "@/hooks/use-orcamentos"

const statusConfig = {
  rascunho: { label: "Rascunho", color: "bg-gray-500", icon: FileText },
  enviado: { label: "Enviado", color: "bg-blue-500", icon: Send },
  aprovado: { label: "Aprovado", color: "bg-green-500", icon: Check },
  rejeitado: { label: "Rejeitado", color: "bg-red-500", icon: X },
  expirado: { label: "Expirado", color: "bg-orange-500", icon: Clock },
}

export default function OrcamentosListaPage() {
  const {
    orcamentos,
    isLoading,
    error,
    loadOrcamentos,
    updateOrcamentoStatus,
    deleteOrcamento,
    recalcularOrcamento,
    orcamentoAprovado,
    clearAprovacaoNotification,
  } = useOrcamentos()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("todos")
  const [sortBy, setSortBy] = useState<string>("data_desc")
  const [showFilters, setShowFilters] = useState(false)
  const [showExport, setShowExport] = useState(false)
  const { toast } = useToast()

  // Forçar recarregamento quando a página é montada
  useEffect(() => {
    loadOrcamentos()
  }, [])

  // Filtrar e ordenar orcamentos
  const filteredOrcamentos = orcamentos
    .filter((orcamento) => {
      const matchesSearch =
        orcamento.numero_orcamento?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        orcamento.cliente?.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        orcamento.endereco_origem?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        orcamento.endereco_destino?.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesStatus = statusFilter === "todos" || orcamento.status === statusFilter

      return matchesSearch && matchesStatus
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "data_desc":
          return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()
        case "data_asc":
          return new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime()
        case "valor_desc":
          return (b.valor_total || 0) - (a.valor_total || 0)
        case "valor_asc":
          return (a.valor_total || 0) - (b.valor_total || 0)
        case "cliente":
          return (a.cliente?.nome || "").localeCompare(b.cliente?.nome || "")
        default:
          return 0
      }
    })

  const handleStatusChange = async (orcamentoId: string, newStatus: string) => {
    const success = await updateOrcamentoStatus(orcamentoId, newStatus)
    if (success) {
      // A lista será recarregada automaticamente pelo hook
    }
  }

  const handleDelete = async (orcamentoId: string) => {
    if (window.confirm("Tem certeza que deseja excluir este orçamento?")) {
      try {
        await deleteOrcamento(orcamentoId)
        toast({
          title: "Sucesso",
          description: "Orçamento excluído com sucesso!",
        })
      } catch (error) {
        console.error("Erro ao excluir orçamento:", error)
        toast({
          title: "Erro",
          description: "Falha ao excluir orçamento.",
          variant: "destructive",
        })
      }
    }
  }

  const getStatusStats = () => {
    const stats = {
      total: orcamentos.length,
      rascunho: orcamentos.filter((o) => o.status === "rascunho").length,
      enviado: orcamentos.filter((o) => o.status === "enviado").length,
      aprovado: orcamentos.filter((o) => o.status === "aprovado").length,
      rejeitado: orcamentos.filter((o) => o.status === "rejeitado").length,
      expirado: orcamentos.filter((o) => o.status === "expirado").length,
    }
    return stats
  }

  const stats = getStatusStats()

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  if (error) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 lg:ml-64">
          <Header />
          <main className="flex-1 p-4 lg:p-6">
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center">
                  <p className="text-red-600 mb-4">Erro ao carregar orçamentos: {error}</p>
                  <Button onClick={loadOrcamentos}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Tentar Novamente
                  </Button>
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />

      <div className="flex-1 lg:ml-64">
        <Header />

        <main className="flex-1 space-y-6 p-4 lg:p-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Orçamentos</h1>
              <p className="text-muted-foreground">Gerencie todos os orçamentos criados</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setShowExport(true)}>
                <Download className="mr-2 h-4 w-4" />
                Exportar
              </Button>
              <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
                <Filter className="mr-2 h-4 w-4" />
                Filtros
              </Button>
              <Button onClick={loadOrcamentos} disabled={isLoading}>
                <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                Atualizar
              </Button>
              <Link href="/orcamentos">
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Orçamento
                </Button>
              </Link>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total</p>
                    <p className="text-2xl font-bold">{stats.total}</p>
                  </div>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Rascunhos</p>
                    <p className="text-2xl font-bold">{stats.rascunho}</p>
                  </div>
                  <FileText className="h-4 w-4 text-gray-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Enviados</p>
                    <p className="text-2xl font-bold">{stats.enviado}</p>
                  </div>
                  <Send className="h-4 w-4 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Aprovados</p>
                    <p className="text-2xl font-bold">{stats.aprovado}</p>
                  </div>
                  <Check className="h-4 w-4 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Rejeitados</p>
                    <p className="text-2xl font-bold">{stats.rejeitado}</p>
                  </div>
                  <X className="h-4 w-4 text-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Expirados</p>
                    <p className="text-2xl font-bold">{stats.expirado}</p>
                  </div>
                  <Clock className="h-4 w-4 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          {showFilters && (
            <Card>
              <CardContent className="p-4">
                <OrcamentoFilters
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  statusFilter={statusFilter}
                  onStatusFilterChange={setStatusFilter}
                  sortBy={sortBy}
                  onSortByChange={setSortBy}
                />
              </CardContent>
            </Card>
          )}

          {/* Search and Quick Filters */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar orçamentos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Status</SelectItem>
                <SelectItem value="rascunho">Rascunho</SelectItem>
                <SelectItem value="enviado">Enviado</SelectItem>
                <SelectItem value="aprovado">Aprovado</SelectItem>
                <SelectItem value="rejeitado">Rejeitado</SelectItem>
                <SelectItem value="expirado">Expirado</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="data_desc">Data (Mais Recente)</SelectItem>
                <SelectItem value="data_asc">Data (Mais Antigo)</SelectItem>
                <SelectItem value="valor_desc">Valor (Maior)</SelectItem>
                <SelectItem value="valor_asc">Valor (Menor)</SelectItem>
                <SelectItem value="cliente">Cliente (A-Z)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Orçamentos List */}
          <Card>
            <CardHeader>
              <CardTitle>Lista de Orçamentos ({filteredOrcamentos.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : filteredOrcamentos.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium text-muted-foreground mb-2">Nenhum orçamento encontrado</h3>
                  <p className="text-muted-foreground mb-4">
                    {searchTerm || statusFilter !== "todos"
                      ? "Tente ajustar os filtros de busca"
                      : "Comece criando seu primeiro orçamento"}
                  </p>
                  <Link href="/orcamentos">
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Criar Primeiro Orçamento
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredOrcamentos.map((orcamento) => {
                    const statusInfo = statusConfig[orcamento.status as keyof typeof statusConfig]
                    const StatusIcon = statusInfo?.icon || FileText

                    return (
                      <Card key={orcamento.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex-1 space-y-2">
                              <div className="flex items-center gap-3">
                                <h3 className="font-semibold text-lg">
                                  {orcamento.numero_orcamento || `#${orcamento.id?.slice(-6)}`}
                                </h3>
                                <Badge variant="secondary" className={`${statusInfo?.color} text-white`}>
                                  <StatusIcon className="mr-1 h-3 w-3" />
                                  {statusInfo?.label || orcamento.status}
                                </Badge>
                              </div>

                              <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-4">
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <User className="h-4 w-4" />
                                  <span>{orcamento.cliente?.nome || "Cliente não informado"}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <MapPin className="h-4 w-4" />
                                  <span className="truncate">
                                    {orcamento.endereco_origem?.split(",")[0] || "Origem não informada"}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <Calendar className="h-4 w-4" />
                                  <span>
                                    {orcamento.data_agendada
                                      ? formatDate(orcamento.data_agendada)
                                      : "Data não informada"}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 text-sm font-medium">
                                  <DollarSign className="h-4 w-4" />
                                  <span>{formatCurrency(orcamento.valor_total || 0)}</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                <span>
                                  Criado em:{" "}
                                  {orcamento.created_at ? formatDate(orcamento.created_at) : "Data não disponível"}
                                </span>
                                {orcamento.tipo_servico?.nome && <span>Serviço: {orcamento.tipo_servico.nome}</span>}
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    Visualizar
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Editar
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  {orcamento.status === "rascunho" && (
                                    <DropdownMenuItem onClick={() => handleStatusChange(orcamento.id, "enviado")}>
                                      <Send className="mr-2 h-4 w-4" />
                                      Enviar
                                    </DropdownMenuItem>
                                  )}
                                  {orcamento.status === "enviado" && (
                                    <>
                                      <DropdownMenuItem onClick={() => handleStatusChange(orcamento.id, "aprovado")}>
                                        <Check className="mr-2 h-4 w-4" />
                                        Aprovar
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => handleStatusChange(orcamento.id, "rejeitado")}>
                                        <X className="mr-2 h-4 w-4" />
                                        Rejeitar
                                      </DropdownMenuItem>
                                    </>
                                  )}
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => handleDelete(orcamento.id)} className="text-red-600">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Excluir
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Export Modal */}
          {showExport && <OrcamentoExport orcamentos={filteredOrcamentos} onClose={() => setShowExport(false)} />}

          {/* Notificação de Aprovação */}
          {orcamentoAprovado && (
            <AprovacaoNotification orcamento={orcamentoAprovado} onClose={clearAprovacaoNotification} />
          )}
        </main>
      </div>
    </div>
  )
}
