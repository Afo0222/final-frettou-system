"use client"

import { useEffect, useState } from "react"
import { Header } from "@/components/layout/header"
import { Sidebar } from "@/components/layout/sidebar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { FileText, Download } from "lucide-react"
import { FinanceiroService, type FinanceiroDashboard } from "@/lib/services/financeiro"
import { FinanceiroDashboardComponent } from "@/components/financeiro/dashboard"
import { ReceitasComponent } from "@/components/financeiro/receitas"
import { DespesasComponent } from "@/components/financeiro/despesas"
import { RelatoriosComponent } from "@/components/financeiro/relatorios"

export default function FinanceiroPage() {
  const [dashboardData, setDashboardData] = useState<FinanceiroDashboard | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        const data = await FinanceiroService.getDashboard()
        setDashboardData(data)
      } catch (error) {
        console.error("Erro ao carregar dashboard financeiro:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadDashboard()
  }, [])

  if (isLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 lg:ml-64">
          <Header />
          <main className="flex-1 p-4 lg:p-6">
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="mt-2 text-muted-foreground">Carregando dados financeiros...</p>
              </div>
            </div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />

      <div className="flex-1 lg:ml-64">
        <Header />

        <main className="flex-1 p-4 lg:p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Financeiro</h1>
              <p className="text-muted-foreground">Controle completo das finanças da empresa</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">
                <FileText className="mr-2 h-4 w-4" />
                Relatórios
              </Button>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Exportar
              </Button>
            </div>
          </div>

          <Tabs defaultValue="dashboard" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="receitas">Receitas</TabsTrigger>
              <TabsTrigger value="despesas">Despesas</TabsTrigger>
              <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="space-y-6">
              {dashboardData && <FinanceiroDashboardComponent data={dashboardData} />}
            </TabsContent>

            <TabsContent value="receitas" className="space-y-6">
              <ReceitasComponent />
            </TabsContent>

            <TabsContent value="despesas" className="space-y-6">
              <DespesasComponent />
            </TabsContent>

            <TabsContent value="relatorios" className="space-y-6">
              <RelatoriosComponent />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
