"use client"

import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Sidebar } from "@/components/layout/sidebar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, List, Clock, CheckCircle, XCircle, User } from "lucide-react"
import AgendamentoList from "@/components/agendamentos/agendamento-list"
import { Toaster } from "@/components/ui/toaster"
import { DriverAvailability } from "@/components/agendamentos/driver-availability"
import { Button } from "@/components/ui/button"
import { CalendarView } from "@/components/agendamentos/calendar-view"
import { AppointmentDetailsModal } from "@/components/agendamentos/appointment-details-modal"
import { NewAppointmentModal } from "@/components/agendamentos/new-appointment-modal"
import type { AgendamentoCompleto } from "@/lib/services/agendamentos-integrado"

export default function AgendamentosPage() {
  const [view, setView] = useState("lista")

  const [selectedAppointment, setSelectedAppointment] = useState<AgendamentoCompleto | null>(null)
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false)
  const [isNewModalOpen, setIsNewModalOpen] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>()

  const handleAppointmentClick = (appointment: AgendamentoCompleto) => {
    setSelectedAppointment(appointment)
    setIsDetailsModalOpen(true)
  }

  const handleNewAppointment = (date?: Date) => {
    setSelectedDate(date)
    setIsNewModalOpen(true)
  }

  const handleModalClose = () => {
    setSelectedAppointment(null)
    setIsDetailsModalOpen(false)
    setIsNewModalOpen(false)
    setSelectedDate(undefined)
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 lg:ml-64">
        <Header />
        <main className="flex-1 space-y-6 p-4 lg:p-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Agendamentos</h1>
              <p className="text-muted-foreground">Gerencie todos os agendamentos de serviços</p>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Agendados</p>
                    <p className="text-2xl font-bold">3</p>
                  </div>
                  <Calendar className="h-4 w-4 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Confirmados</p>
                    <p className="text-2xl font-bold">2</p>
                  </div>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Em Andamento</p>
                    <p className="text-2xl font-bold">1</p>
                  </div>
                  <Clock className="h-4 w-4 text-yellow-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Concluídos</p>
                    <p className="text-2xl font-bold">5</p>
                  </div>
                  <CheckCircle className="h-4 w-4 text-green-700" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Cancelados</p>
                    <p className="text-2xl font-bold">1</p>
                  </div>
                  <XCircle className="h-4 w-4 text-red-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Ações Rápidas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <DriverAvailability data={new Date().toISOString().split("T")[0]} horaInicio="08:00" horaFim="18:00" />
                <Button variant="outline" size="sm">
                  <Calendar className="mr-1 h-4 w-4" />
                  Novo Agendamento
                </Button>
                <Button variant="outline" size="sm">
                  <Clock className="mr-1 h-4 w-4" />
                  Reagendar
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs defaultValue="lista" value={view} onValueChange={setView}>
            <TabsList>
              <TabsTrigger value="lista">
                <List className="mr-2 h-4 w-4" />
                Lista
              </TabsTrigger>
              <TabsTrigger value="calendario">
                <Calendar className="mr-2 h-4 w-4" />
                Calendário
              </TabsTrigger>
            </TabsList>
            <TabsContent value="lista" className="mt-4">
              <AgendamentoList />
            </TabsContent>
            <TabsContent value="calendario" className="mt-4">
              <CalendarView onAppointmentClick={handleAppointmentClick} onNewAppointment={handleNewAppointment} />
            </TabsContent>
          </Tabs>
        </main>
      </div>
      <Toaster />
      <AppointmentDetailsModal
        appointment={selectedAppointment}
        isOpen={isDetailsModalOpen}
        onClose={handleModalClose}
        onUpdate={() => {
          // Refresh data if needed
        }}
      />

      <NewAppointmentModal
        isOpen={isNewModalOpen}
        onClose={handleModalClose}
        onCreated={() => {
          // Refresh data if needed
        }}
        selectedDate={selectedDate}
      />
    </div>
  )
}
