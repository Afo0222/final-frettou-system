import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const origin = searchParams.get("origin")
    const destination = searchParams.get("destination")
    const waypoints = searchParams.get("waypoints")
    const optimize = searchParams.get("optimize") === "true"
    const language = searchParams.get("language") || "pt-BR"
    const region = searchParams.get("region") || "BR"
    const units = searchParams.get("units") || "metric"

    if (!origin || !destination) {
      return NextResponse.json({ error: "Origin and destination parameters are required" }, { status: 400 })
    }

    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: "Google Maps API key not configured" }, { status: 500 })
    }

    const url = new URL("https://maps.googleapis.com/maps/api/directions/json")
    url.searchParams.set("origin", origin)
    url.searchParams.set("destination", destination)
    url.searchParams.set("language", language)
    url.searchParams.set("region", region)
    url.searchParams.set("units", units)
    url.searchParams.set("key", apiKey)

    // Adicionar waypoints se fornecidos
    if (waypoints) {
      const waypointsParam = optimize ? `optimize:true|${waypoints}` : waypoints
      url.searchParams.set("waypoints", waypointsParam)
    }

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`Google Directions API error: ${response.status}`)
    }

    const data = await response.json()

    // Verificar se há resultados válidos
    if (data.status !== "OK") {
      return NextResponse.json({
        error: `Directions API error: ${data.status}`,
        details: data.error_message || "Unknown error",
        status: data.status,
      })
    }

    if (!data.routes || data.routes.length === 0) {
      return NextResponse.json({
        error: "No routes found",
        status: "ZERO_RESULTS",
      })
    }

    // Processar e retornar apenas os dados necessários
    const route = data.routes[0]
    const leg = route.legs[0]

    const processedRoute = {
      distance: leg.distance,
      duration: leg.duration,
      polyline: route.overview_polyline.points,
      steps: leg.steps.map((step: any) => ({
        distance: step.distance,
        duration: step.duration,
        start_location: step.start_location,
        end_location: step.end_location,
        html_instructions: step.html_instructions,
        maneuver: step.maneuver,
      })),
      bounds: route.bounds,
      warnings: route.warnings || [],
      waypoint_order: route.waypoint_order || [],
    }

    return NextResponse.json({
      status: "OK",
      route: processedRoute,
    })
  } catch (error) {
    console.error("Erro na API de direções:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
