import { type NextRequest, NextResponse } from "next/server"

// Cache em memória para reduzir chamadas à API
const autocompleteCache = new Map<string, { data: any; timestamp: number }>()
const CACHE_DURATION = 30 * 60 * 1000 // 30 minutos

// Contador de requisições para controle de taxa
let requestTimestamps: number[] = []
const MAX_REQUESTS_PER_MINUTE = 15

// Função para validar API key
function validateApiKey(apiKey: string | undefined): boolean {
  if (!apiKey) return false

  // Verificar formato básico da API key do Google
  const googleApiKeyPattern = /^AIza[0-9A-Za-z-_]{35}$/
  return googleApiKeyPattern.test(apiKey)
}

// Função para sanitizar input
function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[^\w\s\-.,áàâãéèêíìîóòôõúùûçÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ]/g, "") // Remover caracteres especiais
    .substring(0, 100) // Limitar tamanho
}

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const { searchParams } = new URL(request.url)
    const rawInput = searchParams.get("input")
    const types = searchParams.get("types") || "address"
    const language = searchParams.get("language") || "pt-BR"
    const components = searchParams.get("components") || "country:br"

    console.log(`[AUTOCOMPLETE] Iniciando requisição - Input: "${rawInput}"`)

    // Validação de entrada
    if (!rawInput) {
      console.log("[AUTOCOMPLETE] Erro: Input vazio")
      return NextResponse.json({
        status: "INVALID_REQUEST",
        error: "Parâmetro 'input' é obrigatório",
        predictions: [],
        debug: { timestamp: new Date().toISOString(), input: rawInput },
      })
    }

    const input = sanitizeInput(rawInput)

    if (input.length < 3) {
      console.log(`[AUTOCOMPLETE] Erro: Input muito curto - "${input}"`)
      return NextResponse.json({
        status: "INVALID_REQUEST",
        error: "Input deve ter pelo menos 3 caracteres",
        predictions: [],
        debug: { timestamp: new Date().toISOString(), input: input, length: input.length },
      })
    }

    // Limpar timestamps antigos
    const now = Date.now()
    requestTimestamps = requestTimestamps.filter((time) => now - time < 60000)

    // Verificar limite de requisições
    if (requestTimestamps.length >= MAX_REQUESTS_PER_MINUTE) {
      console.log(`[AUTOCOMPLETE] Rate limit atingido: ${requestTimestamps.length} requisições`)
      return NextResponse.json({
        status: "OVER_QUERY_LIMIT",
        error: "Limite de requisições excedido. Tente novamente em alguns instantes.",
        predictions: [],
        debug: {
          timestamp: new Date().toISOString(),
          requestCount: requestTimestamps.length,
          maxRequests: MAX_REQUESTS_PER_MINUTE,
        },
      })
    }

    // Adicionar timestamp da requisição atual
    requestTimestamps.push(now)

    // Verificar cache
    const cacheKey = `${input.toLowerCase()}_${types}_${language}_${components}`
    const cachedResponse = autocompleteCache.get(cacheKey)

    if (cachedResponse && now - cachedResponse.timestamp < CACHE_DURATION) {
      console.log(`[AUTOCOMPLETE] Cache hit para: "${input}"`)
      return NextResponse.json({
        ...cachedResponse.data,
        debug: {
          ...cachedResponse.data.debug,
          cached: true,
          cacheAge: Math.round((now - cachedResponse.timestamp) / 1000),
        },
      })
    }

    // Verificar API key
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY

    if (!apiKey) {
      console.error("[AUTOCOMPLETE] ERRO CRÍTICO: API key não configurada")
      return NextResponse.json({
        status: "REQUEST_DENIED",
        error: "Google Maps API key não está configurada no servidor",
        predictions: [],
        debug: {
          timestamp: new Date().toISOString(),
          error: "MISSING_API_KEY",
          hasApiKey: false,
        },
      })
    }

    if (!validateApiKey(apiKey)) {
      console.error("[AUTOCOMPLETE] ERRO CRÍTICO: API key inválida")
      return NextResponse.json({
        status: "REQUEST_DENIED",
        error: "Google Maps API key tem formato inválido",
        predictions: [],
        debug: {
          timestamp: new Date().toISOString(),
          error: "INVALID_API_KEY_FORMAT",
          keyLength: apiKey.length,
          keyPrefix: apiKey.substring(0, 4),
        },
      })
    }

    console.log(`[AUTOCOMPLETE] API key válida - Fazendo requisição para Google`)

    // Construir URL da API do Google Places
    const googleUrl = new URL("https://maps.googleapis.com/maps/api/place/autocomplete/json")
    googleUrl.searchParams.set("input", input)
    googleUrl.searchParams.set("types", types)
    googleUrl.searchParams.set("language", language)
    googleUrl.searchParams.set("components", components)
    googleUrl.searchParams.set("key", apiKey)

    console.log(`[AUTOCOMPLETE] URL construída: ${googleUrl.toString().replace(apiKey, "API_KEY_HIDDEN")}`)

    // Configurar timeout e headers
    const controller = new AbortController()
    const timeoutId = setTimeout(() => {
      console.log("[AUTOCOMPLETE] Timeout atingido - Abortando requisição")
      controller.abort()
    }, 8000) // 8 segundos timeout

    try {
      console.log("[AUTOCOMPLETE] Iniciando fetch para Google Places API")

      const response = await fetch(googleUrl.toString(), {
        method: "GET",
        headers: {
          Accept: "application/json",
          "User-Agent": "FreightManagement/1.0",
          "Cache-Control": "no-cache, no-store, must-revalidate",
          Pragma: "no-cache",
        },
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      const responseTime = Date.now() - startTime
      console.log(`[AUTOCOMPLETE] Resposta recebida em ${responseTime}ms - Status: ${response.status}`)

      if (!response.ok) {
        console.error(`[AUTOCOMPLETE] HTTP Error: ${response.status} ${response.statusText}`)

        let errorBody = ""
        try {
          errorBody = await response.text()
          console.error(`[AUTOCOMPLETE] Error body: ${errorBody}`)
        } catch (e) {
          console.error("[AUTOCOMPLETE] Não foi possível ler o corpo do erro")
        }

        return NextResponse.json({
          status: "REQUEST_DENIED",
          error: `Google API retornou erro HTTP ${response.status}: ${response.statusText}`,
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            httpStatus: response.status,
            httpStatusText: response.statusText,
            errorBody: errorBody.substring(0, 200),
            responseTime: responseTime,
          },
        })
      }

      // Tentar fazer parse da resposta JSON
      let data: any
      try {
        const responseText = await response.text()
        console.log(`[AUTOCOMPLETE] Response text length: ${responseText.length}`)

        if (!responseText) {
          throw new Error("Resposta vazia do Google")
        }

        data = JSON.parse(responseText)
        console.log(`[AUTOCOMPLETE] JSON parsed successfully - Status: ${data?.status}`)
      } catch (parseError) {
        console.error("[AUTOCOMPLETE] Erro ao fazer parse do JSON:", parseError)
        return NextResponse.json({
          status: "UNKNOWN_ERROR",
          error: "Resposta inválida da API do Google - não é um JSON válido",
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            error: "JSON_PARSE_ERROR",
            parseError: parseError instanceof Error ? parseError.message : "Unknown parse error",
            responseTime: responseTime,
          },
        })
      }

      // Verificar se a resposta tem a estrutura esperada
      if (!data || typeof data !== "object") {
        console.error("[AUTOCOMPLETE] Resposta não é um objeto válido:", typeof data)
        return NextResponse.json({
          status: "UNKNOWN_ERROR",
          error: "Formato de resposta inválido da API do Google",
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            error: "INVALID_RESPONSE_FORMAT",
            dataType: typeof data,
            responseTime: responseTime,
          },
        })
      }

      // Log detalhado da resposta
      console.log(`[AUTOCOMPLETE] Resposta do Google:`, {
        status: data.status,
        predictions_count: data.predictions?.length || 0,
        error_message: data.error_message,
        has_predictions: Array.isArray(data.predictions),
      })

      // Verificar status da API do Google
      if (!data.status) {
        console.error("[AUTOCOMPLETE] Status ausente na resposta:", data)
        return NextResponse.json({
          status: "UNKNOWN_ERROR",
          error: "Status ausente na resposta da API do Google",
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            error: "MISSING_STATUS",
            responseKeys: Object.keys(data),
            responseTime: responseTime,
          },
        })
      }

      if (data.status !== "OK") {
        console.warn(`[AUTOCOMPLETE] Google API status não é OK: ${data.status}`)

        // Mapear erros específicos do Google
        const errorMessages: { [key: string]: string } = {
          ZERO_RESULTS: "Nenhum resultado encontrado para este endereço",
          OVER_QUERY_LIMIT: "Limite de consultas da API excedido",
          REQUEST_DENIED: "Requisição negada - verifique a configuração da API key",
          INVALID_REQUEST: "Requisição inválida - parâmetros incorretos",
          UNKNOWN_ERROR: "Erro desconhecido da API do Google",
        }

        const result = {
          status: data.status,
          error: errorMessages[data.status] || data.error_message || `Erro da API: ${data.status}`,
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            googleStatus: data.status,
            googleError: data.error_message,
            responseTime: responseTime,
          },
        }

        return NextResponse.json(result)
      }

      // Processar predictions
      const predictions = Array.isArray(data.predictions) ? data.predictions : []
      console.log(`[AUTOCOMPLETE] Processando ${predictions.length} predictions`)

      // Filtrar e formatar predictions
      const formattedPredictions = predictions
        .filter((prediction: any) => {
          const isValid = prediction && typeof prediction === "object" && prediction.description && prediction.place_id

          if (!isValid) {
            console.warn("[AUTOCOMPLETE] Prediction inválida filtrada:", prediction)
          }

          return isValid
        })
        .slice(0, 5) // Limitar a 5 sugestões
        .map((prediction: any, index: number) => {
          try {
            return {
              place_id: prediction.place_id,
              description: prediction.description,
              structured_formatting: prediction.structured_formatting || {},
              types: Array.isArray(prediction.types) ? prediction.types : [],
              terms: Array.isArray(prediction.terms) ? prediction.terms : [],
              matched_substrings: Array.isArray(prediction.matched_substrings) ? prediction.matched_substrings : [],
            }
          } catch (formatError) {
            console.error(`[AUTOCOMPLETE] Erro ao formatar prediction ${index}:`, formatError)
            return null
          }
        })
        .filter(Boolean) // Remover nulls

      console.log(`[AUTOCOMPLETE] ${formattedPredictions.length} predictions formatadas com sucesso`)

      const result = {
        status: "OK",
        predictions: formattedPredictions,
        debug: {
          timestamp: new Date().toISOString(),
          originalCount: predictions.length,
          filteredCount: formattedPredictions.length,
          responseTime: responseTime,
          cached: false,
        },
      }

      // Armazenar no cache apenas se tiver resultados válidos
      if (formattedPredictions.length > 0) {
        autocompleteCache.set(cacheKey, {
          data: result,
          timestamp: now,
        })

        // Limitar tamanho do cache
        if (autocompleteCache.size > 100) {
          const oldestKey = [...autocompleteCache.keys()][0]
          autocompleteCache.delete(oldestKey)
          console.log("[AUTOCOMPLETE] Cache limpo - removida entrada mais antiga")
        }
      }

      console.log(`[AUTOCOMPLETE] Requisição concluída com sucesso em ${Date.now() - startTime}ms`)

      return NextResponse.json(result, {
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
          Pragma: "no-cache",
          Expires: "0",
        },
      })
    } catch (fetchError) {
      clearTimeout(timeoutId)
      const responseTime = Date.now() - startTime

      console.error("[AUTOCOMPLETE] Erro na requisição fetch:", fetchError)

      if (fetchError instanceof Error && fetchError.name === "AbortError") {
        console.log("[AUTOCOMPLETE] Requisição cancelada por timeout")
        return NextResponse.json({
          status: "TIMEOUT",
          error: "Timeout na consulta à API do Google - tente novamente",
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            error: "TIMEOUT",
            responseTime: responseTime,
          },
        })
      }

      // Verificar se é erro de rede
      if (fetchError instanceof TypeError && fetchError.message.includes("fetch")) {
        console.error("[AUTOCOMPLETE] Erro de rede detectado")
        return NextResponse.json({
          status: "NETWORK_ERROR",
          error: "Erro de conexão com a API do Google - verifique sua internet",
          predictions: [],
          debug: {
            timestamp: new Date().toISOString(),
            error: "NETWORK_ERROR",
            errorMessage: fetchError.message,
            responseTime: responseTime,
          },
        })
      }

      return NextResponse.json({
        status: "UNKNOWN_ERROR",
        error: "Erro inesperado ao consultar a API do Google",
        predictions: [],
        debug: {
          timestamp: new Date().toISOString(),
          error: "FETCH_ERROR",
          errorName: fetchError instanceof Error ? fetchError.name : "Unknown",
          errorMessage: fetchError instanceof Error ? fetchError.message : "Unknown error",
          responseTime: responseTime,
        },
      })
    }
  } catch (error) {
    const responseTime = Date.now() - startTime
    console.error("[AUTOCOMPLETE] Erro geral na API:", error)

    return NextResponse.json({
      status: "SERVER_ERROR",
      error: "Erro interno do servidor",
      predictions: [],
      debug: {
        timestamp: new Date().toISOString(),
        error: "SERVER_ERROR",
        errorName: error instanceof Error ? error.name : "Unknown",
        errorMessage: error instanceof Error ? error.message : "Unknown error",
        responseTime: responseTime,
      },
    })
  }
}
