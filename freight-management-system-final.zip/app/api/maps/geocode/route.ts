import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const address = searchParams.get("address")
    const language = searchParams.get("language") || "pt-BR"
    const region = searchParams.get("region") || "br"

    console.log("Geocode API called with:", { address, language, region })

    if (!address) {
      console.error("Missing address parameter")
      return NextResponse.json({ error: "Address parameter is required" }, { status: 400 })
    }

    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    if (!apiKey) {
      console.error("Google Maps API key not configured")
      return NextResponse.json(
        {
          status: "ERROR",
          error: "API key not configured",
          results: [],
        },
        { status: 200 },
      )
    }

    console.log("Using API key:", apiKey.substring(0, 10) + "...")

    const url = new URL("https://maps.googleapis.com/maps/api/geocode/json")
    url.searchParams.set("address", address)
    url.searchParams.set("language", language)
    url.searchParams.set("region", region)
    url.searchParams.set("key", apiKey)

    console.log("Making request to Google Maps API:", url.toString().replace(apiKey, "***"))

    try {
      const response = await fetch(url.toString(), {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      console.log("Google Maps API response status:", response.status)

      if (!response.ok) {
        const errorText = await response.text()
        console.error(`Google Maps API responded with status: ${response.status}, body: ${errorText}`)
        return NextResponse.json(
          {
            status: "REQUEST_DENIED",
            error: `Google API error: ${response.status} - ${errorText}`,
            results: [],
          },
          { status: 200 },
        )
      }

      const data = await response.json()
      console.log("Google Maps API response data:", JSON.stringify(data, null, 2))

      // Se a API do Google retornar um erro
      if (data.status !== "OK") {
        console.warn(`Google Maps API status: ${data.status}, error: ${data.error_message || "Unknown error"}`)
        return NextResponse.json(
          {
            status: data.status,
            error: data.error_message || `Google Maps API returned status: ${data.status}`,
            results: [],
          },
          { status: 200 },
        )
      }

      // Filtrar apenas resultados brasileiros
      const filteredResults =
        data.results?.filter((result: any) => {
          return result.address_components?.some(
            (component: any) =>
              component.types.includes("country") &&
              (component.short_name === "BR" || component.long_name === "Brazil" || component.long_name === "Brasil"),
          )
        }) || []

      console.log(
        `Filtered ${filteredResults.length} Brazilian results from ${data.results?.length || 0} total results`,
      )

      return NextResponse.json({
        status: filteredResults.length > 0 ? "OK" : "ZERO_RESULTS",
        results: filteredResults,
      })
    } catch (fetchError) {
      console.error("Fetch error in geocode API:", fetchError)
      return NextResponse.json(
        {
          status: "FETCH_ERROR",
          error: fetchError instanceof Error ? fetchError.message : "Unknown fetch error",
          results: [],
        },
        { status: 200 },
      )
    }
  } catch (error) {
    console.error("Error in geocode API route:", error)
    return NextResponse.json(
      {
        status: "SERVER_ERROR",
        error: error instanceof Error ? error.message : "Unknown server error",
        results: [],
      },
      { status: 200 },
    )
  }
}
