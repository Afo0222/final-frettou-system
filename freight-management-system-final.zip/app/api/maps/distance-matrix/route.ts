import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const origins = searchParams.get("origins")
    const destinations = searchParams.get("destinations")
    const language = searchParams.get("language") || "pt-BR"
    const units = searchParams.get("units") || "metric"

    if (!origins || !destinations) {
      return NextResponse.json({ error: "Origins and destinations parameters are required" }, { status: 400 })
    }

    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: "Google Maps API key not configured" }, { status: 500 })
    }

    const url = new URL("https://maps.googleapis.com/maps/api/distancematrix/json")
    url.searchParams.set("origins", origins)
    url.searchParams.set("destinations", destinations)
    url.searchParams.set("language", language)
    url.searchParams.set("units", units)
    url.searchParams.set("key", apiKey)

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`Google Distance Matrix API error: ${response.status}`)
    }

    const data = await response.json()

    if (data.status !== "OK") {
      return NextResponse.json({
        error: `Distance Matrix API error: ${data.status}`,
        details: data.error_message || "Unknown error",
        status: data.status,
      })
    }

    // Processar matriz de distâncias
    const matrix = data.rows.map((row: any) =>
      row.elements.map((element: any) => ({
        distance: element.status === "OK" ? element.distance.value : 0,
        duration: element.status === "OK" ? element.duration.value : 0,
        status: element.status,
      })),
    )

    return NextResponse.json({
      status: "OK",
      matrix,
      origin_addresses: data.origin_addresses,
      destination_addresses: data.destination_addresses,
    })
  } catch (error) {
    console.error("Erro na API de matriz de distâncias:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
