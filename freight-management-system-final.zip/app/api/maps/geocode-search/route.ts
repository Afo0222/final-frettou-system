import { type NextRequest, NextResponse } from "next/server"
import { RateLimiter } from "@/lib/services/rate-limiter"

// Cache otimizado com TTL
const geocodeCache = new Map<string, { data: any; timestamp: number; hits: number }>()
const CACHE_DURATION = 45 * 60 * 1000 // 45 minutos (aumentado)
const MAX_CACHE_SIZE = 200 // Aumentado

// Rate Limiter por IP
const ipRateLimiters = new Map<string, RateLimiter>()
const GLOBAL_RATE_LIMITER = new RateLimiter(6, 60000, 60000) // 6 req/min global, cooldown 1min

// Limpeza periódica de cache
setInterval(
  () => {
    const now = Date.now()
    for (const [key, value] of geocodeCache.entries()) {
      if (now - value.timestamp > CACHE_DURATION) {
        geocodeCache.delete(key)
      }
    }

    // Limpar rate limiters inativos
    for (const [ip, limiter] of ipRateLimiters.entries()) {
      if (limiter.getRemainingRequests() === limiter["maxRequests"] && !limiter["isInCooldown"]) {
        ipRateLimiters.delete(ip)
      }
    }
  },
  5 * 60 * 1000,
) // A cada 5 minutos

function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get("x-forwarded-for")
  const real = request.headers.get("x-real-ip")

  if (forwarded) {
    return forwarded.split(",")[0].trim()
  }

  if (real) {
    return real
  }

  return "unknown"
}

function getOrCreateRateLimiter(ip: string): RateLimiter {
  if (!ipRateLimiters.has(ip)) {
    ipRateLimiters.set(ip, new RateLimiter(4, 60000, 30000)) // 4 req/min por IP
  }
  return ipRateLimiters.get(ip)!
}

function validateApiKey(apiKey: string | undefined): boolean {
  if (!apiKey) return false
  const googleApiKeyPattern = /^AIza[0-9A-Za-z-_]{35}$/
  return googleApiKeyPattern.test(apiKey)
}

function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[^\w\s\-.,áàâãéèêíìîóòôõúùûçÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ]/g, "")
    .substring(0, 80) // Reduzido para economizar
}

function generateSmartVariations(input: string): string[] {
  const variations = [input]
  const lowerInput = input.toLowerCase()

  // Apenas adicionar variações se realmente necessário
  if (!lowerInput.includes("brasil") && !lowerInput.includes("brazil")) {
    variations.push(`${input}, Brasil`)
  }

  // Adicionar apenas uma palavra-chave mais relevante
  const keywords = ["rua", "avenida"]
  for (const keyword of keywords) {
    if (!lowerInput.includes(keyword) && variations.length < 2) {
      variations.push(`${keyword} ${input}`)
      break // Apenas uma variação adicional
    }
  }

  return variations.slice(0, 2) // Máximo 2 variações para economizar
}

export async function GET(request: NextRequest) {
  const startTime = Date.now()
  const clientIP = getClientIP(request)

  try {
    const { searchParams } = new URL(request.url)
    const rawInput = searchParams.get("input")
    const language = searchParams.get("language") || "pt-BR"
    const region = searchParams.get("region") || "br"

    console.log(`[GEOCODE_SEARCH] IP: ${clientIP} - Input: "${rawInput}"`)

    // Validação básica
    if (!rawInput) {
      return NextResponse.json({
        status: "INVALID_REQUEST",
        error: "Parâmetro 'input' é obrigatório",
        results: [],
      })
    }

    const input = sanitizeInput(rawInput)

    if (input.length < 4) {
      // Aumentado para 4 caracteres
      return NextResponse.json({
        status: "INVALID_REQUEST",
        error: "Digite pelo menos 4 caracteres",
        results: [],
      })
    }

    // Rate Limiting Global
    const globalCheck = GLOBAL_RATE_LIMITER.canMakeRequest()
    if (!globalCheck.allowed) {
      console.log(`[GEOCODE_SEARCH] Rate limit global atingido`)
      return NextResponse.json({
        status: "OVER_QUERY_LIMIT",
        error: "Sistema temporariamente ocupado. Tente novamente em 1 minuto.",
        results: [],
        rateLimitInfo: {
          waitTime: globalCheck.waitTime,
          reason: globalCheck.reason,
          type: "global",
        },
      })
    }

    // Rate Limiting por IP
    const ipRateLimiter = getOrCreateRateLimiter(clientIP)
    const ipCheck = ipRateLimiter.canMakeRequest()

    if (!ipCheck.allowed) {
      console.log(`[GEOCODE_SEARCH] Rate limit IP ${clientIP} atingido`)
      return NextResponse.json({
        status: "OVER_QUERY_LIMIT",
        error: `Muitas consultas. Aguarde ${Math.ceil((ipCheck.waitTime || 30000) / 1000)} segundos.`,
        results: [],
        rateLimitInfo: {
          waitTime: ipCheck.waitTime,
          reason: ipCheck.reason,
          type: "ip",
          remaining: ipRateLimiter.getRemainingRequests(),
        },
      })
    }

    // Verificar cache (prioridade alta)
    const cacheKey = `geocode_${input.toLowerCase()}_${language}_${region}`
    const cachedResponse = geocodeCache.get(cacheKey)

    if (cachedResponse && Date.now() - cachedResponse.timestamp < CACHE_DURATION) {
      console.log(`[GEOCODE_SEARCH] Cache hit para: "${input}" (${cachedResponse.hits} hits)`)

      // Incrementar contador de hits
      cachedResponse.hits++

      return NextResponse.json({
        ...cachedResponse.data,
        cached: true,
        cacheAge: Math.round((Date.now() - cachedResponse.timestamp) / 1000),
        cacheHits: cachedResponse.hits,
      })
    }

    // Registrar requisição nos rate limiters
    GLOBAL_RATE_LIMITER.recordRequest()
    ipRateLimiter.recordRequest()

    // Verificar API key
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY

    if (!apiKey || !validateApiKey(apiKey)) {
      console.error("[GEOCODE_SEARCH] API key inválida ou não configurada")
      return NextResponse.json({
        status: "REQUEST_DENIED",
        error: "Configuração da API inválida",
        results: [],
      })
    }

    // Gerar variações otimizadas
    const addressVariations = generateSmartVariations(input)
    const allResults: any[] = []

    console.log(`[GEOCODE_SEARCH] Buscando ${addressVariations.length} variações`)

    // Buscar com timeout reduzido
    for (const variation of addressVariations) {
      try {
        const googleUrl = new URL("https://maps.googleapis.com/maps/api/geocode/json")
        googleUrl.searchParams.set("address", variation)
        googleUrl.searchParams.set("language", language)
        googleUrl.searchParams.set("region", region)
        googleUrl.searchParams.set("key", apiKey)

        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 3000) // Reduzido para 3s

        const response = await fetch(googleUrl.toString(), {
          method: "GET",
          headers: {
            Accept: "application/json",
            "User-Agent": "FreightManagement/1.0",
            "Cache-Control": "no-cache",
          },
          signal: controller.signal,
        })

        clearTimeout(timeoutId)

        if (response.ok) {
          const data = await response.json()

          if (data.status === "OK" && Array.isArray(data.results)) {
            allResults.push(...data.results.slice(0, 3)) // Máximo 3 por variação
          } else if (data.status === "OVER_QUERY_LIMIT") {
            // Se Google retornar limite, parar imediatamente
            console.warn("[GEOCODE_SEARCH] Google API rate limit atingido")
            break
          }
        }
      } catch (error) {
        console.warn(`[GEOCODE_SEARCH] Erro na variação "${variation}":`, error)
        // Continuar com outras variações
      }
    }

    const responseTime = Date.now() - startTime
    console.log(`[GEOCODE_SEARCH] Busca concluída em ${responseTime}ms - ${allResults.length} resultados`)

    // Processar resultados de forma otimizada
    const processedResults = allResults
      .filter((result, index, self) => {
        return index === self.findIndex((r) => r.place_id === result.place_id)
      })
      .filter((result) => {
        return result.formatted_address && result.formatted_address.toLowerCase().includes("brasil")
      })
      .map((result) => ({
        place_id: result.place_id,
        formatted_address: result.formatted_address,
        address_components: result.address_components || [],
        geometry: result.geometry || {},
        types: result.types || [],
        partial_match: result.partial_match || false,
        confidence: calculateConfidence(input, result.formatted_address),
      }))
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 4) // Reduzido para 4 resultados

    const result = {
      status: processedResults.length > 0 ? "OK" : "ZERO_RESULTS",
      results: processedResults,
      rateLimitInfo: {
        remaining: ipRateLimiter.getRemainingRequests(),
        resetTime: ipRateLimiter.getResetTime(),
        globalRemaining: GLOBAL_RATE_LIMITER.getRemainingRequests(),
      },
      debug: {
        timestamp: new Date().toISOString(),
        originalInput: input,
        variationsSearched: addressVariations.length,
        totalResults: allResults.length,
        filteredResults: processedResults.length,
        responseTime: responseTime,
        clientIP: clientIP,
        cached: false,
      },
    }

    // Cache apenas resultados bem-sucedidos
    if (processedResults.length > 0) {
      // Limitar tamanho do cache
      if (geocodeCache.size >= MAX_CACHE_SIZE) {
        // Remover entradas mais antigas
        const entries = [...geocodeCache.entries()]
        entries.sort((a, b) => a[1].timestamp - b[1].timestamp)

        for (let i = 0; i < 50; i++) {
          // Remover 50 entradas mais antigas
          if (entries[i]) {
            geocodeCache.delete(entries[i][0])
          }
        }
      }

      geocodeCache.set(cacheKey, {
        data: result,
        timestamp: Date.now(),
        hits: 1,
      })
    }

    return NextResponse.json(result, {
      headers: {
        "Cache-Control": "no-store, no-cache, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
    })
  } catch (error) {
    const responseTime = Date.now() - startTime
    console.error("[GEOCODE_SEARCH] Erro geral:", error)

    return NextResponse.json({
      status: "SERVER_ERROR",
      error: "Erro interno. Tente novamente em alguns instantes.",
      results: [],
      debug: {
        timestamp: new Date().toISOString(),
        error: "SERVER_ERROR",
        responseTime: responseTime,
        clientIP: clientIP,
      },
    })
  }
}

function calculateConfidence(query: string, address: string): number {
  const queryWords = query.toLowerCase().split(/\s+/).filter(Boolean)
  const addressWords = address.toLowerCase().split(/\s+/).filter(Boolean)

  let matches = 0
  queryWords.forEach((queryWord) => {
    if (addressWords.some((addressWord) => addressWord.includes(queryWord) || queryWord.includes(addressWord))) {
      matches++
    }
  })

  return matches / queryWords.length
}
