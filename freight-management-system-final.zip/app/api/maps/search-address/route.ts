import { type NextRequest, NextResponse } from "next/server"

// Cache robusto para endereços
const addressCache = new Map<string, { data: any; timestamp: number; hits: number }>()
const CACHE_DURATION = 2 * 60 * 60 * 1000 // 2 horas
const MAX_CACHE_SIZE = 500

// Rate limiting simplificado
let lastRequestTime = 0
const MIN_REQUEST_INTERVAL = 1000 // 1 segundo entre requisições

// Limpeza periódica do cache
setInterval(
  () => {
    const now = Date.now()
    let cleaned = 0

    for (const [key, value] of addressCache.entries()) {
      if (now - value.timestamp > CACHE_DURATION) {
        addressCache.delete(key)
        cleaned++
      }
    }

    if (cleaned > 0) {
      console.log(`[SEARCH_ADDRESS] Cache limpo: ${cleaned} entradas removidas`)
    }
  },
  10 * 60 * 1000,
) // A cada 10 minutos

function validateApiKey(apiKey: string | undefined): boolean {
  if (!apiKey) return false
  const googleApiKeyPattern = /^AIza[0-9A-Za-z-_]{35}$/
  return googleApiKeyPattern.test(apiKey)
}

function sanitizeAddress(address: string): string {
  return address
    .trim()
    .replace(/\s+/g, " ") // Normalizar espaços
    .replace(/[^\w\s\-.,áàâãéèêíìîóòôõúùûçÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ]/g, "")
    .substring(0, 200)
}

function enhanceAddress(address: string): string {
  const enhanced = address.toLowerCase()

  // Se não contém Brasil, adicionar
  if (!enhanced.includes("brasil") && !enhanced.includes("brazil")) {
    return `${address}, Brasil`
  }

  return address
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const body = await request.json()
    const { address: rawAddress } = body

    console.log(`[SEARCH_ADDRESS] Nova busca: "${rawAddress}"`)

    // Validação de entrada
    if (!rawAddress || typeof rawAddress !== "string") {
      return NextResponse.json(
        {
          success: false,
          error: "Endereço é obrigatório",
          results: [],
        },
        { status: 400 },
      )
    }

    const address = sanitizeAddress(rawAddress)

    if (address.length < 5) {
      return NextResponse.json(
        {
          success: false,
          error: "Endereço deve ter pelo menos 5 caracteres",
          results: [],
        },
        { status: 400 },
      )
    }

    // Rate limiting simples
    const now = Date.now()
    if (now - lastRequestTime < MIN_REQUEST_INTERVAL) {
      return NextResponse.json(
        {
          success: false,
          error: "Aguarde um momento antes de fazer nova busca",
          results: [],
        },
        { status: 429 },
      )
    }

    lastRequestTime = now

    // Verificar cache
    const enhancedAddress = enhanceAddress(address)
    const cacheKey = `search_${enhancedAddress.toLowerCase()}`
    const cached = addressCache.get(cacheKey)

    if (cached && now - cached.timestamp < CACHE_DURATION) {
      console.log(`[SEARCH_ADDRESS] Cache hit: "${address}" (${cached.hits} hits)`)
      cached.hits++

      return NextResponse.json({
        ...cached.data,
        cached: true,
        cacheAge: Math.round((now - cached.timestamp) / 1000),
        cacheHits: cached.hits,
      })
    }

    // Verificar API key
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY

    if (!apiKey || !validateApiKey(apiKey)) {
      console.error("[SEARCH_ADDRESS] API key inválida")
      return NextResponse.json(
        {
          success: false,
          error: "Configuração da API inválida",
          results: [],
        },
        { status: 500 },
      )
    }

    // Buscar no Google Maps
    console.log(`[SEARCH_ADDRESS] Buscando no Google: "${enhancedAddress}"`)

    const googleUrl = new URL("https://maps.googleapis.com/maps/api/geocode/json")
    googleUrl.searchParams.set("address", enhancedAddress)
    googleUrl.searchParams.set("language", "pt-BR")
    googleUrl.searchParams.set("region", "br")
    googleUrl.searchParams.set("key", apiKey)

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 8000) // 8 segundos

    const response = await fetch(googleUrl.toString(), {
      method: "GET",
      headers: {
        Accept: "application/json",
        "User-Agent": "FreightManagement/2.0",
      },
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`Google API HTTP error: ${response.status}`)
    }

    const data = await response.json()
    const responseTime = Date.now() - startTime

    console.log(`[SEARCH_ADDRESS] Resposta Google:`, {
      status: data.status,
      results: data.results?.length || 0,
      responseTime: `${responseTime}ms`,
    })

    // Processar resposta
    if (data.status === "OK" && Array.isArray(data.results) && data.results.length > 0) {
      // Filtrar apenas resultados no Brasil
      const brazilResults = data.results.filter(
        (result: any) => result.formatted_address && result.formatted_address.toLowerCase().includes("brasil"),
      )

      if (brazilResults.length === 0) {
        return NextResponse.json({
          success: false,
          error: "Nenhum endereço encontrado no Brasil",
          results: [],
          debug: {
            originalResults: data.results.length,
            filteredResults: 0,
            query: enhancedAddress,
          },
        })
      }

      // Processar resultados
      const processedResults = brazilResults.map((result: any, index: number) => ({
        id: `result_${index}`,
        place_id: result.place_id,
        formatted_address: result.formatted_address,
        address_components: result.address_components || [],
        geometry: {
          location: result.geometry?.location || null,
          location_type: result.geometry?.location_type || null,
          viewport: result.geometry?.viewport || null,
        },
        types: result.types || [],
        partial_match: result.partial_match || false,
        confidence: calculateAddressConfidence(address, result.formatted_address),
        quality_score: calculateQualityScore(result),
      }))

      // Ordenar por qualidade e confiança
      processedResults.sort((a, b) => {
        const scoreA = a.confidence * 0.6 + a.quality_score * 0.4
        const scoreB = b.confidence * 0.6 + b.quality_score * 0.4
        return scoreB - scoreA
      })

      const result = {
        success: true,
        results: processedResults.slice(0, 5), // Máximo 5 resultados
        total_found: brazilResults.length,
        search_query: enhancedAddress,
        response_time: responseTime,
        debug: {
          timestamp: new Date().toISOString(),
          originalQuery: address,
          enhancedQuery: enhancedAddress,
          googleStatus: data.status,
          originalResults: data.results.length,
          filteredResults: brazilResults.length,
          processedResults: processedResults.length,
        },
      }

      // Armazenar no cache
      if (addressCache.size >= MAX_CACHE_SIZE) {
        // Remover entradas mais antigas
        const entries = [...addressCache.entries()]
        entries.sort((a, b) => a[1].timestamp - b[1].timestamp)

        for (let i = 0; i < 100; i++) {
          if (entries[i]) {
            addressCache.delete(entries[i][0])
          }
        }
      }

      addressCache.set(cacheKey, {
        data: result,
        timestamp: now,
        hits: 1,
      })

      return NextResponse.json(result)
    } else {
      // Tratar diferentes status de erro
      const errorMessages = {
        ZERO_RESULTS: "Nenhum endereço encontrado. Verifique se o endereço está correto.",
        OVER_QUERY_LIMIT: "Limite de consultas excedido. Tente novamente em alguns minutos.",
        REQUEST_DENIED: "Acesso negado à API do Google Maps.",
        INVALID_REQUEST: "Consulta inválida. Verifique o formato do endereço.",
        UNKNOWN_ERROR: "Erro desconhecido. Tente novamente.",
      }

      const errorMessage =
        errorMessages[data.status as keyof typeof errorMessages] || `Erro na API do Google: ${data.status}`

      return NextResponse.json({
        success: false,
        error: errorMessage,
        results: [],
        debug: {
          timestamp: new Date().toISOString(),
          googleStatus: data.status,
          googleError: data.error_message,
          query: enhancedAddress,
          responseTime: responseTime,
        },
      })
    }
  } catch (error) {
    const responseTime = Date.now() - startTime
    console.error("[SEARCH_ADDRESS] Erro geral:", error)

    let errorMessage = "Erro interno do servidor"

    if (error instanceof Error) {
      if (error.name === "AbortError") {
        errorMessage = "Timeout na busca. Tente novamente."
      } else if (error.message.includes("fetch")) {
        errorMessage = "Erro de conexão. Verifique sua internet."
      } else {
        errorMessage = "Erro ao processar a busca"
      }
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        results: [],
        debug: {
          timestamp: new Date().toISOString(),
          error: error instanceof Error ? error.message : "Unknown error",
          responseTime: responseTime,
        },
      },
      { status: 500 },
    )
  }
}

// Calcular confiança do endereço
function calculateAddressConfidence(query: string, result: string): number {
  const queryWords = query.toLowerCase().split(/\s+/).filter(Boolean)
  const resultWords = result.toLowerCase().split(/\s+/).filter(Boolean)

  let matches = 0
  let partialMatches = 0

  queryWords.forEach((queryWord) => {
    const exactMatch = resultWords.some((resultWord) => resultWord === queryWord)
    const partialMatch = resultWords.some(
      (resultWord) => resultWord.includes(queryWord) || queryWord.includes(resultWord),
    )

    if (exactMatch) {
      matches += 1
    } else if (partialMatch) {
      partialMatches += 0.5
    }
  })

  return Math.min(1, (matches + partialMatches) / queryWords.length)
}

// Calcular score de qualidade
function calculateQualityScore(result: any): number {
  let score = 0.5 // Base score

  // Bonus por tipo de endereço
  if (result.types?.includes("street_address")) score += 0.3
  if (result.types?.includes("route")) score += 0.2
  if (result.types?.includes("premise")) score += 0.2

  // Bonus por componentes de endereço
  const components = result.address_components || []
  if (components.some((c: any) => c.types?.includes("street_number"))) score += 0.1
  if (components.some((c: any) => c.types?.includes("route"))) score += 0.1
  if (components.some((c: any) => c.types?.includes("postal_code"))) score += 0.1

  // Penalidade por match parcial
  if (result.partial_match) score -= 0.2

  return Math.max(0, Math.min(1, score))
}
