import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const placeId = searchParams.get("place_id")

    if (!placeId) {
      return NextResponse.json({
        status: "INVALID_REQUEST",
        error: "place_id é obrigatório",
      })
    }

    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    if (!apiKey) {
      return NextResponse.json({
        status: "REQUEST_DENIED",
        error: "API key não configurada",
      })
    }

    const url = new URL("https://maps.googleapis.com/maps/api/place/details/json")
    url.searchParams.set("place_id", placeId)
    url.searchParams.set("fields", "formatted_address,geometry,address_components")
    url.searchParams.set("language", "pt-BR")
    url.searchParams.set("key", apiKey)

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)

    try {
      const response = await fetch(url.toString(), {
        method: "GET",
        headers: {
          Accept: "application/json",
          "User-Agent": "FreightManagement/1.0",
        },
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        return NextResponse.json({
          status: "REQUEST_DENIED",
          error: `Google API HTTP error: ${response.status}`,
        })
      }

      const data = await response.json()

      if (data.status !== "OK") {
        return NextResponse.json({
          status: data.status,
          error: data.error_message || "Erro da API do Google",
        })
      }

      return NextResponse.json({
        status: "OK",
        result: data.result,
      })
    } catch (fetchError) {
      clearTimeout(timeoutId)

      if (fetchError instanceof Error && fetchError.name === "AbortError") {
        return NextResponse.json({
          status: "TIMEOUT",
          error: "Timeout na consulta",
        })
      }

      return NextResponse.json({
        status: "NETWORK_ERROR",
        error: "Erro de rede",
      })
    }
  } catch (error) {
    return NextResponse.json({
      status: "SERVER_ERROR",
      error: "Erro interno do servidor",
    })
  }
}
