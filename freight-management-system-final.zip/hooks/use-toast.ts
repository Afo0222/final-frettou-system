// Arquivo hooks/use-toast.ts
import { useToast as useToastOriginal } from "@/components/ui/use-toast"

export const useToast = useToastOriginal
export { toast } from "@/components/ui/use-toast"
