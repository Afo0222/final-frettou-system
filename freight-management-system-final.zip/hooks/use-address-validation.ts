"use client"

import { useState, useCallback } from "react"
import { AddressValidationService, type AddressValidationResult } from "@/lib/services/address-validation"

export interface UseAddressValidationReturn {
  validateAddress: (address: string) => Promise<AddressValidationResult>
  validateAddressPair: (origin: string, destination: string) => Promise<any>
  isValidating: boolean
  lastValidation: AddressValidationResult | null
  clearValidation: () => void
}

export function useAddressValidation(): UseAddressValidationReturn {
  const [isValidating, setIsValidating] = useState(false)
  const [lastValidation, setLastValidation] = useState<AddressValidationResult | null>(null)

  const validateAddress = useCallback(async (address: string): Promise<AddressValidationResult> => {
    setIsValidating(true)
    try {
      const result = await AddressValidationService.validateAddress(address)
      setLastValidation(result)
      return result
    } catch (error) {
      const errorResult: AddressValidationResult = {
        isValid: false,
        confidence: "low",
        originalAddress: address,
        errors: ["Erro ao validar endereço"],
      }
      setLastValidation(errorResult)
      return errorResult
    } finally {
      setIsValidating(false)
    }
  }, [])

  const validateAddressPair = useCallback(async (origin: string, destination: string) => {
    setIsValidating(true)
    try {
      const result = await AddressValidationService.validateAddressPair(origin, destination)
      return result
    } catch (error) {
      console.error("Erro na validação do par:", error)
      throw error
    } finally {
      setIsValidating(false)
    }
  }, [])

  const clearValidation = useCallback(() => {
    setLastValidation(null)
  }, [])

  return {
    validateAddress,
    validateAddressPair,
    isValidating,
    lastValidation,
    clearValidation,
  }
}
