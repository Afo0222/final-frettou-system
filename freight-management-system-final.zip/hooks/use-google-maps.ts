"use client"

import { useState, useCallback } from "react"
import {
  GoogleMapsService,
  type Address,
  type RouteInfo,
  type OptimizedRoute,
  type Coordinates,
} from "@/lib/services/google-maps"
import { useToast } from "@/hooks/use-toast"

export function useGoogleMaps() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  const handleError = useCallback(
    (error: any, defaultMessage: string) => {
      const message = error?.message || defaultMessage
      setError(message)
      toast({
        title: "Erro",
        description: message,
        variant: "destructive",
      })
    },
    [toast],
  )

  const geocodeAddress = useCallback(
    async (address: string): Promise<Address | null> => {
      if (!address.trim()) return null

      setLoading(true)
      setError(null)

      try {
        const result = await GoogleMapsService.geocodeAddress(address)
        return result
      } catch (error) {
        handleError(error, "Erro ao geocodificar endereço")
        return null
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const reverseGeocode = useCallback(
    async (lat: number, lng: number): Promise<Address | null> => {
      setLoading(true)
      setError(null)

      try {
        const result = await GoogleMapsService.reverseGeocode(lat, lng)
        return result
      } catch (error) {
        handleError(error, "Erro ao obter endereço das coordenadas")
        return null
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const calculateRoute = useCallback(
    async (
      origin: string | Coordinates,
      destination: string | Coordinates,
      waypoints?: (string | Coordinates)[],
      optimize = false,
    ): Promise<RouteInfo | null> => {
      setLoading(true)
      setError(null)

      try {
        const result = await GoogleMapsService.calculateRoute(origin, destination, waypoints, optimize)
        return result
      } catch (error) {
        handleError(error, "Erro ao calcular rota")
        return null
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const optimizeRoute = useCallback(
    async (
      origin: string | Coordinates,
      destination: string | Coordinates,
      waypoints: (string | Coordinates)[],
      vehicleType = "truck",
    ): Promise<OptimizedRoute | null> => {
      setLoading(true)
      setError(null)

      try {
        const result = await GoogleMapsService.optimizeRoute(origin, destination, waypoints, vehicleType)
        return result
      } catch (error) {
        handleError(error, "Erro ao otimizar rota")
        return null
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const validateAddress = useCallback(
    async (address: string) => {
      if (!address.trim()) return { isValid: false }

      setLoading(true)
      setError(null)

      try {
        const result = await GoogleMapsService.validateAddress(address)
        return result
      } catch (error) {
        handleError(error, "Erro ao validar endereço")
        return { isValid: false }
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const findNearbyPlaces = useCallback(
    async (location: Coordinates, type: string, radius = 5000) => {
      setLoading(true)
      setError(null)

      try {
        const result = await GoogleMapsService.findNearbyPlaces(location, type, radius)
        return result
      } catch (error) {
        handleError(error, "Erro ao buscar lugares próximos")
        return []
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const calculateDistance = useCallback(
    async (
      origin: string | Coordinates,
      destination: string | Coordinates,
    ): Promise<{ distance: number; duration: number } | null> => {
      setLoading(true)
      setError(null)

      try {
        const route = await GoogleMapsService.calculateRoute(origin, destination)
        if (!route) return null

        return {
          distance: route.distance.value,
          duration: route.duration.value,
        }
      } catch (error) {
        handleError(error, "Erro ao calcular distância")
        return null
      } finally {
        setLoading(false)
      }
    },
    [handleError],
  )

  const isConfigured = GoogleMapsService.isConfigured()

  return {
    loading,
    error,
    isConfigured,
    geocodeAddress,
    reverseGeocode,
    calculateRoute,
    optimizeRoute,
    validateAddress,
    findNearbyPlaces,
    calculateDistance,
    clearError: () => setError(null),
    clearCache: GoogleMapsService.clearCache,
  }
}
