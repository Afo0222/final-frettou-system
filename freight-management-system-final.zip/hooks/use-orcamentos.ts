"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { NotificationService } from "@/lib/services/notifications"
import { ErrorHandler } from "@/lib/error-handler"
import { createClient } from "@/lib/supabase/client"
import type { Orcamento } from "@/lib/types/database"

interface OrcamentoInput {
  clienteId?: string
  tipoServicoId: string
  enderecoOrigem: string
  observacoesOrigem?: string
  enderecoDestino: string
  observacoesDestino?: string
  dataAgendada: string
  horaAgendada: string
  ajudantesAdicionais: number
  servicosExtrasIds?: string[]
  observacoes?: string
  valorFinal: number
  status: "rascunho" | "enviado"
  novoCliente?: {
    nome: string
    telefone: string
    email?: string
    documento?: string
    endereco?: string
  }
}

export function useOrcamentos() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const createOrcamento = async (input: OrcamentoInput): Promise<Orcamento | null> => {
    setIsLoading(true)

    try {
      // Se tiver um novo cliente, criar primeiro
      let clienteId = input.clienteId

      if (!clienteId && input.novoCliente) {
        const [clienteData, clienteError] = await ErrorHandler.handle(
          supabase.from("clientes").insert([input.novoCliente]).select().single(),
          "Erro ao criar novo cliente",
        )

        if (clienteError || !clienteData) {
          throw new Error("Falha ao criar novo cliente")
        }

        clienteId = clienteData.data.id
      }

      // Criar o orçamento
      const orcamentoData = {
        cliente_id: clienteId,
        tipo_servico_id: input.tipoServicoId,
        endereco_origem: input.enderecoOrigem,
        observacoes_origem: input.observacoesOrigem,
        endereco_destino: input.enderecoDestino,
        observacoes_destino: input.observacoesDestino,
        data_agendada: input.dataAgendada,
        hora_agendada: input.horaAgendada,
        ajudantes_adicionais: input.ajudantesAdicionais,
        servicos_extras: input.servicosExtrasIds,
        observacoes: input.observacoes,
        valor_final: input.valorFinal,
        status: input.status,
      }

      const [orcamentoResult, orcamentoError] = await ErrorHandler.handle(
        supabase.from("orcamentos").insert([orcamentoData]).select().single(),
        "Erro ao criar orçamento",
      )

      if (orcamentoError || !orcamentoResult) {
        throw new Error("Falha ao criar orçamento")
      }

      return orcamentoResult.data as Orcamento
    } catch (error) {
      NotificationService.error("Erro ao criar orçamento", ErrorHandler.formatErrorMessage(error))
      return null
    } finally {
      setIsLoading(false)
    }
  }

  return {
    isLoading,
    createOrcamento,
  }
}
