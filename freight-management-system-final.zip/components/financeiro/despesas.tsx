"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Filter, Plus, MoreHorizontal, Edit, Copy, Trash2, CheckCircle } from "lucide-react"
import { FinanceiroService, type FinanceiroItem } from "@/lib/services/financeiro"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export function DespesasComponent() {
  const [despesas, setDespesas] = useState<FinanceiroItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [currentItem, setCurrentItem] = useState<FinanceiroItem | null>(null)
  const [itemToDelete, setItemToDelete] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const [filters, setFilters] = useState({
    periodo: { inicio: "", fim: "" },
    categoria: "",
    status: "",
  })
  const [formData, setFormData] = useState({
    descricao: "",
    categoria: "",
    valor: "",
    data_vencimento: "",
    metodo_pagamento: "",
    observacoes: "",
    status_pagamento: "pendente",
  })

  const categorias = [
    { value: "combustivel", label: "Combustível" },
    { value: "manutencao", label: "Manutenção" },
    { value: "salarios", label: "Salários" },
    { value: "pedagio", label: "Pedágios" },
    { value: "seguro", label: "Seguro" },
    { value: "outros", label: "Outros" },
  ]

  useEffect(() => {
    loadDespesas()
  }, [])

  const loadDespesas = async () => {
    try {
      setIsLoading(true)

      // Verificar se os filtros de data estão vazios antes de enviar
      const filtrosAplicados = {
        ...filters,
        periodo: {
          inicio: filters.periodo.inicio || "",
          fim: filters.periodo.fim || "",
        },
      }

      const data = await FinanceiroService.getDespesas(filtrosAplicados)
      setDespesas(data)
    } catch (error) {
      console.error("Erro ao carregar despesas:", error)
      // Adicionar feedback visual para o usuário
      alert("Erro ao carregar despesas. Verifique os filtros e tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateDespesa = async () => {
    try {
      const novaDespesa = await FinanceiroService.createDespesa({
        categoria: formData.categoria,
        descricao: formData.descricao,
        valor: Number.parseFloat(formData.valor),
        data_vencimento: formData.data_vencimento,
        status_pagamento: formData.status_pagamento as any,
        metodo_pagamento: formData.metodo_pagamento || undefined,
        observacoes: formData.observacoes || undefined,
      })

      // Adicionar ao estado local em vez de recarregar
      setDespesas((prev) => [novaDespesa, ...prev])

      setIsDialogOpen(false)
      resetFormData()
    } catch (error) {
      console.error("Erro ao criar despesa:", error)
      alert("Erro ao criar despesa. Tente novamente.")
    }
  }

  const handleUpdateDespesa = async () => {
    if (!currentItem) return

    try {
      await FinanceiroService.updateItem(currentItem.id, {
        categoria: formData.categoria,
        descricao: formData.descricao,
        valor: Number.parseFloat(formData.valor),
        data_vencimento: formData.data_vencimento,
        status_pagamento: formData.status_pagamento as any,
        metodo_pagamento: formData.metodo_pagamento || undefined,
        observacoes: formData.observacoes || undefined,
      })

      setIsDialogOpen(false)
      setCurrentItem(null)
      resetFormData()
      loadDespesas()
    } catch (error) {
      console.error("Erro ao atualizar despesa:", error)
    }
  }

  const handleDeleteDespesa = async () => {
    if (!itemToDelete) return

    try {
      setIsDeleting(true)
      await FinanceiroService.deleteItem(itemToDelete)

      // Atualizar estado local em vez de recarregar tudo
      setDespesas((prev) => prev.filter((item) => item.id !== itemToDelete))

      setIsDeleteDialogOpen(false)
      setItemToDelete(null)
    } catch (error) {
      console.error("Erro ao excluir despesa:", error)
      // Mostrar feedback de erro para o usuário
      alert("Erro ao excluir despesa. Tente novamente.")
    } finally {
      setIsDeleting(false)
    }
  }

  const handleDuplicateDespesa = async (id: string) => {
    try {
      await FinanceiroService.duplicateItem(id)
      loadDespesas()
    } catch (error) {
      console.error("Erro ao duplicar despesa:", error)
    }
  }

  const handleStatusChange = async (id: string, status: string) => {
    try {
      const dataPagamento = status === "pago" ? new Date().toISOString().split("T")[0] : undefined
      await FinanceiroService.updateStatus(id, status, dataPagamento)
      loadDespesas()
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
    }
  }

  const openEditDialog = async (id: string) => {
    try {
      const item = await FinanceiroService.getById(id)
      if (item) {
        setCurrentItem(item)
        setFormData({
          descricao: item.descricao,
          categoria: item.categoria,
          valor: item.valor.toString(),
          data_vencimento: item.data_vencimento || "",
          metodo_pagamento: item.metodo_pagamento || "",
          observacoes: item.observacoes || "",
          status_pagamento: item.status_pagamento,
        })
        setIsDialogOpen(true)
      }
    } catch (error) {
      console.error("Erro ao carregar despesa para edição:", error)
    }
  }

  const resetFormData = () => {
    setFormData({
      descricao: "",
      categoria: "combustivel",
      valor: "",
      data_vencimento: "",
      metodo_pagamento: "",
      observacoes: "",
      status_pagamento: "pendente",
    })
  }

  const openNewDialog = () => {
    setCurrentItem(null)
    resetFormData()
    setIsDialogOpen(true)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pago":
        return (
          <Badge variant="default" className="bg-green-500">
            Pago
          </Badge>
        )
      case "pendente":
        return <Badge variant="secondary">Pendente</Badge>
      case "em_atraso":
        return <Badge variant="destructive">Em Atraso</Badge>
      case "cancelado":
        return <Badge variant="outline">Cancelado</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getCategoriaLabel = (categoria: string) => {
    return categorias.find((cat) => cat.value === categoria)?.label || categoria
  }

  return (
    <div className="space-y-6">
      {/* Header com botão Nova Despesa */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestão de Despesas</h2>
          <p className="text-muted-foreground">Controle todas as despesas da empresa</p>
        </div>
        <Button onClick={openNewDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Despesa
        </Button>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="inicio">Data Início</Label>
              <Input
                id="inicio"
                type="date"
                value={filters.periodo.inicio}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    periodo: { ...prev.periodo, inicio: e.target.value },
                  }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fim">Data Fim</Label>
              <Input
                id="fim"
                type="date"
                value={filters.periodo.fim}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    periodo: { ...prev.periodo, fim: e.target.value },
                  }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Categoria</Label>
              <Select
                value={filters.categoria}
                onValueChange={(value) => setFilters((prev) => ({ ...prev, categoria: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todas as categorias" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {categorias.map((categoria) => (
                    <SelectItem key={categoria.value} value={categoria.value}>
                      {categoria.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={loadDespesas} className="w-full">
                Aplicar Filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Despesas */}
      <Card>
        <CardHeader>
          <CardTitle>Despesas</CardTitle>
          <CardDescription>
            {despesas.length} despesa{despesas.length !== 1 ? "s" : ""} encontrada{despesas.length !== 1 ? "s" : ""}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {despesas.map((despesa) => (
                  <TableRow key={despesa.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{despesa.descricao}</p>
                        <p className="text-sm text-muted-foreground">#{despesa.id.slice(0, 8)}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{getCategoriaLabel(despesa.categoria)}</Badge>
                    </TableCell>
                    <TableCell className="font-bold text-red-600">{formatCurrency(despesa.valor)}</TableCell>
                    <TableCell>
                      {despesa.data_vencimento ? new Date(despesa.data_vencimento).toLocaleDateString("pt-BR") : "-"}
                    </TableCell>
                    <TableCell>{getStatusBadge(despesa.status_pagamento)}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {despesa.status_pagamento !== "pago" && (
                            <DropdownMenuItem onClick={() => handleStatusChange(despesa.id, "pago")}>
                              <CheckCircle className="mr-2 h-4 w-4" />
                              Marcar como Pago
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem onClick={() => openEditDialog(despesa.id)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDuplicateDespesa(despesa.id)}>
                            <Copy className="mr-2 h-4 w-4" />
                            Duplicar
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => {
                              setItemToDelete(despesa.id)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Dialog para Nova/Editar Despesa */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{currentItem ? "Editar Despesa" : "Nova Despesa"}</DialogTitle>
            <DialogDescription>
              {currentItem
                ? "Edite os detalhes da despesa selecionada"
                : "Adicione uma nova despesa ao sistema financeiro"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição *</Label>
              <Input
                id="descricao"
                value={formData.descricao}
                onChange={(e) => setFormData((prev) => ({ ...prev, descricao: e.target.value }))}
                placeholder="Descrição da despesa"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Categoria *</Label>
                <Select
                  value={formData.categoria}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, categoria: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    {categorias.map((categoria) => (
                      <SelectItem key={categoria.value} value={categoria.value}>
                        {categoria.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="valor">Valor *</Label>
                <Input
                  id="valor"
                  type="number"
                  step="0.01"
                  value={formData.valor}
                  onChange={(e) => setFormData((prev) => ({ ...prev, valor: e.target.value }))}
                  placeholder="0,00"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data">Data de Vencimento *</Label>
                <Input
                  id="data"
                  type="date"
                  value={formData.data_vencimento}
                  onChange={(e) => setFormData((prev) => ({ ...prev, data_vencimento: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select
                  value={formData.status_pagamento}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, status_pagamento: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="pago">Pago</SelectItem>
                    <SelectItem value="em_atraso">Em Atraso</SelectItem>
                    <SelectItem value="cancelado">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Método de Pagamento</Label>
              <Select
                value={formData.metodo_pagamento}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, metodo_pagamento: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o método" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="cartao">Cartão</SelectItem>
                  <SelectItem value="transferencia">Transferência</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes}
                onChange={(e) => setFormData((prev) => ({ ...prev, observacoes: e.target.value }))}
                placeholder="Observações adicionais"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={currentItem ? handleUpdateDespesa : handleCreateDespesa}>
              {currentItem ? "Salvar Alterações" : "Criar Despesa"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog de confirmação para exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta despesa? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteDespesa}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground"
            >
              {isDeleting ? "Excluindo..." : "Excluir"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
