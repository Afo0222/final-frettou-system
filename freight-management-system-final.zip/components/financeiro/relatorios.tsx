"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Download, Calendar, TrendingUp, Users, DollarSign, BarChart3, PieChart } from "lucide-react"

export function RelatoriosComponent() {
  const tiposRelatorio = [
    {
      id: "faturamento",
      titulo: "Faturamento por Período",
      descricao: "Análise detalhada do faturamento em período específico",
      icon: DollarSign,
    },
    {
      id: "performance",
      titulo: "Performance por Motorista",
      descricao: "Ranking e análise de performance dos motoristas",
      icon: Users,
    },
    {
      id: "custos",
      titulo: "Análise de Custos",
      descricao: "Breakdown detalhado de todas as despesas",
      icon: TrendingUp,
    },
    {
      id: "fluxo",
      titulo: "Fluxo de Caixa",
      descricao: "Entradas e saídas de caixa por período",
      icon: BarChart3,
    },
    {
      id: "clientes",
      titulo: "Clientes Top",
      descricao: "Ranking dos melhores clientes por faturamento",
      icon: Users,
    },
    {
      id: "servicos",
      titulo: "Serviços Mais Rentáveis",
      descricao: "Análise de rentabilidade por tipo de serviço",
      icon: PieChart,
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Relatórios Financeiros</h2>
        <p className="text-muted-foreground">Gere relatórios detalhados para análise financeira</p>
      </div>

      {/* Filtros Gerais */}
      <Card>
        <CardHeader>
          <CardTitle>Configurações Gerais</CardTitle>
          <CardDescription>Configure os parâmetros para todos os relatórios</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="dataInicio">Data Início</Label>
              <Input id="dataInicio" type="date" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dataFim">Data Fim</Label>
              <Input id="dataFim" type="date" />
            </div>
            <div className="space-y-2">
              <Label>Agrupar por</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o agrupamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dia">Dia</SelectItem>
                  <SelectItem value="semana">Semana</SelectItem>
                  <SelectItem value="mes">Mês</SelectItem>
                  <SelectItem value="trimestre">Trimestre</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Grid de Tipos de Relatório */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tiposRelatorio.map((relatorio) => (
          <Card key={relatorio.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <relatorio.icon className="h-5 w-5 text-primary" />
                {relatorio.titulo}
              </CardTitle>
              <CardDescription>{relatorio.descricao}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Button className="flex-1">
                    <FileText className="mr-2 h-4 w-4" />
                    Visualizar
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Download className="mr-2 h-4 w-4" />
                    PDF
                  </Button>
                </div>
                <Button variant="outline" className="w-full">
                  <Calendar className="mr-2 h-4 w-4" />
                  Agendar Envio
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Relatórios Agendados */}
      <Card>
        <CardHeader>
          <CardTitle>Relatórios Agendados</CardTitle>
          <CardDescription>Relatórios configurados para envio automático</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-medium">Faturamento Mensal</h4>
                <p className="text-sm text-muted-foreground">Enviado todo dia 1º do mês para admin@empresa.com</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Editar
                </Button>
                <Button variant="outline" size="sm">
                  Pausar
                </Button>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-medium">Performance Semanal</h4>
                <p className="text-sm text-muted-foreground">Enviado toda segunda-feira para gerencia@empresa.com</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Editar
                </Button>
                <Button variant="outline" size="sm">
                  Pausar
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
