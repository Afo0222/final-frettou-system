"use client"

import { Edit, Package, Wrench, Clock, Weight, Box, Users, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { ProdutoServico } from "@/lib/services/produtos-servicos"

interface ProductServiceDetailsProps {
  produto: ProdutoServico
  onEdit: () => void
  onClose: () => void
}

export function ProductServiceDetails({ produto, onEdit, onClose }: ProductServiceDetailsProps) {
  const getCategoryColor = (categoria: string) => {
    const colors = {
      transporte: "bg-blue-100 text-blue-800",
      mudanca: "bg-green-100 text-green-800",
      entrega: "bg-yellow-100 text-yellow-800",
      logistica: "bg-purple-100 text-purple-800",
      armazenagem: "bg-orange-100 text-orange-800",
      consultoria: "bg-pink-100 text-pink-800",
    }
    return colors[categoria as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  const getTypeIcon = (tipo: string) => {
    return tipo === "produto" ? Package : Wrench
  }

  const TypeIcon = getTypeIcon(produto.tipo)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-lg ${produto.ativo ? "bg-primary/10" : "bg-gray-100"}`}>
            <TypeIcon className={`h-8 w-8 ${produto.ativo ? "text-primary" : "text-gray-400"}`} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl font-bold">{produto.nome}</h2>
              {produto.codigo && <Badge variant="outline">{produto.codigo}</Badge>}
            </div>
            <div className="flex items-center gap-2 mb-2">
              <Badge className={getCategoryColor(produto.categoria)}>{produto.categoria}</Badge>
              <Badge variant={produto.ativo ? "default" : "secondary"}>{produto.ativo ? "Ativo" : "Inativo"}</Badge>
              <Badge variant="outline">{produto.tipo === "produto" ? "Produto" : "Serviço"}</Badge>
            </div>
            {produto.descricao && <p className="text-muted-foreground">{produto.descricao}</p>}
          </div>
        </div>
        <Button onClick={onEdit}>
          <Edit className="h-4 w-4 mr-2" />
          Editar
        </Button>
      </div>

      <Tabs defaultValue="geral" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="geral">Geral</TabsTrigger>
          <TabsTrigger value="precos">Preços</TabsTrigger>
          <TabsTrigger value="requisitos">Requisitos</TabsTrigger>
          <TabsTrigger value="extras">Extras</TabsTrigger>
        </TabsList>

        <TabsContent value="geral" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Informações Básicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Nome:</span>
                  <span className="font-medium">{produto.nome}</span>
                </div>
                {produto.codigo && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Código:</span>
                    <span className="font-medium">{produto.codigo}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tipo:</span>
                  <span className="font-medium capitalize">{produto.tipo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Categoria:</span>
                  <span className="font-medium capitalize">{produto.categoria}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <Badge variant={produto.ativo ? "default" : "secondary"}>{produto.ativo ? "Ativo" : "Inativo"}</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Preço Base</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">
                    R$ {produto.preco_base?.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) || "0,00"}
                  </div>
                  <div className="text-sm text-muted-foreground">por {produto.unidade_preco || "unidade"}</div>
                </div>
                {produto.tempo_estimado && (
                  <div className="flex items-center justify-center gap-2 pt-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{produto.tempo_estimado} minutos estimados</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {produto.descricao && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Descrição</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">{produto.descricao}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="precos" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Configuração de Preços</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-primary">
                    R$ {produto.preco_base?.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) || "0,00"}
                  </div>
                  <div className="text-sm text-muted-foreground">Preço Base</div>
                  <div className="text-xs text-muted-foreground mt-1">por {produto.unidade_preco || "unidade"}</div>
                </div>

                {produto.tempo_estimado && (
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{produto.tempo_estimado}</div>
                    <div className="text-sm text-muted-foreground">Minutos</div>
                    <div className="text-xs text-muted-foreground mt-1">Tempo estimado</div>
                  </div>
                )}

                {produto.preco_tiers && produto.preco_tiers.length > 0 && (
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{produto.preco_tiers.length}</div>
                    <div className="text-sm text-muted-foreground">Tiers</div>
                    <div className="text-xs text-muted-foreground mt-1">Preços por quantidade</div>
                  </div>
                )}
              </div>

              {produto.preco_tiers && produto.preco_tiers.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <h4 className="font-medium mb-3">Preços por Quantidade</h4>
                    <div className="space-y-2">
                      {produto.preco_tiers.map((tier, index) => (
                        <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                          <span className="text-sm">
                            A partir de {tier.quantidade_min} {produto.unidade_preco || "unidades"}
                          </span>
                          <span className="font-semibold">
                            R$ {tier.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requisitos" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Limitações Físicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {produto.peso_maximo && (
                  <div className="flex items-center gap-2">
                    <Weight className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Peso máximo: {produto.peso_maximo} kg</span>
                  </div>
                )}
                {produto.volume_maximo && (
                  <div className="flex items-center gap-2">
                    <Box className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Volume máximo: {produto.volume_maximo} m³</span>
                  </div>
                )}
                {!produto.peso_maximo && !produto.volume_maximo && (
                  <p className="text-sm text-muted-foreground">Nenhuma limitação física definida</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Requisitos Operacionais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Veículo específico:</span>
                  <Badge variant={produto.requer_veiculo_especifico ? "default" : "secondary"}>
                    {produto.requer_veiculo_especifico ? "Sim" : "Não"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Requer ajudantes:</span>
                  <Badge variant={produto.requer_ajudantes ? "default" : "secondary"}>
                    {produto.requer_ajudantes ? "Sim" : "Não"}
                  </Badge>
                </div>
                {produto.requer_ajudantes && produto.numero_ajudantes && (
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{produto.numero_ajudantes} ajudante(s) necessário(s)</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Disponibilidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Fins de semana</span>
                  </div>
                  <Badge variant={produto.disponivel_fins_semana ? "default" : "secondary"}>
                    {produto.disponivel_fins_semana ? "Disponível" : "Indisponível"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Feriados</span>
                  </div>
                  <Badge variant={produto.disponivel_feriados ? "default" : "secondary"}>
                    {produto.disponivel_feriados ? "Disponível" : "Indisponível"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="extras" className="space-y-4">
          {produto.servicos_extras && produto.servicos_extras.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Serviços Extras Disponíveis</CardTitle>
                <CardDescription>Serviços adicionais que podem ser contratados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {produto.servicos_extras.map((servico, index) => (
                    <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                      <div>
                        <span className="font-medium">{servico.nome}</span>
                        <div className="text-sm text-muted-foreground">por {servico.unidade}</div>
                      </div>
                      <span className="font-semibold">
                        R$ {servico.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Package className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum serviço extra</h3>
                <p className="text-gray-600 text-center">
                  Este produto/serviço não possui serviços extras configurados.
                </p>
              </CardContent>
            </Card>
          )}

          {produto.observacoes && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Observações</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">{produto.observacoes}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
