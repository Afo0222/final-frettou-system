"use client"

import { useState, useEffect, useMemo } from "react"
import { Calculator, Download, RefreshCw, Package, Wrench } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { ProdutoServico } from "@/lib/services/produtos-servicos"

interface ProductServiceCalculatorProps {
  produto?: ProdutoServico | null
  produtos: ProdutoServico[]
  onClose: () => void
}

interface CalculationParams {
  produtoId: string
  quantidade: number
  peso?: number
  volume?: number
  distancia?: number
  tempo?: number
  ajudantes?: number
  servicosExtras: Array<{ id: string; quantidade: number }>
}

interface CalculationResult {
  produto: ProdutoServico
  preco_base: number
  preco_quantidade: number
  preco_servicos_extras: number
  preco_total: number
  detalhes: {
    quantidade: number
    preco_unitario: number
    tier_aplicado?: { quantidade_min: number; preco: number }
    servicos_extras: Array<{ nome: string; quantidade: number; preco_unitario: number; total: number }>
  }
}

export function ProductServiceCalculator({ produto, produtos, onClose }: ProductServiceCalculatorProps) {
  const [params, setParams] = useState<CalculationParams>({
    produtoId: produto?.id || "",
    quantidade: 1,
    peso: undefined,
    volume: undefined,
    distancia: undefined,
    tempo: undefined,
    ajudantes: undefined,
    servicosExtras: [],
  })

  const [results, setResults] = useState<CalculationResult[]>([])

  const selectedProduct = useMemo(() => {
    return produtos.find((p) => p.id === params.produtoId)
  }, [produtos, params.produtoId])

  useEffect(() => {
    if (produto) {
      setParams((prev) => ({ ...prev, produtoId: produto.id }))
    }
  }, [produto])

  const calculatePrice = (produto: ProdutoServico, quantidade: number): CalculationResult => {
    let preco_unitario = produto.preco_base || 0
    let tier_aplicado = undefined

    // Aplicar preço por quantidade se disponível
    if (produto.preco_tiers && produto.preco_tiers.length > 0) {
      const tiers = produto.preco_tiers
        .filter((tier) => quantidade >= tier.quantidade_min)
        .sort((a, b) => b.quantidade_min - a.quantidade_min)

      if (tiers.length > 0) {
        tier_aplicado = tiers[0]
        preco_unitario = tier_aplicado.preco
      }
    }

    const preco_base = preco_unitario * quantidade

    // Calcular serviços extras
    const servicos_extras_detalhes = params.servicosExtras.map((extra) => {
      const servicoExtra = produto.servicos_extras?.find((_, index) => index.toString() === extra.id)
      if (!servicoExtra) return { nome: "", quantidade: 0, preco_unitario: 0, total: 0 }

      return {
        nome: servicoExtra.nome,
        quantidade: extra.quantidade,
        preco_unitario: servicoExtra.preco,
        total: servicoExtra.preco * extra.quantidade,
      }
    })

    const preco_servicos_extras = servicos_extras_detalhes.reduce((sum, extra) => sum + extra.total, 0)

    return {
      produto,
      preco_base,
      preco_quantidade: preco_base,
      preco_servicos_extras,
      preco_total: preco_base + preco_servicos_extras,
      detalhes: {
        quantidade,
        preco_unitario,
        tier_aplicado,
        servicos_extras: servicos_extras_detalhes,
      },
    }
  }

  const handleCalculate = () => {
    if (!selectedProduct) return

    const result = calculatePrice(selectedProduct, params.quantidade)
    setResults([result])
  }

  const handleCalculateAll = () => {
    const results = produtos
      .filter((p) => p.ativo)
      .map((produto) => calculatePrice(produto, params.quantidade))
      .sort((a, b) => a.preco_total - b.preco_total)

    setResults(results)
  }

  const handleReset = () => {
    setParams({
      produtoId: produto?.id || "",
      quantidade: 1,
      peso: undefined,
      volume: undefined,
      distancia: undefined,
      tempo: undefined,
      ajudantes: undefined,
      servicosExtras: [],
    })
    setResults([])
  }

  const handleExport = () => {
    const data = {
      parametros: params,
      resultados: results,
      data_calculo: new Date().toISOString(),
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `calculo-produtos-servicos-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const addServicoExtra = () => {
    if (!selectedProduct?.servicos_extras) return

    setParams((prev) => ({
      ...prev,
      servicosExtras: [...prev.servicosExtras, { id: "0", quantidade: 1 }],
    }))
  }

  const updateServicoExtra = (index: number, field: string, value: string | number) => {
    setParams((prev) => ({
      ...prev,
      servicosExtras: prev.servicosExtras.map((extra, i) => (i === index ? { ...extra, [field]: value } : extra)),
    }))
  }

  const removeServicoExtra = (index: number) => {
    setParams((prev) => ({
      ...prev,
      servicosExtras: prev.servicosExtras.filter((_, i) => i !== index),
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Calculadora de Preços</h3>
          <p className="text-sm text-muted-foreground">Calcule preços para produtos e serviços</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleReset}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Limpar
          </Button>
          {results.length > 0 && (
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="parametros" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="parametros">Parâmetros</TabsTrigger>
          <TabsTrigger value="resultados">Resultados</TabsTrigger>
        </TabsList>

        <TabsContent value="parametros" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Parâmetros de Cálculo</CardTitle>
              <CardDescription>Configure os parâmetros para calcular o preço</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="produto">Produto/Serviço</Label>
                  <Select
                    value={params.produtoId}
                    onValueChange={(value) => setParams((prev) => ({ ...prev, produtoId: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um produto/serviço" />
                    </SelectTrigger>
                    <SelectContent>
                      {produtos.map((produto) => (
                        <SelectItem key={produto.id} value={produto.id}>
                          <div className="flex items-center gap-2">
                            {produto.tipo === "produto" ? (
                              <Package className="h-4 w-4" />
                            ) : (
                              <Wrench className="h-4 w-4" />
                            )}
                            {produto.nome}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantidade">Quantidade</Label>
                  <Input
                    id="quantidade"
                    type="number"
                    min="1"
                    value={params.quantidade}
                    onChange={(e) =>
                      setParams((prev) => ({ ...prev, quantidade: Number.parseInt(e.target.value) || 1 }))
                    }
                  />
                </div>
              </div>

              {selectedProduct && (
                <>
                  <Separator />
                  <div>
                    <h4 className="font-medium mb-3">Informações do Produto/Serviço</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center p-3 border rounded-lg">
                        <div className="text-lg font-semibold">
                          R${" "}
                          {selectedProduct.preco_base?.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) || "0,00"}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Preço base por {selectedProduct.unidade_preco}
                        </div>
                      </div>

                      {selectedProduct.tempo_estimado && (
                        <div className="text-center p-3 border rounded-lg">
                          <div className="text-lg font-semibold">{selectedProduct.tempo_estimado} min</div>
                          <div className="text-sm text-muted-foreground">Tempo estimado</div>
                        </div>
                      )}

                      {selectedProduct.preco_tiers && selectedProduct.preco_tiers.length > 0 && (
                        <div className="text-center p-3 border rounded-lg">
                          <div className="text-lg font-semibold">{selectedProduct.preco_tiers.length}</div>
                          <div className="text-sm text-muted-foreground">Preços por quantidade</div>
                        </div>
                      )}
                    </div>
                  </div>

                  {selectedProduct.servicos_extras && selectedProduct.servicos_extras.length > 0 && (
                    <>
                      <Separator />
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium">Serviços Extras</h4>
                          <Button variant="outline" size="sm" onClick={addServicoExtra}>
                            Adicionar
                          </Button>
                        </div>

                        {params.servicosExtras.map((extra, index) => (
                          <div key={index} className="grid grid-cols-12 gap-2 items-center mb-2">
                            <Select value={extra.id} onValueChange={(value) => updateServicoExtra(index, "id", value)}>
                              <SelectTrigger className="col-span-6">
                                <SelectValue placeholder="Selecione um serviço" />
                              </SelectTrigger>
                              <SelectContent>
                                {selectedProduct.servicos_extras?.map((servico, servicoIndex) => (
                                  <SelectItem key={servicoIndex} value={servicoIndex.toString()}>
                                    {servico.nome} - R${" "}
                                    {servico.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              min="1"
                              placeholder="Qtd"
                              value={extra.quantidade}
                              onChange={(e) =>
                                updateServicoExtra(index, "quantidade", Number.parseInt(e.target.value) || 1)
                              }
                              className="col-span-4"
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeServicoExtra(index)}
                              className="col-span-2"
                            >
                              Remover
                            </Button>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </>
              )}

              <div className="flex gap-2 pt-4">
                <Button onClick={handleCalculate} disabled={!selectedProduct}>
                  <Calculator className="h-4 w-4 mr-2" />
                  Calcular Selecionado
                </Button>
                <Button variant="outline" onClick={handleCalculateAll}>
                  <Calculator className="h-4 w-4 mr-2" />
                  Calcular Todos
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resultados" className="space-y-4">
          {results.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calculator className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum cálculo realizado</h3>
                <p className="text-gray-600 text-center">
                  Configure os parâmetros e clique em "Calcular" para ver os resultados.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {results.map((result, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {result.produto.tipo === "produto" ? (
                          <Package className="h-5 w-5" />
                        ) : (
                          <Wrench className="h-5 w-5" />
                        )}
                        <CardTitle className="text-lg">{result.produto.nome}</CardTitle>
                        <Badge variant="outline">{result.produto.categoria}</Badge>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">
                          R$ {result.preco_total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                        </div>
                        <div className="text-sm text-muted-foreground">Total</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center p-3 border rounded-lg">
                          <div className="font-semibold">
                            R$ {result.detalhes.preco_unitario.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </div>
                          <div className="text-sm text-muted-foreground">Preço unitário</div>
                        </div>
                        <div className="text-center p-3 border rounded-lg">
                          <div className="font-semibold">{result.detalhes.quantidade}</div>
                          <div className="text-sm text-muted-foreground">Quantidade</div>
                        </div>
                        <div className="text-center p-3 border rounded-lg">
                          <div className="font-semibold">
                            R$ {result.preco_quantidade.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </div>
                          <div className="text-sm text-muted-foreground">Subtotal</div>
                        </div>
                      </div>

                      {result.detalhes.tier_aplicado && (
                        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                          <div className="text-sm font-medium text-blue-800">Desconto por quantidade aplicado</div>
                          <div className="text-sm text-blue-600">
                            A partir de {result.detalhes.tier_aplicado.quantidade_min} unidades: R${" "}
                            {result.detalhes.tier_aplicado.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}{" "}
                            por unidade
                          </div>
                        </div>
                      )}

                      {result.detalhes.servicos_extras.length > 0 && (
                        <>
                          <Separator />
                          <div>
                            <h5 className="font-medium mb-2">Serviços Extras</h5>
                            <div className="space-y-2">
                              {result.detalhes.servicos_extras.map((extra, extraIndex) => (
                                <div key={extraIndex} className="flex justify-between items-center p-2 border rounded">
                                  <span className="text-sm">
                                    {extra.nome} ({extra.quantidade}x)
                                  </span>
                                  <span className="font-medium">
                                    R$ {extra.total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
