"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Plus, Minus, Save, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { produtoServicoService, type ProdutoServico } from "@/lib/services/produtos-servicos"
import { useToast } from "@/hooks/use-toast"

const formSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  codigo: z.string().optional(),
  descricao: z.string().optional(),
  tipo: z.enum(["produto", "servico"]),
  categoria: z.string().min(1, "Categoria é obrigatória"),
  preco_base: z.number().min(0, "Preço deve ser maior ou igual a zero"),
  unidade_preco: z.string().min(1, "Unidade de preço é obrigatória"),
  tempo_estimado: z.number().optional(),
  peso_maximo: z.number().optional(),
  volume_maximo: z.number().optional(),
  requer_veiculo_especifico: z.boolean().default(false),
  tipos_veiculo_aceitos: z.array(z.string()).optional(),
  requer_ajudantes: z.boolean().default(false),
  numero_ajudantes: z.number().optional(),
  disponivel_fins_semana: z.boolean().default(true),
  disponivel_feriados: z.boolean().default(false),
  observacoes: z.string().optional(),
  ativo: z.boolean().default(true),
})

type FormData = z.infer<typeof formSchema>

interface ProductServiceFormProps {
  produto?: ProdutoServico | null
  onSuccess: () => void
  onCancel: () => void
}

export function ProductServiceForm({ produto, onSuccess, onCancel }: ProductServiceFormProps) {
  const [loading, setLoading] = useState(false)
  const [precoTiers, setPrecoTiers] = useState<Array<{ quantidade_min: number; preco: number }>>([])
  const [servicosExtras, setServicosExtras] = useState<Array<{ nome: string; preco: number; unidade: string }>>([])
  const { toast } = useToast()

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nome: "",
      codigo: "",
      descricao: "",
      tipo: "servico",
      categoria: "",
      preco_base: 0,
      unidade_preco: "unidade",
      tempo_estimado: undefined,
      peso_maximo: undefined,
      volume_maximo: undefined,
      requer_veiculo_especifico: false,
      tipos_veiculo_aceitos: [],
      requer_ajudantes: false,
      numero_ajudantes: undefined,
      disponivel_fins_semana: true,
      disponivel_feriados: false,
      observacoes: "",
      ativo: true,
    },
  })

  useEffect(() => {
    if (produto) {
      form.reset({
        nome: produto.nome,
        codigo: produto.codigo || "",
        descricao: produto.descricao || "",
        tipo: produto.tipo,
        categoria: produto.categoria,
        preco_base: produto.preco_base || 0,
        unidade_preco: produto.unidade_preco || "unidade",
        tempo_estimado: produto.tempo_estimado,
        peso_maximo: produto.peso_maximo,
        volume_maximo: produto.volume_maximo,
        requer_veiculo_especifico: produto.requer_veiculo_especifico || false,
        tipos_veiculo_aceitos: produto.tipos_veiculo_aceitos || [],
        requer_ajudantes: produto.requer_ajudantes || false,
        numero_ajudantes: produto.numero_ajudantes,
        disponivel_fins_semana: produto.disponivel_fins_semana ?? true,
        disponivel_feriados: produto.disponivel_feriados ?? false,
        observacoes: produto.observacoes || "",
        ativo: produto.ativo,
      })
      setPrecoTiers(produto.preco_tiers || [])
      setServicosExtras(produto.servicos_extras || [])
    }
  }, [produto, form])

  const onSubmit = async (data: FormData) => {
    try {
      setLoading(true)

      const produtoData = {
        ...data,
        preco_tiers: precoTiers.length > 0 ? precoTiers : undefined,
        servicos_extras: servicosExtras.length > 0 ? servicosExtras : undefined,
      }

      if (produto?.id) {
        await produtoServicoService.update(produto.id, produtoData)
        toast({
          title: "Sucesso",
          description: "Produto/serviço atualizado com sucesso.",
        })
      } else {
        await produtoServicoService.create(produtoData)
        toast({
          title: "Sucesso",
          description: "Produto/serviço criado com sucesso.",
        })
      }

      onSuccess()
    } catch (error) {
      console.error("Erro ao salvar produto/serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar o produto/serviço.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const addPrecoTier = () => {
    setPrecoTiers([...precoTiers, { quantidade_min: 1, preco: 0 }])
  }

  const removePrecoTier = (index: number) => {
    setPrecoTiers(precoTiers.filter((_, i) => i !== index))
  }

  const updatePrecoTier = (index: number, field: string, value: number) => {
    const updated = [...precoTiers]
    updated[index] = { ...updated[index], [field]: value }
    setPrecoTiers(updated)
  }

  const addServicoExtra = () => {
    setServicosExtras([...servicosExtras, { nome: "", preco: 0, unidade: "unidade" }])
  }

  const removeServicoExtra = (index: number) => {
    setServicosExtras(servicosExtras.filter((_, i) => i !== index))
  }

  const updateServicoExtra = (index: number, field: string, value: string | number) => {
    const updated = [...servicosExtras]
    updated[index] = { ...updated[index], [field]: value }
    setServicosExtras(updated)
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Tabs defaultValue="basico" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basico">Básico</TabsTrigger>
            <TabsTrigger value="precos">Preços</TabsTrigger>
            <TabsTrigger value="requisitos">Requisitos</TabsTrigger>
            <TabsTrigger value="extras">Extras</TabsTrigger>
          </TabsList>

          <TabsContent value="basico" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Informações Básicas</CardTitle>
                <CardDescription>Dados principais do produto ou serviço</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="nome"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome *</FormLabel>
                        <FormControl>
                          <Input placeholder="Nome do produto/serviço" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="codigo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Código</FormLabel>
                        <FormControl>
                          <Input placeholder="Código identificador" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="descricao"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descrição</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Descrição detalhada do produto/serviço"
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="tipo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipo *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione o tipo" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="produto">Produto</SelectItem>
                            <SelectItem value="servico">Serviço</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="categoria"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Categoria *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione a categoria" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="transporte">Transporte</SelectItem>
                            <SelectItem value="mudanca">Mudança</SelectItem>
                            <SelectItem value="entrega">Entrega</SelectItem>
                            <SelectItem value="logistica">Logística</SelectItem>
                            <SelectItem value="armazenagem">Armazenagem</SelectItem>
                            <SelectItem value="consultoria">Consultoria</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="ativo"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Ativo</FormLabel>
                        <FormDescription>Produto/serviço disponível para uso</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="precos" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Configuração de Preços</CardTitle>
                <CardDescription>Defina o preço base e configurações de cobrança</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="preco_base"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preço Base *</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                            onChange={(e) => field.onChange(Number.parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="unidade_preco"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Unidade de Preço *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione a unidade" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="unidade">Por unidade</SelectItem>
                            <SelectItem value="hora">Por hora</SelectItem>
                            <SelectItem value="km">Por quilômetro</SelectItem>
                            <SelectItem value="kg">Por quilograma</SelectItem>
                            <SelectItem value="m3">Por metro cúbico</SelectItem>
                            <SelectItem value="viagem">Por viagem</SelectItem>
                            <SelectItem value="dia">Por dia</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="tempo_estimado"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tempo Estimado (minutos)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="Tempo em minutos"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value) || undefined)}
                        />
                      </FormControl>
                      <FormDescription>Tempo estimado para execução do serviço</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator />

                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-sm font-medium">Preços por Quantidade</h4>
                      <p className="text-sm text-muted-foreground">Configure preços diferenciados por quantidade</p>
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={addPrecoTier}>
                      <Plus className="h-4 w-4 mr-2" />
                      Adicionar Tier
                    </Button>
                  </div>

                  {precoTiers.map((tier, index) => (
                    <div key={index} className="flex items-center gap-2 mb-2">
                      <Input
                        type="number"
                        placeholder="Qtd. mínima"
                        value={tier.quantidade_min}
                        onChange={(e) => updatePrecoTier(index, "quantidade_min", Number.parseInt(e.target.value) || 0)}
                        className="w-32"
                      />
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Preço"
                        value={tier.preco}
                        onChange={(e) => updatePrecoTier(index, "preco", Number.parseFloat(e.target.value) || 0)}
                        className="flex-1"
                      />
                      <Button type="button" variant="outline" size="sm" onClick={() => removePrecoTier(index)}>
                        <Minus className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requisitos" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Requisitos e Limitações</CardTitle>
                <CardDescription>Configure requisitos específicos para o produto/serviço</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="peso_maximo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Peso Máximo (kg)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.1"
                            placeholder="Peso em kg"
                            {...field}
                            onChange={(e) => field.onChange(Number.parseFloat(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="volume_maximo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Volume Máximo (m³)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.1"
                            placeholder="Volume em m³"
                            {...field}
                            onChange={(e) => field.onChange(Number.parseFloat(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="requer_veiculo_especifico"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Requer Veículo Específico</FormLabel>
                        <FormDescription>Serviço necessita de tipos específicos de veículos</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="requer_ajudantes"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Requer Ajudantes</FormLabel>
                        <FormDescription>Serviço necessita de ajudantes adicionais</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                {form.watch("requer_ajudantes") && (
                  <FormField
                    control={form.control}
                    name="numero_ajudantes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Número de Ajudantes</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            placeholder="Quantidade de ajudantes"
                            {...field}
                            onChange={(e) => field.onChange(Number.parseInt(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="disponivel_fins_semana"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Fins de Semana</FormLabel>
                          <FormDescription>Disponível aos sábados e domingos</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="disponivel_feriados"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Feriados</FormLabel>
                          <FormDescription>Disponível em feriados</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="extras" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Serviços Extras</CardTitle>
                <CardDescription>Configure serviços adicionais que podem ser oferecidos</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium">Serviços Adicionais</h4>
                    <p className="text-sm text-muted-foreground">Serviços extras que podem ser contratados junto</p>
                  </div>
                  <Button type="button" variant="outline" size="sm" onClick={addServicoExtra}>
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Serviço
                  </Button>
                </div>

                {servicosExtras.map((servico, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-center">
                    <Input
                      placeholder="Nome do serviço"
                      value={servico.nome}
                      onChange={(e) => updateServicoExtra(index, "nome", e.target.value)}
                      className="col-span-5"
                    />
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Preço"
                      value={servico.preco}
                      onChange={(e) => updateServicoExtra(index, "preco", Number.parseFloat(e.target.value) || 0)}
                      className="col-span-3"
                    />
                    <Select
                      value={servico.unidade}
                      onValueChange={(value) => updateServicoExtra(index, "unidade", value)}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unidade">Unidade</SelectItem>
                        <SelectItem value="hora">Hora</SelectItem>
                        <SelectItem value="kg">Kg</SelectItem>
                        <SelectItem value="m3">m³</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeServicoExtra(index)}
                      className="col-span-1"
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                <Separator />

                <FormField
                  control={form.control}
                  name="observacoes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Observações</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Observações adicionais sobre o produto/serviço"
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="h-4 w-4 mr-2" />
            Cancelar
          </Button>
          <Button type="submit" disabled={loading}>
            <Save className="h-4 w-4 mr-2" />
            {loading ? "Salvando..." : "Salvar"}
          </Button>
        </div>
      </form>
    </Form>
  )
}
