"use client"

import { useState } from "react"
import {
  Eye,
  Edit,
  Trash2,
  Copy,
  MoreHorizontal,
  Package,
  Wrench,
  Calculator,
  ToggleLeft,
  ToggleRight,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Separator } from "@/components/ui/separator"
import type { ProdutoServico } from "@/lib/services/produtos-servicos"

interface ProductServiceCardProps {
  produto: ProdutoServico
  viewMode: "grid" | "list"
  onView: () => void
  onEdit: () => void
  onDelete: () => void
  onDuplicate: () => void
  onToggleStatus: () => void
  onCalculate: () => void
}

export function ProductServiceCard({
  produto,
  viewMode,
  onView,
  onEdit,
  onDelete,
  onDuplicate,
  onToggleStatus,
  onCalculate,
}: ProductServiceCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const getCategoryColor = (categoria: string) => {
    const colors = {
      transporte: "bg-blue-100 text-blue-800",
      mudanca: "bg-green-100 text-green-800",
      entrega: "bg-yellow-100 text-yellow-800",
      logistica: "bg-purple-100 text-purple-800",
      armazenagem: "bg-orange-100 text-orange-800",
      consultoria: "bg-pink-100 text-pink-800",
    }
    return colors[categoria as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  const getTypeIcon = (tipo: string) => {
    return tipo === "produto" ? Package : Wrench
  }

  const TypeIcon = getTypeIcon(produto.tipo)

  if (viewMode === "list") {
    return (
      <Card
        className={`transition-all duration-200 ${isHovered ? "shadow-md border-primary/20" : ""}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 flex-1">
              <div className={`p-2 rounded-lg ${produto.ativo ? "bg-primary/10" : "bg-gray-100"}`}>
                <TypeIcon className={`h-5 w-5 ${produto.ativo ? "text-primary" : "text-gray-400"}`} />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold truncate">{produto.nome}</h3>
                  {produto.codigo && (
                    <Badge variant="outline" className="text-xs">
                      {produto.codigo}
                    </Badge>
                  )}
                  <Badge className={getCategoryColor(produto.categoria)}>{produto.categoria}</Badge>
                  <Badge variant={produto.ativo ? "default" : "secondary"}>{produto.ativo ? "Ativo" : "Inativo"}</Badge>
                </div>
                <p className="text-sm text-muted-foreground truncate">{produto.descricao || "Sem descrição"}</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="font-semibold">
                  R$ {produto.preco_base?.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) || "0,00"}
                </div>
                <div className="text-xs text-muted-foreground">{produto.unidade_preco || "unidade"}</div>
              </div>

              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" onClick={onView}>
                  <Eye className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={onCalculate}>
                  <Calculator className="h-4 w-4" />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={onEdit}>
                      <Edit className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onDuplicate}>
                      <Copy className="h-4 w-4 mr-2" />
                      Duplicar
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onToggleStatus}>
                      {produto.ativo ? (
                        <>
                          <ToggleLeft className="h-4 w-4 mr-2" />
                          Desativar
                        </>
                      ) : (
                        <>
                          <ToggleRight className="h-4 w-4 mr-2" />
                          Ativar
                        </>
                      )}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={onDelete} className="text-red-600">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card
      className={`transition-all duration-200 cursor-pointer ${
        isHovered ? "shadow-lg border-primary/20 scale-[1.02]" : ""
      } ${!produto.ativo ? "opacity-75" : ""}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onView}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className={`p-2 rounded-lg ${produto.ativo ? "bg-primary/10" : "bg-gray-100"}`}>
            <TypeIcon className={`h-6 w-6 ${produto.ativo ? "text-primary" : "text-gray-400"}`} />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onView()
                }}
              >
                <Eye className="h-4 w-4 mr-2" />
                Visualizar
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onEdit()
                }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onCalculate()
                }}
              >
                <Calculator className="h-4 w-4 mr-2" />
                Calcular
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onDuplicate()
                }}
              >
                <Copy className="h-4 w-4 mr-2" />
                Duplicar
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onToggleStatus()
                }}
              >
                {produto.ativo ? (
                  <>
                    <ToggleLeft className="h-4 w-4 mr-2" />
                    Desativar
                  </>
                ) : (
                  <>
                    <ToggleRight className="h-4 w-4 mr-2" />
                    Ativar
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onDelete()
                }}
                className="text-red-600"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg truncate">{produto.nome}</CardTitle>
            {produto.codigo && (
              <Badge variant="outline" className="text-xs">
                {produto.codigo}
              </Badge>
            )}
          </div>
          <CardDescription className="line-clamp-2">{produto.descricao || "Sem descrição disponível"}</CardDescription>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Badge className={getCategoryColor(produto.categoria)}>{produto.categoria}</Badge>
            <Badge variant={produto.ativo ? "default" : "secondary"}>{produto.ativo ? "Ativo" : "Inativo"}</Badge>
          </div>

          <Separator />

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Preço Base:</span>
              <span className="font-semibold">
                R$ {produto.preco_base?.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) || "0,00"}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Unidade:</span>
              <span className="text-sm">{produto.unidade_preco || "unidade"}</span>
            </div>
            {produto.tempo_estimado && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Tempo:</span>
                <span className="text-sm">{produto.tempo_estimado} min</span>
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              onClick={(e) => {
                e.stopPropagation()
                onCalculate()
              }}
            >
              <Calculator className="h-4 w-4 mr-1" />
              Calcular
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              onClick={(e) => {
                e.stopPropagation()
                onEdit()
              }}
            >
              <Edit className="h-4 w-4 mr-1" />
              Editar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
