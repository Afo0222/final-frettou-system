"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Download, Mail, MessageSquare, Send } from "lucide-react"
import { NotificationService } from "@/lib/services/notifications"
import type { Orcamento } from "@/lib/types/database"

interface OrcamentoExportProps {
  orcamento: Orcamento
}

export function OrcamentoExport({ orcamento }: OrcamentoExportProps) {
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false)
  const [isWhatsAppDialogOpen, setIsWhatsAppDialogOpen] = useState(false)
  const [emailData, setEmailData] = useState({
    to: orcamento.cliente?.email || "",
    subject: `Orçamento ${orcamento.numero_orcamento} - ${orcamento.tipo_servico?.nome}`,
    message: `Prezado(a) ${orcamento.cliente?.nome},\n\nSegue em anexo o orçamento solicitado.\n\nAtenciosamente,\nEquipe de Vendas`,
  })
  const [whatsappMessage, setWhatsappMessage] = useState(
    `Olá ${orcamento.cliente?.nome}! 👋\n\nSeu orçamento está pronto!\n\n📋 *Orçamento:* ${orcamento.numero_orcamento}\n🚚 *Serviço:* ${orcamento.tipo_servico?.nome}\n💰 *Valor:* R$ ${orcamento.valor_total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\n\nClique no link para visualizar: [LINK_DO_ORCAMENTO]\n\nTem alguma dúvida? Estou aqui para ajudar! 😊`,
  )
  const [isLoading, setIsLoading] = useState(false)

  const generatePDF = async () => {
    try {
      setIsLoading(true)

      // Simular geração de PDF
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Em produção, aqui seria a integração com uma biblioteca de PDF
      const pdfContent = {
        orcamento: orcamento.numero_orcamento,
        cliente: orcamento.cliente?.nome,
        servico: orcamento.tipo_servico?.nome,
        valor: orcamento.valor_total,
        origem: orcamento.endereco_origem,
        destino: orcamento.endereco_destino,
        data: orcamento.data_agendada,
        hora: orcamento.hora_agendada,
      }

      // Simular download
      const blob = new Blob([JSON.stringify(pdfContent, null, 2)], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `orcamento-${orcamento.numero_orcamento}.pdf`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      NotificationService.success("PDF gerado", "O orçamento foi baixado com sucesso.")
    } catch (error) {
      NotificationService.error("Erro", "Falha ao gerar PDF do orçamento.")
    } finally {
      setIsLoading(false)
    }
  }

  const sendEmail = async () => {
    try {
      setIsLoading(true)

      if (!emailData.to) {
        NotificationService.error("Erro", "E-mail do cliente é obrigatório.")
        return
      }

      // Simular envio de email
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Em produção, aqui seria a integração com serviço de email
      console.log("Enviando email:", emailData)

      NotificationService.success("E-mail enviado", "O orçamento foi enviado por e-mail com sucesso.")
      setIsEmailDialogOpen(false)
    } catch (error) {
      NotificationService.error("Erro", "Falha ao enviar e-mail.")
    } finally {
      setIsLoading(false)
    }
  }

  const sendWhatsApp = async () => {
    try {
      setIsLoading(true)

      const phone = orcamento.cliente?.telefone?.replace(/\D/g, "")
      if (!phone) {
        NotificationService.error("Erro", "Telefone do cliente é obrigatório.")
        return
      }

      // Simular envio via WhatsApp
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const whatsappUrl = `https://wa.me/55${phone}?text=${encodeURIComponent(whatsappMessage)}`
      window.open(whatsappUrl, "_blank")

      NotificationService.success("WhatsApp aberto", "A conversa foi iniciada no WhatsApp.")
      setIsWhatsAppDialogOpen(false)
    } catch (error) {
      NotificationService.error("Erro", "Falha ao abrir WhatsApp.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Send className="mr-2 h-4 w-4" />
            Enviar
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={generatePDF}>
            <Download className="mr-2 h-4 w-4" />
            Baixar PDF
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setIsEmailDialogOpen(true)}>
            <Mail className="mr-2 h-4 w-4" />
            Enviar por E-mail
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setIsWhatsAppDialogOpen(true)}>
            <MessageSquare className="mr-2 h-4 w-4" />
            Enviar WhatsApp
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Dialog de E-mail */}
      <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Enviar Orçamento por E-mail</DialogTitle>
            <DialogDescription>Configure os detalhes do e-mail antes de enviar o orçamento.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email-to">Para</Label>
              <Input
                id="email-to"
                type="email"
                value={emailData.to}
                onChange={(e) => setEmailData((prev) => ({ ...prev, to: e.target.value }))}
                placeholder="cliente@email.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email-subject">Assunto</Label>
              <Input
                id="email-subject"
                value={emailData.subject}
                onChange={(e) => setEmailData((prev) => ({ ...prev, subject: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email-message">Mensagem</Label>
              <Textarea
                id="email-message"
                value={emailData.message}
                onChange={(e) => setEmailData((prev) => ({ ...prev, message: e.target.value }))}
                rows={6}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsEmailDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={sendEmail} disabled={isLoading}>
                {isLoading ? "Enviando..." : "Enviar E-mail"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog de WhatsApp */}
      <Dialog open={isWhatsAppDialogOpen} onOpenChange={setIsWhatsAppDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Enviar Orçamento via WhatsApp</DialogTitle>
            <DialogDescription>Personalize a mensagem antes de abrir o WhatsApp.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="whatsapp-message">Mensagem</Label>
              <Textarea
                id="whatsapp-message"
                value={whatsappMessage}
                onChange={(e) => setWhatsappMessage(e.target.value)}
                rows={8}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsWhatsAppDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={sendWhatsApp} disabled={isLoading}>
                {isLoading ? "Abrindo..." : "Abrir WhatsApp"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
