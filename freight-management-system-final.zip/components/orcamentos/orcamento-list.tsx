"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Eye, CheckCircle, XCircle, Clock, FileText } from "lucide-react"
import { OrcamentoService } from "@/lib/services/orcamentos"
import { NotificationService } from "@/lib/services/notifications"
import type { Orcamento } from "@/lib/types/database"

interface OrcamentoListProps {
  onViewDetails?: (orcamento: Orcamento) => void
}

export function OrcamentoList({ onViewDetails }: OrcamentoListProps) {
  const [orcamentos, setOrcamentos] = useState<Orcamento[]>([])
  const [filteredOrcamentos, setFilteredOrcamentos] = useState<Orcamento[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("todos")

  useEffect(() => {
    loadOrcamentos()
  }, [])

  useEffect(() => {
    filterOrcamentos()
  }, [orcamentos, searchTerm, statusFilter])

  const loadOrcamentos = async () => {
    try {
      setIsLoading(true)
      const data = await OrcamentoService.getAll()
      setOrcamentos(data)
    } catch (error) {
      console.error("Erro ao carregar orçamentos:", error)
      NotificationService.error("Erro", "Falha ao carregar orçamentos")
    } finally {
      setIsLoading(false)
    }
  }

  const filterOrcamentos = () => {
    let filtered = orcamentos

    // Filtro por termo de busca
    if (searchTerm) {
      filtered = filtered.filter(
        (orc) =>
          orc.numero_orcamento.toLowerCase().includes(searchTerm.toLowerCase()) ||
          orc.cliente?.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          orc.endereco_origem?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          orc.endereco_destino?.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filtro por status
    if (statusFilter !== "todos") {
      filtered = filtered.filter((orc) => orc.status === statusFilter)
    }

    setFilteredOrcamentos(filtered)
  }

  const handleStatusChange = async (orcamentoId: string, newStatus: string) => {
    try {
      const result = await OrcamentoService.updateStatus(orcamentoId, newStatus)

      if (result.success) {
        // Atualizar lista local
        setOrcamentos((prev) =>
          prev.map((orc) => (orc.id === orcamentoId ? { ...orc, status: newStatus as any } : orc)),
        )

        // Mostrar notificação de sucesso
        if (newStatus === "aprovado") {
          NotificationService.success(
            "Orçamento Aprovado! 🎉",
            `Agendamento criado automaticamente${result.agendamento ? ` - Motorista: ${result.agendamento.motorista?.nome}` : ""}`,
          )
        } else {
          NotificationService.success("Status Atualizado", `Orçamento ${newStatus} com sucesso`)
        }
      } else {
        NotificationService.error("Erro", result.error || "Falha ao atualizar status")
      }
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      NotificationService.error("Erro", "Falha ao atualizar status do orçamento")
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      rascunho: "secondary",
      enviado: "outline",
      aprovado: "default",
      rejeitado: "destructive",
    } as const

    const labels = {
      rascunho: "Rascunho",
      enviado: "Enviado",
      aprovado: "Aprovado",
      rejeitado: "Rejeitado",
    }

    return (
      <Badge variant={variants[status as keyof typeof variants] || "secondary"}>
        {labels[status as keyof typeof labels] || status}
      </Badge>
    )
  }

  const getStatusActions = (orcamento: Orcamento) => {
    const actions = []

    if (orcamento.status === "rascunho" || orcamento.status === "enviado") {
      actions.push(
        <Button
          key="aprovar"
          size="sm"
          onClick={() => handleStatusChange(orcamento.id, "aprovado")}
          className="bg-green-600 hover:bg-green-700"
        >
          <CheckCircle className="h-4 w-4 mr-1" />
          Aprovar
        </Button>,
      )
      actions.push(
        <Button
          key="rejeitar"
          size="sm"
          variant="destructive"
          onClick={() => handleStatusChange(orcamento.id, "rejeitado")}
        >
          <XCircle className="h-4 w-4 mr-1" />
          Rejeitar
        </Button>,
      )
    }

    if (orcamento.status === "rejeitado") {
      actions.push(
        <Button key="reenviar" size="sm" variant="outline" onClick={() => handleStatusChange(orcamento.id, "enviado")}>
          <Clock className="h-4 w-4 mr-1" />
          Reenviar
        </Button>,
      )
    }

    return actions
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-3 bg-gray-200 rounded w-3/4"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por número, cliente ou endereço..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Status</SelectItem>
                <SelectItem value="rascunho">Rascunho</SelectItem>
                <SelectItem value="enviado">Enviado</SelectItem>
                <SelectItem value="aprovado">Aprovado</SelectItem>
                <SelectItem value="rejeitado">Rejeitado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Orçamentos */}
      <div className="space-y-4">
        {filteredOrcamentos.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {searchTerm || statusFilter !== "todos" ? "Nenhum orçamento encontrado" : "Nenhum orçamento cadastrado"}
              </h3>
              <p className="text-gray-500">
                {searchTerm || statusFilter !== "todos"
                  ? "Tente ajustar os filtros de busca"
                  : "Crie seu primeiro orçamento para começar"}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredOrcamentos.map((orcamento) => (
            <Card key={orcamento.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{orcamento.numero_orcamento}</h3>
                    <p className="text-sm text-gray-600">Cliente: {orcamento.cliente?.nome || "N/A"}</p>
                  </div>
                  <div className="flex items-center gap-2">{getStatusBadge(orcamento.status)}</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm font-medium text-gray-700">Origem:</p>
                    <p className="text-sm text-gray-600">{orcamento.endereco_origem || "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Destino:</p>
                    <p className="text-sm text-gray-600">{orcamento.endereco_destino || "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Serviço:</p>
                    <p className="text-sm text-gray-600">{orcamento.tipo_servico?.nome || "N/A"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Valor:</p>
                    <p className="text-sm font-semibold text-green-600">
                      R$ {orcamento.valor_total?.toFixed(2) || "0,00"}
                    </p>
                  </div>
                </div>

                {orcamento.data_agendada && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700">Data Agendada:</p>
                    <p className="text-sm text-gray-600">
                      {new Date(orcamento.data_agendada).toLocaleDateString("pt-BR")}
                      {orcamento.hora_agendada && ` às ${orcamento.hora_agendada}`}
                    </p>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <div className="flex gap-2">{getStatusActions(orcamento)}</div>
                  <Button variant="outline" size="sm" onClick={() => onViewDetails?.(orcamento)}>
                    <Eye className="h-4 w-4 mr-1" />
                    Ver Detalhes
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
