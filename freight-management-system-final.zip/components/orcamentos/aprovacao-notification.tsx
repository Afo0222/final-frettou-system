"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, X, Calendar, MapPin, DollarSign, ExternalLink } from "lucide-react"
import Link from "next/link"
import type { Orcamento } from "@/lib/types/database"

interface AprovacaoNotificationProps {
  orcamento: Orcamento
  onClose: () => void
}

export function AprovacaoNotification({ orcamento, onClose }: AprovacaoNotificationProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Animar entrada
    setIsVisible(true)

    // Auto-fechar após 10 segundos
    const timer = setTimeout(() => {
      handleClose()
    }, 10000)

    return () => clearTimeout(timer)
  }, [])

  const handleClose = () => {
    setIsVisible(false)
    setTimeout(onClose, 300) // Aguardar animação de saída
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  return (
    <div
      className={`fixed top-4 right-4 z-50 transition-all duration-300 ${
        isVisible ? "translate-x-0 opacity-100" : "translate-x-full opacity-0"
      }`}
    >
      <Card className="w-96 border-green-200 bg-green-50 shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <h3 className="font-semibold text-green-800">Orçamento Aprovado!</h3>
            </div>
            <Button variant="ghost" size="sm" onClick={handleClose} className="h-6 w-6 p-0">
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{orcamento.numero_orcamento || `#${orcamento.id?.slice(-6)}`}</span>
              <Badge className="bg-green-600 text-white">Aprovado</Badge>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="h-4 w-4" />
                <span className="truncate">{orcamento.endereco_origem?.split(",")[0] || "Origem"}</span>
              </div>

              {orcamento.data_agendada && (
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <span>{formatDate(orcamento.data_agendada)}</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-gray-600">
                <DollarSign className="h-4 w-4" />
                <span className="font-medium">{formatCurrency(orcamento.valor_total || 0)}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-green-200">
              <p className="text-xs text-green-700 mb-3">
                ✅ Agendamento criado automaticamente
                <br />✅ Receita adicionada ao financeiro
              </p>

              <div className="flex gap-2">
                <Link href="/agendamentos" className="flex-1">
                  <Button variant="outline" size="sm" className="w-full text-xs">
                    <ExternalLink className="mr-1 h-3 w-3" />
                    Ver Agendamentos
                  </Button>
                </Link>
                <Link href="/financeiro" className="flex-1">
                  <Button variant="outline" size="sm" className="w-full text-xs">
                    <ExternalLink className="mr-1 h-3 w-3" />
                    Ver Financeiro
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
