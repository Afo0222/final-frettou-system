"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Filter, X, CalendarIcon, Search } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"

interface OrcamentoFiltersProps {
  onFiltersChange: (filters: any) => void
  totalCount: number
  filteredCount: number
}

export function OrcamentoFilters({ onFiltersChange, totalCount, filteredCount }: OrcamentoFiltersProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [filters, setFilters] = useState({
    search: "",
    status: "",
    tipoServico: "",
    dataInicio: undefined as Date | undefined,
    dataFim: undefined as Date | undefined,
    valorMin: "",
    valorMax: "",
    cliente: "",
  })

  const statusOptions = [
    { value: "rascunho", label: "Rascunho", color: "bg-gray-500" },
    { value: "enviado", label: "Enviado", color: "bg-blue-500" },
    { value: "aprovado", label: "Aprovado", color: "bg-green-500" },
    { value: "rejeitado", label: "Rejeitado", color: "bg-red-500" },
    { value: "expirado", label: "Expirado", color: "bg-orange-500" },
  ]

  const tipoServicoOptions = [
    { value: "frete-padrao", label: "Frete Padrão" },
    { value: "mudanca-residencial", label: "Mudança Residencial" },
    { value: "frete-expresso", label: "Frete Expresso" },
    { value: "mudanca-comercial", label: "Mudança Comercial" },
  ]

  const updateFilters = (newFilters: any) => {
    const updatedFilters = { ...filters, ...newFilters }
    setFilters(updatedFilters)
    onFiltersChange(updatedFilters)
  }

  const clearFilters = () => {
    const emptyFilters = {
      search: "",
      status: "",
      tipoServico: "",
      dataInicio: undefined,
      dataFim: undefined,
      valorMin: "",
      valorMax: "",
      cliente: "",
    }
    setFilters(emptyFilters)
    onFiltersChange(emptyFilters)
  }

  const getActiveFiltersCount = () => {
    return Object.values(filters).filter((value) => value !== "" && value !== undefined).length
  }

  const activeFiltersCount = getActiveFiltersCount()

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros
            {activeFiltersCount > 0 && <Badge variant="secondary">{activeFiltersCount}</Badge>}
          </CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {filteredCount} de {totalCount} orçamentos
            </span>
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? "Ocultar" : "Mostrar"}
            </Button>
          </div>
        </div>
      </CardHeader>

      {isOpen && (
        <CardContent className="space-y-4">
          {/* Busca Geral */}
          <div className="space-y-2">
            <Label htmlFor="search">Busca Geral</Label>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Buscar por número, cliente, endereço..."
                value={filters.search}
                onChange={(e) => updateFilters({ search: e.target.value })}
                className="pl-10"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {/* Status */}
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={filters.status} onValueChange={(value) => updateFilters({ status: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  {statusOptions.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${status.color}`} />
                        {status.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Tipo de Serviço */}
            <div className="space-y-2">
              <Label>Tipo de Serviço</Label>
              <Select value={filters.tipoServico} onValueChange={(value) => updateFilters({ tipoServico: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os tipos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os tipos</SelectItem>
                  {tipoServicoOptions.map((tipo) => (
                    <SelectItem key={tipo.value} value={tipo.value}>
                      {tipo.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Data Início */}
            <div className="space-y-2">
              <Label>Data Início</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !filters.dataInicio && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filters.dataInicio
                      ? format(filters.dataInicio, "dd/MM/yyyy", { locale: ptBR })
                      : "Selecionar data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={filters.dataInicio}
                    onSelect={(date) => updateFilters({ dataInicio: date })}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Data Fim */}
            <div className="space-y-2">
              <Label>Data Fim</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !filters.dataFim && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filters.dataFim ? format(filters.dataFim, "dd/MM/yyyy", { locale: ptBR }) : "Selecionar data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={filters.dataFim}
                    onSelect={(date) => updateFilters({ dataFim: date })}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            {/* Cliente */}
            <div className="space-y-2">
              <Label htmlFor="cliente">Cliente</Label>
              <Input
                id="cliente"
                placeholder="Nome do cliente"
                value={filters.cliente}
                onChange={(e) => updateFilters({ cliente: e.target.value })}
              />
            </div>

            {/* Valor Mínimo */}
            <div className="space-y-2">
              <Label htmlFor="valorMin">Valor Mínimo</Label>
              <Input
                id="valorMin"
                type="number"
                placeholder="0,00"
                value={filters.valorMin}
                onChange={(e) => updateFilters({ valorMin: e.target.value })}
              />
            </div>

            {/* Valor Máximo */}
            <div className="space-y-2">
              <Label htmlFor="valorMax">Valor Máximo</Label>
              <Input
                id="valorMax"
                type="number"
                placeholder="0,00"
                value={filters.valorMax}
                onChange={(e) => updateFilters({ valorMax: e.target.value })}
              />
            </div>
          </div>

          {/* Ações */}
          <div className="flex justify-between pt-4">
            <Button variant="outline" onClick={clearFilters}>
              <X className="mr-2 h-4 w-4" />
              Limpar Filtros
            </Button>
            <div className="text-sm text-muted-foreground">
              {activeFiltersCount > 0 && `${activeFiltersCount} filtro(s) ativo(s)`}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  )
}
