"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Calculator, RefreshCw, Edit2, Check, X, AlertCircle } from "lucide-react"
import { OrcamentoIntegradoService } from "@/lib/services/orcamentos-integrado"
import { TipoServicoRealService } from "@/lib/services/tipos-servico-real"
import { NotificationService } from "@/lib/services/notifications"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { CalculoOrcamento } from "@/lib/types/tipos-servico"

interface CalculadoraOrcamentoProps {
  tipoServicoId: string
  enderecoOrigem: string
  enderecoDestino: string
  ajudantesAdicionais?: number
  servicosExtrasIds?: string[]
  onCalculoChange?: (calculo: CalculoOrcamento | null) => void
  autoCalcular?: boolean
}

export function CalculadoraOrcamento({
  tipoServicoId,
  enderecoOrigem,
  enderecoDestino,
  ajudantesAdicionais = 0,
  servicosExtrasIds = [],
  onCalculoChange,
  autoCalcular = false,
}: CalculadoraOrcamentoProps) {
  const [calculo, setCalculo] = useState<CalculoOrcamento | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [tipoServico, setTipoServico] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  // Estados para edição manual do valor
  const [isEditingValue, setIsEditingValue] = useState(false)
  const [valorManual, setValorManual] = useState("")
  const [motivoAjuste, setMotivoAjuste] = useState("")
  const [valorOriginal, setValorOriginal] = useState<number | null>(null)

  // Carregar tipo de serviço
  useEffect(() => {
    const loadTipoServico = async () => {
      if (!tipoServicoId) return

      try {
        const data = await TipoServicoRealService.getById(tipoServicoId)
        setTipoServico(data)
      } catch (error) {
        console.error("Erro ao carregar tipo de serviço:", error)
      }
    }

    loadTipoServico()
  }, [tipoServicoId])

  // Auto-calcular quando os parâmetros mudarem
  useEffect(() => {
    if (autoCalcular && tipoServicoId && enderecoOrigem && enderecoDestino) {
      handleCalcular()
    }
  }, [tipoServicoId, enderecoOrigem, enderecoDestino, ajudantesAdicionais, servicosExtrasIds, autoCalcular])

  const handleCalcular = async () => {
    if (!tipoServicoId || !enderecoOrigem || !enderecoDestino) {
      setError("Preencha todos os campos obrigatórios para calcular o orçamento.")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const resultado = await OrcamentoIntegradoService.calcularOrcamentoAutomatico({
        tipoServicoId,
        enderecoOrigem,
        enderecoDestino,
        ajudantesAdicionais,
        servicosExtrasIds,
      })

      setCalculo(resultado)
      setValorOriginal(resultado.valor_total)
      setIsEditingValue(false)
      setValorManual("")
      setMotivoAjuste("")

      if (onCalculoChange) {
        onCalculoChange(resultado)
      }
    } catch (error) {
      console.error("Erro ao calcular orçamento:", error)
      setError("Ocorreu um erro ao calcular o orçamento. Tente novamente.")
      NotificationService.error("Erro", "Falha ao calcular orçamento.")

      if (onCalculoChange) {
        onCalculoChange(null)
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Funções para edição manual do valor
  const handleStartEditing = () => {
    if (calculo) {
      setValorManual(calculo.valor_total.toFixed(2))
      setIsEditingValue(true)
    }
  }

  const handleCancelEditing = () => {
    setIsEditingValue(false)
    setValorManual("")
    setMotivoAjuste("")
  }

  const handleConfirmManualValue = () => {
    if (!calculo || !valorManual) return

    const novoValor = Number.parseFloat(valorManual.replace(",", "."))

    if (isNaN(novoValor) || novoValor <= 0) {
      setError("Digite um valor válido maior que zero.")
      return
    }

    const calculoAtualizado = {
      ...calculo,
      valor_total: novoValor,
      valor_ajustado_manualmente: true,
      valor_original: valorOriginal || calculo.valor_total,
      motivo_ajuste: motivoAjuste || "Ajuste manual",
      diferenca_ajuste: novoValor - (valorOriginal || calculo.valor_total),
    }

    setCalculo(calculoAtualizado)
    setIsEditingValue(false)

    if (onCalculoChange) {
      onCalculoChange(calculoAtualizado)
    }

    NotificationService.success("Valor ajustado", "O valor do orçamento foi ajustado manualmente.")
  }

  const handleRestoreOriginalValue = () => {
    if (!calculo || !valorOriginal) return

    const calculoRestaurado = {
      ...calculo,
      valor_total: valorOriginal,
      valor_ajustado_manualmente: false,
      valor_original: undefined,
      motivo_ajuste: undefined,
      diferenca_ajuste: undefined,
    }

    setCalculo(calculoRestaurado)
    setIsEditingValue(false)
    setValorManual("")
    setMotivoAjuste("")

    if (onCalculoChange) {
      onCalculoChange(calculoRestaurado)
    }

    NotificationService.success("Valor restaurado", "O valor original do orçamento foi restaurado.")
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Calculadora de Orçamento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Parâmetros do cálculo */}
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h4 className="text-sm font-medium mb-2">Parâmetros</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tipo de Serviço:</span>
                    <span>{tipoServico?.nome || "Não especificado"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Origem:</span>
                    <span className="text-right max-w-[250px] truncate">{enderecoOrigem || "Não especificado"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Destino:</span>
                    <span className="text-right max-w-[250px] truncate">{enderecoDestino || "Não especificado"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Ajudantes Adicionais:</span>
                    <span>{ajudantesAdicionais}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Serviços Extras:</span>
                    <span>{servicosExtrasIds.length}</span>
                  </div>
                </div>
              </div>

              {/* Botão de cálculo */}
              <div className="flex flex-col justify-center items-center">
                <Button
                  onClick={handleCalcular}
                  disabled={isLoading || !tipoServicoId || !enderecoOrigem || !enderecoDestino}
                  className="w-full"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Calculando...
                    </>
                  ) : (
                    <>
                      <Calculator className="mr-2 h-4 w-4" />
                      Calcular Orçamento
                    </>
                  )}
                </Button>
                {error && <p className="text-sm text-red-500 mt-2">{error}</p>}
              </div>
            </div>

            {/* Resultados do cálculo */}
            {calculo && (
              <>
                <Separator />
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="font-medium">Resultado do Cálculo</h4>
                    {!isEditingValue && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleStartEditing}
                        className="flex items-center gap-1"
                      >
                        <Edit2 className="h-3 w-3" />
                        Ajustar Valor
                      </Button>
                    )}
                  </div>

                  {/* Edição manual do valor */}
                  {isEditingValue ? (
                    <div className="bg-muted/30 p-4 rounded-lg border space-y-4">
                      <h5 className="font-medium text-sm">Ajuste Manual de Valor</h5>

                      <div className="space-y-2">
                        <Label htmlFor="valorManual">Novo Valor (R$)</Label>
                        <Input
                          id="valorManual"
                          type="text"
                          value={valorManual}
                          onChange={(e) => setValorManual(e.target.value)}
                          placeholder="0,00"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="motivoAjuste">Motivo do Ajuste</Label>
                        <Textarea
                          id="motivoAjuste"
                          value={motivoAjuste}
                          onChange={(e) => setMotivoAjuste(e.target.value)}
                          placeholder="Ex: Desconto para cliente fidelidade, custo adicional por item especial..."
                          rows={2}
                        />
                      </div>

                      <div className="flex gap-2 justify-end">
                        <Button variant="outline" size="sm" onClick={handleCancelEditing}>
                          <X className="h-3 w-3 mr-1" />
                          Cancelar
                        </Button>
                        <Button size="sm" onClick={handleConfirmManualValue}>
                          <Check className="h-3 w-3 mr-1" />
                          Confirmar
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* Exibição do valor ajustado */}
                      {calculo.valor_ajustado_manualmente && (
                        <Alert className="bg-amber-50 border-amber-200">
                          <AlertCircle className="h-4 w-4 text-amber-600" />
                          <AlertDescription className="text-amber-800">
                            <div className="flex flex-col gap-1">
                              <span className="font-medium">Valor ajustado manualmente</span>
                              <span className="text-xs">
                                Valor original: {formatCurrency(calculo.valor_original || 0)}
                              </span>
                              {calculo.motivo_ajuste && (
                                <span className="text-xs">Motivo: {calculo.motivo_ajuste}</span>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={handleRestoreOriginalValue}
                                className="mt-1 w-fit text-xs h-7 bg-white"
                              >
                                Restaurar valor original
                              </Button>
                            </div>
                          </AlertDescription>
                        </Alert>
                      )}

                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Distância:</span>
                            <span>{calculo.distancia_km} km</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Tempo estimado:</span>
                            <span>{calculo.tempo_estimado_horas.toFixed(1)} horas</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Valor base:</span>
                            <span>{formatCurrency(calculo.subtotal_base)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Valor distância:</span>
                            <span>{formatCurrency(calculo.subtotal_distancia)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Valor tempo:</span>
                            <span>{formatCurrency(calculo.subtotal_tempo)}</span>
                          </div>
                        </div>

                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Valor ajudantes:</span>
                            <span>{formatCurrency(calculo.subtotal_ajudantes)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Custos variáveis:</span>
                            <span>{formatCurrency(calculo.subtotal_variaveis)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Serviços extras:</span>
                            <span>{formatCurrency(calculo.subtotal_extras)}</span>
                          </div>
                          <Separator className="my-1" />
                          <div className="flex justify-between font-medium">
                            <span>Valor Total:</span>
                            <span className="text-green-600 text-lg">{formatCurrency(calculo.valor_total)}</span>
                          </div>
                          {calculo.valor_ajustado_manualmente && calculo.diferenca_ajuste && (
                            <div className="flex justify-between text-xs">
                              <span>Diferença do ajuste:</span>
                              <span className={calculo.diferenca_ajuste >= 0 ? "text-green-600" : "text-red-600"}>
                                {calculo.diferenca_ajuste >= 0 ? "+" : ""}
                                {formatCurrency(calculo.diferenca_ajuste)}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
