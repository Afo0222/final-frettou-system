"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, AlertCircle, Download } from "lucide-react"

interface PWADebugInfo {
  isHttps: boolean
  hasServiceWorker: boolean
  hasManifest: boolean
  isInstallable: boolean
  isInstalled: boolean
  manifestData: any
  serviceWorkerStatus: string
}

export function PWADebug() {
  const [debugInfo, setDebugInfo] = useState<PWADebugInfo | null>(null)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)

  useEffect(() => {
    const checkPWAStatus = async () => {
      const info: PWADebugInfo = {
        isHttps: window.location.protocol === "https:" || window.location.hostname === "localhost",
        hasServiceWorker: "serviceWorker" in navigator,
        hasManifest: false,
        isInstallable: false,
        isInstalled: window.matchMedia("(display-mode: standalone)").matches,
        manifestData: null,
        serviceWorkerStatus: "unknown",
      }

      // Check manifest
      try {
        const manifestResponse = await fetch("/manifest.json")
        if (manifestResponse.ok) {
          info.hasManifest = true
          info.manifestData = await manifestResponse.json()
        }
      } catch (error) {
        console.error("Manifest check failed:", error)
      }

      // Check service worker
      if (info.hasServiceWorker) {
        try {
          const registration = await navigator.serviceWorker.getRegistration()
          if (registration) {
            info.serviceWorkerStatus = registration.active ? "active" : "installing"
          } else {
            info.serviceWorkerStatus = "not registered"
          }
        } catch (error) {
          info.serviceWorkerStatus = "error"
        }
      }

      setDebugInfo(info)
    }

    checkPWAStatus()

    // Listen for install prompt
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setDebugInfo((prev) => (prev ? { ...prev, isInstallable: true } : null))
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      console.log("Install prompt result:", outcome)
      setDeferredPrompt(null)
    }
  }

  if (!debugInfo) {
    return <div>Carregando debug info...</div>
  }

  const StatusIcon = ({ condition }: { condition: boolean }) =>
    condition ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          PWA Debug Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center justify-between">
            <span>HTTPS/Localhost</span>
            <div className="flex items-center gap-2">
              <StatusIcon condition={debugInfo.isHttps} />
              <Badge variant={debugInfo.isHttps ? "default" : "destructive"}>
                {debugInfo.isHttps ? "OK" : "Required"}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span>Service Worker</span>
            <div className="flex items-center gap-2">
              <StatusIcon condition={debugInfo.hasServiceWorker} />
              <Badge variant={debugInfo.hasServiceWorker ? "default" : "destructive"}>
                {debugInfo.serviceWorkerStatus}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span>Manifest</span>
            <div className="flex items-center gap-2">
              <StatusIcon condition={debugInfo.hasManifest} />
              <Badge variant={debugInfo.hasManifest ? "default" : "destructive"}>
                {debugInfo.hasManifest ? "Found" : "Missing"}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span>Installable</span>
            <div className="flex items-center gap-2">
              <StatusIcon condition={debugInfo.isInstallable} />
              <Badge variant={debugInfo.isInstallable ? "default" : "secondary"}>
                {debugInfo.isInstallable ? "Yes" : "No"}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span>Installed</span>
            <div className="flex items-center gap-2">
              <StatusIcon condition={debugInfo.isInstalled} />
              <Badge variant={debugInfo.isInstalled ? "default" : "secondary"}>
                {debugInfo.isInstalled ? "Yes" : "No"}
              </Badge>
            </div>
          </div>
        </div>

        {deferredPrompt && (
          <div className="pt-4 border-t">
            <Button onClick={handleInstall} className="w-full">
              <Download className="w-4 h-4 mr-2" />
              Install PWA Now
            </Button>
          </div>
        )}

        {debugInfo.manifestData && (
          <details className="pt-4 border-t">
            <summary className="cursor-pointer font-medium">Manifest Data</summary>
            <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">
              {JSON.stringify(debugInfo.manifestData, null, 2)}
            </pre>
          </details>
        )}

        <div className="pt-4 border-t text-sm text-gray-600">
          <h4 className="font-medium mb-2">Troubleshooting Tips:</h4>
          <ul className="space-y-1 text-xs">
            <li>• PWA requires HTTPS (or localhost for development)</li>
            <li>• Service Worker must be registered and active</li>
            <li>• Manifest must be valid and accessible</li>
            <li>• Icons must be available (192x192 and 512x512 minimum)</li>
            <li>• User must interact with the page before install prompt</li>
            <li>• Some browsers have different install criteria</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
