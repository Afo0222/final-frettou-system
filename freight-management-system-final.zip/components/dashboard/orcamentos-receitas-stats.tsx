"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calculator, DollarSign, Link, Eye } from "lucide-react"
import { OrcamentoService } from "@/lib/services/orcamentos"
import { FinanceiroService } from "@/lib/services/financeiro"

interface OrcamentoReceitaStats {
  totalOrcamentos: number
  orcamentosAprovados: number
  receitasVinculadas: number
  valorTotalOrcamentos: number
  valorReceitasVinculadas: number
  taxaConversao: number
}

export function OrcamentosReceitasStats() {
  const [stats, setStats] = useState<OrcamentoReceitaStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      setIsLoading(true)

      // Buscar todos os orçamentos
      const orcamentos = await OrcamentoService.getAll()

      // Buscar receitas vinculadas
      const receitas = await FinanceiroService.getReceitas()
      const receitasVinculadas = receitas.filter((r) => r.orcamento_id)

      // Calcular estatísticas
      const orcamentosAprovados = orcamentos.filter((o) => o.status === "aprovado")
      const valorTotalOrcamentos = orcamentos.reduce((sum, o) => sum + o.valor_total, 0)
      const valorReceitasVinculadas = receitasVinculadas.reduce((sum, r) => sum + r.valor, 0)
      const taxaConversao = orcamentos.length > 0 ? (orcamentosAprovados.length / orcamentos.length) * 100 : 0

      setStats({
        totalOrcamentos: orcamentos.length,
        orcamentosAprovados: orcamentosAprovados.length,
        receitasVinculadas: receitasVinculadas.length,
        valorTotalOrcamentos,
        valorReceitasVinculadas,
        taxaConversao,
      })
    } catch (error) {
      console.error("Erro ao carregar estatísticas:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  if (!stats) return null

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Orçamentos Aprovados</CardTitle>
          <Calculator className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.orcamentosAprovados}</div>
          <p className="text-xs text-muted-foreground">de {stats.totalOrcamentos} orçamentos totais</p>
          <div className="mt-2">
            <Badge variant="outline">Taxa: {stats.taxaConversao.toFixed(1)}%</Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Receitas Vinculadas</CardTitle>
          <Link className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.receitasVinculadas}</div>
          <p className="text-xs text-muted-foreground">receitas criadas automaticamente</p>
          <div className="mt-2">
            <Badge variant="default" className="bg-green-500">
              Automático
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Valor em Receitas</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatCurrency(stats.valorReceitasVinculadas)}</div>
          <p className="text-xs text-muted-foreground">de {formatCurrency(stats.valorTotalOrcamentos)} em orçamentos</p>
          <div className="mt-2 flex gap-2">
            <Button size="sm" variant="outline" onClick={() => (window.location.href = "/orcamentos/lista")}>
              <Eye className="mr-1 h-3 w-3" />
              Ver Lista
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
