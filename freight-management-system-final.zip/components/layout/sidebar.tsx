"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  LayoutDashboard,
  Calculator,
  Calendar,
  DollarSign,
  Truck,
  Settings,
  Menu,
  ChevronDown,
  Users,
  Car,
  Wrench,
  Package,
  UserCog,
  Cog,
  Plus,
  FileText,
} from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

const navigation = [
  {
    name: "Painel de Controle",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    name: "Orçamentos",
    href: "/orcamentos",
    icon: Calculator,
    children: [
      { name: "Novo Orçamento", href: "/orcamentos", icon: Plus },
      { name: "Lista de Orçamentos", href: "/orcamentos/lista", icon: FileText },
    ],
  },
  {
    name: "Agendamentos",
    href: "/agendamentos",
    icon: Calendar,
  },
  {
    name: "Financeiro",
    href: "/financeiro",
    icon: DollarSign,
  },
  {
    name: "Painel do Motorista",
    href: "/motorista",
    icon: Truck,
  },
  {
    name: "Configurações",
    href: "/configuracoes",
    icon: Settings,
    children: [
      { name: "Tipos de Serviço", href: "/configuracoes/tipos-servico", icon: Package },
      { name: "Veículos", href: "/configuracoes/veiculos", icon: Car },
      { name: "Clientes", href: "/configuracoes/clientes", icon: Users },
      { name: "Variáveis de Custo", href: "/configuracoes/variaveis-custo", icon: DollarSign },
      { name: "Produtos/Serviços", href: "/configuracoes/produtos-servicos", icon: Wrench },
      { name: "Motoristas", href: "/configuracoes/motoristas", icon: UserCog },
      { name: "Configurações Gerais", href: "/configuracoes/gerais", icon: Cog },
    ],
  },
]

interface SidebarProps {
  className?: string
}

export function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname()
  const [openItems, setOpenItems] = useState<string[]>(["Configurações"])

  const toggleItem = (name: string) => {
    setOpenItems((prev) => (prev.includes(name) ? prev.filter((item) => item !== name) : [...prev, name]))
  }

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center border-b px-6">
        <div className="flex items-center gap-2">
          <Truck className="h-8 w-8 text-primary" />
          <div className="flex flex-col">
            <span className="text-lg font-bold">FreteSystem</span>
            <span className="text-xs text-muted-foreground">Gestão de Fretes</span>
          </div>
        </div>
      </div>
      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-2">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            const hasChildren = item.children && item.children.length > 0
            const isOpen = openItems.includes(item.name)

            if (hasChildren) {
              return (
                <Collapsible key={item.name} open={isOpen} onOpenChange={() => toggleItem(item.name)}>
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      className={cn(
                        "w-full justify-between px-3 py-2 text-left font-normal",
                        isActive && "bg-primary/10 text-primary",
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <item.icon className="h-5 w-5" />
                        <span>{item.name}</span>
                      </div>
                      <ChevronDown className={cn("h-4 w-4 transition-transform", isOpen && "rotate-180")} />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-1 pl-6 pt-1">
                    {item.children.map((child) => {
                      const isChildActive = pathname === child.href
                      return (
                        <Link key={child.href} href={child.href}>
                          <Button
                            variant="ghost"
                            size="sm"
                            className={cn(
                              "w-full justify-start gap-3 px-3 py-2 text-sm font-normal",
                              isChildActive && "bg-primary/10 text-primary",
                            )}
                          >
                            <child.icon className="h-4 w-4" />
                            <span>{child.name}</span>
                          </Button>
                        </Link>
                      )
                    })}
                  </CollapsibleContent>
                </Collapsible>
              )
            }

            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className={cn(
                    "w-full justify-start gap-3 px-3 py-2 font-normal",
                    isActive && "bg-primary/10 text-primary",
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Button>
              </Link>
            )
          })}
        </nav>
      </ScrollArea>
    </div>
  )

  return (
    <>
      {/* Desktop Sidebar */}
      <div className={cn("hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0", className)}>
        <div className="flex flex-col flex-grow bg-card border-r">
          <SidebarContent />
        </div>
      </div>

      {/* Mobile Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <SidebarContent />
        </SheetContent>
      </Sheet>
    </>
  )
}
