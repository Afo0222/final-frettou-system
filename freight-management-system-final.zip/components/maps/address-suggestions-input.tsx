"use client"

import type React from "react"
import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MapPin, Search, Loader2, AlertCircle, Clock, Navigation, CheckCircle, AlertTriangle } from "lucide-react"
import { AddressSuggestionsService, type AddressSuggestion } from "@/lib/services/address-suggestions"

interface AddressSuggestionsInputProps {
  label: string
  placeholder?: string
  value: string
  onChange: (value: string, suggestion?: AddressSuggestion) => void
  required?: boolean
  type?: "pickup" | "delivery"
  className?: string
  debounceMs?: number
  maxSuggestions?: number
  showTypes?: boolean
  showDebug?: boolean
}

export function AddressSuggestionsInput({
  label,
  placeholder = "Digite o endereço...",
  value,
  onChange,
  required = false,
  type = "pickup",
  className = "",
  debounceMs = 1500,
  maxSuggestions = 5,
  showTypes = false,
  showDebug = false,
}: AddressSuggestionsInputProps) {
  // Estados
  const [inputState, setInputState] = useState({
    suggestions: [] as AddressSuggestion[],
    showSuggestions: false,
    isLoading: false,
    error: null as string | null,
    selectedIndex: -1,
    rateLimitInfo: null as string | null,
    lastQuery: "",
    lastSearchTime: 0,
    debugInfo: null as any,
  })

  // Refs
  const debounceRef = useRef<NodeJS.Timeout | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const suggestionsRef = useRef<HTMLDivElement>(null)
  const abortControllerRef = useRef<AbortController | null>(null)
  const lastValueRef = useRef<string>(value || "")
  const isMountedRef = useRef<boolean>(true)
  const searchInProgressRef = useRef<boolean>(false)

  // Função para verificar se houve mudança significativa no input
  const checkSignificantChange = useCallback((newValue: string, oldValue: string): boolean => {
    // Se o valor for menor que o anterior, é uma nova consulta
    if (newValue.length < oldValue.length) return true

    // Se adicionou pelo menos 3 caracteres
    if (newValue.length >= oldValue.length + 3) return true

    // Se adicionou uma nova palavra
    const oldWords = oldValue.split(/\s+/).filter(Boolean)
    const newWords = newValue.split(/\s+/).filter(Boolean)
    if (newWords.length > oldWords.length) return true

    // Se adicionou um número
    const oldHasNumber = /\d/.test(oldValue)
    const newHasNumber = /\d/.test(newValue)
    if (newHasNumber && !oldHasNumber) return true

    // Se adicionou uma palavra-chave importante
    const keywords = ["rua", "av", "avenida", "n°", "número", "alameda", "travessa"]
    for (const keyword of keywords) {
      if (newValue.toLowerCase().includes(keyword) && !oldValue.toLowerCase().includes(keyword)) {
        return true
      }
    }

    return false
  }, [])

  // Função para buscar sugestões
  const fetchSuggestions = useCallback(
    async (query: string) => {
      // Evitar buscas simultâneas
      if (searchInProgressRef.current) {
        console.log("[COMPONENT] Busca já em andamento, ignorando")
        return
      }

      // Verificar se a consulta é significativamente diferente da última
      const isSignificant = checkSignificantChange(query, inputState.lastQuery)

      // Se não for significativa e já temos uma consulta anterior, não buscar
      if (!isSignificant && inputState.lastQuery && query.length > 0) {
        console.log("[COMPONENT] Consulta não é significativa, ignorando")
        return
      }

      // Verificar tempo mínimo entre buscas (2 segundos)
      const now = Date.now()
      if (now - inputState.lastSearchTime < 2000) {
        console.log("[COMPONENT] Muito cedo para nova busca, ignorando")
        return
      }

      // Cancelar requisição anterior
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
        abortControllerRef.current = null
      }

      // Validar entrada
      if (query.trim().length < 3) {
        setInputState((prev) => ({
          ...prev,
          suggestions: [],
          showSuggestions: false,
          error: null,
          rateLimitInfo: null,
          debugInfo: null,
        }))
        return
      }

      // Marcar busca em andamento
      searchInProgressRef.current = true

      console.log(`[COMPONENT] Iniciando busca para: "${query}"`)

      setInputState((prev) => ({
        ...prev,
        isLoading: true,
        error: null,
        rateLimitInfo: null,
        lastQuery: query,
        lastSearchTime: now,
        debugInfo: null,
      }))

      try {
        const response = await AddressSuggestionsService.getSuggestions(query)

        // Verificar se o componente ainda está montado
        if (!isMountedRef.current) return

        console.log(`[COMPONENT] Resposta recebida:`, {
          status: response.status,
          suggestions_count: response.suggestions.length,
          error: response.error,
        })

        if (response.status === "OK") {
          setInputState((prev) => ({
            ...prev,
            suggestions: response.suggestions.slice(0, maxSuggestions),
            showSuggestions: response.suggestions.length > 0,
            isLoading: false,
            error: null,
            debugInfo: response.debug,
          }))
        } else if (response.status === "RATE_LIMITED") {
          setInputState((prev) => ({
            ...prev,
            suggestions: [],
            showSuggestions: false,
            isLoading: false,
            rateLimitInfo: response.error || "Limite de requisições atingido",
            debugInfo: response.debug,
          }))
        } else if (response.status === "NO_RESULTS") {
          setInputState((prev) => ({
            ...prev,
            suggestions: [],
            showSuggestions: false,
            isLoading: false,
            error: response.error || "Nenhum endereço encontrado",
            debugInfo: response.debug,
          }))
        } else if (response.status === "API_ERROR") {
          setInputState((prev) => ({
            ...prev,
            suggestions: [],
            showSuggestions: false,
            isLoading: false,
            error: response.error || "Erro na API do Google Maps",
            debugInfo: response.debug,
          }))
        } else {
          setInputState((prev) => ({
            ...prev,
            suggestions: [],
            showSuggestions: false,
            isLoading: false,
            error: response.error || "Erro ao buscar sugestões",
            debugInfo: response.debug,
          }))
        }
      } catch (err) {
        // Verificar se o componente ainda está montado
        if (!isMountedRef.current) return

        console.error("[COMPONENT] Erro ao buscar sugestões:", err)
        setInputState((prev) => ({
          ...prev,
          suggestions: [],
          showSuggestions: false,
          isLoading: false,
          error: "Erro de conexão. Tente novamente.",
          debugInfo: {
            error: err instanceof Error ? err.message : "Unknown error",
            timestamp: new Date().toISOString(),
          },
        }))
      } finally {
        searchInProgressRef.current = false
      }
    },
    [inputState.lastQuery, inputState.lastSearchTime, checkSignificantChange, maxSuggestions],
  )

  // Debounced search com proteção contra reflash
  const debouncedSearch = useCallback(
    (query: string) => {
      // Limpar timeout anterior
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
        debounceRef.current = null
      }

      // Definir novo timeout
      debounceRef.current = setTimeout(() => {
        fetchSuggestions(query)
      }, debounceMs)
    },
    [fetchSuggestions, debounceMs],
  )

  // Effect para buscar sugestões quando o valor muda
  useEffect(() => {
    // Evitar reflash desnecessário
    if (value === lastValueRef.current) {
      return
    }

    lastValueRef.current = value

    if (value) {
      debouncedSearch(value)
    } else {
      // Limpar sugestões quando o valor for vazio
      setInputState((prev) => ({
        ...prev,
        suggestions: [],
        showSuggestions: false,
        error: null,
        rateLimitInfo: null,
        lastQuery: "",
        debugInfo: null,
      }))
    }

    // Cleanup
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
        debounceRef.current = null
      }
    }
  }, [value, debouncedSearch])

  // Gerenciar ciclo de vida do componente
  useEffect(() => {
    isMountedRef.current = true
    AddressSuggestionsService.reset()

    return () => {
      isMountedRef.current = false

      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
        debounceRef.current = null
      }

      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
        abortControllerRef.current = null
      }
    }
  }, [])

  // Handlers
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value
      onChange(newValue)

      // Resetar índice selecionado
      setInputState((prev) => ({
        ...prev,
        selectedIndex: -1,
      }))
    },
    [onChange],
  )

  const handleSuggestionSelect = useCallback(
    (suggestion: AddressSuggestion) => {
      // Atualizar valor no componente pai
      onChange(suggestion.description, suggestion)

      // Atualizar estado local
      setInputState((prev) => ({
        ...prev,
        suggestions: [],
        showSuggestions: false,
        selectedIndex: -1,
        error: null,
        rateLimitInfo: null,
        lastQuery: suggestion.description,
        debugInfo: null,
      }))

      // Atualizar ref para evitar reflash
      lastValueRef.current = suggestion.description
    },
    [onChange],
  )

  const handleInputFocus = useCallback(() => {
    // Mostrar sugestões apenas se houver alguma
    if (inputState.suggestions.length > 0) {
      setInputState((prev) => ({
        ...prev,
        showSuggestions: true,
      }))
    }
  }, [inputState.suggestions.length])

  const handleInputBlur = useCallback(() => {
    // Delay para permitir clique nas sugestões
    setTimeout(() => {
      setInputState((prev) => ({
        ...prev,
        showSuggestions: false,
        selectedIndex: -1,
      }))
    }, 200)
  }, [])

  // Navegação por teclado
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (!inputState.showSuggestions || inputState.suggestions.length === 0) return

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault()
          setInputState((prev) => ({
            ...prev,
            selectedIndex: prev.selectedIndex < prev.suggestions.length - 1 ? prev.selectedIndex + 1 : 0,
          }))
          break
        case "ArrowUp":
          e.preventDefault()
          setInputState((prev) => ({
            ...prev,
            selectedIndex: prev.selectedIndex > 0 ? prev.selectedIndex - 1 : prev.suggestions.length - 1,
          }))
          break
        case "Enter":
          e.preventDefault()
          if (inputState.selectedIndex >= 0 && inputState.selectedIndex < inputState.suggestions.length) {
            handleSuggestionSelect(inputState.suggestions[inputState.selectedIndex])
          }
          break
        case "Escape":
          setInputState((prev) => ({
            ...prev,
            showSuggestions: false,
            selectedIndex: -1,
          }))
          inputRef.current?.blur()
          break
      }
    },
    [inputState.showSuggestions, inputState.suggestions, inputState.selectedIndex, handleSuggestionSelect],
  )

  // Memoizar funções que não mudam frequentemente
  const getTypeIcon = useCallback((types: string[]) => {
    if (types.includes("street_address")) return <Navigation className="h-3 w-3" />
    if (types.includes("route")) return <MapPin className="h-3 w-3" />
    if (types.includes("establishment")) return <CheckCircle className="h-3 w-3" />
    return <Search className="h-3 w-3" />
  }, [])

  const getConfidenceColor = useCallback((confidence: number) => {
    if (confidence > 0.8) return "bg-green-100 text-green-800"
    if (confidence > 0.5) return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }, [])

  const typeLabels = useMemo(() => ({ pickup: "Retirada", delivery: "Entrega" }), [])

  return (
    <div className={`space-y-2 relative ${className}`}>
      {/* Label */}
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
        <Badge variant="outline" className="text-xs">
          {typeLabels[type]}
        </Badge>
      </div>

      {/* Input */}
      <div className="relative">
        <Input
          ref={inputRef}
          value={value}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="pr-10"
          autoComplete="off"
        />

        <div className="absolute right-2 top-1/2 -translate-y-1/2">
          {inputState.isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
          ) : (
            <Search className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </div>

      {/* Rate limit info */}
      {inputState.rateLimitInfo && (
        <Alert variant="default" className="border-orange-200 bg-orange-50">
          <Clock className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800">{inputState.rateLimitInfo}</AlertDescription>
        </Alert>
      )}

      {/* Error */}
      {inputState.error && (
        <Alert variant="default" className="border-blue-200 bg-blue-50">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">{inputState.error}</AlertDescription>
        </Alert>
      )}

      {/* Debug Info */}
      {showDebug && inputState.debugInfo && (
        <Alert variant="default" className="border-gray-200 bg-gray-50">
          <AlertTriangle className="h-4 w-4 text-gray-600" />
          <AlertDescription className="text-gray-800">
            <details>
              <summary className="cursor-pointer">Debug Info</summary>
              <pre className="text-xs mt-2 overflow-auto">{JSON.stringify(inputState.debugInfo, null, 2)}</pre>
            </details>
          </AlertDescription>
        </Alert>
      )}

      {/* Sugestões */}
      {inputState.showSuggestions && inputState.suggestions.length > 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 shadow-lg">
          <CardContent className="p-0" ref={suggestionsRef}>
            <div className="max-h-60 overflow-y-auto">
              {inputState.suggestions.map((suggestion, index) => (
                <button
                  key={suggestion.place_id}
                  type="button"
                  className={`w-full text-left p-3 hover:bg-muted transition-colors border-b last:border-b-0 ${
                    index === inputState.selectedIndex ? "bg-muted" : ""
                  }`}
                  onClick={() => handleSuggestionSelect(suggestion)}
                  onMouseEnter={() => {
                    setInputState((prev) => ({
                      ...prev,
                      selectedIndex: index,
                    }))
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1 text-muted-foreground">{getTypeIcon(suggestion.types)}</div>

                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{suggestion.main_text}</div>
                      {suggestion.secondary_text && (
                        <div className="text-xs text-muted-foreground truncate mt-0.5">{suggestion.secondary_text}</div>
                      )}

                      {/* Badges */}
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline" className={`text-xs ${getConfidenceColor(suggestion.confidence)}`}>
                          {Math.round(suggestion.confidence * 100)}% compatível
                        </Badge>

                        {showTypes && suggestion.types.length > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {suggestion.types[0].replace(/_/g, " ")}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading state para sugestões */}
      {inputState.showSuggestions && inputState.isLoading && inputState.suggestions.length === 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 shadow-lg">
          <CardContent className="p-4 text-center">
            <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Buscando sugestões...</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
