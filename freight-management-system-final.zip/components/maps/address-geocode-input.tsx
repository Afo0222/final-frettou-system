"use client"

import type React from "react"
import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { MapPin, Search, Loader2, AlertCircle, Clock, Navigation, CheckCircle, Home, Zap } from "lucide-react"
import { AddressGeocodeSearchService, type AddressResult } from "@/lib/services/address-geocode-search"

interface AddressGeocodeInputProps {
  label: string
  placeholder?: string
  value: string
  onChange: (value: string, result?: AddressResult) => void
  required?: boolean
  type?: "pickup" | "delivery"
  className?: string
  debounceMs?: number
  maxResults?: number
  showTypes?: boolean
  showDebug?: boolean
}

export function AddressGeocodeInput({
  label,
  placeholder = "Digite pelo menos 4 caracteres...",
  value,
  onChange,
  required = false,
  type = "pickup",
  className = "",
  debounceMs = 2500, // Aumentado para 2.5s
  maxResults = 4,
  showTypes = false,
  showDebug = false,
}: AddressGeocodeInputProps) {
  // Estado consolidado
  const [state, setState] = useState({
    results: [] as AddressResult[],
    showResults: false,
    isLoading: false,
    error: null as string | null,
    selectedIndex: -1,
    rateLimitInfo: null as any,
    lastQuery: "",
    lastSearchTime: 0,
    debugInfo: null as any,
    waitTime: 0,
    searchProgress: 0,
  })

  // Refs
  const debounceRef = useRef<NodeJS.Timeout | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const resultsRef = useRef<HTMLDivElement>(null)
  const lastValueRef = useRef<string>(value || "")
  const isMountedRef = useRef<boolean>(true)
  const searchInProgressRef = useRef<boolean>(false)
  const waitTimeIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Verificar se deve buscar
  const shouldSearch = useCallback(
    (newValue: string): boolean => {
      if (newValue.length < 4) return false
      if (searchInProgressRef.current) return false

      const now = Date.now()
      if (now - state.lastSearchTime < 2000) return false

      // Verificar mudança significativa
      if (state.lastQuery) {
        if (newValue === state.lastQuery) return false
        if (newValue.startsWith(state.lastQuery) && newValue.length < state.lastQuery.length + 3) return false
      }

      return true
    },
    [state.lastQuery, state.lastSearchTime],
  )

  // Buscar endereços
  const searchAddresses = useCallback(
    async (query: string) => {
      if (!shouldSearch(query)) {
        console.log("[COMPONENT] Busca ignorada")
        return
      }

      searchInProgressRef.current = true
      const now = Date.now()

      console.log(`[COMPONENT] Iniciando busca: "${query}"`)

      setState((prev) => ({
        ...prev,
        isLoading: true,
        error: null,
        rateLimitInfo: null,
        lastQuery: query,
        lastSearchTime: now,
        searchProgress: 10,
      }))

      // Simular progresso
      const progressInterval = setInterval(() => {
        setState((prev) => ({
          ...prev,
          searchProgress: Math.min(90, prev.searchProgress + 20),
        }))
      }, 200)

      try {
        const response = await AddressGeocodeSearchService.searchAddresses(query)

        clearInterval(progressInterval)

        if (!isMountedRef.current) return

        console.log(`[COMPONENT] Resposta:`, {
          status: response.status,
          results: response.results.length,
          cached: response.cached,
          rateLimitInfo: response.rateLimitInfo,
        })

        if (response.status === "OK") {
          setState((prev) => ({
            ...prev,
            results: response.results.slice(0, maxResults),
            showResults: response.results.length > 0,
            isLoading: false,
            error: null,
            rateLimitInfo: response.rateLimitInfo,
            debugInfo: response.debug,
            searchProgress: 100,
          }))
        } else if (response.status === "RATE_LIMITED") {
          const waitTime = response.rateLimitInfo?.waitTime || 30000

          setState((prev) => ({
            ...prev,
            results: [],
            showResults: false,
            isLoading: false,
            error: null,
            rateLimitInfo: response.rateLimitInfo,
            waitTime: Math.ceil(waitTime / 1000),
            debugInfo: response.debug,
            searchProgress: 0,
          }))

          // Countdown do tempo de espera
          if (waitTimeIntervalRef.current) {
            clearInterval(waitTimeIntervalRef.current)
          }

          waitTimeIntervalRef.current = setInterval(() => {
            setState((prev) => {
              const newWaitTime = Math.max(0, prev.waitTime - 1)
              if (newWaitTime === 0 && waitTimeIntervalRef.current) {
                clearInterval(waitTimeIntervalRef.current)
                waitTimeIntervalRef.current = null
              }
              return { ...prev, waitTime: newWaitTime }
            })
          }, 1000)
        } else {
          setState((prev) => ({
            ...prev,
            results: [],
            showResults: false,
            isLoading: false,
            error: response.error || "Erro ao buscar endereços",
            rateLimitInfo: response.rateLimitInfo,
            debugInfo: response.debug,
            searchProgress: 0,
          }))
        }
      } catch (err) {
        clearInterval(progressInterval)

        if (!isMountedRef.current) return

        console.error("[COMPONENT] Erro:", err)
        setState((prev) => ({
          ...prev,
          results: [],
          showResults: false,
          isLoading: false,
          error: "Erro de conexão. Verifique sua internet.",
          searchProgress: 0,
        }))
      } finally {
        searchInProgressRef.current = false
      }
    },
    [shouldSearch, maxResults],
  )

  // Debounced search
  const debouncedSearch = useCallback(
    (query: string) => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }

      debounceRef.current = setTimeout(() => {
        searchAddresses(query)
      }, debounceMs)
    },
    [searchAddresses, debounceMs],
  )

  // Effect para mudanças no valor
  useEffect(() => {
    if (value === lastValueRef.current) return

    lastValueRef.current = value

    if (value && value.length >= 4) {
      debouncedSearch(value)
    } else {
      setState((prev) => ({
        ...prev,
        results: [],
        showResults: false,
        error: null,
        rateLimitInfo: null,
        searchProgress: 0,
      }))
    }

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
    }
  }, [value, debouncedSearch])

  // Cleanup
  useEffect(() => {
    isMountedRef.current = true

    return () => {
      isMountedRef.current = false

      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }

      if (waitTimeIntervalRef.current) {
        clearInterval(waitTimeIntervalRef.current)
      }
    }
  }, [])

  // Handlers
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value
      onChange(newValue)

      setState((prev) => ({ ...prev, selectedIndex: -1 }))
    },
    [onChange],
  )

  const handleResultSelect = useCallback(
    (result: AddressResult) => {
      onChange(result.formatted_address, result)

      setState((prev) => ({
        ...prev,
        results: [],
        showResults: false,
        selectedIndex: -1,
        error: null,
        rateLimitInfo: null,
        lastQuery: result.formatted_address,
      }))

      lastValueRef.current = result.formatted_address
    },
    [onChange],
  )

  const handleInputFocus = useCallback(() => {
    if (state.results.length > 0) {
      setState((prev) => ({ ...prev, showResults: true }))
    }
  }, [state.results.length])

  const handleInputBlur = useCallback(() => {
    setTimeout(() => {
      setState((prev) => ({ ...prev, showResults: false, selectedIndex: -1 }))
    }, 200)
  }, [])

  // Navegação por teclado
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (!state.showResults || state.results.length === 0) return

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault()
          setState((prev) => ({
            ...prev,
            selectedIndex: prev.selectedIndex < prev.results.length - 1 ? prev.selectedIndex + 1 : 0,
          }))
          break
        case "ArrowUp":
          e.preventDefault()
          setState((prev) => ({
            ...prev,
            selectedIndex: prev.selectedIndex > 0 ? prev.selectedIndex - 1 : prev.results.length - 1,
          }))
          break
        case "Enter":
          e.preventDefault()
          if (state.selectedIndex >= 0 && state.selectedIndex < state.results.length) {
            handleResultSelect(state.results[state.selectedIndex])
          }
          break
        case "Escape":
          setState((prev) => ({ ...prev, showResults: false, selectedIndex: -1 }))
          inputRef.current?.blur()
          break
      }
    },
    [state.showResults, state.results, state.selectedIndex, handleResultSelect],
  )

  // Funções auxiliares memoizadas
  const getTypeIcon = useCallback((types: string[]) => {
    if (types.includes("street_address")) return <Navigation className="h-3 w-3" />
    if (types.includes("route")) return <MapPin className="h-3 w-3" />
    if (types.includes("establishment")) return <CheckCircle className="h-3 w-3" />
    if (types.includes("premise")) return <Home className="h-3 w-3" />
    return <Search className="h-3 w-3" />
  }, [])

  const getConfidenceColor = useCallback((confidence: number) => {
    if (confidence > 0.8) return "bg-green-100 text-green-800"
    if (confidence > 0.5) return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }, [])

  const typeLabels = useMemo(() => ({ pickup: "Retirada", delivery: "Entrega" }), [])

  return (
    <div className={`space-y-2 relative ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {typeLabels[type]}
          </Badge>
          {state.rateLimitInfo?.remaining !== undefined && (
            <Badge variant="outline" className="text-xs">
              {state.rateLimitInfo.remaining} restantes
            </Badge>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="relative">
        <Input
          ref={inputRef}
          value={value}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="pr-10"
          autoComplete="off"
        />

        <div className="absolute right-2 top-1/2 -translate-y-1/2">
          {state.isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
          ) : state.waitTime > 0 ? (
            <Clock className="h-4 w-4 text-orange-500" />
          ) : (
            <Search className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </div>

      {/* Progress bar */}
      {state.isLoading && state.searchProgress > 0 && <Progress value={state.searchProgress} className="h-1" />}

      {/* Rate limit warning */}
      {state.waitTime > 0 && (
        <Alert variant="default" className="border-orange-200 bg-orange-50">
          <Clock className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800">
            Aguarde {state.waitTime} segundos antes de buscar novamente
          </AlertDescription>
        </Alert>
      )}

      {/* Error */}
      {state.error && !state.waitTime && (
        <Alert variant="default" className="border-blue-200 bg-blue-50">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">{state.error}</AlertDescription>
        </Alert>
      )}

      {/* Debug Info */}
      {showDebug && state.debugInfo && (
        <Alert variant="default" className="border-gray-200 bg-gray-50">
          <Zap className="h-4 w-4 text-gray-600" />
          <AlertDescription className="text-gray-800">
            <details>
              <summary className="cursor-pointer">Debug & Stats</summary>
              <pre className="text-xs mt-2 overflow-auto max-h-32">
                {JSON.stringify(
                  {
                    ...state.debugInfo,
                    serviceStats: AddressGeocodeSearchService.getStats(),
                  },
                  null,
                  2,
                )}
              </pre>
            </details>
          </AlertDescription>
        </Alert>
      )}

      {/* Resultados */}
      {state.showResults && state.results.length > 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 shadow-lg">
          <CardContent className="p-0" ref={resultsRef}>
            <div className="max-h-60 overflow-y-auto">
              {state.results.map((result, index) => (
                <button
                  key={result.place_id}
                  type="button"
                  className={`w-full text-left p-3 hover:bg-muted transition-colors border-b last:border-b-0 ${
                    index === state.selectedIndex ? "bg-muted" : ""
                  }`}
                  onClick={() => handleResultSelect(result)}
                  onMouseEnter={() => setState((prev) => ({ ...prev, selectedIndex: index }))}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1 text-muted-foreground">{getTypeIcon(result.types)}</div>

                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{result.formatted_address}</div>

                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline" className={`text-xs ${getConfidenceColor(result.confidence)}`}>
                          {Math.round(result.confidence * 100)}%
                        </Badge>

                        {result.partial_match && (
                          <Badge variant="outline" className="text-xs bg-orange-100 text-orange-800">
                            Parcial
                          </Badge>
                        )}

                        {showTypes && result.types.length > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {result.types[0].replace(/_/g, " ")}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading state */}
      {state.showResults && state.isLoading && state.results.length === 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 shadow-lg">
          <CardContent className="p-4 text-center">
            <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Buscando endereços...</p>
            {state.searchProgress > 0 && <Progress value={state.searchProgress} className="h-1 mt-2" />}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
