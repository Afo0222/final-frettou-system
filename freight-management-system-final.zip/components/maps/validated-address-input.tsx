"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MapPin, CheckCircle, AlertCircle, AlertTriangle, Loader2, RefreshCw, Navigation, Search } from "lucide-react"
import {
  AddressValidationService,
  type AddressValidationResult,
  type AddressSuggestion,
} from "@/lib/services/address-validation"

interface AddressPairValidatorProps {
  label: string
  placeholder?: string
  value: string
  onChange: (value: string, validation?: AddressValidationResult) => void
  required?: boolean
  type?: "pickup" | "delivery"
  className?: string
  showCoordinates?: boolean
  autoValidate?: boolean
}

export function ValidatedAddressInput({
  label,
  placeholder = "Digite o endereço completo...",
  value,
  onChange,
  required = false,
  type = "pickup",
  className = "",
  showCoordinates = false,
  autoValidate = true,
}: AddressPairValidatorProps) {
  const [validation, setValidation] = useState<AddressValidationResult | null>(null)
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [isValidating, setIsValidating] = useState(false)
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false)
  const [hasApiError, setHasApiError] = useState(false)
  const [validationAttempts, setValidationAttempts] = useState(0)

  const inputRef = useRef<HTMLInputElement>(null)
  const debounceRef = useRef<NodeJS.Timeout>()

  // Validação com debounce
  const debouncedValidation = useCallback(
    async (address: string) => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }

      debounceRef.current = setTimeout(async () => {
        if (address.trim().length > 5) {
          setIsValidating(true)
          setHasApiError(false)

          try {
            const result = await AddressValidationService.validateAddress(address)
            setValidation(result)
            onChange(address, result)
            setValidationAttempts(0) // Reset attempts on success

            // Buscar sugestões se endereço não for válido
            if (!result.isValid && result.confidence === "low") {
              setIsLoadingSuggestions(true)
              try {
                const addressSuggestions = await AddressValidationService.findSimilarAddresses(address)
                setSuggestions(addressSuggestions)
                setShowSuggestions(addressSuggestions.length > 0)
              } catch (suggestionError) {
                console.warn("Erro ao buscar sugestões:", suggestionError)
                setSuggestions([])
                setShowSuggestions(false)
              } finally {
                setIsLoadingSuggestions(false)
              }
            } else {
              setSuggestions([])
              setShowSuggestions(false)
            }
          } catch (error) {
            console.error("Erro na validação:", error)
            setHasApiError(true)

            // Incrementar tentativas
            const newAttempts = validationAttempts + 1
            setValidationAttempts(newAttempts)

            // Se excedeu tentativas, usar validação offline
            if (newAttempts >= 3) {
              // Usar validação offline como fallback
              const offlineValidation = {
                isValid: true, // Consideramos válido para não bloquear o usuário
                confidence: "low" as const,
                originalAddress: address,
                warnings: ["Validação online indisponível. Usando validação básica."],
              }
              setValidation(offlineValidation)
              onChange(address, offlineValidation)
            }
          } finally {
            setIsValidating(false)
          }
        } else {
          setValidation(null)
          setSuggestions([])
          setShowSuggestions(false)
          setHasApiError(false)
        }
      }, 800)
    },
    [onChange, validationAttempts],
  )

  useEffect(() => {
    if (autoValidate && value) {
      debouncedValidation(value)
    }

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
    }
  }, [value, debouncedValidation, autoValidate])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    onChange(newValue)
    setShowSuggestions(false)
    setHasApiError(false)
  }

  const handleManualValidation = async () => {
    if (!value.trim()) return

    setIsValidating(true)
    setHasApiError(false)

    try {
      const result = await AddressValidationService.validateAddress(value)
      setValidation(result)
      onChange(value, result)
      setValidationAttempts(0) // Reset attempts on success

      if (!result.isValid) {
        setIsLoadingSuggestions(true)
        try {
          const addressSuggestions = await AddressValidationService.findSimilarAddresses(value)
          setSuggestions(addressSuggestions)
          setShowSuggestions(addressSuggestions.length > 0)
        } catch (suggestionError) {
          console.warn("Erro ao buscar sugestões:", suggestionError)
          setSuggestions([])
          setShowSuggestions(false)
        } finally {
          setIsLoadingSuggestions(false)
        }
      }
    } catch (error) {
      console.error("Erro na validação manual:", error)
      setHasApiError(true)

      // Incrementar tentativas
      const newAttempts = validationAttempts + 1
      setValidationAttempts(newAttempts)

      // Se excedeu tentativas, usar validação offline
      if (newAttempts >= 3) {
        // Usar validação offline como fallback
        const offlineValidation = {
          isValid: true, // Consideramos válido para não bloquear o usuário
          confidence: "low" as const,
          originalAddress: value,
          warnings: ["Validação online indisponível. Usando validação básica."],
        }
        setValidation(offlineValidation)
        onChange(value, offlineValidation)
      } else {
        setValidation({
          isValid: false,
          confidence: "low",
          originalAddress: value,
          errors: ["Erro ao validar endereço. Tente novamente."],
        })
      }
    } finally {
      setIsValidating(false)
    }
  }

  const handleSuggestionSelect = (suggestion: AddressSuggestion) => {
    onChange(suggestion.address)
    setShowSuggestions(false)
    setSuggestions([])
    setHasApiError(false)
    setValidationAttempts(0) // Reset attempts on selection

    // Validar endereço selecionado
    setTimeout(() => {
      debouncedValidation(suggestion.address)
    }, 100)
  }

  const getValidationIcon = () => {
    if (isValidating) {
      return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
    }

    if (hasApiError) {
      return <AlertTriangle className="h-4 w-4 text-orange-500" />
    }

    if (!validation) {
      return <MapPin className="h-4 w-4 text-muted-foreground" />
    }

    if (validation.isValid) {
      return <CheckCircle className="h-4 w-4 text-green-500" />
    }

    if (validation.errors?.length) {
      return <AlertCircle className="h-4 w-4 text-red-500" />
    }

    return <AlertTriangle className="h-4 w-4 text-yellow-500" />
  }

  const getValidationColor = () => {
    if (hasApiError) return "border-orange-500 focus:border-orange-500"
    if (!validation) return ""

    if (validation.isValid) return "border-green-500 focus:border-green-500"
    if (validation.errors?.length) return "border-red-500 focus:border-red-500"
    return "border-yellow-500 focus:border-yellow-500"
  }

  const getConfidenceBadge = () => {
    if (!validation || !validation.isValid) return null

    const colors = {
      high: "bg-green-100 text-green-800",
      medium: "bg-yellow-100 text-yellow-800",
      low: "bg-red-100 text-red-800",
    }

    return (
      <Badge variant="outline" className={colors[validation.confidence]}>
        Confiança: {validation.confidence === "high" ? "Alta" : validation.confidence === "medium" ? "Média" : "Baixa"}
      </Badge>
    )
  }

  const typeLabels = {
    pickup: "Retirada",
    delivery: "Entrega",
  }

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Label */}
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
        <Badge variant="outline" className="text-xs">
          {typeLabels[type]}
        </Badge>
      </div>

      {/* Input com validação */}
      <div className="relative">
        <Input
          ref={inputRef}
          value={value}
          onChange={handleInputChange}
          placeholder={placeholder}
          className={`pr-20 ${getValidationColor()}`}
          onFocus={() => {
            if (suggestions.length > 0) {
              setShowSuggestions(true)
            }
          }}
        />

        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
          {getValidationIcon()}

          {value && !isValidating && (
            <Button type="button" variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={handleManualValidation}>
              <RefreshCw className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Status da validação */}
      {validation && (
        <div className="space-y-2">
          {/* Confiança */}
          <div className="flex items-center gap-2">
            {getConfidenceBadge()}
            {validation.coordinates && showCoordinates && (
              <Badge variant="outline" className="text-xs">
                <Navigation className="h-3 w-3 mr-1" />
                {validation.coordinates.lat.toFixed(4)}, {validation.coordinates.lng.toFixed(4)}
              </Badge>
            )}
          </div>

          {/* Avisos */}
          {validation.warnings?.map((warning, index) => (
            <Alert key={index} variant="default">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{warning}</AlertDescription>
            </Alert>
          ))}

          {/* Erros */}
          {validation.errors?.map((error, index) => (
            <Alert key={index} variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ))}

          {/* Erro de API */}
          {hasApiError && (
            <Alert variant="default" className="border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">
                {validationAttempts >= 3
                  ? "Validação online indisponível. Usando validação básica."
                  : "Erro na validação. Tente novamente."}
              </AlertDescription>
            </Alert>
          )}

          {/* Componentes do endereço */}
          {validation.isValid && validation.components && (
            <div className="grid grid-cols-2 gap-2 text-xs bg-muted p-2 rounded">
              {validation.components.city && (
                <div>
                  <span className="text-muted-foreground">Cidade:</span>
                  <span className="ml-1 font-medium">{validation.components.city}</span>
                </div>
              )}
              {validation.components.state && (
                <div>
                  <span className="text-muted-foreground">Estado:</span>
                  <span className="ml-1 font-medium">{validation.components.state}</span>
                </div>
              )}
              {validation.components.neighborhood && (
                <div>
                  <span className="text-muted-foreground">Bairro:</span>
                  <span className="ml-1 font-medium">{validation.components.neighborhood}</span>
                </div>
              )}
              {validation.components.postal_code && (
                <div>
                  <span className="text-muted-foreground">CEP:</span>
                  <span className="ml-1 font-medium">{validation.components.postal_code}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Sugestões */}
      {showSuggestions && (suggestions.length > 0 || isLoadingSuggestions) && (
        <Card className="relative z-50">
          <CardContent className="p-0">
            {isLoadingSuggestions ? (
              <div className="p-4 text-center">
                <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Buscando sugestões...</p>
              </div>
            ) : (
              <>
                <div className="p-2 border-b bg-muted">
                  <p className="text-xs font-medium text-muted-foreground">Sugestões de endereços:</p>
                </div>
                {suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    type="button"
                    className="w-full text-left p-3 hover:bg-muted transition-colors border-b last:border-b-0"
                    onClick={() => handleSuggestionSelect(suggestion)}
                  >
                    <div className="flex items-start gap-2">
                      <Search className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{suggestion.address}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              suggestion.type === "exact"
                                ? "bg-green-50 text-green-700"
                                : suggestion.type === "partial"
                                  ? "bg-yellow-50 text-yellow-700"
                                  : "bg-blue-50 text-blue-700"
                            }`}
                          >
                            {suggestion.type === "exact"
                              ? "Exato"
                              : suggestion.type === "partial"
                                ? "Parcial"
                                : "Aproximado"}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {Math.round(suggestion.confidence * 100)}% compatível
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
