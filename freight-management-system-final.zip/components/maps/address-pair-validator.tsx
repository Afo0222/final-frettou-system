"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { MapPin, Navigation, Clock, Truck, AlertTriangle } from "lucide-react"
import { ValidatedAddressInput } from "./validated-address-input"
import { AddressValidationService, type AddressValidationResult } from "@/lib/services/address-validation"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface AddressPairValidatorProps {
  originValue: string
  destinationValue: string
  onOriginChange: (value: string, validation?: AddressValidationResult) => void
  onDestinationChange: (value: string, validation?: AddressValidationResult) => void
  onValidationComplete?: (isValid: boolean, data?: any) => void
  autoValidate?: boolean
  showRoute?: boolean
  className?: string
}

export function AddressPairValidator({
  originValue,
  destinationValue,
  onOriginChange,
  onDestinationChange,
  onValidationComplete,
  autoValidate = true,
  showRoute = true,
  className = "",
}: AddressPairValidatorProps) {
  const [originValidation, setOriginValidation] = useState<AddressValidationResult | null>(null)
  const [destinationValidation, setDestinationValidation] = useState<AddressValidationResult | null>(null)
  const [routeInfo, setRouteInfo] = useState<any>(null)
  const [isValidatingPair, setIsValidatingPair] = useState(false)
  const [pairValidation, setPairValidation] = useState<any>(null)

  // Validar par de endereços quando ambos estão preenchidos
  useEffect(() => {
    if (
      autoValidate &&
      originValue.trim().length > 10 &&
      destinationValue.trim().length > 10 &&
      originValidation?.isValid &&
      destinationValidation?.isValid
    ) {
      validateAddressPair()
    }
  }, [originValue, destinationValue, originValidation, destinationValidation, autoValidate])

  const validateAddressPair = async () => {
    if (!originValue.trim() || !destinationValue.trim()) return

    setIsValidatingPair(true)
    try {
      const result = await AddressValidationService.validateAddressPair(originValue, destinationValue)
      setPairValidation(result)
      setRouteInfo(result.route)

      const isValid = result.origin.isValid && result.destination.isValid && (!result.route || result.route.feasible)

      onValidationComplete?.(isValid, {
        origin: result.origin,
        destination: result.destination,
        route: result.route,
      })
    } catch (error) {
      console.error("Erro na validação do par de endereços:", error)
      setPairValidation(null)
      setRouteInfo(null)
      onValidationComplete?.(false)
    } finally {
      setIsValidatingPair(false)
    }
  }

  const handleOriginChange = (value: string, validation?: AddressValidationResult) => {
    setOriginValidation(validation || null)
    onOriginChange(value, validation)
  }

  const handleDestinationChange = (value: string, validation?: AddressValidationResult) => {
    setDestinationValidation(validation || null)
    onDestinationChange(value, validation)
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Inputs de endereço */}
      <div className="grid gap-6 md:grid-cols-2">
        <ValidatedAddressInput
          label="Endereço de Retirada"
          placeholder="Rua, número, bairro, cidade, CEP"
          value={originValue}
          onChange={handleOriginChange}
          type="pickup"
          required
          showCoordinates
          autoValidate={autoValidate}
        />

        <ValidatedAddressInput
          label="Endereço de Entrega"
          placeholder="Rua, número, bairro, cidade, CEP"
          value={destinationValue}
          onChange={handleDestinationChange}
          type="delivery"
          required
          showCoordinates
          autoValidate={autoValidate}
        />
      </div>

      {/* Informações da rota */}
      {showRoute && routeInfo && (
        <Card>
          <CardContent>
            <>
              <Separator />
              <div>
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <Navigation className="h-4 w-4" />
                  Informações da Rota
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Truck className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Distância:</span>
                    <Badge variant="outline">{routeInfo.distance.toFixed(1)} km</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Tempo estimado:</span>
                    <Badge variant="outline">{routeInfo.duration.toFixed(1)}h</Badge>
                  </div>
                </div>

                {/* Avisos da rota */}
                {routeInfo.warnings?.map((warning: string, index: number) => (
                  <Alert key={index} variant="default" className="mt-2">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>{warning}</AlertDescription>
                  </Alert>
                ))}

                {/* Status de viabilidade */}
                <div className="mt-3">
                  <Badge
                    variant={routeInfo.feasible ? "default" : "destructive"}
                    className={routeInfo.feasible ? "bg-green-100 text-green-800" : ""}
                  >
                    {routeInfo.feasible ? "Rota Viável" : "Rota Inviável"}
                  </Badge>
                </div>
              </div>
            </>
          </CardContent>
        </Card>
      )}

      {/* Resumo das validações */}
      {(originValidation || destinationValidation) && (
        <Card>
          <CardContent>
            <>
              <Separator />
              <div className="grid gap-3 md:grid-cols-2">
                {/* Origem */}
                <div className="space-y-2">
                  <h5 className="font-medium text-sm flex items-center gap-2">
                    <MapPin className="h-3 w-3" />
                    Retirada
                  </h5>
                  {originValidation ? (
                    <div className="space-y-1">
                      <Badge
                        variant={originValidation.isValid ? "default" : "destructive"}
                        className={originValidation.isValid ? "bg-green-100 text-green-800" : ""}
                      >
                        {originValidation.isValid ? "Válido" : "Inválido"}
                      </Badge>
                      {originValidation.components?.city && (
                        <p className="text-xs text-muted-foreground">
                          {originValidation.components.city}, {originValidation.components.state}
                        </p>
                      )}
                    </div>
                  ) : (
                    <Badge variant="outline">Não validado</Badge>
                  )}
                </div>

                {/* Destino */}
                <div className="space-y-2">
                  <h5 className="font-medium text-sm flex items-center gap-2">
                    <MapPin className="h-3 w-3" />
                    Entrega
                  </h5>
                  {destinationValidation ? (
                    <div className="space-y-1">
                      <Badge
                        variant={destinationValidation.isValid ? "default" : "destructive"}
                        className={destinationValidation.isValid ? "bg-green-100 text-green-800" : ""}
                      >
                        {destinationValidation.isValid ? "Válido" : "Inválido"}
                      </Badge>
                      {destinationValidation.components?.city && (
                        <p className="text-xs text-muted-foreground">
                          {destinationValidation.components.city}, {destinationValidation.components.state}
                        </p>
                      )}
                    </div>
                  ) : (
                    <Badge variant="outline">Não validado</Badge>
                  )}
                </div>
              </div>
            </>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
