"use client"

import type React from "react"
import { useState, useRef, useCallback } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Search, MapPin, Loader2, CheckCircle, AlertCircle, Navigation, Home, Building, Star, Info } from "lucide-react"
import { AddressSearchService, type AddressSearchResult } from "@/lib/services/address-search"

interface AddressSearchInputProps {
  label: string
  placeholder?: string
  value: string
  onChange: (value: string, result?: AddressSearchResult) => void
  required?: boolean
  type?: "pickup" | "delivery"
  className?: string
  showDebug?: boolean
}

export function AddressSearchInput({
  label,
  placeholder = "Digite o endereço completo...",
  value,
  onChange,
  required = false,
  type = "pickup",
  className = "",
  showDebug = false,
}: AddressSearchInputProps) {
  // Estados
  const [searchState, setSearchState] = useState({
    isSearching: false,
    results: [] as AddressSearchResult[],
    showResults: false,
    error: null as string | null,
    selectedResult: null as AddressSearchResult | null,
    searchPerformed: false,
    debugInfo: null as any,
  })

  // Refs
  const inputRef = useRef<HTMLInputElement>(null)

  // Validar endereço
  const validateAndSearch = useCallback(async () => {
    const trimmedValue = value.trim()

    // Validação local
    const validation = AddressSearchService.validateAddress(trimmedValue)
    if (!validation.valid) {
      setSearchState((prev) => ({
        ...prev,
        error: validation.error || "Endereço inválido",
        results: [],
        showResults: false,
        searchPerformed: true,
      }))
      return
    }

    // Iniciar busca
    setSearchState((prev) => ({
      ...prev,
      isSearching: true,
      error: null,
      results: [],
      showResults: false,
      selectedResult: null,
      searchPerformed: true,
      debugInfo: null,
    }))

    console.log(`[COMPONENT] Iniciando busca para: "${trimmedValue}"`)

    try {
      const response = await AddressSearchService.searchAddress(trimmedValue)

      console.log(`[COMPONENT] Resposta recebida:`, {
        success: response.success,
        results: response.results.length,
        cached: response.cached,
        error: response.error,
      })

      if (response.success && response.results.length > 0) {
        setSearchState((prev) => ({
          ...prev,
          isSearching: false,
          results: response.results,
          showResults: true,
          error: null,
          debugInfo: response.debug,
        }))
      } else {
        setSearchState((prev) => ({
          ...prev,
          isSearching: false,
          results: [],
          showResults: false,
          error: response.error || "Nenhum endereço encontrado",
          debugInfo: response.debug,
        }))
      }
    } catch (error) {
      console.error("[COMPONENT] Erro na busca:", error)

      setSearchState((prev) => ({
        ...prev,
        isSearching: false,
        results: [],
        showResults: false,
        error: "Erro ao buscar endereço. Tente novamente.",
        debugInfo: {
          error: error instanceof Error ? error.message : "Unknown error",
          timestamp: new Date().toISOString(),
        },
      }))
    }
  }, [value])

  // Selecionar resultado
  const selectResult = useCallback(
    (result: AddressSearchResult) => {
      console.log(`[COMPONENT] Endereço selecionado:`, result.formatted_address)

      onChange(result.formatted_address, result)

      setSearchState((prev) => ({
        ...prev,
        selectedResult: result,
        showResults: false,
        error: null,
      }))
    },
    [onChange],
  )

  // Limpar busca
  const clearSearch = useCallback(() => {
    setSearchState({
      isSearching: false,
      results: [],
      showResults: false,
      error: null,
      selectedResult: null,
      searchPerformed: false,
      debugInfo: null,
    })
  }, [])

  // Handlers
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value
      onChange(newValue)

      // Limpar estado se o valor mudou significativamente
      if (searchState.selectedResult && newValue !== searchState.selectedResult.formatted_address) {
        clearSearch()
      }
    },
    [onChange, searchState.selectedResult, clearSearch],
  )

  const handleSearchClick = useCallback(() => {
    validateAndSearch()
  }, [validateAndSearch])

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter") {
        e.preventDefault()
        validateAndSearch()
      }
    },
    [validateAndSearch],
  )

  // Funções auxiliares
  const getTypeIcon = useCallback((types: string[]) => {
    if (types.includes("street_address")) return <Navigation className="h-4 w-4 text-blue-600" />
    if (types.includes("route")) return <MapPin className="h-4 w-4 text-green-600" />
    if (types.includes("establishment")) return <Building className="h-4 w-4 text-purple-600" />
    if (types.includes("premise")) return <Home className="h-4 w-4 text-orange-600" />
    return <Search className="h-4 w-4 text-gray-600" />
  }, [])

  const getConfidenceColor = useCallback((confidence: number) => {
    if (confidence > 0.8) return "bg-green-100 text-green-800 border-green-200"
    if (confidence > 0.6) return "bg-yellow-100 text-yellow-800 border-yellow-200"
    return "bg-red-100 text-red-800 border-red-200"
  }, [])

  const getQualityStars = useCallback((score: number) => {
    const stars = Math.round(score * 5)
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`h-3 w-3 ${i < stars ? "text-yellow-400 fill-current" : "text-gray-300"}`} />
    ))
  }, [])

  const typeLabels = { pickup: "Retirada", delivery: "Entrega" }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
        <Badge variant="outline" className="text-xs">
          {typeLabels[type]}
        </Badge>
      </div>

      {/* Input e Botão de Busca */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            ref={inputRef}
            value={value}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className="pr-10"
            disabled={searchState.isSearching}
          />

          <div className="absolute right-2 top-1/2 -translate-y-1/2">
            {searchState.selectedResult ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <Search className="h-4 w-4 text-muted-foreground" />
            )}
          </div>
        </div>

        <Button
          onClick={handleSearchClick}
          disabled={searchState.isSearching || !value.trim() || value.trim().length < 5}
          className="min-w-[120px]"
        >
          {searchState.isSearching ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Buscando...
            </>
          ) : (
            <>
              <Search className="h-4 w-4 mr-2" />
              Buscar
            </>
          )}
        </Button>
      </div>

      {/* Endereço Selecionado */}
      {searchState.selectedResult && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <div className="font-medium">Endereço confirmado:</div>
            <div className="text-sm mt-1">{searchState.selectedResult.formatted_address}</div>
          </AlertDescription>
        </Alert>
      )}

      {/* Erro */}
      {searchState.error && searchState.searchPerformed && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{searchState.error}</AlertDescription>
        </Alert>
      )}

      {/* Resultados da Busca */}
      {searchState.showResults && searchState.results.length > 0 && (
        <Card className="border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <MapPin className="h-4 w-4 text-blue-600" />
              Endereços Encontrados ({searchState.results.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {searchState.results.map((result, index) => (
              <div key={result.id}>
                <button
                  type="button"
                  onClick={() => selectResult(result)}
                  className="w-full text-left p-3 rounded-lg border hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">{getTypeIcon(result.types)}</div>

                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm mb-2">{result.formatted_address}</div>

                      {/* Badges de Informação */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className={`text-xs ${getConfidenceColor(result.confidence)}`}>
                          {Math.round(result.confidence * 100)}% compatível
                        </Badge>

                        <div className="flex items-center gap-1">
                          <span className="text-xs text-muted-foreground">Qualidade:</span>
                          <div className="flex">{getQualityStars(result.quality_score)}</div>
                        </div>

                        {result.partial_match && (
                          <Badge variant="outline" className="text-xs bg-orange-100 text-orange-800 border-orange-200">
                            Match Parcial
                          </Badge>
                        )}

                        {result.geometry.location && (
                          <Badge variant="outline" className="text-xs bg-blue-100 text-blue-800 border-blue-200">
                            Coordenadas
                          </Badge>
                        )}
                      </div>

                      {/* Tipo de Localização */}
                      {result.types.length > 0 && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Tipo: {result.types[0].replace(/_/g, " ")}
                        </div>
                      )}
                    </div>
                  </div>
                </button>

                {index < searchState.results.length - 1 && <Separator className="mt-3" />}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Debug Info */}
      {showDebug && searchState.debugInfo && (
        <Alert className="border-gray-200 bg-gray-50">
          <Info className="h-4 w-4 text-gray-600" />
          <AlertDescription className="text-gray-800">
            <details>
              <summary className="cursor-pointer font-medium">Informações de Debug</summary>
              <pre className="text-xs mt-2 overflow-auto max-h-40 bg-white p-2 rounded border">
                {JSON.stringify(
                  {
                    ...searchState.debugInfo,
                    serviceStats: AddressSearchService.getStats(),
                  },
                  null,
                  2,
                )}
              </pre>
            </details>
          </AlertDescription>
        </Alert>
      )}

      {/* Instruções */}
      {!searchState.searchPerformed && !searchState.selectedResult && (
        <div className="text-xs text-muted-foreground bg-blue-50 p-3 rounded-lg border border-blue-200">
          <div className="flex items-start gap-2">
            <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <div className="font-medium text-blue-800 mb-1">Como usar:</div>
              <ul className="space-y-1 text-blue-700">
                <li>• Digite o endereço completo (rua, número, bairro, cidade)</li>
                <li>• Clique em "Buscar" ou pressione Enter</li>
                <li>• Selecione o endereço correto da lista</li>
                <li>• O endereço será confirmado automaticamente</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
