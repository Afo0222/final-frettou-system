"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useGoogleMaps } from "@/hooks/use-google-maps"
import { MapPin, Search, CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import type { Address } from "@/lib/services/google-maps"

interface AddressAutocompleteProps {
  label?: string
  placeholder?: string
  value?: string
  onChange?: (address: string, coordinates?: { lat: number; lng: number }) => void
  onAddressSelect?: (address: Address) => void
  required?: boolean
  error?: string
  className?: string
}

export function AddressAutocomplete({
  label,
  placeholder = "Digite o endereço...",
  value = "",
  onChange,
  onAddressSelect,
  required = false,
  error,
  className,
}: AddressAutocompleteProps) {
  const [inputValue, setInputValue] = useState(value)
  const [suggestions, setSuggestions] = useState<Address[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null)
  const [validationStatus, setValidationStatus] = useState<"idle" | "validating" | "valid" | "invalid">("idle")

  const { geocodeAddress, validateAddress, loading, isConfigured } = useGoogleMaps()
  const inputRef = useRef<HTMLInputElement>(null)
  const debounceRef = useRef<NodeJS.Timeout>()

  // Debounced geocoding
  const debouncedGeocode = useCallback(
    (address: string) => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }

      debounceRef.current = setTimeout(async () => {
        if (address.length > 3) {
          setValidationStatus("validating")
          const result = await geocodeAddress(address)

          if (result) {
            setSuggestions([result])
            setValidationStatus("valid")
          } else {
            setSuggestions([])
            setValidationStatus("invalid")
          }
        } else {
          setSuggestions([])
          setValidationStatus("idle")
        }
      }, 500)
    },
    [geocodeAddress],
  )

  useEffect(() => {
    if (inputValue !== value) {
      setInputValue(value)
    }
  }, [value])

  useEffect(() => {
    if (inputValue && isConfigured) {
      debouncedGeocode(inputValue)
    } else {
      setSuggestions([])
      setValidationStatus("idle")
    }

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
    }
  }, [inputValue, debouncedGeocode, isConfigured])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    setInputValue(newValue)
    setSelectedAddress(null)
    setShowSuggestions(true)
    onChange?.(newValue)
  }

  const handleAddressSelect = (address: Address) => {
    setInputValue(address.formatted_address)
    setSelectedAddress(address)
    setShowSuggestions(false)
    setValidationStatus("valid")

    onChange?.(address.formatted_address, address.coordinates)
    onAddressSelect?.(address)
  }

  const handleValidateAddress = async () => {
    if (!inputValue.trim()) return

    setValidationStatus("validating")
    const validation = await validateAddress(inputValue)

    if (validation.isValid && validation.correctedAddress) {
      const geocoded = await geocodeAddress(validation.correctedAddress)
      if (geocoded) {
        handleAddressSelect(geocoded)
      }
    } else {
      setValidationStatus("invalid")
    }
  }

  const getValidationIcon = () => {
    switch (validationStatus) {
      case "validating":
        return <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      case "valid":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "invalid":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <MapPin className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getValidationMessage = () => {
    switch (validationStatus) {
      case "validating":
        return "Validando endereço..."
      case "valid":
        return selectedAddress ? "Endereço validado" : "Endereço encontrado"
      case "invalid":
        return "Endereço não encontrado"
      default:
        return ""
    }
  }

  if (!isConfigured) {
    return (
      <div className={className}>
        {label && <Label className="text-sm font-medium">{label}</Label>}
        <Input
          ref={inputRef}
          value={inputValue}
          onChange={handleInputChange}
          placeholder={placeholder}
          className="mt-1"
        />
        <p className="text-xs text-muted-foreground mt-1">Google Maps não configurado. Usando entrada manual.</p>
      </div>
    )
  }

  return (
    <div className={`relative ${className}`}>
      {label && (
        <Label className="text-sm font-medium">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
      )}

      <div className="relative mt-1">
        <Input
          ref={inputRef}
          value={inputValue}
          onChange={handleInputChange}
          placeholder={placeholder}
          className={`pr-20 ${error ? "border-red-500" : ""} ${validationStatus === "valid" ? "border-green-500" : ""}`}
          onFocus={() => setShowSuggestions(true)}
        />

        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
          {getValidationIcon()}

          {inputValue && validationStatus !== "validating" && (
            <Button type="button" variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={handleValidateAddress}>
              <Search className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Validation Message */}
      {getValidationMessage() && (
        <p
          className={`text-xs mt-1 ${
            validationStatus === "valid"
              ? "text-green-600"
              : validationStatus === "invalid"
                ? "text-red-600"
                : "text-muted-foreground"
          }`}
        >
          {getValidationMessage()}
        </p>
      )}

      {/* Error Message */}
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}

      {/* Suggestions */}
      {showSuggestions && suggestions.length > 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 max-h-60 overflow-auto">
          <CardContent className="p-0">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                type="button"
                className="w-full text-left p-3 hover:bg-muted transition-colors border-b last:border-b-0"
                onClick={() => handleAddressSelect(suggestion)}
              >
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{suggestion.formatted_address}</p>
                    {suggestion.city && suggestion.state && (
                      <p className="text-xs text-muted-foreground">
                        {suggestion.city}, {suggestion.state}
                      </p>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Selected Address Details */}
      {selectedAddress && (
        <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-md">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">Endereço Confirmado</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {selectedAddress.city && (
              <div>
                <span className="text-muted-foreground">Cidade:</span>
                <span className="ml-1 font-medium">{selectedAddress.city}</span>
              </div>
            )}
            {selectedAddress.state && (
              <div>
                <span className="text-muted-foreground">Estado:</span>
                <span className="ml-1 font-medium">{selectedAddress.state}</span>
              </div>
            )}
            {selectedAddress.postal_code && (
              <div>
                <span className="text-muted-foreground">CEP:</span>
                <span className="ml-1 font-medium">{selectedAddress.postal_code}</span>
              </div>
            )}
            <div>
              <span className="text-muted-foreground">Coordenadas:</span>
              <span className="ml-1 font-medium">
                {selectedAddress.coordinates.lat.toFixed(6)}, {selectedAddress.coordinates.lng.toFixed(6)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
