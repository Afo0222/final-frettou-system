"use client"

import type React from "react"
import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MapPin, CheckCircle, AlertCircle, AlertTriangle, Loader2, RefreshCw, Navigation, Search } from "lucide-react"
import {
  OptimizedAddressValidationService,
  type AddressValidationResult,
  type AddressSuggestion,
} from "@/lib/services/address-validation-optimized"

interface OptimizedAddressInputProps {
  label: string
  placeholder?: string
  value: string
  onChange: (value: string, validation?: AddressValidationResult) => void
  required?: boolean
  type?: "pickup" | "delivery"
  className?: string
  showCoordinates?: boolean
  autoValidate?: boolean
  debounceMs?: number
}

export function OptimizedAddressInput({
  label,
  placeholder = "Digite o endereço completo...",
  value,
  onChange,
  required = false,
  type = "pickup",
  className = "",
  showCoordinates = false,
  autoValidate = true,
  debounceMs = 1000,
}: OptimizedAddressInputProps) {
  // Estados consolidados para reduzir re-renders
  const [state, setState] = useState({
    validation: null as AddressValidationResult | null,
    suggestions: [] as AddressSuggestion[],
    showSuggestions: false,
    isValidating: false,
    isLoadingSuggestions: false,
    hasApiError: false,
  })

  // Refs para controle de requisições
  const debounceRef = useRef<NodeJS.Timeout>()
  const abortControllerRef = useRef<AbortController>()
  const lastValidatedAddress = useRef<string>("")

  // Função para atualizar estado de forma otimizada
  const updateState = useCallback((updates: Partial<typeof state>) => {
    setState((prev) => ({ ...prev, ...updates }))
  }, [])

  // Debounced validation otimizada
  const debouncedValidation = useCallback(
    async (address: string) => {
      // Cancelar requisição anterior
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }

      // Limpar timeout anterior
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }

      // Verificar se já foi validado
      if (address === lastValidatedAddress.current) {
        return
      }

      debounceRef.current = setTimeout(async () => {
        if (address.trim().length <= 5) {
          updateState({
            validation: null,
            suggestions: [],
            showSuggestions: false,
            hasApiError: false,
          })
          return
        }

        // Criar novo AbortController
        abortControllerRef.current = new AbortController()
        const currentAddress = address

        updateState({ isValidating: true, hasApiError: false })

        try {
          // Validar endereço
          const validation = await OptimizedAddressValidationService.validateAddress(currentAddress)

          // Verificar se a requisição não foi cancelada
          if (abortControllerRef.current?.signal.aborted || currentAddress !== value) {
            return
          }

          lastValidatedAddress.current = currentAddress
          onChange(currentAddress, validation)

          updateState({
            validation,
            isValidating: false,
          })

          // Buscar sugestões apenas se necessário
          if (!validation.isValid && validation.confidence === "low") {
            updateState({ isLoadingSuggestions: true })

            try {
              const suggestions = await OptimizedAddressValidationService.findSimilarAddresses(currentAddress)

              // Verificar novamente se não foi cancelada
              if (!abortControllerRef.current?.signal.aborted && currentAddress === value) {
                updateState({
                  suggestions,
                  showSuggestions: suggestions.length > 0,
                  isLoadingSuggestions: false,
                })
              }
            } catch (suggestionError) {
              if (!abortControllerRef.current?.signal.aborted) {
                updateState({
                  suggestions: [],
                  showSuggestions: false,
                  isLoadingSuggestions: false,
                })
              }
            }
          } else {
            updateState({
              suggestions: [],
              showSuggestions: false,
            })
          }
        } catch (error) {
          if (!abortControllerRef.current?.signal.aborted && currentAddress === value) {
            console.error("Erro na validação:", error)
            updateState({
              hasApiError: true,
              isValidating: false,
              validation: {
                isValid: true, // Não bloquear o usuário
                confidence: "low",
                originalAddress: currentAddress,
                warnings: ["Validação indisponível. Usando validação básica."],
              },
            })
            onChange(currentAddress, state.validation!)
          }
        }
      }, debounceMs)
    },
    [value, onChange, debounceMs, updateState],
  )

  // Effect para validação automática
  useEffect(() => {
    if (autoValidate && value) {
      debouncedValidation(value)
    }

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }
    }
  }, [value, debouncedValidation, autoValidate])

  // Handlers otimizados
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value
      onChange(newValue)
      updateState({
        showSuggestions: false,
        hasApiError: false,
      })
    },
    [onChange, updateState],
  )

  const handleSuggestionSelect = useCallback(
    (suggestion: AddressSuggestion) => {
      onChange(suggestion.address)
      updateState({
        showSuggestions: false,
        suggestions: [],
        hasApiError: false,
      })
      lastValidatedAddress.current = ""
    },
    [onChange, updateState],
  )

  const handleManualValidation = useCallback(async () => {
    if (!value.trim()) return
    lastValidatedAddress.current = ""
    debouncedValidation(value)
  }, [value, debouncedValidation])

  // Memoized computed values
  const validationIcon = useMemo(() => {
    if (state.isValidating) return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
    if (state.hasApiError) return <AlertTriangle className="h-4 w-4 text-orange-500" />
    if (!state.validation) return <MapPin className="h-4 w-4 text-muted-foreground" />
    if (state.validation.isValid) return <CheckCircle className="h-4 w-4 text-green-500" />
    if (state.validation.errors?.length) return <AlertCircle className="h-4 w-4 text-red-500" />
    return <AlertTriangle className="h-4 w-4 text-yellow-500" />
  }, [state.isValidating, state.hasApiError, state.validation])

  const validationColor = useMemo(() => {
    if (state.hasApiError) return "border-orange-500 focus:border-orange-500"
    if (!state.validation) return ""
    if (state.validation.isValid) return "border-green-500 focus:border-green-500"
    if (state.validation.errors?.length) return "border-red-500 focus:border-red-500"
    return "border-yellow-500 focus:border-yellow-500"
  }, [state.hasApiError, state.validation])

  const confidenceBadge = useMemo(() => {
    if (!state.validation?.isValid) return null

    const colors = {
      high: "bg-green-100 text-green-800",
      medium: "bg-yellow-100 text-yellow-800",
      low: "bg-red-100 text-red-800",
    }

    const labels = { high: "Alta", medium: "Média", low: "Baixa" }

    return (
      <Badge variant="outline" className={colors[state.validation.confidence]}>
        Confiança: {labels[state.validation.confidence]}
      </Badge>
    )
  }, [state.validation])

  const typeLabels = { pickup: "Retirada", delivery: "Entrega" }

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Label */}
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
        <Badge variant="outline" className="text-xs">
          {typeLabels[type]}
        </Badge>
      </div>

      {/* Input */}
      <div className="relative">
        <Input
          value={value}
          onChange={handleInputChange}
          placeholder={placeholder}
          className={`pr-20 ${validationColor}`}
          onFocus={() => {
            if (state.suggestions.length > 0) {
              updateState({ showSuggestions: true })
            }
          }}
        />

        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
          {validationIcon}
          {value && !state.isValidating && (
            <Button type="button" variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={handleManualValidation}>
              <RefreshCw className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Status da validação */}
      {state.validation && (
        <div className="space-y-2">
          {/* Confiança e coordenadas */}
          <div className="flex items-center gap-2">
            {confidenceBadge}
            {state.validation.coordinates && showCoordinates && (
              <Badge variant="outline" className="text-xs">
                <Navigation className="h-3 w-3 mr-1" />
                {state.validation.coordinates.lat.toFixed(4)}, {state.validation.coordinates.lng.toFixed(4)}
              </Badge>
            )}
          </div>

          {/* Avisos */}
          {state.validation.warnings?.map((warning, index) => (
            <Alert key={index} variant="default">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{warning}</AlertDescription>
            </Alert>
          ))}

          {/* Erros */}
          {state.validation.errors?.map((error, index) => (
            <Alert key={index} variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ))}

          {/* Erro de API */}
          {state.hasApiError && (
            <Alert variant="default" className="border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">
                Validação online indisponível. Usando validação básica.
              </AlertDescription>
            </Alert>
          )}

          {/* Componentes do endereço */}
          {state.validation.isValid && state.validation.components && (
            <div className="grid grid-cols-2 gap-2 text-xs bg-muted p-2 rounded">
              {state.validation.components.city && (
                <div>
                  <span className="text-muted-foreground">Cidade:</span>
                  <span className="ml-1 font-medium">{state.validation.components.city}</span>
                </div>
              )}
              {state.validation.components.state && (
                <div>
                  <span className="text-muted-foreground">Estado:</span>
                  <span className="ml-1 font-medium">{state.validation.components.state}</span>
                </div>
              )}
              {state.validation.components.neighborhood && (
                <div>
                  <span className="text-muted-foreground">Bairro:</span>
                  <span className="ml-1 font-medium">{state.validation.components.neighborhood}</span>
                </div>
              )}
              {state.validation.components.postal_code && (
                <div>
                  <span className="text-muted-foreground">CEP:</span>
                  <span className="ml-1 font-medium">{state.validation.components.postal_code}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Sugestões */}
      {state.showSuggestions && (state.suggestions.length > 0 || state.isLoadingSuggestions) && (
        <Card className="relative z-50">
          <CardContent className="p-0">
            {state.isLoadingSuggestions ? (
              <div className="p-4 text-center">
                <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Buscando sugestões...</p>
              </div>
            ) : (
              <>
                <div className="p-2 border-b bg-muted">
                  <p className="text-xs font-medium text-muted-foreground">Sugestões de endereços:</p>
                </div>
                {state.suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    type="button"
                    className="w-full text-left p-3 hover:bg-muted transition-colors border-b last:border-b-0"
                    onClick={() => handleSuggestionSelect(suggestion)}
                  >
                    <div className="flex items-start gap-2">
                      <Search className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{suggestion.address}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              suggestion.type === "exact"
                                ? "bg-green-50 text-green-700"
                                : suggestion.type === "partial"
                                  ? "bg-yellow-50 text-yellow-700"
                                  : "bg-blue-50 text-blue-700"
                            }`}
                          >
                            {suggestion.type === "exact"
                              ? "Exato"
                              : suggestion.type === "partial"
                                ? "Parcial"
                                : "Aproximado"}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {Math.round(suggestion.confidence * 100)}% compatível
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
