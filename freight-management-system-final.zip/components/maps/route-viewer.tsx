"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useGoogleMaps } from "@/hooks/use-google-maps"
import { GoogleMapsService } from "@/lib/services/google-maps"
import { MapPin, Navigation, Clock, Truck, DollarSign, Route, ExternalLink, RefreshCw, Zap } from "lucide-react"
import type { RouteInfo, OptimizedRoute } from "@/lib/services/google-maps"

interface RouteViewerProps {
  origin: string
  destination: string
  waypoints?: string[]
  vehicleType?: string
  onRouteCalculated?: (route: RouteInfo | OptimizedRoute) => void
  showOptimization?: boolean
  autoCalculate?: boolean
}

export function RouteViewer({
  origin,
  destination,
  waypoints = [],
  vehicleType = "truck",
  onRouteCalculated,
  showOptimization = true,
  autoCalculate = true,
}: RouteViewerProps) {
  const [route, setRoute] = useState<RouteInfo | null>(null)
  const [optimizedRoute, setOptimizedRoute] = useState<OptimizedRoute | null>(null)
  const [isOptimized, setIsOptimized] = useState(false)
  const [mapUrl, setMapUrl] = useState<string>("")

  const { calculateRoute, optimizeRoute, loading, error, isConfigured } = useGoogleMaps()

  useEffect(() => {
    if (autoCalculate && origin && destination && isConfigured) {
      handleCalculateRoute()
    }
  }, [origin, destination, waypoints, autoCalculate, isConfigured])

  const handleCalculateRoute = async () => {
    if (!origin || !destination) return

    try {
      const result = await calculateRoute(origin, destination, waypoints)
      if (result) {
        setRoute(result)
        setIsOptimized(false)
        onRouteCalculated?.(result)
        updateMapUrl(origin, destination, waypoints)
      }
    } catch (error) {
      console.error("Erro ao calcular rota:", error)
    }
  }

  const handleOptimizeRoute = async () => {
    if (!origin || !destination) return

    try {
      const result = await optimizeRoute(origin, destination, waypoints, vehicleType)
      if (result) {
        setOptimizedRoute(result)
        setIsOptimized(true)
        onRouteCalculated?.(result)
        updateMapUrl(origin, destination, waypoints)
      }
    } catch (error) {
      console.error("Erro ao otimizar rota:", error)
    }
  }

  const updateMapUrl = (origin: string, destination: string, waypoints: string[]) => {
    const url = GoogleMapsService.getDirectionsUrl(origin, destination, waypoints)
    setMapUrl(url)
  }

  const openInGoogleMaps = () => {
    if (mapUrl) {
      window.open(mapUrl, "_blank")
    }
  }

  const formatDistance = (meters: number): string => {
    if (meters < 1000) {
      return `${meters} m`
    }
    return `${(meters / 1000).toFixed(1)} km`
  }

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)

    if (hours > 0) {
      return `${hours}h ${minutes}min`
    }
    return `${minutes}min`
  }

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const currentRoute = isOptimized ? optimizedRoute : route
  const routeInfo = isOptimized && optimizedRoute ? optimizedRoute.routes[0] : route

  if (!isConfigured) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Google Maps não configurado</h3>
          <p className="text-muted-foreground">
            Configure a API do Google Maps para visualizar rotas e calcular distâncias.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Route Controls */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Route className="h-5 w-5" />
              Planejamento de Rota
            </CardTitle>
            <div className="flex items-center gap-2">
              {isOptimized && (
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  <Zap className="h-3 w-3 mr-1" />
                  Otimizada
                </Badge>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={handleCalculateRoute}
                disabled={loading || !origin || !destination}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
                Recalcular
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Route Points */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-sm font-medium">Origem:</span>
              <span className="text-sm text-muted-foreground">{origin}</span>
            </div>

            {waypoints.map((waypoint, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-sm font-medium">Parada {index + 1}:</span>
                <span className="text-sm text-muted-foreground">{waypoint}</span>
              </div>
            ))}

            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-sm font-medium">Destino:</span>
              <span className="text-sm text-muted-foreground">{destination}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            {showOptimization && waypoints.length > 0 && (
              <Button variant="outline" size="sm" onClick={handleOptimizeRoute} disabled={loading}>
                <Zap className="h-4 w-4 mr-2" />
                Otimizar Rota
              </Button>
            )}

            {mapUrl && (
              <Button variant="outline" size="sm" onClick={openInGoogleMaps}>
                <ExternalLink className="h-4 w-4 mr-2" />
                Abrir no Maps
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Route Information */}
      {routeInfo && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5" />
              Informações da Rota
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Truck className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Distância</span>
                </div>
                <p className="text-lg font-bold text-blue-600">{formatDistance(routeInfo.distance.value)}</p>
              </div>

              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Tempo</span>
                </div>
                <p className="text-lg font-bold text-green-600">{formatDuration(routeInfo.duration.value)}</p>
              </div>

              {isOptimized && optimizedRoute && (
                <>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Custo Est.</span>
                    </div>
                    <p className="text-lg font-bold text-purple-600">{formatCurrency(optimizedRoute.estimated_cost)}</p>
                  </div>

                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Zap className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Economia</span>
                    </div>
                    <p className="text-lg font-bold text-orange-600">
                      {waypoints.length > 0 ? `${Math.round(waypoints.length * 0.15 * 100)}%` : "0%"}
                    </p>
                  </div>
                </>
              )}
            </div>

            {/* Route Steps Preview */}
            {routeInfo.steps && routeInfo.steps.length > 0 && (
              <>
                <Separator className="my-4" />
                <div>
                  <h4 className="text-sm font-medium mb-2">Principais Direções:</h4>
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {routeInfo.steps.slice(0, 5).map((step, index) => (
                      <div key={index} className="flex items-start gap-2 text-xs">
                        <span className="bg-muted text-muted-foreground rounded-full w-5 h-5 flex items-center justify-center shrink-0 mt-0.5">
                          {index + 1}
                        </span>
                        <div className="flex-1">
                          <p dangerouslySetInnerHTML={{ __html: step.html_instructions }} />
                          <p className="text-muted-foreground">
                            {formatDistance(step.distance.value)} • {formatDuration(step.duration.value)}
                          </p>
                        </div>
                      </div>
                    ))}
                    {routeInfo.steps.length > 5 && (
                      <p className="text-xs text-muted-foreground text-center">
                        +{routeInfo.steps.length - 5} direções adicionais
                      </p>
                    )}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {loading && (
        <Card>
          <CardContent className="p-6 text-center">
            <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Calculando rota...</p>
          </CardContent>
        </Card>
      )}

      {/* Error State */}
      {error && (
        <Card className="border-red-200">
          <CardContent className="p-6 text-center">
            <div className="text-red-500 mb-2">⚠️</div>
            <p className="text-red-600 font-medium mb-2">Erro ao calcular rota</p>
            <p className="text-sm text-muted-foreground">{error}</p>
            <Button variant="outline" size="sm" onClick={handleCalculateRoute} className="mt-4">
              Tentar Novamente
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
