"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Star } from "lucide-react"

interface CustomerRatingProps {
  onSubmit: (rating: number, comment: string) => void
  onSkip: () => void
}

export function CustomerRating({ onSubmit, onSkip }: CustomerRatingProps) {
  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState("")
  const [hoveredRating, setHoveredRating] = useState(0)

  const handleSubmit = () => {
    onSubmit(rating, comment)
  }

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3 className="text-lg font-medium mb-2">Como foi o atendimento?</h3>
        <p className="text-sm text-muted-foreground mb-4">Sua avaliação nos ajuda a melhorar nossos serviços</p>
      </div>

      <div className="flex justify-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            className="p-1"
            onMouseEnter={() => setHoveredRating(star)}
            onMouseLeave={() => setHoveredRating(0)}
            onClick={() => setRating(star)}
          >
            <Star
              className={`h-8 w-8 ${
                star <= (hoveredRating || rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
              }`}
            />
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <label htmlFor="comment" className="text-sm font-medium">
          Comentário (opcional)
        </label>
        <Textarea
          id="comment"
          placeholder="Deixe um comentário sobre o atendimento..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          rows={3}
        />
      </div>

      <div className="flex gap-2">
        <Button variant="outline" onClick={onSkip} className="flex-1">
          Pular
        </Button>
        <Button onClick={handleSubmit} disabled={rating === 0} className="flex-1">
          Finalizar
        </Button>
      </div>
    </div>
  )
}
