"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  User,
  Building2,
  Phone,
  Mail,
  MapPin,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Calendar,
  FileText,
} from "lucide-react"
import type { Cliente } from "@/lib/types/database"

interface ClientCardProps {
  cliente: Cliente
  viewMode: "grid" | "list"
  onView: () => void
  onEdit: () => void
  onDelete: () => void
}

export function ClientCard({ cliente, viewMode, onView, onEdit, onDelete }: ClientCardProps) {
  const isCompany = cliente.documento && cliente.documento.replace(/\D/g, "").length === 14
  const hasEmail = Boolean(cliente.email)
  const hasAddress = Boolean(cliente.endereco)

  if (viewMode === "list") {
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 flex-1">
              <div className="flex-shrink-0">
                <div className={`p-2 rounded-lg ${isCompany ? "bg-blue-100" : "bg-green-100"}`}>
                  {isCompany ? (
                    <Building2 className={`h-5 w-5 ${isCompany ? "text-blue-600" : "text-green-600"}`} />
                  ) : (
                    <User className={`h-5 w-5 ${isCompany ? "text-blue-600" : "text-green-600"}`} />
                  )}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold truncate">{cliente.nome}</h3>
                  <Badge variant={isCompany ? "default" : "secondary"} className="text-xs">
                    {isCompany ? "PJ" : "PF"}
                  </Badge>
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    <span>{cliente.telefone}</span>
                  </div>
                  {hasEmail && (
                    <div className="flex items-center gap-1">
                      <Mail className="h-3 w-3" />
                      <span className="truncate max-w-[200px]">{cliente.email}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    <span>{new Date(cliente.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={onView}>
                <Eye className="h-4 w-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={onView}>
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Detalhes
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onEdit}>
                    <Edit className="h-4 w-4 mr-2" />
                    Editar
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onDelete} className="text-red-600">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Excluir
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={onView}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${isCompany ? "bg-blue-100" : "bg-green-100"}`}>
              {isCompany ? (
                <Building2 className={`h-5 w-5 ${isCompany ? "text-blue-600" : "text-green-600"}`} />
              ) : (
                <User className={`h-5 w-5 ${isCompany ? "text-blue-600" : "text-green-600"}`} />
              )}
            </div>
            <div>
              <h3 className="font-semibold text-lg leading-tight">{cliente.nome}</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant={isCompany ? "default" : "secondary"}>
                  {isCompany ? "Pessoa Jurídica" : "Pessoa Física"}
                </Badge>
              </div>
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onView()
                }}
              >
                <Eye className="h-4 w-4 mr-2" />
                Ver Detalhes
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onEdit()
                }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onDelete()
                }}
                className="text-red-600"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span>{cliente.telefone}</span>
          </div>

          {hasEmail && (
            <div className="flex items-center gap-2 text-sm">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <span className="truncate">{cliente.email}</span>
            </div>
          )}

          {cliente.documento && (
            <div className="flex items-center gap-2 text-sm">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span>{cliente.documento}</span>
            </div>
          )}

          {hasAddress && (
            <div className="flex items-start gap-2 text-sm">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
              <span className="line-clamp-2">{cliente.endereco}</span>
            </div>
          )}
        </div>

        <div className="pt-2 border-t">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Cadastrado em {new Date(cliente.created_at).toLocaleDateString()}</span>
            {cliente.updated_at !== cliente.created_at && (
              <span>Atualizado em {new Date(cliente.updated_at).toLocaleDateString()}</span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
