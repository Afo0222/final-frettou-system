"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { User, Building2, Phone, Mail, FileText, MapPin, MessageSquare } from "lucide-react"
import { ClienteService } from "@/lib/services/clientes"
import { NotificationService } from "@/lib/services/notifications"
import type { Cliente } from "@/lib/types/database"

interface QuickClientModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onClientCreated: (cliente: Cliente) => void
  initialData?: {
    nome?: string
    telefone?: string
    email?: string
    documento?: string
    endereco?: string
  }
}

export function QuickClientModal({ open, onOpenChange, onClientCreated, initialData }: QuickClientModalProps) {
  const [formData, setFormData] = useState({
    nome: initialData?.nome || "",
    telefone: initialData?.telefone || "",
    email: initialData?.email || "",
    documento: initialData?.documento || "",
    endereco: initialData?.endereco || "",
    observacoes: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.nome.trim()) {
      newErrors.nome = "Nome e obrigatorio"
    }

    if (!formData.telefone.trim()) {
      newErrors.telefone = "Telefone e obrigatorio"
    } else {
      const numbersOnly = formData.telefone.replace(/\D/g, "")
      if (numbersOnly.length < 10 || numbersOnly.length > 11) {
        newErrors.telefone = "Telefone deve ter 10 ou 11 digitos"
      }
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Email invalido"
    }

    if (formData.documento) {
      const doc = formData.documento.replace(/\D/g, "")
      if (doc.length === 11) {
        if (!/^\d{11}$/.test(doc) || /^(\d)\1{10}$/.test(doc)) {
          newErrors.documento = "CPF invalido"
        }
      } else if (doc.length === 14) {
        if (!/^\d{14}$/.test(doc)) {
          newErrors.documento = "CNPJ invalido"
        }
      } else if (doc.length > 0) {
        newErrors.documento = "Documento deve ter 11 (CPF) ou 14 (CNPJ) digitos"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    const limitedNumbers = numbers.slice(0, 11)

    if (limitedNumbers.length <= 2) {
      return limitedNumbers
    } else if (limitedNumbers.length <= 6) {
      return `(${limitedNumbers.slice(0, 2)}) ${limitedNumbers.slice(2)}`
    } else if (limitedNumbers.length <= 10) {
      return `(${limitedNumbers.slice(0, 2)}) ${limitedNumbers.slice(2, 6)}-${limitedNumbers.slice(6)}`
    } else {
      return `(${limitedNumbers.slice(0, 2)}) ${limitedNumbers.slice(2, 7)}-${limitedNumbers.slice(7)}`
    }
  }

  const formatDocument = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    if (numbers.length <= 11) {
      if (numbers.length <= 3) return numbers
      if (numbers.length <= 6) return `${numbers.slice(0, 3)}.${numbers.slice(3)}`
      if (numbers.length <= 9) return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6)}`
      return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6, 9)}-${numbers.slice(9, 11)}`
    } else {
      const limitedNumbers = numbers.slice(0, 14)
      if (limitedNumbers.length <= 2) return limitedNumbers
      if (limitedNumbers.length <= 5) return `${limitedNumbers.slice(0, 2)}.${limitedNumbers.slice(2)}`
      if (limitedNumbers.length <= 8)
        return `${limitedNumbers.slice(0, 2)}.${limitedNumbers.slice(2, 5)}.${limitedNumbers.slice(5)}`
      if (limitedNumbers.length <= 12)
        return `${limitedNumbers.slice(0, 2)}.${limitedNumbers.slice(2, 5)}.${limitedNumbers.slice(5, 8)}/${limitedNumbers.slice(8)}`
      return `${limitedNumbers.slice(0, 2)}.${limitedNumbers.slice(2, 5)}.${limitedNumbers.slice(5, 8)}/${limitedNumbers.slice(8, 12)}-${limitedNumbers.slice(12)}`
    }
  }

  const handleInputChange = (field: string, value: string) => {
    let formattedValue = value

    if (field === "telefone") {
      formattedValue = formatPhone(value)
    } else if (field === "documento") {
      formattedValue = formatDocument(value)
    }

    setFormData((prev) => ({ ...prev, [field]: formattedValue }))

    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)
    try {
      const novoCliente = await ClienteService.create(formData)
      NotificationService.success("Cliente criado", "Cliente adicionado com sucesso!")
      onClientCreated(novoCliente)
      onOpenChange(false)

      setFormData({
        nome: "",
        telefone: "",
        email: "",
        documento: "",
        endereco: "",
        observacoes: "",
      })
      setErrors({})
    } catch (error) {
      console.error("Erro ao criar cliente:", error)
      NotificationService.error("Erro", "Falha ao criar cliente. Tente novamente.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const isCompany = formData.documento && formData.documento.replace(/\D/g, "").length === 14

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isCompany ? <Building2 className="h-5 w-5" /> : <User className="h-5 w-5" />}
            Adicionar Novo Cliente
          </DialogTitle>
          <DialogDescription>
            Preencha os dados basicos do cliente para adiciona-lo rapidamente ao sistema.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="nome">Nome / Razao Social *</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => handleInputChange("nome", e.target.value)}
                placeholder={isCompany ? "Razao social da empresa" : "Nome completo"}
                className={errors.nome ? "border-red-500" : ""}
              />
              {errors.nome && <p className="text-sm text-red-500">{errors.nome}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="telefone">Telefone *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  id="telefone"
                  value={formData.telefone}
                  onChange={(e) => handleInputChange("telefone", e.target.value)}
                  placeholder="(11) 99999-9999"
                  className={`pl-10 ${errors.telefone ? "border-red-500" : ""}`}
                  maxLength={15}
                />
              </div>
              {errors.telefone && <p className="text-sm text-red-500">{errors.telefone}</p>}
              <p className="text-xs text-muted-foreground">Aceita telefone fixo (8 digitos) ou celular (9 digitos)</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="email@exemplo.com"
                  className={`pl-10 ${errors.email ? "border-red-500" : ""}`}
                />
              </div>
              {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="documento">CPF / CNPJ</Label>
              <div className="relative">
                <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  id="documento"
                  value={formData.documento}
                  onChange={(e) => handleInputChange("documento", e.target.value)}
                  placeholder="000.000.000-00 ou 00.000.000/0000-00"
                  className={`pl-10 ${errors.documento ? "border-red-500" : ""}`}
                  maxLength={18}
                />
              </div>
              {errors.documento && <p className="text-sm text-red-500">{errors.documento}</p>}
              {formData.documento && (
                <div className="flex items-center gap-2">
                  <Badge variant={isCompany ? "default" : "secondary"}>
                    {isCompany ? "Pessoa Juridica" : "Pessoa Fisica"}
                  </Badge>
                </div>
              )}
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="endereco">Endereco Completo</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 text-muted-foreground h-4 w-4" />
                <Textarea
                  id="endereco"
                  value={formData.endereco}
                  onChange={(e) => handleInputChange("endereco", e.target.value)}
                  placeholder="Rua, numero, bairro, cidade, estado, CEP"
                  className="pl-10 min-h-[60px]"
                  rows={2}
                />
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="observacoes">Observacoes</Label>
              <div className="relative">
                <MessageSquare className="absolute left-3 top-3 text-muted-foreground h-4 w-4" />
                <Textarea
                  id="observacoes"
                  value={formData.observacoes}
                  onChange={(e) => handleInputChange("observacoes", e.target.value)}
                  placeholder="Informacoes adicionais sobre o cliente..."
                  className="pl-10 min-h-[60px]"
                  rows={2}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Salvando..." : "Criar Cliente"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
