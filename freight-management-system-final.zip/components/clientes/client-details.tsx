"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  User,
  Building2,
  Phone,
  Mail,
  MapPin,
  FileText,
  Calendar,
  Edit,
  MessageSquare,
  Clock,
  TrendingUp,
  Package,
} from "lucide-react"
import type { Cliente } from "@/lib/types/database"

interface ClientDetailsProps {
  cliente: Cliente | null
  onEdit: () => void
  onClose: () => void
}

export function ClientDetails({ cliente, onEdit, onClose }: ClientDetailsProps) {
  // Verificação de segurança - não renderizar se cliente for null
  if (!cliente) {
    return null
  }

  const isCompany = cliente.documento && cliente.documento.replace(/\D/g, "").length === 14
  const hasEmail = Boolean(cliente.email)
  const hasAddress = Boolean(cliente.endereco)
  const hasObservations = Boolean(cliente.observacoes)

  // Mock data for client statistics (would come from database in real implementation)
  const clientStats = {
    totalOrcamentos: 12,
    orcamentosAprovados: 8,
    valorTotal: 45600.0,
    ultimoOrcamento: "2024-01-25",
    servicosFavoritos: ["Mudança Residencial", "Transporte de Móveis"],
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="details" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="details">Detalhes</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
          <TabsTrigger value="stats">Estatísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${isCompany ? "bg-blue-100" : "bg-green-100"}`}>
                    {isCompany ? (
                      <Building2 className={`h-6 w-6 ${isCompany ? "text-blue-600" : "text-green-600"}`} />
                    ) : (
                      <User className={`h-6 w-6 ${isCompany ? "text-blue-600" : "text-green-600"}`} />
                    )}
                  </div>
                  <div>
                    <CardTitle className="text-xl">{cliente.nome}</CardTitle>
                    <CardDescription>
                      <Badge variant={isCompany ? "default" : "secondary"} className="mt-1">
                        {isCompany ? "Pessoa Jurídica" : "Pessoa Física"}
                      </Badge>
                    </CardDescription>
                  </div>
                </div>
                <Button onClick={onEdit}>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Telefone</p>
                      <p className="text-sm text-muted-foreground">{cliente.telefone}</p>
                    </div>
                  </div>

                  {hasEmail && (
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Email</p>
                        <p className="text-sm text-muted-foreground">{cliente.email}</p>
                      </div>
                    </div>
                  )}

                  {cliente.documento && (
                    <div className="flex items-center gap-3">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">{isCompany ? "CNPJ" : "CPF"}</p>
                        <p className="text-sm text-muted-foreground">{cliente.documento}</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Data de Cadastro</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(cliente.created_at).toLocaleDateString("pt-BR", {
                          day: "2-digit",
                          month: "2-digit",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                  </div>

                  {cliente.updated_at !== cliente.created_at && (
                    <div className="flex items-center gap-3">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Última Atualização</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(cliente.updated_at).toLocaleDateString("pt-BR", {
                            day: "2-digit",
                            month: "2-digit",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Address */}
          {hasAddress && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Endereço
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{cliente.endereco}</p>
              </CardContent>
            </Card>
          )}

          {/* Observations */}
          {hasObservations && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Observações
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm whitespace-pre-wrap">{cliente.observacoes}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Orçamentos</CardTitle>
              <CardDescription>Últimos orçamentos solicitados por este cliente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Mudança Residencial</p>
                    <p className="text-sm text-muted-foreground">25/01/2024 - Aprovado</p>
                  </div>
                  <Badge variant="default">R$ 1.200,00</Badge>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Transporte de Móveis</p>
                    <p className="text-sm text-muted-foreground">20/01/2024 - Concluído</p>
                  </div>
                  <Badge variant="secondary">R$ 800,00</Badge>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Entrega de Eletrodomésticos</p>
                    <p className="text-sm text-muted-foreground">15/01/2024 - Concluído</p>
                  </div>
                  <Badge variant="secondary">R$ 350,00</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Orçamentos</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{clientStats.totalOrcamentos}</div>
                <p className="text-xs text-muted-foreground">{clientStats.orcamentosAprovados} aprovados</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {clientStats.valorTotal.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </div>
                <p className="text-xs text-muted-foreground">Em orçamentos aprovados</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Serviços Mais Solicitados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {clientStats.servicosFavoritos.map((servico, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm">{servico}</span>
                    <Badge variant="outline">{Math.floor(Math.random() * 5) + 1}x</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Separator />

      <div className="flex justify-end">
        <Button variant="outline" onClick={onClose}>
          Fechar
        </Button>
      </div>
    </div>
  )
}
