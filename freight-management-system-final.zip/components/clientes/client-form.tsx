"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { User, Building2, Phone, Mail, MapPin, FileText, MessageSquare } from "lucide-react"
import type { Cliente } from "@/lib/types/database"

interface ClienteFormProps {
  cliente?: Cliente | null
  onSubmit: (data: Omit<Cliente, "id" | "created_at" | "updated_at">) => void
  onCancel: () => void
}

export function ClienteForm({ cliente, onSubmit, onCancel }: ClienteFormProps) {
  const [formData, setFormData] = useState({
    nome: "",
    telefone: "",
    email: "",
    documento: "",
    endereco: "",
    observacoes: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (cliente) {
      setFormData({
        nome: cliente.nome || "",
        telefone: cliente.telefone || "",
        email: cliente.email || "",
        documento: cliente.documento || "",
        endereco: cliente.endereco || "",
        observacoes: cliente.observacoes || "",
      })
    }
  }, [cliente])

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.nome.trim()) {
      newErrors.nome = "Nome é obrigatório"
    }

    if (!formData.telefone.trim()) {
      newErrors.telefone = "Telefone é obrigatório"
    } else if (!/^$$\d{2}$$\s\d{4,5}-\d{4}$/.test(formData.telefone)) {
      newErrors.telefone = "Formato inválido. Use: (11) 99999-9999"
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Email inválido"
    }

    if (formData.documento) {
      const doc = formData.documento.replace(/\D/g, "")
      if (doc.length === 11) {
        // Validação básica de CPF
        if (!/^\d{11}$/.test(doc) || /^(\d)\1{10}$/.test(doc)) {
          newErrors.documento = "CPF inválido"
        }
      } else if (doc.length === 14) {
        // Validação básica de CNPJ
        if (!/^\d{14}$/.test(doc)) {
          newErrors.documento = "CNPJ inválido"
        }
      } else {
        newErrors.documento = "Documento deve ter 11 (CPF) ou 14 (CNPJ) dígitos"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    if (numbers.length <= 10) {
      return numbers.replace(/(\d{2})(\d{4})(\d{4})/, "($1) $2-$3")
    } else {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
    }
  }

  const formatDocument = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
    } else {
      return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5")
    }
  }

  const handleInputChange = (field: string, value: string) => {
    let formattedValue = value

    if (field === "telefone") {
      formattedValue = formatPhone(value)
    } else if (field === "documento") {
      formattedValue = formatDocument(value)
    }

    setFormData((prev) => ({ ...prev, [field]: formattedValue }))

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)
    try {
      await onSubmit(formData)
    } catch (error) {
      console.error("Erro ao salvar cliente:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const isCompany = formData.documento && formData.documento.replace(/\D/g, "").length === 14

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="basic">Dados Básicos</TabsTrigger>
          <TabsTrigger value="additional">Informações Adicionais</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {isCompany ? <Building2 className="h-5 w-5" /> : <User className="h-5 w-5" />}
                Identificação
              </CardTitle>
              <CardDescription>Informações básicas do cliente</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome / Razão Social *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => handleInputChange("nome", e.target.value)}
                  placeholder={isCompany ? "Razão social da empresa" : "Nome completo"}
                  className={errors.nome ? "border-red-500" : ""}
                />
                {errors.nome && <p className="text-sm text-red-500">{errors.nome}</p>}
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone *</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="telefone"
                      value={formData.telefone}
                      onChange={(e) => handleInputChange("telefone", e.target.value)}
                      placeholder="(11) 99999-9999"
                      className={`pl-10 ${errors.telefone ? "border-red-500" : ""}`}
                      maxLength={15}
                    />
                  </div>
                  {errors.telefone && <p className="text-sm text-red-500">{errors.telefone}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="email@exemplo.com"
                      className={`pl-10 ${errors.email ? "border-red-500" : ""}`}
                    />
                  </div>
                  {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="documento">CPF / CNPJ</Label>
                <div className="relative">
                  <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="documento"
                    value={formData.documento}
                    onChange={(e) => handleInputChange("documento", e.target.value)}
                    placeholder="000.000.000-00 ou 00.000.000/0000-00"
                    className={`pl-10 ${errors.documento ? "border-red-500" : ""}`}
                    maxLength={18}
                  />
                </div>
                {errors.documento && <p className="text-sm text-red-500">{errors.documento}</p>}
                {formData.documento && (
                  <div className="flex items-center gap-2">
                    <Badge variant={isCompany ? "default" : "secondary"}>
                      {isCompany ? "Pessoa Jurídica" : "Pessoa Física"}
                    </Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="additional" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Endereço e Observações
              </CardTitle>
              <CardDescription>Informações complementares do cliente</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="endereco">Endereço Completo</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 text-muted-foreground h-4 w-4" />
                  <Textarea
                    id="endereco"
                    value={formData.endereco}
                    onChange={(e) => handleInputChange("endereco", e.target.value)}
                    placeholder="Rua, número, bairro, cidade, estado, CEP"
                    className="pl-10 min-h-[80px]"
                    rows={3}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <div className="relative">
                  <MessageSquare className="absolute left-3 top-3 text-muted-foreground h-4 w-4" />
                  <Textarea
                    id="observacoes"
                    value={formData.observacoes}
                    onChange={(e) => handleInputChange("observacoes", e.target.value)}
                    placeholder="Informações adicionais sobre o cliente..."
                    className="pl-10 min-h-[100px]"
                    rows={4}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Separator />

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Salvando..." : cliente ? "Atualizar" : "Criar Cliente"}
        </Button>
      </div>
    </form>
  )
}
