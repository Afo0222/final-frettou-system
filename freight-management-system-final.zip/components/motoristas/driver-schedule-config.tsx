"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, Calendar, Settings, Plus, Trash2, Coffee, Sun, AlertTriangle, Save, RotateCcw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface DriverScheduleConfig {
  id: string
  motorista_id: string
  // Working hours
  working_hours: {
    monday: { enabled: boolean; start: string; end: string }
    tuesday: { enabled: boolean; start: string; end: string }
    wednesday: { enabled: boolean; start: string; end: string }
    thursday: { enabled: boolean; start: string; end: string }
    friday: { enabled: boolean; start: string; end: string }
    saturday: { enabled: boolean; start: string; end: string }
    sunday: { enabled: boolean; start: string; end: string }
  }
  // Break times
  break_times: Array<{
    id: string
    name: string
    start: string
    end: string
    days: string[]
    mandatory: boolean
  }>
  // Scheduling constraints
  constraints: {
    max_appointments_per_day: number
    min_time_between_appointments: number // minutes
    max_working_hours_per_day: number
    allow_overtime: boolean
    overtime_rate_multiplier: number
    travel_time_buffer: number // minutes
  }
  // Availability exceptions
  exceptions: Array<{
    id: string
    date: string
    type: "unavailable" | "custom_hours" | "holiday"
    start_time?: string
    end_time?: string
    reason: string
  }>
  created_at: string
  updated_at: string
}

interface DriverScheduleConfigProps {
  motorista: any
  onConfigUpdated: () => void
}

const defaultWorkingHours = {
  monday: { enabled: true, start: "08:00", end: "18:00" },
  tuesday: { enabled: true, start: "08:00", end: "18:00" },
  wednesday: { enabled: true, start: "08:00", end: "18:00" },
  thursday: { enabled: true, start: "08:00", end: "18:00" },
  friday: { enabled: true, start: "08:00", end: "18:00" },
  saturday: { enabled: false, start: "08:00", end: "12:00" },
  sunday: { enabled: false, start: "08:00", end: "12:00" },
}

const defaultConstraints = {
  max_appointments_per_day: 8,
  min_time_between_appointments: 30,
  max_working_hours_per_day: 10,
  allow_overtime: false,
  overtime_rate_multiplier: 1.5,
  travel_time_buffer: 15,
}

export function DriverScheduleConfig({ motorista, onConfigUpdated }: DriverScheduleConfigProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [config, setConfig] = useState<DriverScheduleConfig | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (isOpen) {
      loadConfig()
    }
  }, [isOpen, motorista.id])

  const loadConfig = async () => {
    try {
      setIsLoading(true)
      // In a real implementation, you would load from your database
      // For now, we'll create a default config
      const defaultConfig: DriverScheduleConfig = {
        id: `config-${motorista.id}`,
        motorista_id: motorista.id,
        working_hours: defaultWorkingHours,
        break_times: [
          {
            id: "lunch",
            name: "Almoço",
            start: "12:00",
            end: "13:00",
            days: ["monday", "tuesday", "wednesday", "thursday", "friday"],
            mandatory: true,
          },
        ],
        constraints: defaultConstraints,
        exceptions: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      setConfig(defaultConfig)
    } catch (error) {
      console.error("Erro ao carregar configuração:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar a configuração",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const saveConfig = async () => {
    if (!config) return

    try {
      setIsSaving(true)
      // In a real implementation, you would save to your database
      console.log("Salvando configuração:", config)

      toast({
        title: "Sucesso",
        description: "Configuração de horários salva com sucesso!",
      })

      onConfigUpdated()
      setIsOpen(false)
    } catch (error) {
      console.error("Erro ao salvar configuração:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar a configuração",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const updateWorkingHours = (day: string, field: string, value: any) => {
    if (!config) return
    setConfig({
      ...config,
      working_hours: {
        ...config.working_hours,
        [day]: {
          ...config.working_hours[day as keyof typeof config.working_hours],
          [field]: value,
        },
      },
    })
  }

  const updateConstraints = (field: string, value: any) => {
    if (!config) return
    setConfig({
      ...config,
      constraints: {
        ...config.constraints,
        [field]: value,
      },
    })
  }

  const addBreakTime = () => {
    if (!config) return
    const newBreak = {
      id: `break-${Date.now()}`,
      name: "Nova Pausa",
      start: "15:00",
      end: "15:15",
      days: ["monday", "tuesday", "wednesday", "thursday", "friday"],
      mandatory: false,
    }
    setConfig({
      ...config,
      break_times: [...config.break_times, newBreak],
    })
  }

  const updateBreakTime = (breakId: string, field: string, value: any) => {
    if (!config) return
    setConfig({
      ...config,
      break_times: config.break_times.map((breakTime) =>
        breakTime.id === breakId ? { ...breakTime, [field]: value } : breakTime,
      ),
    })
  }

  const removeBreakTime = (breakId: string) => {
    if (!config) return
    setConfig({
      ...config,
      break_times: config.break_times.filter((breakTime) => breakTime.id !== breakId),
    })
  }

  const addException = () => {
    if (!config) return
    const newException = {
      id: `exception-${Date.now()}`,
      date: new Date().toISOString().split("T")[0],
      type: "unavailable" as const,
      reason: "",
    }
    setConfig({
      ...config,
      exceptions: [...config.exceptions, newException],
    })
  }

  const updateException = (exceptionId: string, field: string, value: any) => {
    if (!config) return
    setConfig({
      ...config,
      exceptions: config.exceptions.map((exception) =>
        exception.id === exceptionId ? { ...exception, [field]: value } : exception,
      ),
    })
  }

  const removeException = (exceptionId: string) => {
    if (!config) return
    setConfig({
      ...config,
      exceptions: config.exceptions.filter((exception) => exception.id !== exceptionId),
    })
  }

  const resetToDefaults = () => {
    if (!config) return
    setConfig({
      ...config,
      working_hours: defaultWorkingHours,
      constraints: defaultConstraints,
      break_times: [
        {
          id: "lunch",
          name: "Almoço",
          start: "12:00",
          end: "13:00",
          days: ["monday", "tuesday", "wednesday", "thursday", "friday"],
          mandatory: true,
        },
      ],
    })
  }

  const dayNames = {
    monday: "Segunda",
    tuesday: "Terça",
    wednesday: "Quarta",
    thursday: "Quinta",
    friday: "Sexta",
    saturday: "Sábado",
    sunday: "Domingo",
  }

  if (!config) return null

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Settings className="mr-2 h-4 w-4" />
          Configurar Horários
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Configuração de Horários - {motorista.nome}
          </DialogTitle>
          <DialogDescription>
            Configure os horários de trabalho, pausas e restrições de agendamento para este motorista
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <Tabs defaultValue="working-hours" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="working-hours">Horários</TabsTrigger>
              <TabsTrigger value="breaks">Pausas</TabsTrigger>
              <TabsTrigger value="constraints">Restrições</TabsTrigger>
              <TabsTrigger value="exceptions">Exceções</TabsTrigger>
            </TabsList>

            {/* Working Hours Tab */}
            <TabsContent value="working-hours" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sun className="h-5 w-5" />
                    Horários de Trabalho
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(config.working_hours).map(([day, hours]) => (
                    <div key={day} className="flex items-center gap-4 p-3 border rounded-lg">
                      <div className="w-20">
                        <Label className="text-sm font-medium">{dayNames[day as keyof typeof dayNames]}</Label>
                      </div>
                      <Switch
                        checked={hours.enabled}
                        onCheckedChange={(checked) => updateWorkingHours(day, "enabled", checked)}
                      />
                      {hours.enabled && (
                        <>
                          <div className="flex items-center gap-2">
                            <Label className="text-sm">Início:</Label>
                            <Input
                              type="time"
                              value={hours.start}
                              onChange={(e) => updateWorkingHours(day, "start", e.target.value)}
                              className="w-32"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Label className="text-sm">Fim:</Label>
                            <Input
                              type="time"
                              value={hours.end}
                              onChange={(e) => updateWorkingHours(day, "end", e.target.value)}
                              className="w-32"
                            />
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Break Times Tab */}
            <TabsContent value="breaks" className="space-y-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Coffee className="h-5 w-5" />
                    Horários de Pausa
                  </CardTitle>
                  <Button onClick={addBreakTime} size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Pausa
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {config.break_times.map((breakTime) => (
                    <div key={breakTime.id} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Input
                          value={breakTime.name}
                          onChange={(e) => updateBreakTime(breakTime.id, "name", e.target.value)}
                          className="font-medium"
                          placeholder="Nome da pausa"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeBreakTime(breakTime.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label className="text-sm">Início</Label>
                          <Input
                            type="time"
                            value={breakTime.start}
                            onChange={(e) => updateBreakTime(breakTime.id, "start", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Fim</Label>
                          <Input
                            type="time"
                            value={breakTime.end}
                            onChange={(e) => updateBreakTime(breakTime.id, "end", e.target.value)}
                          />
                        </div>
                        <div className="flex items-center gap-2 pt-6">
                          <Switch
                            checked={breakTime.mandatory}
                            onCheckedChange={(checked) => updateBreakTime(breakTime.id, "mandatory", checked)}
                          />
                          <Label className="text-sm">Obrigatória</Label>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Constraints Tab */}
            <TabsContent value="constraints" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Restrições de Agendamento
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Máximo de agendamentos por dia</Label>
                      <Input
                        type="number"
                        value={config.constraints.max_appointments_per_day}
                        onChange={(e) => updateConstraints("max_appointments_per_day", Number.parseInt(e.target.value))}
                        min="1"
                        max="20"
                      />
                    </div>
                    <div>
                      <Label>Tempo mínimo entre agendamentos (minutos)</Label>
                      <Input
                        type="number"
                        value={config.constraints.min_time_between_appointments}
                        onChange={(e) =>
                          updateConstraints("min_time_between_appointments", Number.parseInt(e.target.value))
                        }
                        min="0"
                        max="120"
                      />
                    </div>
                    <div>
                      <Label>Máximo de horas de trabalho por dia</Label>
                      <Input
                        type="number"
                        value={config.constraints.max_working_hours_per_day}
                        onChange={(e) =>
                          updateConstraints("max_working_hours_per_day", Number.parseInt(e.target.value))
                        }
                        min="1"
                        max="16"
                      />
                    </div>
                    <div>
                      <Label>Buffer de tempo de viagem (minutos)</Label>
                      <Input
                        type="number"
                        value={config.constraints.travel_time_buffer}
                        onChange={(e) => updateConstraints("travel_time_buffer", Number.parseInt(e.target.value))}
                        min="0"
                        max="60"
                      />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={config.constraints.allow_overtime}
                        onCheckedChange={(checked) => updateConstraints("allow_overtime", checked)}
                      />
                      <Label>Permitir horas extras</Label>
                    </div>
                    {config.constraints.allow_overtime && (
                      <div>
                        <Label>Multiplicador de hora extra</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={config.constraints.overtime_rate_multiplier}
                          onChange={(e) =>
                            updateConstraints("overtime_rate_multiplier", Number.parseFloat(e.target.value))
                          }
                          min="1"
                          max="3"
                        />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Exceptions Tab */}
            <TabsContent value="exceptions" className="space-y-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Exceções de Disponibilidade
                  </CardTitle>
                  <Button onClick={addException} size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Exceção
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {config.exceptions.map((exception) => (
                    <div key={exception.id} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="grid grid-cols-3 gap-4 flex-1">
                          <div>
                            <Label className="text-sm">Data</Label>
                            <Input
                              type="date"
                              value={exception.date}
                              onChange={(e) => updateException(exception.id, "date", e.target.value)}
                            />
                          </div>
                          <div>
                            <Label className="text-sm">Tipo</Label>
                            <Select
                              value={exception.type}
                              onValueChange={(value) => updateException(exception.id, "type", value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="unavailable">Indisponível</SelectItem>
                                <SelectItem value="custom_hours">Horário Personalizado</SelectItem>
                                <SelectItem value="holiday">Feriado</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-sm">Motivo</Label>
                            <Input
                              value={exception.reason}
                              onChange={(e) => updateException(exception.id, "reason", e.target.value)}
                              placeholder="Motivo da exceção"
                            />
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeException(exception.id)}
                          className="text-red-600 ml-4"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      {exception.type === "custom_hours" && (
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label className="text-sm">Início</Label>
                            <Input
                              type="time"
                              value={exception.start_time || ""}
                              onChange={(e) => updateException(exception.id, "start_time", e.target.value)}
                            />
                          </div>
                          <div>
                            <Label className="text-sm">Fim</Label>
                            <Input
                              type="time"
                              value={exception.end_time || ""}
                              onChange={(e) => updateException(exception.id, "end_time", e.target.value)}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {config.exceptions.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <Calendar className="mx-auto h-12 w-12 mb-4" />
                      <p>Nenhuma exceção configurada</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={resetToDefaults}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Restaurar Padrões
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={saveConfig} disabled={isSaving}>
              {isSaving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Salvar Configuração
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
