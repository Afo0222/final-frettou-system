"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Calculator, MoreVertical, Edit, Eye, Copy, Trash2, RotateCcw, DollarSign, Tag, Building } from "lucide-react"
import type { VariavelCusto, TipoServico } from "@/lib/types/tipos-servico"

interface CostVariableCardProps {
  variavel: VariavelCusto
  tipoServico?: TipoServico
  onEdit: (variavel: VariavelCusto) => void
  onDelete: (id: string) => void
  onView: (variavel: VariavelCusto) => void
  onDuplicate: (variavel: VariavelCusto) => void
  onReactivate: (id: string) => void
}

export function CostVariableCard({
  variavel,
  tipoServico,
  onEdit,
  onDelete,
  onView,
  onDuplicate,
  onReactivate,
}: CostVariableCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const getUnidadeLabel = (unidade?: string) => {
    const labels: Record<string, string> = {
      fixo: "Valor Fixo",
      percentual: "Percentual",
      por_km: "Por KM",
      por_hora: "Por Hora",
      por_peso: "Por Peso",
      por_volume: "Por Volume",
    }
    return labels[unidade || "fixo"] || unidade || "Fixo"
  }

  const getUnidadeColor = (unidade?: string) => {
    const colors: Record<string, string> = {
      fixo: "bg-blue-100 text-blue-800",
      percentual: "bg-green-100 text-green-800",
      por_km: "bg-orange-100 text-orange-800",
      por_hora: "bg-purple-100 text-purple-800",
      por_peso: "bg-yellow-100 text-yellow-800",
      por_volume: "bg-pink-100 text-pink-800",
    }
    return colors[unidade || "fixo"] || "bg-gray-100 text-gray-800"
  }

  return (
    <Card
      className={`transition-all duration-200 cursor-pointer ${
        isHovered ? "shadow-md scale-[1.02]" : "shadow-sm"
      } ${!variavel.ativo ? "opacity-60" : ""}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onView(variavel)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center gap-2">
              <Calculator className="h-5 w-5 text-primary" />
              {variavel.nome}
            </CardTitle>
            <CardDescription className="mt-1">{variavel.descricao || "Sem descrição"}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {!variavel.ativo && (
              <Badge variant="secondary" className="text-xs">
                Inativo
              </Badge>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    onView(variavel)
                  }}
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Visualizar
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    onEdit(variavel)
                  }}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    onDuplicate(variavel)
                  }}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Duplicar
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {variavel.ativo ? (
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation()
                      onDelete(variavel.id)
                    }}
                    className="text-red-600"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Desativar
                  </DropdownMenuItem>
                ) : (
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation()
                      onReactivate(variavel.id)
                    }}
                    className="text-green-600"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reativar
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Valor Principal */}
        <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
          <div className="flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-green-600" />
            <span className="font-medium">Valor</span>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold text-green-600">
              {variavel.unidade === "percentual" ? `${variavel.valor}%` : formatCurrency(variavel.valor)}
            </p>
          </div>
        </div>

        {/* Informações Adicionais */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Tag className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Unidade</span>
            </div>
            <Badge className={getUnidadeColor(variavel.unidade)}>{getUnidadeLabel(variavel.unidade)}</Badge>
          </div>

          {tipoServico && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Tipo de Serviço</span>
              </div>
              <Badge variant="outline" className="text-xs">
                {tipoServico.nome}
              </Badge>
            </div>
          )}

          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>Criado em</span>
            <span>{formatDate(variavel.created_at)}</span>
          </div>
        </div>

        {/* Status Indicator */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${variavel.ativo ? "bg-green-500" : "bg-gray-400"}`} />
            <span className="text-sm font-medium">{variavel.ativo ? "Ativo" : "Inativo"}</span>
          </div>
          {variavel.ativo && (
            <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
              Em uso
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
