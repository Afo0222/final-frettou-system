"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calculator, DollarSign, Info } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { VariaveisCustoService } from "@/lib/services/variaveis-custo"
import type { VariavelCusto, TipoServico } from "@/lib/types/tipos-servico"

interface CostVariableFormProps {
  isOpen: boolean
  onClose: () => void
  onSave: () => void
  variavel?: VariavelCusto | null
  tiposServico: TipoServico[]
}

const unidadeOptions = [
  { value: "fixo", label: "Valor Fixo", description: "Valor fixo aplicado uma vez" },
  { value: "percentual", label: "Percentual", description: "Percentual sobre o valor total" },
  { value: "por_km", label: "Por Quilômetro", description: "Valor multiplicado pela distância" },
  { value: "por_hora", label: "Por Hora", description: "Valor multiplicado pelo tempo" },
  { value: "por_peso", label: "Por Peso", description: "Valor multiplicado pelo peso da carga" },
  { value: "por_volume", label: "Por Volume", description: "Valor multiplicado pelo volume da carga" },
]

export function CostVariableForm({ isOpen, onClose, onSave, variavel, tiposServico }: CostVariableFormProps) {
  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    valor: 0,
    unidade: "fixo",
    tipo_servico_id: "",
    ativo: true,
  })

  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (isOpen) {
      if (variavel) {
        // Edit mode
        setFormData({
          nome: variavel.nome,
          descricao: variavel.descricao || "",
          valor: variavel.valor,
          unidade: variavel.unidade || "fixo",
          tipo_servico_id: variavel.tipo_servico_id || "",
          ativo: variavel.ativo,
        })
      } else {
        // Create mode
        resetForm()
      }
      setErrors({})
    }
  }, [isOpen, variavel])

  const resetForm = () => {
    setFormData({
      nome: "",
      descricao: "",
      valor: 0,
      unidade: "fixo",
      tipo_servico_id: "",
      ativo: true,
    })
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.nome.trim()) {
      newErrors.nome = "Nome é obrigatório"
    }

    if (formData.valor < 0) {
      newErrors.valor = "Valor não pode ser negativo"
    }

    if (formData.unidade === "percentual" && formData.valor > 100) {
      newErrors.valor = "Percentual não pode ser maior que 100%"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Erro de validação",
        description: "Verifique os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const dataToSave = {
        ...formData,
        tipo_servico_id: formData.tipo_servico_id || null,
      }

      if (variavel) {
        await VariaveisCustoService.update(variavel.id, dataToSave)
      } else {
        await VariaveisCustoService.create(dataToSave)
      }

      onSave()
      onClose()
    } catch (error) {
      console.error("Erro ao salvar variável de custo:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar a variável de custo",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const getUnidadeDescription = (unidade: string) => {
    return unidadeOptions.find((opt) => opt.value === unidade)?.description || ""
  }

  const getExampleCalculation = () => {
    const baseValue = 100
    const distance = 10
    const time = 2
    const weight = 1000
    const volume = 5

    switch (formData.unidade) {
      case "fixo":
        return `Valor fixo: ${formatCurrency(formData.valor)}`
      case "percentual":
        return `${formData.valor}% de ${formatCurrency(baseValue)} = ${formatCurrency((baseValue * formData.valor) / 100)}`
      case "por_km":
        return `${distance} km × ${formatCurrency(formData.valor)} = ${formatCurrency(distance * formData.valor)}`
      case "por_hora":
        return `${time} horas × ${formatCurrency(formData.valor)} = ${formatCurrency(time * formData.valor)}`
      case "por_peso":
        return `${weight} kg × ${formatCurrency(formData.valor)} = ${formatCurrency(weight * formData.valor)}`
      case "por_volume":
        return `${volume} m³ × ${formatCurrency(formData.valor)} = ${formatCurrency(volume * formData.valor)}`
      default:
        return ""
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            {variavel ? "Editar Variável de Custo" : "Nova Variável de Custo"}
          </DialogTitle>
          <DialogDescription>
            Configure uma variável de custo que será aplicada automaticamente aos cálculos de orçamento.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Informações Básicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    className={errors.nome ? "border-red-500" : ""}
                    placeholder="Ex: Taxa de combustível"
                    required
                  />
                  {errors.nome && <p className="text-sm text-red-500">{errors.nome}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipo_servico_id">Tipo de Serviço</Label>
                  <Select
                    value={formData.tipo_servico_id}
                    onValueChange={(value) => setFormData({ ...formData, tipo_servico_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um tipo (opcional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os tipos</SelectItem>
                      {tiposServico.map((tipo) => (
                        <SelectItem key={tipo.id} value={tipo.id}>
                          {tipo.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  rows={3}
                  placeholder="Descreva quando e como esta variável é aplicada..."
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="ativo"
                  checked={formData.ativo}
                  onCheckedChange={(checked) => setFormData({ ...formData, ativo: checked })}
                />
                <Label htmlFor="ativo">Variável ativa</Label>
              </div>
            </CardContent>
          </Card>

          {/* Value Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Configuração de Valor
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="valor">Valor * {formData.unidade === "percentual" && "(%)"}</Label>
                  <Input
                    id="valor"
                    type="number"
                    min="0"
                    max={formData.unidade === "percentual" ? "100" : undefined}
                    step="0.01"
                    value={formData.valor}
                    onChange={(e) => setFormData({ ...formData, valor: Number(e.target.value) })}
                    className={errors.valor ? "border-red-500" : ""}
                    required
                  />
                  {errors.valor && <p className="text-sm text-red-500">{errors.valor}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="unidade">Unidade de Medida</Label>
                  <Select
                    value={formData.unidade}
                    onValueChange={(value) => setFormData({ ...formData, unidade: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {unidadeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Unit Description */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-900">
                      {unidadeOptions.find((opt) => opt.value === formData.unidade)?.label}
                    </p>
                    <p className="text-sm text-blue-700">{getUnidadeDescription(formData.unidade)}</p>
                  </div>
                </div>
              </div>

              {/* Example Calculation */}
              {formData.valor > 0 && (
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Exemplo de Cálculo</h4>
                  <p className="text-sm text-muted-foreground">{getExampleCalculation()}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Resumo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Nome:</span>
                  <span>{formData.nome || "Não informado"}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Valor:</span>
                  <span className="font-semibold text-green-600">
                    {formData.unidade === "percentual" ? `${formData.valor}%` : formatCurrency(formData.valor)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Unidade:</span>
                  <Badge variant="outline">{unidadeOptions.find((opt) => opt.value === formData.unidade)?.label}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Aplicação:</span>
                  <span>
                    {formData.tipo_servico_id
                      ? tiposServico.find((t) => t.id === formData.tipo_servico_id)?.nome
                      : "Todos os tipos de serviço"}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Status:</span>
                  <Badge variant={formData.ativo ? "default" : "secondary"}>
                    {formData.ativo ? "Ativo" : "Inativo"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Salvando..." : variavel ? "Atualizar" : "Criar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
