"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calculator, DollarSign, Settings, TrendingUp, Edit, Building, Calendar, Info, BarChart3 } from "lucide-react"
import type { VariavelCusto, TipoServico } from "@/lib/types/tipos-servico"

interface CostVariableDetailsProps {
  isOpen: boolean
  onClose: () => void
  variavel: VariavelCusto | null
  tipoServico?: TipoServico
  onEdit?: (variavel: VariavelCusto) => void
}

export function CostVariableDetails({ isOpen, onClose, variavel, tipoServico, onEdit }: CostVariableDetailsProps) {
  const [usageStats, setUsageStats] = useState({
    totalOrcamentos: 0,
    valorTotalAplicado: 0,
    mediaAplicacao: 0,
    ultimaAplicacao: null as string | null,
  })

  useEffect(() => {
    if (isOpen && variavel) {
      // Simulate loading usage statistics
      setUsageStats({
        totalOrcamentos: Math.floor(Math.random() * 50) + 10,
        valorTotalAplicado: Math.random() * 10000 + 1000,
        mediaAplicacao: Math.random() * 500 + 50,
        ultimaAplicacao: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      })
    }
  }, [isOpen, variavel])

  if (!variavel) return null

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getUnidadeLabel = (unidade?: string) => {
    const labels: Record<string, string> = {
      fixo: "Valor Fixo",
      percentual: "Percentual",
      por_km: "Por KM",
      por_hora: "Por Hora",
      por_peso: "Por Peso",
      por_volume: "Por Volume",
    }
    return labels[unidade || "fixo"] || unidade || "Fixo"
  }

  const getExampleCalculations = () => {
    const examples = [
      { scenario: "Frete curto (5km, 1h)", km: 5, hours: 1, weight: 500, volume: 2 },
      { scenario: "Frete médio (15km, 2h)", km: 15, hours: 2, weight: 1000, volume: 5 },
      { scenario: "Frete longo (50km, 4h)", km: 50, hours: 4, weight: 2000, volume: 10 },
    ]

    return examples.map((example) => {
      let value = 0
      let calculation = ""

      switch (variavel.unidade) {
        case "fixo":
          value = variavel.valor
          calculation = `Valor fixo: ${formatCurrency(variavel.valor)}`
          break
        case "percentual":
          const baseValue = 200 // Exemplo de valor base
          value = (baseValue * variavel.valor) / 100
          calculation = `${variavel.valor}% de ${formatCurrency(baseValue)} = ${formatCurrency(value)}`
          break
        case "por_km":
          value = example.km * variavel.valor
          calculation = `${example.km} km × ${formatCurrency(variavel.valor)} = ${formatCurrency(value)}`
          break
        case "por_hora":
          value = example.hours * variavel.valor
          calculation = `${example.hours}h × ${formatCurrency(variavel.valor)} = ${formatCurrency(value)}`
          break
        case "por_peso":
          value = example.weight * variavel.valor
          calculation = `${example.weight} kg × ${formatCurrency(variavel.valor)} = ${formatCurrency(value)}`
          break
        case "por_volume":
          value = example.volume * variavel.valor
          calculation = `${example.volume} m³ × ${formatCurrency(variavel.valor)} = ${formatCurrency(value)}`
          break
      }

      return {
        ...example,
        value,
        calculation,
      }
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Calculator className="h-6 w-6 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-xl">{variavel.nome}</DialogTitle>
              <DialogDescription>{variavel.descricao}</DialogDescription>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {variavel.ativo ? (
                <Badge variant="default" className="bg-green-100 text-green-800">
                  Ativo
                </Badge>
              ) : (
                <Badge variant="secondary">Inativo</Badge>
              )}
              {onEdit && (
                <Button variant="outline" size="sm" onClick={() => onEdit(variavel)}>
                  <Edit className="h-4 w-4 mr-1" />
                  Editar
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="geral" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="geral">Geral</TabsTrigger>
            <TabsTrigger value="calculos">Cálculos</TabsTrigger>
            <TabsTrigger value="uso">Uso</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
          </TabsList>

          <TabsContent value="geral" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Informações Básicas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Nome</label>
                    <p className="font-semibold">{variavel.nome}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Descrição</label>
                    <p className="text-sm">{variavel.descricao || "Sem descrição"}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Unidade</label>
                      <p className="text-sm font-medium">{getUnidadeLabel(variavel.unidade)}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Status</label>
                      <p className="text-sm font-medium">{variavel.ativo ? "Ativo" : "Inativo"}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Valor e Aplicação
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Valor</label>
                    <p className="text-2xl font-bold text-green-600">
                      {variavel.unidade === "percentual" ? `${variavel.valor}%` : formatCurrency(variavel.valor)}
                    </p>
                  </div>
                  {tipoServico ? (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Tipo de Serviço</label>
                      <div className="flex items-center gap-2 mt-1">
                        <Building className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{tipoServico.nome}</span>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Aplicação</label>
                      <p className="text-sm font-medium">Todos os tipos de serviço</p>
                    </div>
                  )}
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Criado em</label>
                    <p className="text-sm">{formatDate(variavel.created_at)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Atualizado em</label>
                    <p className="text-sm">{formatDate(variavel.updated_at)}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="calculos" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Exemplos de Cálculo
                </CardTitle>
                <CardDescription>Veja como esta variável é aplicada em diferentes cenários</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {getExampleCalculations().map((example, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{example.scenario}</h4>
                        <Badge variant="outline" className="text-green-600 border-green-200">
                          {formatCurrency(example.value)}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{example.calculation}</p>
                      <div className="mt-2 text-xs text-muted-foreground">
                        Cenário: {example.km}km, {example.hours}h, {example.weight}kg, {example.volume}m³
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Info className="h-4 w-4 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-blue-900">Como funciona</p>
                      <p className="text-sm text-blue-700">
                        {variavel.unidade === "fixo" &&
                          "Esta variável adiciona um valor fixo ao orçamento, independente das características do frete."}
                        {variavel.unidade === "percentual" &&
                          "Esta variável adiciona um percentual sobre o valor total do orçamento."}
                        {variavel.unidade === "por_km" &&
                          "Esta variável multiplica o valor pela distância em quilômetros do frete."}
                        {variavel.unidade === "por_hora" &&
                          "Esta variável multiplica o valor pelo tempo estimado em horas do frete."}
                        {variavel.unidade === "por_peso" &&
                          "Esta variável multiplica o valor pelo peso da carga em quilogramas."}
                        {variavel.unidade === "por_volume" &&
                          "Esta variável multiplica o valor pelo volume da carga em metros cúbicos."}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="uso" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Estatísticas de Uso
                </CardTitle>
                <CardDescription>Dados sobre a utilização desta variável nos orçamentos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Total de Orçamentos</span>
                      </div>
                      <p className="text-2xl font-bold text-blue-600">{usageStats.totalOrcamentos}</p>
                      <p className="text-sm text-muted-foreground">Orçamentos que usaram esta variável</p>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Valor Total Aplicado</span>
                      </div>
                      <p className="text-2xl font-bold text-green-600">
                        {formatCurrency(usageStats.valorTotalAplicado)}
                      </p>
                      <p className="text-sm text-muted-foreground">Soma de todos os valores aplicados</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Calculator className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Média por Aplicação</span>
                      </div>
                      <p className="text-2xl font-bold text-orange-600">{formatCurrency(usageStats.mediaAplicacao)}</p>
                      <p className="text-sm text-muted-foreground">Valor médio por orçamento</p>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Última Aplicação</span>
                      </div>
                      <p className="text-lg font-bold text-purple-600">
                        {usageStats.ultimaAplicacao ? formatDate(usageStats.ultimaAplicacao) : "Nunca utilizada"}
                      </p>
                      <p className="text-sm text-muted-foreground">Data da última utilização</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="historico" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Histórico de Alterações
                </CardTitle>
                <CardDescription>Registro de modificações desta variável de custo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 border rounded-lg">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="font-medium">Variável criada</p>
                      <p className="text-sm text-muted-foreground">Criada em {formatDate(variavel.created_at)}</p>
                    </div>
                  </div>

                  {variavel.updated_at !== variavel.created_at && (
                    <div className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div className="flex-1">
                        <p className="font-medium">Última atualização</p>
                        <p className="text-sm text-muted-foreground">Atualizada em {formatDate(variavel.updated_at)}</p>
                      </div>
                    </div>
                  )}

                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Histórico detalhado será implementado em breve</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
