"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Calculator, DollarSign, RefreshCw, Download } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import type { VariavelCusto, TipoServico } from "@/lib/types/tipos-servico"

interface CostVariableCalculatorProps {
  variaveis: VariavelCusto[]
  tiposServico: TipoServico[]
}

interface CalculationParams {
  valorBase: number
  distanciaKm: number
  tempoHoras: number
  pesoKg: number
  volumeM3: number
  tipoServicoId: string
  variaveisSelecionadas: string[]
}

interface CalculationResult {
  valorBase: number
  variaveisAplicadas: Array<{
    variavel: VariavelCusto
    valorCalculado: number
    calculo: string
  }>
  valorTotal: number
}

export function CostVariableCalculator({ variaveis, tiposServico }: CostVariableCalculatorProps) {
  const [params, setParams] = useState<CalculationParams>({
    valorBase: 200,
    distanciaKm: 10,
    tempoHoras: 2,
    pesoKg: 1000,
    volumeM3: 5,
    tipoServicoId: "",
    variaveisSelecionadas: [],
  })

  const [result, setResult] = useState<CalculationResult | null>(null)
  const [isCalculating, setIsCalculating] = useState(false)

  // Filter variables based on selected service type
  const availableVariaveis = useMemo(() => {
    return variaveis.filter(
      (variavel) =>
        !params.tipoServicoId || !variavel.tipo_servico_id || variavel.tipo_servico_id === params.tipoServicoId,
    )
  }, [variaveis, params.tipoServicoId])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const calculateVariable = (variavel: VariavelCusto): { valor: number; calculo: string } => {
    let valor = 0
    let calculo = ""

    switch (variavel.unidade) {
      case "fixo":
        valor = variavel.valor
        calculo = `Valor fixo: ${formatCurrency(variavel.valor)}`
        break
      case "percentual":
        valor = (params.valorBase * variavel.valor) / 100
        calculo = `${variavel.valor}% de ${formatCurrency(params.valorBase)} = ${formatCurrency(valor)}`
        break
      case "por_km":
        valor = params.distanciaKm * variavel.valor
        calculo = `${params.distanciaKm} km × ${formatCurrency(variavel.valor)} = ${formatCurrency(valor)}`
        break
      case "por_hora":
        valor = params.tempoHoras * variavel.valor
        calculo = `${params.tempoHoras}h × ${formatCurrency(variavel.valor)} = ${formatCurrency(valor)}`
        break
      case "por_peso":
        valor = params.pesoKg * variavel.valor
        calculo = `${params.pesoKg} kg × ${formatCurrency(variavel.valor)} = ${formatCurrency(valor)}`
        break
      case "por_volume":
        valor = params.volumeM3 * variavel.valor
        calculo = `${params.volumeM3} m³ × ${formatCurrency(variavel.valor)} = ${formatCurrency(valor)}`
        break
      default:
        valor = variavel.valor
        calculo = `${formatCurrency(variavel.valor)}`
    }

    return { valor, calculo }
  }

  const handleCalculate = () => {
    setIsCalculating(true)

    setTimeout(() => {
      const variaveisAplicadas = params.variaveisSelecionadas
        .map((id) => variaveis.find((v) => v.id === id))
        .filter(Boolean)
        .map((variavel) => {
          const { valor, calculo } = calculateVariable(variavel!)
          return {
            variavel: variavel!,
            valorCalculado: valor,
            calculo,
          }
        })

      const valorTotal = params.valorBase + variaveisAplicadas.reduce((sum, item) => sum + item.valorCalculado, 0)

      setResult({
        valorBase: params.valorBase,
        variaveisAplicadas,
        valorTotal,
      })

      setIsCalculating(false)

      toast({
        title: "Cálculo realizado",
        description: `Valor total: ${formatCurrency(valorTotal)}`,
      })
    }, 500)
  }

  const handleVariavelToggle = (variavelId: string, checked: boolean) => {
    setParams((prev) => ({
      ...prev,
      variaveisSelecionadas: checked
        ? [...prev.variaveisSelecionadas, variavelId]
        : prev.variaveisSelecionadas.filter((id) => id !== variavelId),
    }))
  }

  const handleSelectAll = () => {
    setParams((prev) => ({
      ...prev,
      variaveisSelecionadas: availableVariaveis.map((v) => v.id),
    }))
  }

  const handleClearAll = () => {
    setParams((prev) => ({
      ...prev,
      variaveisSelecionadas: [],
    }))
  }

  const handleReset = () => {
    setParams({
      valorBase: 200,
      distanciaKm: 10,
      tempoHoras: 2,
      pesoKg: 1000,
      volumeM3: 5,
      tipoServicoId: "",
      variaveisSelecionadas: [],
    })
    setResult(null)
  }

  const exportResult = () => {
    if (!result) return

    const data = {
      parametros: params,
      resultado: result,
      dataCalculo: new Date().toISOString(),
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `calculo-variaveis-${new Date().toISOString().split("T")[0]}.json`
    link.click()

    toast({
      title: "Resultado exportado",
      description: "Arquivo JSON baixado com sucesso",
    })
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Calculator Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Calculadora de Variáveis
          </CardTitle>
          <CardDescription>
            Configure os parâmetros e selecione as variáveis para calcular o impacto no orçamento
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Base Parameters */}
          <div className="space-y-4">
            <h4 className="font-medium">Parâmetros Base</h4>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="valorBase">Valor Base (R$)</Label>
                <Input
                  id="valorBase"
                  type="number"
                  min="0"
                  step="0.01"
                  value={params.valorBase}
                  onChange={(e) => setParams({ ...params, valorBase: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tipoServico">Tipo de Serviço</Label>
                <Select
                  value={params.tipoServicoId}
                  onValueChange={(value) => setParams({ ...params, tipoServicoId: value, variaveisSelecionadas: [] })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os tipos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os tipos</SelectItem>
                    {tiposServico.map((tipo) => (
                      <SelectItem key={tipo.id} value={tipo.id}>
                        {tipo.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="distancia">Distância (km)</Label>
                <Input
                  id="distancia"
                  type="number"
                  min="0"
                  step="0.1"
                  value={params.distanciaKm}
                  onChange={(e) => setParams({ ...params, distanciaKm: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tempo">Tempo (horas)</Label>
                <Input
                  id="tempo"
                  type="number"
                  min="0"
                  step="0.5"
                  value={params.tempoHoras}
                  onChange={(e) => setParams({ ...params, tempoHoras: Number(e.target.value) })}
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="peso">Peso (kg)</Label>
                <Input
                  id="peso"
                  type="number"
                  min="0"
                  value={params.pesoKg}
                  onChange={(e) => setParams({ ...params, pesoKg: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="volume">Volume (m³)</Label>
                <Input
                  id="volume"
                  type="number"
                  min="0"
                  step="0.1"
                  value={params.volumeM3}
                  onChange={(e) => setParams({ ...params, volumeM3: Number(e.target.value) })}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Variable Selection */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Variáveis Disponíveis</h4>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleSelectAll}>
                  Selecionar Todas
                </Button>
                <Button variant="outline" size="sm" onClick={handleClearAll}>
                  Limpar
                </Button>
              </div>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {availableVariaveis.length > 0 ? (
                availableVariaveis.map((variavel) => (
                  <div key={variavel.id} className="flex items-center space-x-2 p-2 border rounded">
                    <Checkbox
                      id={variavel.id}
                      checked={params.variaveisSelecionadas.includes(variavel.id)}
                      onCheckedChange={(checked) => handleVariavelToggle(variavel.id, checked as boolean)}
                    />
                    <div className="flex-1">
                      <Label htmlFor={variavel.id} className="font-medium cursor-pointer">
                        {variavel.nome}
                      </Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {variavel.unidade === "percentual" ? `${variavel.valor}%` : formatCurrency(variavel.valor)}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {variavel.unidade}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Nenhuma variável disponível para o tipo selecionado
                </p>
              )}
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleCalculate} disabled={isCalculating} className="flex-1">
              {isCalculating ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Calculando...
                </>
              ) : (
                <>
                  <Calculator className="h-4 w-4 mr-2" />
                  Calcular
                </>
              )}
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Calculation Result */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Resultado do Cálculo
              </CardTitle>
              <CardDescription>Breakdown detalhado dos custos com variáveis aplicadas</CardDescription>
            </div>
            {result && (
              <Button variant="outline" size="sm" onClick={exportResult}>
                <Download className="h-4 w-4 mr-1" />
                Exportar
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {result ? (
            <div className="space-y-4">
              {/* Base Value */}
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-medium">Valor Base:</span>
                <span className="font-semibold">{formatCurrency(result.valorBase)}</span>
              </div>

              {/* Applied Variables */}
              {result.variaveisAplicadas.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-medium">Variáveis Aplicadas:</h4>
                  {result.variaveisAplicadas.map((item, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-medium">{item.variavel.nome}</span>
                        <span className="font-semibold text-green-600">{formatCurrency(item.valorCalculado)}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.calculo}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Total */}
              <Separator />
              <div className="flex justify-between items-center p-4 bg-green-50 border border-green-200 rounded-lg">
                <span className="text-lg font-bold">Valor Total:</span>
                <span className="text-2xl font-bold text-green-600">{formatCurrency(result.valorTotal)}</span>
              </div>

              {/* Summary */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Resumo</h4>
                <div className="text-sm text-blue-700 space-y-1">
                  <p>• Valor base: {formatCurrency(result.valorBase)}</p>
                  <p>• Variáveis aplicadas: {result.variaveisAplicadas.length}</p>
                  <p>• Acréscimo total: {formatCurrency(result.valorTotal - result.valorBase)}</p>
                  <p>
                    • Percentual de acréscimo:{" "}
                    {(((result.valorTotal - result.valorBase) / result.valorBase) * 100).toFixed(1)}%
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Calculator className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Pronto para calcular</h3>
              <p className="text-muted-foreground">
                Configure os parâmetros e selecione as variáveis para ver o resultado
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
