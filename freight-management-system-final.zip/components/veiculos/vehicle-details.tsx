"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Car,
  Truck,
  User,
  Fuel,
  Calendar,
  FileText,
  Wrench,
  DollarSign,
  CheckCircle,
  XCircle,
  AlertTriangle,
} from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import type { Veiculo } from "@/lib/types/database"

interface VehicleDetailsProps {
  vehicle: Veiculo
}

export function VehicleDetails({ vehicle }: VehicleDetailsProps) {
  const getVehicleIcon = () => {
    switch (vehicle.tipo_veiculo) {
      case "caminhao":
        return <Truck className="h-6 w-6" />
      case "van":
      case "pickup":
        return <Car className="h-6 w-6" />
      default:
        return <Car className="h-6 w-6" />
    }
  }

  const getStatusBadge = () => {
    if (!vehicle.ativo) {
      return <Badge variant="secondary">Inativo</Badge>
    }

    const hoje = new Date()
    const proximoMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate())

    const vencimentos = [vehicle.vencimento_seguro, vehicle.vencimento_ipva, vehicle.vencimento_licenciamento].filter(
      Boolean,
    )

    const temVencimentoProximo = vencimentos.some((vencimento) => vencimento && new Date(vencimento) <= proximoMes)

    if (temVencimentoProximo) {
      return <Badge variant="destructive">Vencimento Próximo</Badge>
    }

    if (!vehicle.seguro_vigente || !vehicle.ipva_pago || !vehicle.licenciamento_vigente) {
      return <Badge variant="destructive">Documentos Pendentes</Badge>
    }

    if (vehicle.motorista_id) {
      return <Badge variant="default">Em Uso</Badge>
    }

    return (
      <Badge variant="outline" className="text-green-600 border-green-600">
        Disponível
      </Badge>
    )
  }

  const getMaintenanceProgress = () => {
    if (!vehicle.manutencao_preventiva || !vehicle.km_atual) return 0

    // Simular progresso baseado na quilometragem
    const kmParaRevisao = 10000 // Exemplo: revisão a cada 10.000 km
    const kmDesdeUltimaRevisao = (vehicle.km_atual || 0) % kmParaRevisao
    return (kmDesdeUltimaRevisao / kmParaRevisao) * 100
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR })
    } catch {
      return dateString
    }
  }

  const isDateExpiring = (dateString: string) => {
    if (!dateString) return false
    const date = new Date(dateString)
    const hoje = new Date()
    const proximoMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate())
    return date <= proximoMes
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          {getVehicleIcon()}
          <div>
            <h2 className="text-2xl font-bold">
              {vehicle.marca} {vehicle.modelo}
            </h2>
            <p className="text-muted-foreground">
              {vehicle.placa} • {vehicle.ano}
            </p>
          </div>
        </div>
        {getStatusBadge()}
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">Geral</TabsTrigger>
          <TabsTrigger value="specs">Especificações</TabsTrigger>
          <TabsTrigger value="docs">Documentação</TabsTrigger>
          <TabsTrigger value="maintenance">Manutenção</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Car className="h-5 w-5" />
                <span>Informações Básicas</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Marca</p>
                  <p className="font-medium">{vehicle.marca}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Modelo</p>
                  <p className="font-medium">{vehicle.modelo}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Placa</p>
                  <p className="font-medium">{vehicle.placa}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Ano</p>
                  <p className="font-medium">{vehicle.ano}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Cor</p>
                  <p className="font-medium">{vehicle.cor || "Não informado"}</p>
                </div>
              </div>

              {(vehicle.chassi || vehicle.renavam) && (
                <>
                  <Separator />
                  <div className="grid grid-cols-2 gap-4">
                    {vehicle.chassi && (
                      <div>
                        <p className="text-sm text-muted-foreground">Chassi</p>
                        <p className="font-medium font-mono text-sm">{vehicle.chassi}</p>
                      </div>
                    )}
                    {vehicle.renavam && (
                      <div>
                        <p className="text-sm text-muted-foreground">RENAVAM</p>
                        <p className="font-medium font-mono text-sm">{vehicle.renavam}</p>
                      </div>
                    )}
                  </div>
                </>
              )}

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Tipo de Veículo</p>
                  <p className="font-medium capitalize">{vehicle.tipo_veiculo}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Proprietário</p>
                  <p className="font-medium capitalize">{vehicle.proprietario}</p>
                </div>
              </div>

              {vehicle.motorista && (
                <>
                  <Separator />
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Motorista Designado</p>
                      <p className="font-medium">{vehicle.motorista.nome}</p>
                      <p className="text-sm text-muted-foreground">
                        CNH {vehicle.motorista.categoria_cnh} - {vehicle.motorista.cnh}
                      </p>
                    </div>
                  </div>
                </>
              )}

              {vehicle.observacoes && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm text-muted-foreground">Observações</p>
                    <p className="text-sm">{vehicle.observacoes}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="specs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Truck className="h-5 w-5" />
                <span>Especificações Técnicas</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Capacidade de Peso</p>
                  <p className="font-medium">{(vehicle.capacidade_peso || 0).toLocaleString()} kg</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Capacidade de Volume</p>
                  <p className="font-medium">{vehicle.capacidade_volume || 0} m³</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">CNH Necessária</p>
                  <p className="font-medium">Categoria {vehicle.categoria_cnh}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Quilometragem Atual</p>
                  <p className="font-medium">{(vehicle.km_atual || 0).toLocaleString()} km</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Fuel className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Combustível</p>
                    <p className="font-medium capitalize">{vehicle.combustivel}</p>
                  </div>
                </div>
                {vehicle.consumo_medio && (
                  <div>
                    <p className="text-sm text-muted-foreground">Consumo Médio</p>
                    <p className="font-medium">{vehicle.consumo_medio || "Não informado"} km/l</p>
                  </div>
                )}
              </div>

              {vehicle.valor_fipe && vehicle.valor_fipe > 0 && (
                <>
                  <Separator />
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Valor FIPE</p>
                      <p className="font-medium">{formatCurrency(vehicle.valor_fipe)}</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="docs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Documentação</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Seguro */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {vehicle.seguro_vigente ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-600" />
                  )}
                  <div>
                    <p className="font-medium">Seguro</p>
                    <p className="text-sm text-muted-foreground">{vehicle.seguro_vigente ? "Vigente" : "Vencido"}</p>
                  </div>
                </div>
                {vehicle.vencimento_seguro && (
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      {isDateExpiring(vehicle.vencimento_seguro) && (
                        <AlertTriangle className="inline h-4 w-4 text-yellow-600 mr-1" />
                      )}
                      {formatDate(vehicle.vencimento_seguro)}
                    </p>
                    <p className="text-xs text-muted-foreground">Vencimento</p>
                  </div>
                )}
              </div>

              <Separator />

              {/* IPVA */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {vehicle.ipva_pago ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-600" />
                  )}
                  <div>
                    <p className="font-medium">IPVA</p>
                    <p className="text-sm text-muted-foreground">{vehicle.ipva_pago ? "Pago" : "Pendente"}</p>
                  </div>
                </div>
                {vehicle.vencimento_ipva && (
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      {isDateExpiring(vehicle.vencimento_ipva) && (
                        <AlertTriangle className="inline h-4 w-4 text-yellow-600 mr-1" />
                      )}
                      {formatDate(vehicle.vencimento_ipva)}
                    </p>
                    <p className="text-xs text-muted-foreground">Vencimento</p>
                  </div>
                )}
              </div>

              <Separator />

              {/* Licenciamento */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {vehicle.licenciamento_vigente ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-600" />
                  )}
                  <div>
                    <p className="font-medium">Licenciamento</p>
                    <p className="text-sm text-muted-foreground">
                      {vehicle.licenciamento_vigente ? "Vigente" : "Vencido"}
                    </p>
                  </div>
                </div>
                {vehicle.vencimento_licenciamento && (
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      {isDateExpiring(vehicle.vencimento_licenciamento) && (
                        <AlertTriangle className="inline h-4 w-4 text-yellow-600 mr-1" />
                      )}
                      {formatDate(vehicle.vencimento_licenciamento)}
                    </p>
                    <p className="text-xs text-muted-foreground">Vencimento</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Wrench className="h-5 w-5" />
                <span>Manutenção</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {vehicle.manutencao_preventiva && (
                <div>
                  <p className="text-sm text-muted-foreground">Plano de Manutenção Preventiva</p>
                  <p className="font-medium">{vehicle.manutencao_preventiva}</p>
                </div>
              )}

              {vehicle.manutencao_preventiva && (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Progresso até próxima manutenção</span>
                      <span className="font-medium">{Math.round(getMaintenanceProgress())}%</span>
                    </div>
                    <Progress value={getMaintenanceProgress()} className="h-2" />
                  </div>
                  <Separator />
                </>
              )}

              {vehicle.proxima_revisao && (
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Próxima Revisão</p>
                    <p className="font-medium">
                      {isDateExpiring(vehicle.proxima_revisao) && (
                        <AlertTriangle className="inline h-4 w-4 text-yellow-600 mr-1" />
                      )}
                      {formatDate(vehicle.proxima_revisao)}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <p className="text-sm text-muted-foreground">Quilometragem Atual</p>
                <p className="font-medium">{(vehicle.km_atual || 0).toLocaleString()} km</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
