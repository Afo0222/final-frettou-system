"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Progress } from "@/components/ui/progress"
import { Car, Truck, MoreVertical, Edit, Eye, Trash2, User, Fuel, CheckCircle, XCircle } from "lucide-react"
import { deleteVeiculo } from "@/lib/services/veiculos"
import { useToast } from "@/hooks/use-toast"
import type { Veiculo } from "@/lib/types/database"

interface VehicleCardProps {
  vehicle: Veiculo
  onEdit: (vehicle: Veiculo) => void
  onView: (vehicle: Veiculo) => void
  onRefresh: () => void
}

export function VehicleCard({ vehicle, onEdit, onView, onRefresh }: VehicleCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const { toast } = useToast()

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await deleteVeiculo(vehicle.id)
      toast({
        title: "Sucesso",
        description: "Veículo desativado com sucesso!",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao desativar veículo",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
      setShowDeleteDialog(false)
    }
  }

  const getVehicleIcon = () => {
    switch (vehicle.tipo_veiculo) {
      case "caminhao":
        return <Truck className="h-5 w-5" />
      case "van":
      case "pickup":
        return <Car className="h-5 w-5" />
      default:
        return <Car className="h-5 w-5" />
    }
  }

  const getStatusBadge = () => {
    if (!vehicle.ativo) {
      return <Badge variant="secondary">Inativo</Badge>
    }

    const hoje = new Date()
    const proximoMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate())

    const vencimentos = [vehicle.vencimento_seguro, vehicle.vencimento_ipva, vehicle.vencimento_licenciamento].filter(
      Boolean,
    )

    const temVencimentoProximo = vencimentos.some((vencimento) => vencimento && new Date(vencimento) <= proximoMes)

    if (temVencimentoProximo) {
      return <Badge variant="destructive">Vencimento Próximo</Badge>
    }

    if (!vehicle.seguro_vigente || !vehicle.ipva_pago || !vehicle.licenciamento_vigente) {
      return <Badge variant="destructive">Documentos Pendentes</Badge>
    }

    if (vehicle.motorista_id) {
      return <Badge variant="default">Em Uso</Badge>
    }

    return (
      <Badge variant="outline" className="text-green-600 border-green-600">
        Disponível
      </Badge>
    )
  }

  const getMaintenanceProgress = () => {
    if (!vehicle.manutencao_preventiva || !vehicle.km_atual) return 0

    // Simular progresso baseado na quilometragem
    const kmParaRevisao = 10000 // Exemplo: revisão a cada 10.000 km
    const kmAtual = vehicle.km_atual || 0
    const kmDesdeUltimaRevisao = kmAtual % kmParaRevisao
    return (kmDesdeUltimaRevisao / kmParaRevisao) * 100
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  return (
    <>
      <Card className="hover:shadow-md transition-shadow cursor-pointer group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              {getVehicleIcon()}
              <div>
                <CardTitle className="text-lg">
                  {vehicle.marca} {vehicle.modelo}
                </CardTitle>
                <p className="text-sm text-muted-foreground">{vehicle.placa}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusBadge()}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onView(vehicle)}>
                    <Eye className="mr-2 h-4 w-4" />
                    Ver Detalhes
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onEdit(vehicle)}>
                    <Edit className="mr-2 h-4 w-4" />
                    Editar
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => setShowDeleteDialog(true)}
                    className="text-destructive focus:text-destructive"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Desativar
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4" onClick={() => onView(vehicle)}>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="space-y-1">
              <p className="text-muted-foreground">Ano</p>
              <p className="font-medium">{vehicle.ano}</p>
            </div>
            <div className="space-y-1">
              <p className="text-muted-foreground">Tipo</p>
              <p className="font-medium capitalize">{vehicle.tipo_veiculo}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="space-y-1">
              <p className="text-muted-foreground">Capacidade</p>
              <p className="font-medium">{vehicle.capacidade_peso || 0}kg</p>
            </div>
            <div className="space-y-1">
              <p className="text-muted-foreground">Volume</p>
              <p className="font-medium">{vehicle.capacidade_volume || 0}m³</p>
            </div>
          </div>

          {vehicle.motorista && (
            <div className="flex items-center space-x-2 text-sm">
              <User className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Motorista:</span>
              <span className="font-medium">{vehicle.motorista.nome}</span>
            </div>
          )}

          <div className="flex items-center space-x-2 text-sm">
            <Fuel className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Combustível:</span>
            <span className="font-medium capitalize">{vehicle.combustivel}</span>
            {vehicle.consumo_medio && <span className="text-muted-foreground">({vehicle.consumo_medio} km/l)</span>}
          </div>

          {vehicle.valor_fipe && vehicle.valor_fipe > 0 && (
            <div className="text-sm">
              <span className="text-muted-foreground">Valor FIPE: </span>
              <span className="font-medium">{formatCurrency(vehicle.valor_fipe)}</span>
            </div>
          )}

          {vehicle.manutencao_preventiva && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Manutenção</span>
                <span className="text-xs">{Math.round(getMaintenanceProgress())}%</span>
              </div>
              <Progress value={getMaintenanceProgress()} className="h-2" />
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex space-x-1">
              {vehicle.seguro_vigente ? (
                <CheckCircle className="h-4 w-4 text-green-600" title="Seguro vigente" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" title="Seguro vencido" />
              )}
              {vehicle.ipva_pago ? (
                <CheckCircle className="h-4 w-4 text-green-600" title="IPVA pago" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" title="IPVA pendente" />
              )}
              {vehicle.licenciamento_vigente ? (
                <CheckCircle className="h-4 w-4 text-green-600" title="Licenciamento vigente" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" title="Licenciamento vencido" />
              )}
            </div>
            <div className="text-xs text-muted-foreground">{(vehicle.km_atual || 0).toLocaleString()} km</div>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Desativar Veículo</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja desativar o veículo {vehicle.marca} {vehicle.modelo} ({vehicle.placa})? Esta ação
              pode ser revertida posteriormente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Desativando..." : "Desativar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
