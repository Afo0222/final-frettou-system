"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Loader2 } from "lucide-react"
import { createVeiculo, updateVeiculo, type VeiculoFormData } from "@/lib/services/veiculos"
import { getMotoristasAtivos } from "@/lib/services/motoristas"
import { useToast } from "@/hooks/use-toast"
import type { Veiculo, Motorista } from "@/lib/types/database"

interface VehicleFormProps {
  vehicle?: Veiculo
  onSuccess: () => void
  onCancel: () => void
}

export function VehicleForm({ vehicle, onSuccess, onCancel }: VehicleFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [formData, setFormData] = useState<VeiculoFormData>({
    modelo: vehicle?.modelo || "",
    marca: vehicle?.marca || "",
    placa: vehicle?.placa || "",
    ano: vehicle?.ano || new Date().getFullYear(),
    cor: vehicle?.cor || "",
    chassi: vehicle?.chassi || "",
    renavam: vehicle?.renavam || "",
    capacidade_peso: vehicle?.capacidade_peso || 0,
    capacidade_volume: vehicle?.capacidade_volume || 0,
    tipo_veiculo: vehicle?.tipo_veiculo || "van",
    categoria_cnh: vehicle?.categoria_cnh || "B",
    combustivel: vehicle?.combustivel || "flex",
    consumo_medio: vehicle?.consumo_medio || 0,
    motorista_id: vehicle?.motorista_id || "",
    proprietario: vehicle?.proprietario || "empresa",
    valor_fipe: vehicle?.valor_fipe || 0,
    seguro_vigente: vehicle?.seguro_vigente ?? true,
    vencimento_seguro: vehicle?.vencimento_seguro || "",
    ipva_pago: vehicle?.ipva_pago ?? true,
    vencimento_ipva: vehicle?.vencimento_ipva || "",
    licenciamento_vigente: vehicle?.licenciamento_vigente ?? true,
    vencimento_licenciamento: vehicle?.vencimento_licenciamento || "",
    manutencao_preventiva: vehicle?.manutencao_preventiva || "",
    proxima_revisao: vehicle?.proxima_revisao || "",
    km_atual: vehicle?.km_atual || 0,
    observacoes: vehicle?.observacoes || "",
    ativo: vehicle?.ativo ?? true,
  })

  const { toast } = useToast()

  useEffect(() => {
    loadMotoristas()
  }, [])

  const loadMotoristas = async () => {
    try {
      const data = await getMotoristasAtivos()
      setMotoristas(data)
    } catch (error) {
      console.error("Erro ao carregar motoristas:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (vehicle) {
        await updateVeiculo(vehicle.id, formData)
        toast({
          title: "Sucesso",
          description: "Veículo atualizado com sucesso!",
        })
      } else {
        await createVeiculo(formData)
        toast({
          title: "Sucesso",
          description: "Veículo criado com sucesso!",
        })
      }
      onSuccess()
    } catch (error) {
      toast({
        title: "Erro",
        description: vehicle ? "Erro ao atualizar veículo" : "Erro ao criar veículo",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (field: keyof VeiculoFormData, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="basic">Básico</TabsTrigger>
          <TabsTrigger value="specs">Especificações</TabsTrigger>
          <TabsTrigger value="docs">Documentação</TabsTrigger>
          <TabsTrigger value="maintenance">Manutenção</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Informações Básicas</CardTitle>
              <CardDescription>Dados principais do veículo</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="marca">Marca *</Label>
                  <Input
                    id="marca"
                    value={formData.marca}
                    onChange={(e) => handleInputChange("marca", e.target.value)}
                    placeholder="Ex: Mercedes-Benz"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="modelo">Modelo *</Label>
                  <Input
                    id="modelo"
                    value={formData.modelo}
                    onChange={(e) => handleInputChange("modelo", e.target.value)}
                    placeholder="Ex: Sprinter 415"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="placa">Placa *</Label>
                  <Input
                    id="placa"
                    value={formData.placa}
                    onChange={(e) => handleInputChange("placa", e.target.value.toUpperCase())}
                    placeholder="ABC-1234"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ano">Ano *</Label>
                  <Input
                    id="ano"
                    type="number"
                    value={formData.ano}
                    onChange={(e) => handleInputChange("ano", Number.parseInt(e.target.value))}
                    min="1990"
                    max={new Date().getFullYear() + 1}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cor">Cor</Label>
                  <Input
                    id="cor"
                    value={formData.cor}
                    onChange={(e) => handleInputChange("cor", e.target.value)}
                    placeholder="Ex: Branco"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="chassi">Chassi</Label>
                  <Input
                    id="chassi"
                    value={formData.chassi}
                    onChange={(e) => handleInputChange("chassi", e.target.value.toUpperCase())}
                    placeholder="17 dígitos"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="renavam">RENAVAM</Label>
                  <Input
                    id="renavam"
                    value={formData.renavam}
                    onChange={(e) => handleInputChange("renavam", e.target.value)}
                    placeholder="11 dígitos"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tipo_veiculo">Tipo de Veículo *</Label>
                  <Select
                    value={formData.tipo_veiculo}
                    onValueChange={(value) => handleInputChange("tipo_veiculo", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="caminhao">Caminhão</SelectItem>
                      <SelectItem value="van">Van</SelectItem>
                      <SelectItem value="pickup">Pickup</SelectItem>
                      <SelectItem value="moto">Motocicleta</SelectItem>
                      <SelectItem value="bicicleta">Bicicleta</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="proprietario">Proprietário *</Label>
                  <Select
                    value={formData.proprietario}
                    onValueChange={(value) => handleInputChange("proprietario", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="empresa">Empresa</SelectItem>
                      <SelectItem value="terceiro">Terceiro</SelectItem>
                      <SelectItem value="motorista">Motorista</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="motorista_id">Motorista Designado</Label>
                <Select
                  value={formData.motorista_id || "none"}
                  onValueChange={(value) => handleInputChange("motorista_id", value === "none" ? null : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um motorista (opcional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum motorista</SelectItem>
                    {motoristas.map((motorista) => (
                      <SelectItem key={motorista.id} value={motorista.id}>
                        {motorista.nome} - CNH {motorista.categoria_cnh}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="ativo"
                  checked={formData.ativo}
                  onCheckedChange={(checked) => handleInputChange("ativo", checked)}
                />
                <Label htmlFor="ativo">Veículo ativo</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="specs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Especificações Técnicas</CardTitle>
              <CardDescription>Capacidades e características do veículo</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="capacidade_peso">Capacidade de Peso (kg) *</Label>
                  <Input
                    id="capacidade_peso"
                    type="number"
                    value={formData.capacidade_peso}
                    onChange={(e) => handleInputChange("capacidade_peso", Number.parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.1"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="capacidade_volume">Capacidade de Volume (m³) *</Label>
                  <Input
                    id="capacidade_volume"
                    type="number"
                    value={formData.capacidade_volume}
                    onChange={(e) => handleInputChange("capacidade_volume", Number.parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.1"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="categoria_cnh">Categoria CNH Necessária *</Label>
                  <Select
                    value={formData.categoria_cnh}
                    onValueChange={(value) => handleInputChange("categoria_cnh", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">A - Motocicletas</SelectItem>
                      <SelectItem value="B">B - Carros até 3.500kg</SelectItem>
                      <SelectItem value="C">C - Caminhões até 6.000kg</SelectItem>
                      <SelectItem value="D">D - Ônibus e vans</SelectItem>
                      <SelectItem value="E">E - Caminhões pesados</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="combustivel">Combustível *</Label>
                  <Select
                    value={formData.combustivel}
                    onValueChange={(value) => handleInputChange("combustivel", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gasolina">Gasolina</SelectItem>
                      <SelectItem value="etanol">Etanol</SelectItem>
                      <SelectItem value="diesel">Diesel</SelectItem>
                      <SelectItem value="flex">Flex</SelectItem>
                      <SelectItem value="gnv">GNV</SelectItem>
                      <SelectItem value="eletrico">Elétrico</SelectItem>
                      <SelectItem value="hibrido">Híbrido</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="consumo_medio">Consumo Médio (km/l)</Label>
                  <Input
                    id="consumo_medio"
                    type="number"
                    value={formData.consumo_medio}
                    onChange={(e) => handleInputChange("consumo_medio", Number.parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.1"
                    placeholder="Ex: 8.5"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="valor_fipe">Valor FIPE (R$)</Label>
                  <Input
                    id="valor_fipe"
                    type="number"
                    value={formData.valor_fipe}
                    onChange={(e) => handleInputChange("valor_fipe", Number.parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    placeholder="Ex: 180000"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="km_atual">Quilometragem Atual *</Label>
                <Input
                  id="km_atual"
                  type="number"
                  value={formData.km_atual}
                  onChange={(e) => handleInputChange("km_atual", Number.parseInt(e.target.value) || 0)}
                  min="0"
                  required
                  placeholder="Ex: 45000"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="docs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Documentação</CardTitle>
              <CardDescription>Status e vencimentos dos documentos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="seguro_vigente">Seguro</Label>
                    <p className="text-sm text-muted-foreground">Seguro do veículo está vigente</p>
                  </div>
                  <Switch
                    id="seguro_vigente"
                    checked={formData.seguro_vigente}
                    onCheckedChange={(checked) => handleInputChange("seguro_vigente", checked)}
                  />
                </div>
                {formData.seguro_vigente && (
                  <div className="space-y-2">
                    <Label htmlFor="vencimento_seguro">Vencimento do Seguro</Label>
                    <Input
                      id="vencimento_seguro"
                      type="date"
                      value={formData.vencimento_seguro}
                      onChange={(e) => handleInputChange("vencimento_seguro", e.target.value)}
                    />
                  </div>
                )}
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="ipva_pago">IPVA</Label>
                    <p className="text-sm text-muted-foreground">IPVA está pago</p>
                  </div>
                  <Switch
                    id="ipva_pago"
                    checked={formData.ipva_pago}
                    onCheckedChange={(checked) => handleInputChange("ipva_pago", checked)}
                  />
                </div>
                {formData.ipva_pago && (
                  <div className="space-y-2">
                    <Label htmlFor="vencimento_ipva">Vencimento do IPVA</Label>
                    <Input
                      id="vencimento_ipva"
                      type="date"
                      value={formData.vencimento_ipva}
                      onChange={(e) => handleInputChange("vencimento_ipva", e.target.value)}
                    />
                  </div>
                )}
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="licenciamento_vigente">Licenciamento</Label>
                    <p className="text-sm text-muted-foreground">Licenciamento está vigente</p>
                  </div>
                  <Switch
                    id="licenciamento_vigente"
                    checked={formData.licenciamento_vigente}
                    onCheckedChange={(checked) => handleInputChange("licenciamento_vigente", checked)}
                  />
                </div>
                {formData.licenciamento_vigente && (
                  <div className="space-y-2">
                    <Label htmlFor="vencimento_licenciamento">Vencimento do Licenciamento</Label>
                    <Input
                      id="vencimento_licenciamento"
                      type="date"
                      value={formData.vencimento_licenciamento}
                      onChange={(e) => handleInputChange("vencimento_licenciamento", e.target.value)}
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Manutenção</CardTitle>
              <CardDescription>Planos de manutenção e revisões</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="manutencao_preventiva">Plano de Manutenção Preventiva</Label>
                <Input
                  id="manutencao_preventiva"
                  value={formData.manutencao_preventiva}
                  onChange={(e) => handleInputChange("manutencao_preventiva", e.target.value)}
                  placeholder="Ex: A cada 10.000 km"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="proxima_revisao">Próxima Revisão</Label>
                <Input
                  id="proxima_revisao"
                  type="date"
                  value={formData.proxima_revisao}
                  onChange={(e) => handleInputChange("proxima_revisao", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  value={formData.observacoes}
                  onChange={(e) => handleInputChange("observacoes", e.target.value)}
                  placeholder="Observações gerais sobre o veículo..."
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {vehicle ? "Atualizar" : "Criar"} Veículo
        </Button>
      </div>
    </form>
  )
}
