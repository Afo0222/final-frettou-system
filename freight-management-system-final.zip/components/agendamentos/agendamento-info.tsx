import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, User } from "lucide-react"

interface AgendamentoInfoProps {
  agendamento: {
    id: string
    data_agendada: string
    hora_agendada: string
    status: string
    endereco_origem: string
    endereco_destino: string
    motorista?: {
      nome: string
    }
    orcamento?: {
      numero_orcamento: string
      cliente?: {
        nome: string
      }
    }
  }
}

export function AgendamentoInfo({ agendamento }: AgendamentoInfoProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "agendado":
        return "bg-blue-100 text-blue-800"
      case "em_andamento":
        return "bg-yellow-100 text-yellow-800"
      case "concluido":
        return "bg-green-100 text-green-800"
      case "cancelado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Agendamento #{agendamento.id.slice(-6)}</CardTitle>
          <Badge className={getStatusColor(agendamento.status)}>
            {agendamento.status.replace("_", " ").toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <span className="text-sm">
              <strong>Data:</strong> {formatDate(agendamento.data_agendada)}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-gray-500" />
            <span className="text-sm">
              <strong>Hora:</strong> {agendamento.hora_agendada}
            </span>
          </div>

          {agendamento.motorista && (
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-gray-500" />
              <span className="text-sm">
                <strong>Motorista:</strong> {agendamento.motorista.nome}
              </span>
            </div>
          )}

          {agendamento.orcamento?.cliente && (
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-gray-500" />
              <span className="text-sm">
                <strong>Cliente:</strong> {agendamento.orcamento.cliente.nome}
              </span>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <div className="flex items-start space-x-2">
            <MapPin className="h-4 w-4 text-gray-500 mt-0.5" />
            <div className="text-sm">
              <strong>Origem:</strong> {agendamento.endereco_origem}
            </div>
          </div>

          <div className="flex items-start space-x-2">
            <MapPin className="h-4 w-4 text-gray-500 mt-0.5" />
            <div className="text-sm">
              <strong>Destino:</strong> {agendamento.endereco_destino}
            </div>
          </div>
        </div>

        {agendamento.orcamento?.numero_orcamento && (
          <div className="pt-2 border-t">
            <span className="text-sm text-gray-600">Orçamento: {agendamento.orcamento.numero_orcamento}</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
