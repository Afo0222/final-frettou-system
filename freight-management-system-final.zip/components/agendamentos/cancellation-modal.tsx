"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { AlertTriangle, Calendar, Clock, User, DollarSign, Bell } from "lucide-react"
import type { AgendamentoCompleto } from "@/lib/services/agendamentos-integrado"
import {
  AppointmentCancellationService,
  type CancellationData,
  type CancellationReason,
} from "@/lib/services/appointment-cancellation"
import { useToast } from "@/hooks/use-toast"

interface CancellationModalProps {
  appointment: AgendamentoCompleto | null
  isOpen: boolean
  onClose: () => void
  onCancelled: () => void
}

export function CancellationModal({ appointment, isOpen, onClose, onCancelled }: CancellationModalProps) {
  const [selectedReason, setSelectedReason] = useState<CancellationReason | null>(null)
  const [cancellationNotes, setCancellationNotes] = useState("")
  const [refundAmount, setRefundAmount] = useState("")
  const [rescheduleRequested, setRescheduleRequested] = useState(false)
  const [notifyClient, setNotifyClient] = useState(true)
  const [notifyDriver, setNotifyDriver] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  if (!appointment) return null

  const canCancel = AppointmentCancellationService.canCancelAppointment(appointment)

  const handleReasonChange = (reasonId: string) => {
    const reason = AppointmentCancellationService.CANCELLATION_REASONS.find((r) => r.id === reasonId)
    setSelectedReason(reason || null)

    // Auto-set refund amount based on reason
    if (reason?.affects_billing && appointment.valor_servico) {
      if (reason.category === "client") {
        setRefundAmount((appointment.valor_servico * 0.5).toString()) // 50% refund for client cancellations
      } else if (reason.category === "company" || reason.category === "driver") {
        setRefundAmount(appointment.valor_servico.toString()) // Full refund for company/driver issues
      }
    } else {
      setRefundAmount("")
    }
  }

  const handleCancel = async () => {
    if (!selectedReason) {
      toast({
        title: "Erro",
        description: "Selecione um motivo para o cancelamento",
        variant: "destructive",
      })
      return
    }

    if (selectedReason.requires_note && !cancellationNotes.trim()) {
      toast({
        title: "Erro",
        description: "Este motivo requer observações adicionais",
        variant: "destructive",
      })
      return
    }

    try {
      setIsProcessing(true)

      const cancellationData: Partial<CancellationData> = {
        reason_id: selectedReason.id,
        reason_category: selectedReason.category,
        reason_text: selectedReason.reason,
        cancellation_notes: cancellationNotes.trim() || undefined,
        refund_amount: refundAmount ? Number.parseFloat(refundAmount) : undefined,
        reschedule_requested: rescheduleRequested,
        client_notified: notifyClient,
        driver_notified: notifyDriver,
      }

      const result = await AppointmentCancellationService.cancelAppointment(
        appointment.id,
        cancellationData,
        "admin", // In a real app, this would be the current user
      )

      if (result.success) {
        toast({
          title: "Sucesso",
          description: result.message,
        })
        onCancelled()
        onClose()
        resetForm()
      }
    } catch (error) {
      console.error("Erro ao cancelar agendamento:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao cancelar agendamento",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const resetForm = () => {
    setSelectedReason(null)
    setCancellationNotes("")
    setRefundAmount("")
    setRescheduleRequested(false)
    setNotifyClient(true)
    setNotifyDriver(true)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Cancelar Agendamento
          </DialogTitle>
          <DialogDescription>
            Esta ação cancelará o agendamento e liberará o horário para novos agendamentos. Os dados serão preservados
            para histórico.
          </DialogDescription>
        </DialogHeader>

        {!canCancel.canCancel ? (
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Não é possível cancelar</span>
              </div>
              <p className="text-red-700 mt-2">{canCancel.reason}</p>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={onClose}>
                Fechar
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Appointment Summary */}
            <div className="bg-muted/50 rounded-lg p-4 space-y-3">
              <h3 className="font-semibold">Resumo do Agendamento</h3>
              <div className="grid gap-2 text-sm">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>{appointment.cliente_nome}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{formatDate(appointment.data_agendada)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{appointment.hora_agendada}</span>
                </div>
                {appointment.valor_servico && (
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span>{formatCurrency(appointment.valor_servico)}</span>
                  </div>
                )}
                <Badge variant="secondary" className="w-fit">
                  {appointment.status}
                </Badge>
              </div>
            </div>

            <Separator />

            {/* Cancellation Reason */}
            <div className="space-y-3">
              <Label htmlFor="reason">Motivo do Cancelamento *</Label>
              <Select onValueChange={handleReasonChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o motivo" />
                </SelectTrigger>
                <SelectContent>
                  {AppointmentCancellationService.CANCELLATION_REASONS.map((reason) => (
                    <SelectItem key={reason.id} value={reason.id}>
                      <div className="flex items-center gap-2">
                        <span>{reason.reason}</span>
                        <Badge variant="outline" className="text-xs">
                          {reason.category}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Additional Notes */}
            {selectedReason && (
              <div className="space-y-3">
                <Label htmlFor="notes">
                  Observações {selectedReason.requires_note && "*"}
                  {selectedReason.requires_note && (
                    <span className="text-sm text-muted-foreground ml-1">(obrigatório para este motivo)</span>
                  )}
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Adicione observações sobre o cancelamento..."
                  value={cancellationNotes}
                  onChange={(e) => setCancellationNotes(e.target.value)}
                  rows={3}
                />
              </div>
            )}

            {/* Refund Amount */}
            {selectedReason?.affects_billing && (
              <div className="space-y-3">
                <Label htmlFor="refund">Valor do Reembolso</Label>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">R$</span>
                  <Input
                    id="refund"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={refundAmount}
                    onChange={(e) => setRefundAmount(e.target.value)}
                  />
                </div>
                {appointment.valor_servico && (
                  <p className="text-sm text-muted-foreground">
                    Valor original: {formatCurrency(appointment.valor_servico)}
                  </p>
                )}
              </div>
            )}

            <Separator />

            {/* Options */}
            <div className="space-y-4">
              <h3 className="font-semibold">Opções</h3>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="reschedule"
                  checked={rescheduleRequested}
                  onCheckedChange={(checked) => setRescheduleRequested(checked as boolean)}
                />
                <Label htmlFor="reschedule" className="text-sm">
                  Cliente solicitou reagendamento
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="notify-client"
                  checked={notifyClient}
                  onCheckedChange={(checked) => setNotifyClient(checked as boolean)}
                />
                <Label htmlFor="notify-client" className="text-sm flex items-center gap-1">
                  <Bell className="h-3 w-3" />
                  Notificar cliente
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="notify-driver"
                  checked={notifyDriver}
                  onCheckedChange={(checked) => setNotifyDriver(checked as boolean)}
                />
                <Label htmlFor="notify-driver" className="text-sm flex items-center gap-1">
                  <Bell className="h-3 w-3" />
                  Notificar motorista
                </Label>
              </div>
            </div>

            <Separator />

            {/* Actions */}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={onClose} disabled={isProcessing}>
                Cancelar
              </Button>
              <Button
                variant="destructive"
                onClick={handleCancel}
                disabled={!selectedReason || isProcessing}
                className="flex items-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Processando...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-4 w-4" />
                    Confirmar Cancelamento
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
