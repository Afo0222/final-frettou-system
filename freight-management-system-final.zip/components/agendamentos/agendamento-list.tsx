"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Calendar,
  Clock,
  MapPin,
  User,
  Truck,
  DollarSign,
  Search,
  CheckCircle,
  XCircle,
  AlertCircle,
  PlayCircle,
  RefreshCw,
  Trash2,
  Filter,
} from "lucide-react"
import { AgendamentoIntegradoService } from "@/lib/services/agendamentos-integrado"
import { useToast } from "@/hooks/use-toast"
import { DriverSelector } from "./driver-selector"
import { EnhancedCancellationModal } from "./enhanced-cancellation-modal"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const statusConfig = {
  agendado: { label: "Agendado", color: "bg-blue-500", icon: Calendar },
  confirmado: { label: "Confirmado", color: "bg-green-500", icon: CheckCircle },
  em_andamento: { label: "Em Andamento", color: "bg-yellow-500", icon: PlayCircle },
  concluido: { label: "Concluído", color: "bg-green-700", icon: CheckCircle },
  cancelado: { label: "Cancelado", color: "bg-red-500", icon: XCircle },
  reagendado: { label: "Reagendado", color: "bg-purple-500", icon: RefreshCw },
}

export default function AgendamentoList() {
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [motoristas, setMotoristas] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("todos")
  const [motoristaFilter, setMotoristaFilter] = useState("todos")
  const { toast } = useToast()

  const [selectedAppointmentForCancellation, setSelectedAppointmentForCancellation] = useState<any>(null)
  const [isCancellationModalOpen, setIsCancellationModalOpen] = useState(false)

  const [selectedAppointmentForDeletion, setSelectedAppointmentForDeletion] = useState<any>(null)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setIsLoading(true)
      setError(null)

      // Carregar agendamentos e motoristas em paralelo
      const [agendamentosData, motoristasData] = await Promise.all([
        AgendamentoIntegradoService.getAll(),
        AgendamentoIntegradoService.getMotoristas(),
      ])

      setAgendamentos(agendamentosData)
      setMotoristas(motoristasData)
    } catch (err) {
      console.error("Erro ao carregar dados:", err)
      setError(err instanceof Error ? err.message : "Erro ao carregar dados")
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleStatusChange = async (agendamentoId: string, newStatus: string) => {
    try {
      await AgendamentoIntegradoService.updateStatus(agendamentoId, newStatus)
      toast({
        title: "Sucesso",
        description: `Status atualizado para ${statusConfig[newStatus as keyof typeof statusConfig]?.label || newStatus}`,
      })
      loadData()
    } catch (err) {
      console.error("Erro ao atualizar status:", err)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status",
        variant: "destructive",
      })
    }
  }

  const filteredAgendamentos = agendamentos.filter((agendamento) => {
    const matchesSearch =
      agendamento.cliente_nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agendamento.endereco_origem?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agendamento.endereco_destino?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agendamento.tipo_servico?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agendamento.orcamento?.numero_orcamento?.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "todos" || agendamento.status === statusFilter

    const matchesMotorista =
      motoristaFilter === "todos" ||
      agendamento.motorista?.nome === motoristaFilter ||
      agendamento.motorista_nome === motoristaFilter

    return matchesSearch && matchesStatus && matchesMotorista
  })

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const handleDeleteAppointment = async (agendamento: any) => {
    try {
      setIsDeleting(true)
      await AgendamentoIntegradoService.delete(agendamento.id)

      // Atualizar estado local para performance otimizada
      setAgendamentos((prev) => prev.filter((item) => item.id !== agendamento.id))

      toast({
        title: "Sucesso",
        description: "Agendamento excluído com sucesso",
      })
      setIsDeleteModalOpen(false)
      setSelectedAppointmentForDeletion(null)
    } catch (err) {
      console.error("Erro ao excluir agendamento:", err)
      toast({
        title: "Erro",
        description: "Não foi possível excluir o agendamento",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const clearFilters = () => {
    setSearchTerm("")
    setStatusFilter("todos")
    setMotoristaFilter("todos")
  }

  const getStatusActions = (agendamento: any) => {
    const actions = []

    // Sempre mostrar o seletor de motorista se não estiver concluído ou cancelado
    if (agendamento.status !== "concluido" && agendamento.status !== "cancelado") {
      actions.push(<DriverSelector key="driver-selector" agendamento={agendamento} onDriverAssigned={loadData} />)
    }

    switch (agendamento.status) {
      case "agendado":
        actions.push(
          <Button
            key="confirm"
            size="sm"
            variant="outline"
            className="text-green-600"
            onClick={() => handleStatusChange(agendamento.id, "confirmado")}
          >
            <CheckCircle className="mr-1 h-4 w-4" />
            Confirmar
          </Button>,
        )
        actions.push(
          <Button
            key="cancel"
            size="sm"
            variant="outline"
            className="text-red-600"
            onClick={() => {
              setSelectedAppointmentForCancellation(agendamento)
              setIsCancellationModalOpen(true)
            }}
          >
            <XCircle className="mr-1 h-4 w-4" />
            Cancelar
          </Button>,
        )
        break
      case "confirmado":
        actions.push(
          <Button
            key="start"
            size="sm"
            variant="outline"
            className="text-yellow-600"
            onClick={() => handleStatusChange(agendamento.id, "em_andamento")}
          >
            <PlayCircle className="mr-1 h-4 w-4" />
            Iniciar
          </Button>,
        )
        actions.push(
          <Button
            key="cancel"
            size="sm"
            variant="outline"
            className="text-red-600"
            onClick={() => {
              setSelectedAppointmentForCancellation(agendamento)
              setIsCancellationModalOpen(true)
            }}
          >
            <XCircle className="mr-1 h-4 w-4" />
            Cancelar
          </Button>,
        )
        break
      case "em_andamento":
        actions.push(
          <Button
            key="complete"
            size="sm"
            variant="outline"
            className="text-green-600"
            onClick={() => handleStatusChange(agendamento.id, "concluido")}
          >
            <CheckCircle className="mr-1 h-4 w-4" />
            Concluir
          </Button>,
        )
        break
      default:
        break
    }

    // Adicionar no final das ações, após os outros botões
    actions.push(
      <Button
        key="delete"
        size="sm"
        variant="outline"
        className="text-red-600 hover:text-red-700 hover:bg-red-50"
        onClick={() => {
          setSelectedAppointmentForDeletion(agendamento)
          setIsDeleteModalOpen(true)
        }}
      >
        <Trash2 className="mr-1 h-4 w-4" />
        Excluir
      </Button>,
    )

    return actions
  }

  // Contar agendamentos por motorista
  const getMotoristaStats = () => {
    const stats: { [key: string]: number } = {}
    agendamentos.forEach((agendamento) => {
      const motoristaNome = agendamento.motorista?.nome || agendamento.motorista_nome || "Não atribuído"
      stats[motoristaNome] = (stats[motoristaNome] || 0) + 1
    })
    return stats
  }

  const motoristaStats = getMotoristaStats()

  if (error) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <p className="text-red-600 mb-4">{error}</p>
            <Button onClick={loadData}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Tentar Novamente
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {/* Busca */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar agendamentos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filtro por Status */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Status</SelectItem>
                <SelectItem value="agendado">Agendado</SelectItem>
                <SelectItem value="confirmado">Confirmado</SelectItem>
                <SelectItem value="em_andamento">Em Andamento</SelectItem>
                <SelectItem value="concluido">Concluído</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
                <SelectItem value="reagendado">Reagendado</SelectItem>
              </SelectContent>
            </Select>

            {/* Filtro por Motorista */}
            <Select value={motoristaFilter} onValueChange={setMotoristaFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por Motorista" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Motoristas</SelectItem>
                {motoristas.map((motorista) => (
                  <SelectItem key={motorista.id} value={motorista.nome}>
                    <div className="flex items-center justify-between w-full">
                      <span>{motorista.nome}</span>
                      <Badge variant="secondary" className="ml-2">
                        {motoristaStats[motorista.nome] || 0}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
                {motoristaStats["Não atribuído"] > 0 && (
                  <SelectItem value="Não atribuído">
                    <div className="flex items-center justify-between w-full">
                      <span>Não atribuído</span>
                      <Badge variant="secondary" className="ml-2">
                        {motoristaStats["Não atribuído"]}
                      </Badge>
                    </div>
                  </SelectItem>
                )}
              </SelectContent>
            </Select>

            {/* Ações */}
            <div className="flex gap-2">
              <Button variant="outline" onClick={clearFilters} size="sm">
                Limpar Filtros
              </Button>
              <Button variant="outline" onClick={loadData} disabled={isLoading} size="sm">
                <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                Atualizar
              </Button>
            </div>
          </div>

          {/* Resumo dos filtros ativos */}
          {(searchTerm || statusFilter !== "todos" || motoristaFilter !== "todos") && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Filtros ativos:</strong> {searchTerm && `Busca: "${searchTerm}"`}
                {statusFilter !== "todos" &&
                  ` | Status: ${statusConfig[statusFilter as keyof typeof statusConfig]?.label || statusFilter}`}
                {motoristaFilter !== "todos" && ` | Motorista: ${motoristaFilter}`} | Mostrando{" "}
                {filteredAgendamentos.length} de {agendamentos.length} agendamentos
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Agendamentos ({filteredAgendamentos.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredAgendamentos.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">Nenhum agendamento encontrado</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm || statusFilter !== "todos" || motoristaFilter !== "todos"
                  ? "Tente ajustar os filtros de busca"
                  : "Não há agendamentos para exibir"}
              </p>
              {(searchTerm || statusFilter !== "todos" || motoristaFilter !== "todos") && (
                <Button onClick={clearFilters} variant="outline">
                  Limpar Filtros
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredAgendamentos.map((agendamento) => {
                const statusInfo = statusConfig[agendamento.status as keyof typeof statusConfig] || {
                  label: agendamento.status,
                  color: "bg-gray-500",
                  icon: Calendar,
                }
                const StatusIcon = statusInfo.icon

                return (
                  <Card key={agendamento.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <h3 className="font-semibold text-lg">
                              {agendamento.cliente_nome || "Cliente não informado"}
                            </h3>
                            <Badge variant="secondary" className={`${statusInfo.color} text-white`}>
                              <StatusIcon className="mr-1 h-3 w-3" />
                              {statusInfo.label}
                            </Badge>
                          </div>

                          <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDate(agendamento.data_agendada)}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              <span>
                                {agendamento.hora_agendada} - {agendamento.hora_fim || "N/A"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <User className="h-4 w-4" />
                              <span>
                                {agendamento.motorista?.nome || agendamento.motorista_nome || "Motorista não atribuído"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Truck className="h-4 w-4" />
                              <span>
                                {agendamento.veiculo
                                  ? `${agendamento.veiculo.modelo} - ${agendamento.veiculo.placa}`
                                  : "Veículo não atribuído"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <MapPin className="h-4 w-4" />
                              <span className="truncate">
                                {agendamento.endereco_origem?.split(",")[0] || "Origem não informada"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-medium">
                              <DollarSign className="h-4 w-4" />
                              <span>
                                {agendamento.valor_servico ? formatCurrency(agendamento.valor_servico) : "N/A"}
                              </span>
                            </div>
                          </div>

                          {agendamento.orcamento && (
                            <div className="text-xs text-muted-foreground">
                              Orçamento: {agendamento.orcamento.numero_orcamento}
                            </div>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-2 justify-end">{getStatusActions(agendamento)}</div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
      <EnhancedCancellationModal
        appointment={selectedAppointmentForCancellation}
        isOpen={isCancellationModalOpen}
        onClose={() => {
          setIsCancellationModalOpen(false)
          setSelectedAppointmentForCancellation(null)
        }}
        onCancelled={() => {
          loadData()
          setIsCancellationModalOpen(false)
          setSelectedAppointmentForCancellation(null)
        }}
      />
      {/* Delete Confirmation Modal */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="h-5 w-5" />
              Excluir Agendamento
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>

          {selectedAppointmentForDeletion && (
            <div className="space-y-4">
              <div className="bg-red-50 p-3 rounded-lg">
                <p className="text-sm text-red-800">
                  <strong>Cliente:</strong> {selectedAppointmentForDeletion.cliente_nome || "Não informado"}
                </p>
                <p className="text-sm text-red-800">
                  <strong>Data:</strong> {formatDate(selectedAppointmentForDeletion.data_agendada)} às{" "}
                  {selectedAppointmentForDeletion.hora_agendada}
                </p>
                <p className="text-sm text-red-800">
                  <strong>Status:</strong>{" "}
                  {statusConfig[selectedAppointmentForDeletion.status as keyof typeof statusConfig]?.label ||
                    selectedAppointmentForDeletion.status}
                </p>
              </div>

              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsDeleteModalOpen(false)
                    setSelectedAppointmentForDeletion(null)
                  }}
                  disabled={isDeleting}
                >
                  Cancelar
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => handleDeleteAppointment(selectedAppointmentForDeletion)}
                  disabled={isDeleting}
                >
                  {isDeleting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Excluindo...
                    </>
                  ) : (
                    <>
                      <Trash2 className="mr-1 h-4 w-4" />
                      Excluir
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
