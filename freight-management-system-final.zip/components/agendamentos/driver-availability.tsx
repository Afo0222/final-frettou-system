"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Calendar, Clock, User, AlertTriangle, CheckCircle, MapPin } from "lucide-react"
import { AgendamentoIntegradoService, type Motorista } from "@/lib/services/agendamentos-integrado"

interface DriverAvailabilityProps {
  data: string
  horaInicio: string
  horaFim: string
}

export function DriverAvailability({ data, horaInicio, horaFim }: DriverAvailabilityProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [availability, setAvailability] = useState<Record<string, any>>({})
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (isOpen) {
      loadAvailability()
    }
  }, [isOpen, data, horaInicio, horaFim])

  const loadAvailability = async () => {
    try {
      setIsLoading(true)
      const motoristasData = await AgendamentoIntegradoService.getMotoristas()
      setMotoristas(motoristasData)

      const availabilityData: Record<string, any> = {}

      for (const motorista of motoristasData) {
        const result = await AgendamentoIntegradoService.checkDriverAvailability(
          motorista.id,
          data,
          horaInicio,
          horaFim,
        )
        availabilityData[motorista.id] = result
      }

      setAvailability(availabilityData)
    } catch (error) {
      console.error("Erro ao verificar disponibilidade:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const formatTime = (time: string) => {
    return time.slice(0, 5)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <User className="mr-1 h-4 w-4" />
          Ver Disponibilidade
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Disponibilidade de Motoristas
          </DialogTitle>
          <DialogDescription>
            Verificando disponibilidade para {new Date(data).toLocaleDateString("pt-BR")} das {formatTime(horaInicio)}{" "}
            às {formatTime(horaFim)}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : motoristas.length === 0 ? (
            <div className="text-center py-8">
              <User className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhum motorista encontrado</p>
            </div>
          ) : (
            motoristas.map((motorista) => {
              const driverAvailability = availability[motorista.id]
              const isAvailable = driverAvailability?.available !== false
              const conflicts = driverAvailability?.conflicts || []

              return (
                <Card key={motorista.id} className={isAvailable ? "border-green-200" : "border-red-200"}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>{getInitials(motorista.nome)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{motorista.nome}</h4>
                          <Badge variant={isAvailable ? "default" : "destructive"}>
                            {isAvailable ? (
                              <>
                                <CheckCircle className="mr-1 h-3 w-3" />
                                Disponível
                              </>
                            ) : (
                              <>
                                <AlertTriangle className="mr-1 h-3 w-3" />
                                Ocupado
                              </>
                            )}
                          </Badge>
                        </div>
                        {motorista.telefone && <p className="text-sm text-muted-foreground">{motorista.telefone}</p>}
                      </div>
                    </div>

                    {conflicts.length > 0 && (
                      <div className="mt-3 space-y-2">
                        <h5 className="text-sm font-medium text-red-600">Conflitos:</h5>
                        {conflicts.map((conflict: any, index: number) => (
                          <div key={index} className="bg-red-50 p-2 rounded text-sm">
                            <div className="flex items-center gap-2">
                              <Clock className="h-3 w-3 text-red-500" />
                              <span>
                                {formatTime(conflict.hora_inicio)} - {formatTime(conflict.hora_fim)}
                              </span>
                            </div>
                            {conflict.endereco_origem && (
                              <div className="flex items-center gap-2 mt-1">
                                <MapPin className="h-3 w-3 text-red-500" />
                                <span className="truncate">{conflict.endereco_origem.split(",")[0]}</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
