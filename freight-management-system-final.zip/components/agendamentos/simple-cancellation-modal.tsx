"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertTriangle, Calendar, Clock, User } from "lucide-react"
import type { AgendamentoCompleto } from "@/lib/services/agendamentos-integrado"
import { AgendamentoIntegradoService } from "@/lib/services/agendamentos-integrado"
import { useToast } from "@/hooks/use-toast"

interface SimpleCancellationModalProps {
  appointment: AgendamentoCompleto | null
  isOpen: boolean
  onClose: () => void
  onCancelled: () => void
}

const CANCELLATION_REASONS = [
  "Solicitação do cliente",
  "Cliente não compareceu",
  "Motorista indisponível",
  "Problema no veículo",
  "Condições climáticas",
  "Decisão da empresa",
  "Emergência",
  "Agendamento duplicado",
  "Outro motivo",
]

export function SimpleCancellationModal({ appointment, isOpen, onClose, onCancelled }: SimpleCancellationModalProps) {
  const [selectedReason, setSelectedReason] = useState("")
  const [additionalNotes, setAdditionalNotes] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  if (!appointment) return null

  const handleCancel = async () => {
    if (!selectedReason) {
      toast({
        title: "Erro",
        description: "Selecione um motivo para o cancelamento",
        variant: "destructive",
      })
      return
    }

    try {
      setIsProcessing(true)

      const fullReason = additionalNotes.trim()
        ? `${selectedReason}. Observações: ${additionalNotes.trim()}`
        : selectedReason

      await AgendamentoIntegradoService.cancelAppointment(
        appointment.id,
        fullReason,
        "admin", // Em um app real, seria o usuário atual
      )

      toast({
        title: "Sucesso",
        description: "Agendamento cancelado com sucesso. O horário foi liberado para novos agendamentos.",
      })

      onCancelled()
      onClose()
      resetForm()
    } catch (error) {
      console.error("Erro ao cancelar agendamento:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao cancelar agendamento",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const resetForm = () => {
    setSelectedReason("")
    setAdditionalNotes("")
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const canCancel = appointment.status !== "concluido" && appointment.status !== "cancelado"

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Cancelar Agendamento
          </DialogTitle>
          <DialogDescription>
            Esta ação cancelará o agendamento e liberará o horário para novos agendamentos.
          </DialogDescription>
        </DialogHeader>

        {!canCancel ? (
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Não é possível cancelar</span>
              </div>
              <p className="text-red-700 mt-2">
                {appointment.status === "concluido"
                  ? "Este agendamento já foi concluído"
                  : "Este agendamento já foi cancelado"}
              </p>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={onClose}>
                Fechar
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Resumo do Agendamento */}
            <div className="bg-muted/50 rounded-lg p-3 space-y-2">
              <h3 className="font-semibold text-sm">Resumo do Agendamento</h3>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <User className="h-3 w-3 text-muted-foreground" />
                  <span>{appointment.cliente_nome}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  <span>{formatDate(appointment.data_agendada)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-3 w-3 text-muted-foreground" />
                  <span>{appointment.hora_agendada}</span>
                </div>
              </div>
            </div>

            {/* Motivo do Cancelamento */}
            <div className="space-y-2">
              <Label htmlFor="reason">Motivo do Cancelamento *</Label>
              <Select value={selectedReason} onValueChange={setSelectedReason}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o motivo" />
                </SelectTrigger>
                <SelectContent>
                  {CANCELLATION_REASONS.map((reason) => (
                    <SelectItem key={reason} value={reason}>
                      {reason}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Observações Adicionais */}
            <div className="space-y-2">
              <Label htmlFor="notes">Observações Adicionais (opcional)</Label>
              <Textarea
                id="notes"
                placeholder="Adicione observações sobre o cancelamento..."
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                rows={3}
              />
            </div>

            {/* Ações */}
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={onClose} disabled={isProcessing}>
                Cancelar
              </Button>
              <Button
                variant="destructive"
                onClick={handleCancel}
                disabled={!selectedReason || isProcessing}
                className="flex items-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Processando...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-4 w-4" />
                    Confirmar Cancelamento
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
