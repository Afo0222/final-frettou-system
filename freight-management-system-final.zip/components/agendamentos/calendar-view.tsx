"use client"

import { useState, useEffect } from "react"
import { Calendar, dateFnsLocalizer } from "react-big-calendar"
import { format, parse, startOfWeek, getDay } from "date-fns"
import ptBR from "date-fns/locale/pt-BR"
import "react-big-calendar/lib/css/react-big-calendar.css"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, User, Filter } from "lucide-react"
import { supabase } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { AgendamentoIntegradoService } from "@/lib/services/agendamentos-integrado"

// Configuração do localizador para o calendário
const locales = {
  "pt-BR": ptBR,
}

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
})

// Interface para os eventos do calendário
interface CalendarEvent {
  id: string
  title: string
  start: Date
  end: Date
  resource?: any // Dados adicionais do evento
}

// Interface para os agendamentos do banco de dados
interface Agendamento {
  id: string
  cliente_nome: string
  data_agendada: string
  hora_agendada: string
  hora_fim?: string
  duracao_estimada_minutos?: number
  status: string
  tipo_servico: string
  endereco_origem: string
  endereco_destino: string
  motorista_id?: string
  motorista_nome?: string
  veiculo_id?: string
  veiculo_placa?: string
}

interface CalendarViewProps {
  onAppointmentClick?: (event: CalendarEvent) => void
  onNewAppointment?: (slotInfo: any) => void
}

export function CalendarView({ onAppointmentClick, onNewAppointment }: CalendarViewProps) {
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const [allEvents, setAllEvents] = useState<CalendarEvent[]>([])
  const [motoristas, setMotoristas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [motoristaFilter, setMotoristaFilter] = useState("todos")
  const { toast } = useToast()

  // Função para carregar os agendamentos
  const loadAgendamentos = async () => {
    try {
      setLoading(true)

      // Carregar agendamentos e motoristas em paralelo
      const [agendamentosData, motoristasData] = await Promise.all([
        supabase
          .from("agendamentos")
          .select("*")
          .neq("status", "cancelado") // Filtrar para não incluir agendamentos cancelados
          .order("data_agendada", { ascending: true })
          .order("hora_agendada", { ascending: true }),
        AgendamentoIntegradoService.getMotoristas(),
      ])

      if (agendamentosData.error) throw agendamentosData.error

      setMotoristas(motoristasData)

      // Converter os agendamentos para eventos do calendário
      const calendarEvents = (agendamentosData.data || []).map((agendamento: Agendamento) => {
        // Calcular a data e hora de início
        const startDate = new Date(`${agendamento.data_agendada}T${agendamento.hora_agendada}`)

        // Calcular a data e hora de término
        let endDate
        if (agendamento.hora_fim) {
          endDate = new Date(`${agendamento.data_agendada}T${agendamento.hora_fim}`)
        } else if (agendamento.duracao_estimada_minutos) {
          endDate = new Date(startDate.getTime() + agendamento.duracao_estimada_minutos * 60000)
        } else {
          // Padrão: 1 hora de duração
          endDate = new Date(startDate.getTime() + 60 * 60000)
        }

        // Definir a cor do evento com base no status
        let backgroundColor
        switch (agendamento.status) {
          case "agendado":
            backgroundColor = "#3b82f6" // blue-500
            break
          case "confirmado":
            backgroundColor = "#10b981" // emerald-500
            break
          case "em_andamento":
            backgroundColor = "#f97316" // orange-500
            break
          case "concluido":
            backgroundColor = "#6366f1" // indigo-500
            break
          default:
            backgroundColor = "#6b7280" // gray-500
        }

        return {
          id: agendamento.id,
          title: `${agendamento.cliente_nome} - ${agendamento.tipo_servico}`,
          start: startDate,
          end: endDate,
          resource: {
            ...agendamento,
            backgroundColor,
          },
        }
      })

      setAllEvents(calendarEvents)
      applyMotoristaFilter(calendarEvents, motoristaFilter)
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os agendamentos",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Função para aplicar filtro por motorista
  const applyMotoristaFilter = (eventsToFilter: CalendarEvent[], filter: string) => {
    if (filter === "todos") {
      setEvents(eventsToFilter)
    } else {
      const filteredEvents = eventsToFilter.filter((event) => {
        const motoristaNome = event.resource?.motorista_nome || "Não atribuído"
        return motoristaNome === filter
      })
      setEvents(filteredEvents)
    }
  }

  // Efeito para aplicar filtro quando mudado
  useEffect(() => {
    applyMotoristaFilter(allEvents, motoristaFilter)
  }, [motoristaFilter, allEvents])

  useEffect(() => {
    loadAgendamentos()
  }, [])

  // Função para navegar para o mês anterior
  const goToPreviousMonth = () => {
    const newDate = new Date(currentDate)
    newDate.setMonth(newDate.getMonth() - 1)
    setCurrentDate(newDate)
  }

  // Função para navegar para o próximo mês
  const goToNextMonth = () => {
    const newDate = new Date(currentDate)
    newDate.setMonth(newDate.getMonth() + 1)
    setCurrentDate(newDate)
  }

  // Função para navegar para hoje
  const goToToday = () => {
    setCurrentDate(new Date())
  }

  // Estilo personalizado para os eventos
  const eventStyleGetter = (event: CalendarEvent) => {
    const backgroundColor = event.resource?.backgroundColor || "#3b82f6"
    return {
      style: {
        backgroundColor,
        borderRadius: "4px",
        opacity: 0.8,
        color: "white",
        border: "0px",
        display: "block",
      },
    }
  }

  // Contar agendamentos por motorista
  const getMotoristaStats = () => {
    const stats: { [key: string]: number } = {}
    allEvents.forEach((event) => {
      const motoristaNome = event.resource?.motorista_nome || "Não atribuído"
      stats[motoristaNome] = (stats[motoristaNome] || 0) + 1
    })
    return stats
  }

  const motoristaStats = getMotoristaStats()

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Calendário de Agendamentos
          </CardTitle>

          {/* Filtro por Motorista */}
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={motoristaFilter} onValueChange={setMotoristaFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por Motorista" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">
                  <div className="flex items-center justify-between w-full">
                    <span>Todos os Motoristas</span>
                    <Badge variant="secondary" className="ml-2">
                      {allEvents.length}
                    </Badge>
                  </div>
                </SelectItem>
                {motoristas.map((motorista) => (
                  <SelectItem key={motorista.id} value={motorista.nome}>
                    <div className="flex items-center justify-between w-full">
                      <span>{motorista.nome}</span>
                      <Badge variant="secondary" className="ml-2">
                        {motoristaStats[motorista.nome] || 0}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
                {motoristaStats["Não atribuído"] > 0 && (
                  <SelectItem value="Não atribuído">
                    <div className="flex items-center justify-between w-full">
                      <span>Não atribuído</span>
                      <Badge variant="secondary" className="ml-2">
                        {motoristaStats["Não atribuído"]}
                      </Badge>
                    </div>
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Resumo do filtro ativo */}
        {motoristaFilter !== "todos" && (
          <div className="mt-2 p-2 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Filtro ativo:</strong> Motorista: {motoristaFilter} | Mostrando {events.length} de{" "}
              {allEvents.length} agendamentos
            </p>
          </div>
        )}
      </CardHeader>

      <CardContent className="p-4">
        {/* Controles de navegação */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Hoje
            </Button>
            <Button variant="outline" size="sm" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <h2 className="text-lg font-semibold">{format(currentDate, "MMMM yyyy", { locale: ptBR })}</h2>
          <Button variant="outline" size="sm" onClick={loadAgendamentos}>
            Atualizar
          </Button>
        </div>

        <div className="h-[600px]">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Calendar
              localizer={localizer}
              events={events}
              startAccessor="start"
              endAccessor="end"
              style={{ height: "100%" }}
              date={currentDate}
              onNavigate={setCurrentDate}
              eventPropGetter={eventStyleGetter}
              views={["month", "week", "day", "agenda"]}
              messages={{
                today: "Hoje",
                previous: "Anterior",
                next: "Próximo",
                month: "Mês",
                week: "Semana",
                day: "Dia",
                agenda: "Agenda",
                date: "Data",
                time: "Hora",
                event: "Evento",
                noEventsInRange:
                  motoristaFilter !== "todos"
                    ? `Nenhum agendamento encontrado para ${motoristaFilter} neste período.`
                    : "Não há agendamentos neste período.",
              }}
              culture="pt-BR"
              onSelectEvent={onAppointmentClick}
              selectable={!!onNewAppointment}
              onSelectSlot={onNewAppointment}
            />
          )}
        </div>
      </CardContent>
    </Card>
  )
}
