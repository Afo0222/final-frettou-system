"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { User, Phone, Mail, Calendar, Clock, Truck, MapPin, CheckCircle, Search, UserCheck } from "lucide-react"
import { AgendamentoIntegradoService, type Motorista, type Veiculo } from "@/lib/services/agendamentos-integrado"
import { useToast } from "@/hooks/use-toast"
import { DriverScheduleConfig } from "@/components/motoristas/driver-schedule-config"

interface DriverSelectorProps {
  agendamento: any
  onDriverAssigned: () => void
}

export function DriverSelector({ agendamento, onDriverAssigned }: DriverSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [veiculos, setVeiculos] = useState<Veiculo[]>([])
  const [selectedMotorista, setSelectedMotorista] = useState<string>("")
  const [selectedVeiculo, setSelectedVeiculo] = useState<string>("")
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [observacoes, setObservacoes] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    if (isOpen) {
      loadData()
    }
  }, [isOpen])

  const loadData = async () => {
    try {
      setIsLoading(true)
      const [motoristasData, veiculosData] = await Promise.all([
        AgendamentoIntegradoService.getMotoristas(),
        AgendamentoIntegradoService.getVeiculos(),
      ])
      setMotoristas(motoristasData)
      setVeiculos(veiculosData)
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAssignDriver = async () => {
    if (!selectedMotorista) {
      toast({
        title: "Atenção",
        description: "Selecione um motorista",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      const motorista = motoristas.find((m) => m.id === selectedMotorista)
      const veiculo = veiculos.find((v) => v.id === selectedVeiculo)

      // Update the agendamento with driver and vehicle assignment
      await AgendamentoIntegradoService.assignDriver(agendamento.id, {
        motoristaId: selectedMotorista,
        motoristaNome: motorista?.nome || "",
        veiculoId: selectedVeiculo,
        veiculoInfo: veiculo ? `${veiculo.modelo} - ${veiculo.placa}` : "",
        observacoes: observacoes.trim(),
      })

      toast({
        title: "Sucesso",
        description: `Motorista ${motorista?.nome} atribuído com sucesso`,
      })

      setIsOpen(false)
      onDriverAssigned()
    } catch (error) {
      console.error("Erro ao atribuir motorista:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atribuir o motorista",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filteredMotoristas = motoristas.filter(
    (motorista) =>
      motorista.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      motorista.telefone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      motorista.email?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const selectedMotoristaData = motoristas.find((m) => m.id === selectedMotorista)
  const selectedVeiculoData = veiculos.find((v) => v.id === selectedVeiculo)

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const formatPhone = (phone: string) => {
    if (!phone) return ""
    return phone.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="text-blue-600">
          <UserCheck className="mr-1 h-4 w-4" />
          {agendamento.motorista?.nome !== "Motorista Padrão" ? "Alterar Motorista" : "Atribuir Motorista"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Atribuir Motorista ao Agendamento
          </DialogTitle>
          <DialogDescription>
            Selecione um motorista e veículo para o agendamento de <strong>{agendamento.cliente_nome}</strong> em{" "}
            <strong>{new Date(agendamento.data_agendada).toLocaleDateString("pt-BR")}</strong>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Agendamento Info */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Detalhes do Agendamento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{new Date(agendamento.data_agendada).toLocaleDateString("pt-BR")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{agendamento.hora_agendada}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span className="truncate">{agendamento.endereco_origem?.split(",")[0]}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span className="truncate">{agendamento.endereco_destino?.split(",")[0]}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Driver Search */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Buscar motorista por nome, telefone ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Driver List */}
            <div className="grid gap-3 max-h-60 overflow-y-auto">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : filteredMotoristas.length === 0 ? (
                <div className="text-center py-8">
                  <User className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    {searchTerm ? "Nenhum motorista encontrado" : "Nenhum motorista disponível"}
                  </p>
                </div>
              ) : (
                filteredMotoristas.map((motorista) => (
                  <Card
                    key={motorista.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedMotorista === motorista.id ? "ring-2 ring-primary bg-primary/5" : ""
                    }`}
                    onClick={() => setSelectedMotorista(motorista.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>{getInitials(motorista.nome)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{motorista.nome}</h4>
                            {selectedMotorista === motorista.id && <CheckCircle className="h-4 w-4 text-primary" />}
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            {motorista.telefone && (
                              <div className="flex items-center gap-1">
                                <Phone className="h-3 w-3" />
                                <span>{formatPhone(motorista.telefone)}</span>
                              </div>
                            )}
                            {motorista.email && (
                              <div className="flex items-center gap-1">
                                <Mail className="h-3 w-3" />
                                <span>{motorista.email}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <Badge variant={motorista.ativo ? "default" : "secondary"}>
                          {motorista.ativo ? "Ativo" : "Inativo"}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>

          {/* Vehicle Selection */}
          {selectedMotorista && (
            <div className="space-y-3">
              <Label htmlFor="veiculo">Veículo (Opcional)</Label>
              <Select value={selectedVeiculo} onValueChange={setSelectedVeiculo}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um veículo" />
                </SelectTrigger>
                <SelectContent>
                  {veiculos.map((veiculo) => (
                    <SelectItem key={veiculo.id} value={veiculo.id}>
                      <div className="flex items-center gap-2">
                        <Truck className="h-4 w-4" />
                        <span>
                          {veiculo.modelo} - {veiculo.placa}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Selected Driver Summary */}
          {selectedMotoristaData && (
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-primary" />
                  Motorista Selecionado
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>{getInitials(selectedMotoristaData.nome)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{selectedMotoristaData.nome}</h4>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      {selectedMotoristaData.telefone && <span>{formatPhone(selectedMotoristaData.telefone)}</span>}
                      {selectedMotoristaData.email && <span>{selectedMotoristaData.email}</span>}
                    </div>
                  </div>
                </div>
                {selectedVeiculoData && (
                  <div className="flex items-center gap-2 text-sm">
                    <Truck className="h-4 w-4 text-muted-foreground" />
                    <span>
                      {selectedVeiculoData.modelo} - {selectedVeiculoData.placa}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {selectedMotoristaData && (
            <div className="flex justify-center">
              <DriverScheduleConfig
                motorista={selectedMotoristaData}
                onConfigUpdated={() => {
                  // Refresh driver data if needed
                  loadData()
                }}
              />
            </div>
          )}

          {/* Observações */}
          {selectedMotorista && (
            <div className="space-y-3">
              <Label htmlFor="observacoes">Observações da Atribuição</Label>
              <Textarea
                id="observacoes"
                placeholder="Adicione observações sobre a atribuição do motorista..."
                value={observacoes}
                onChange={(e) => setObservacoes(e.target.value)}
                rows={3}
              />
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleAssignDriver} disabled={!selectedMotorista || isLoading}>
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Atribuindo...
              </>
            ) : (
              <>
                <UserCheck className="mr-2 h-4 w-4" />
                Atribuir Motorista
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
