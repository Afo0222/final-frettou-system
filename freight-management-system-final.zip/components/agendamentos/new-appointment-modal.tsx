"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, User, MapPin, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface NewAppointmentModalProps {
  isOpen: boolean
  onClose: () => void
  onCreated: () => void
  selectedDate?: Date
}

export function NewAppointmentModal({ isOpen, onClose, onCreated, selectedDate }: NewAppointmentModalProps) {
  const [isCreating, setIsCreating] = useState(false)
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    cliente_nome: "",
    cliente_telefone: "",
    data_agendada: selectedDate && selectedDate instanceof Date ? selectedDate.toISOString().split("T")[0] : "",
    hora_agendada: "08:00",
    endereco_origem: "",
    endereco_destino: "",
    observacoes: "",
  })

  useEffect(() => {
    if (selectedDate && selectedDate instanceof Date) {
      setFormData((prev) => ({
        ...prev,
        data_agendada: selectedDate.toISOString().split("T")[0],
      }))
    }
  }, [selectedDate])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      setIsCreating(true)

      // Here you would call your service to create the appointment
      // For now, we'll just show a success message

      toast({
        title: "Sucesso",
        description: "Agendamento criado com sucesso!",
      })

      onCreated()
      onClose()

      // Reset form
      setFormData({
        cliente_nome: "",
        cliente_telefone: "",
        data_agendada: selectedDate && selectedDate instanceof Date ? selectedDate.toISOString().split("T")[0] : "",
        hora_agendada: "08:00",
        endereco_origem: "",
        endereco_destino: "",
        observacoes: "",
      })
    } catch (error) {
      console.error("Erro ao criar agendamento:", error)
      toast({
        title: "Erro",
        description: "Não foi possível criar o agendamento",
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Novo Agendamento
          </DialogTitle>
          <DialogDescription>Preencha as informações para criar um novo agendamento</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Cliente Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <User className="h-5 w-5" />
              Informações do Cliente
            </h3>
            <div className="grid gap-4">
              <div>
                <Label htmlFor="cliente_nome">Nome do Cliente *</Label>
                <Input
                  id="cliente_nome"
                  value={formData.cliente_nome}
                  onChange={(e) => handleInputChange("cliente_nome", e.target.value)}
                  placeholder="Digite o nome do cliente"
                  required
                />
              </div>
              <div>
                <Label htmlFor="cliente_telefone">Telefone</Label>
                <Input
                  id="cliente_telefone"
                  value={formData.cliente_telefone}
                  onChange={(e) => handleInputChange("cliente_telefone", e.target.value)}
                  placeholder="(11) 99999-9999"
                />
              </div>
            </div>
          </div>

          {/* Date and Time */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Data e Horário
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="data_agendada">Data *</Label>
                <Input
                  id="data_agendada"
                  type="date"
                  value={formData.data_agendada}
                  onChange={(e) => handleInputChange("data_agendada", e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="hora_agendada">Horário *</Label>
                <Input
                  id="hora_agendada"
                  type="time"
                  value={formData.hora_agendada}
                  onChange={(e) => handleInputChange("hora_agendada", e.target.value)}
                  required
                />
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Localização
            </h3>
            <div className="grid gap-4">
              <div>
                <Label htmlFor="endereco_origem">Endereço de Origem</Label>
                <Input
                  id="endereco_origem"
                  value={formData.endereco_origem}
                  onChange={(e) => handleInputChange("endereco_origem", e.target.value)}
                  placeholder="Digite o endereço de origem"
                />
              </div>
              <div>
                <Label htmlFor="endereco_destino">Endereço de Destino</Label>
                <Input
                  id="endereco_destino"
                  value={formData.endereco_destino}
                  onChange={(e) => handleInputChange("endereco_destino", e.target.value)}
                  placeholder="Digite o endereço de destino"
                />
              </div>
            </div>
          </div>

          {/* Observations */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes}
                onChange={(e) => handleInputChange("observacoes", e.target.value)}
                placeholder="Digite observações adicionais"
                rows={3}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isCreating}>
              {isCreating ? "Criando..." : "Criar Agendamento"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
