"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { AlertTriangle, Calendar, Clock, User, MapPin, CheckCircle, Info } from "lucide-react"
import type { AgendamentoCompleto } from "@/lib/services/agendamentos-integrado"
import { AppointmentCancellationService } from "@/lib/services/appointment-cancellation-enhanced"
import { useToast } from "@/hooks/use-toast"

interface EnhancedCancellationModalProps {
  appointment: AgendamentoCompleto | null
  isOpen: boolean
  onClose: () => void
  onCancelled: () => void
}

const CANCELLATION_REASONS = [
  { value: "client_request", label: "Solicitação do cliente", category: "client" },
  { value: "client_no_show", label: "Cliente não compareceu", category: "client" },
  { value: "driver_unavailable", label: "Motorista indisponível", category: "driver" },
  { value: "driver_emergency", label: "Emergência do motorista", category: "driver" },
  { value: "vehicle_breakdown", label: "Problema no veículo", category: "vehicle" },
  { value: "vehicle_maintenance", label: "Manutenção do veículo", category: "vehicle" },
  { value: "weather_conditions", label: "Condições climáticas", category: "weather" },
  { value: "company_decision", label: "Decisão da empresa", category: "company" },
  { value: "duplicate_booking", label: "Agendamento duplicado", category: "company" },
  { value: "emergency", label: "Emergência", category: "emergency" },
  { value: "other", label: "Outro motivo", category: "other" },
]

const REASON_CATEGORIES = {
  client: { label: "Cliente", color: "bg-blue-500" },
  driver: { label: "Motorista", color: "bg-green-500" },
  vehicle: { label: "Veículo", color: "bg-yellow-500" },
  weather: { label: "Clima", color: "bg-gray-500" },
  company: { label: "Empresa", color: "bg-purple-500" },
  emergency: { label: "Emergência", color: "bg-red-500" },
  other: { label: "Outro", color: "bg-gray-400" },
}

export function EnhancedCancellationModal({
  appointment,
  isOpen,
  onClose,
  onCancelled,
}: EnhancedCancellationModalProps) {
  const [selectedReason, setSelectedReason] = useState("")
  const [additionalNotes, setAdditionalNotes] = useState("")
  const [preserveData, setPreserveData] = useState(true)
  const [notifyClient, setNotifyClient] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  if (!appointment) return null

  const selectedReasonData = CANCELLATION_REASONS.find((r) => r.value === selectedReason)
  const canCancel = appointment.status !== "concluido" && appointment.status !== "cancelado"

  const handleCancel = async () => {
    if (!selectedReason) {
      toast({
        title: "Erro",
        description: "Selecione um motivo para o cancelamento",
        variant: "destructive",
      })
      return
    }

    try {
      setIsProcessing(true)

      const result = await AppointmentCancellationService.cancelAppointment(appointment.id, {
        reason: selectedReasonData?.label || selectedReason,
        notes: additionalNotes.trim() || undefined,
        cancelledBy: "admin", // In a real app, this would be the current user
        preserveData,
      })

      toast({
        title: "Sucesso",
        description: result.message,
      })

      // Show additional info about freed time slot
      toast({
        title: "Horário Liberado",
        description: `${result.freedTimeSlot.date} às ${result.freedTimeSlot.time} para ${result.freedTimeSlot.driverName}`,
      })

      onCancelled()
      onClose()
      resetForm()
    } catch (error) {
      console.error("Erro ao cancelar agendamento:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao cancelar agendamento",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const resetForm = () => {
    setSelectedReason("")
    setAdditionalNotes("")
    setPreserveData(true)
    setNotifyClient(true)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Cancelar Agendamento
          </DialogTitle>
          <DialogDescription>
            Esta ação cancelará o agendamento e liberará o horário para novos agendamentos. Todos os dados serão
            preservados para rastreamento histórico.
          </DialogDescription>
        </DialogHeader>

        {!canCancel ? (
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Não é possível cancelar</span>
              </div>
              <p className="text-red-700 mt-2">
                {appointment.status === "concluido"
                  ? "Este agendamento já foi concluído"
                  : "Este agendamento já foi cancelado"}
              </p>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={onClose}>
                Fechar
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Resumo do Agendamento */}
            <div className="bg-muted/50 rounded-lg p-4 space-y-3">
              <h3 className="font-semibold flex items-center gap-2">
                <Info className="h-4 w-4" />
                Resumo do Agendamento
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <User className="h-3 w-3 text-muted-foreground" />
                    <span className="font-medium">{appointment.cliente_nome}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-3 w-3 text-muted-foreground" />
                    <span>{formatDate(appointment.data_agendada)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    <span>{appointment.hora_agendada}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <User className="h-3 w-3 text-muted-foreground" />
                    <span>{appointment.motorista?.nome || "Motorista não atribuído"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    <span className="truncate">
                      {appointment.endereco_origem?.split(",")[0] || "Origem não informada"}
                    </span>
                  </div>
                  {appointment.valor_servico && (
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Valor:</span>
                      <span className="font-medium">{formatCurrency(appointment.valor_servico)}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <Separator />

            {/* Motivo do Cancelamento */}
            <div className="space-y-3">
              <Label htmlFor="reason">Motivo do Cancelamento *</Label>
              <Select value={selectedReason} onValueChange={setSelectedReason}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o motivo" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(
                    CANCELLATION_REASONS.reduce(
                      (acc, reason) => {
                        if (!acc[reason.category]) acc[reason.category] = []
                        acc[reason.category].push(reason)
                        return acc
                      },
                      {} as Record<string, typeof CANCELLATION_REASONS>,
                    ),
                  ).map(([category, reasons]) => (
                    <div key={category}>
                      <div className="px-2 py-1 text-xs font-semibold text-muted-foreground uppercase">
                        {REASON_CATEGORIES[category as keyof typeof REASON_CATEGORIES]?.label}
                      </div>
                      {reasons.map((reason) => (
                        <SelectItem key={reason.value} value={reason.value}>
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-2 h-2 rounded-full ${REASON_CATEGORIES[reason.category as keyof typeof REASON_CATEGORIES]?.color}`}
                            />
                            {reason.label}
                          </div>
                        </SelectItem>
                      ))}
                    </div>
                  ))}
                </SelectContent>
              </Select>
              {selectedReasonData && (
                <Badge
                  variant="secondary"
                  className={`${REASON_CATEGORIES[selectedReasonData.category as keyof typeof REASON_CATEGORIES]?.color} text-white`}
                >
                  {REASON_CATEGORIES[selectedReasonData.category as keyof typeof REASON_CATEGORIES]?.label}
                </Badge>
              )}
            </div>

            {/* Observações Adicionais */}
            <div className="space-y-2">
              <Label htmlFor="notes">Observações Adicionais</Label>
              <Textarea
                id="notes"
                placeholder="Adicione observações sobre o cancelamento..."
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                rows={3}
              />
            </div>

            {/* Opções de Cancelamento */}
            <div className="space-y-3">
              <Label>Opções de Cancelamento</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="preserve-data" checked={preserveData} onCheckedChange={setPreserveData} />
                  <Label htmlFor="preserve-data" className="text-sm">
                    Preservar dados para rastreamento histórico
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="notify-client" checked={notifyClient} onCheckedChange={setNotifyClient} />
                  <Label htmlFor="notify-client" className="text-sm">
                    Notificar cliente sobre o cancelamento
                  </Label>
                </div>
              </div>
            </div>

            {/* Impacto do Cancelamento */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2 flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                Impacto do Cancelamento
              </h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Status será alterado para "Cancelado"</li>
                <li>
                  • Horário será liberado: {appointment.data_agendada} às {appointment.hora_agendada}
                </li>
                <li>• Motorista ficará disponível para novos agendamentos</li>
                <li>• Dados serão preservados para histórico</li>
                {notifyClient && <li>• Cliente será notificado automaticamente</li>}
              </ul>
            </div>

            {/* Ações */}
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={onClose} disabled={isProcessing}>
                Cancelar
              </Button>
              <Button
                variant="destructive"
                onClick={handleCancel}
                disabled={!selectedReason || isProcessing}
                className="flex items-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Processando...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-4 w-4" />
                    Confirmar Cancelamento
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
