"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  Calendar,
  Clock,
  User,
  MapPin,
  Truck,
  DollarSign,
  Phone,
  FileText,
  CheckCircle,
  XCircle,
  PlayCircle,
  Edit,
  Trash2,
} from "lucide-react"
import { type AgendamentoCompleto, AgendamentoIntegradoService } from "@/lib/services/agendamentos-integrado"
import { useToast } from "@/hooks/use-toast"
import { DriverSelector } from "./driver-selector"
import { SimpleCancellationModal } from "./simple-cancellation-modal"

interface AppointmentDetailsModalProps {
  appointment: AgendamentoCompleto | null
  isOpen: boolean
  onClose: () => void
  onUpdate: () => void
}

const statusConfig = {
  agendado: { label: "Agendado", color: "bg-blue-500", icon: Calendar },
  confirmado: { label: "Confirmado", color: "bg-green-500", icon: CheckCircle },
  em_andamento: { label: "Em Andamento", color: "bg-yellow-500", icon: PlayCircle },
  concluido: { label: "Concluído", color: "bg-green-700", icon: CheckCircle },
  cancelado: { label: "Cancelado", color: "bg-red-500", icon: XCircle },
  reagendado: { label: "Reagendado", color: "bg-purple-500", icon: Calendar },
}

export function AppointmentDetailsModal({ appointment, isOpen, onClose, onUpdate }: AppointmentDetailsModalProps) {
  const [isUpdating, setIsUpdating] = useState(false)
  const { toast } = useToast()
  const [isCancellationModalOpen, setIsCancellationModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  if (!appointment) return null

  const statusInfo = statusConfig[appointment.status as keyof typeof statusConfig] || {
    label: appointment.status,
    color: "bg-gray-500",
    icon: Calendar,
  }
  const StatusIcon = statusInfo.icon

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const handleStatusChange = async (newStatus: string) => {
    try {
      setIsUpdating(true)
      await AgendamentoIntegradoService.updateStatus(appointment.id, newStatus)
      toast({
        title: "Sucesso",
        description: `Status atualizado para ${statusConfig[newStatus as keyof typeof statusConfig]?.label || newStatus}`,
      })
      onUpdate()
      onClose()
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status",
        variant: "destructive",
      })
    } finally {
      setIsUpdating(false)
    }
  }

  const handleDeleteAppointment = async () => {
    try {
      setIsDeleting(true)
      await AgendamentoIntegradoService.delete(appointment.id)
      toast({
        title: "Sucesso",
        description: "Agendamento excluído com sucesso",
      })
      onUpdate()
      onClose()
      setIsDeleteModalOpen(false)
    } catch (error) {
      console.error("Erro ao excluir agendamento:", error)
      toast({
        title: "Erro",
        description: "Não foi possível excluir o agendamento",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const getStatusActions = () => {
    const actions = []

    switch (appointment.status) {
      case "agendado":
        actions.push(
          <Button
            key="confirm"
            size="sm"
            className="bg-green-600 hover:bg-green-700"
            onClick={() => handleStatusChange("confirmado")}
            disabled={isUpdating}
          >
            <CheckCircle className="mr-1 h-4 w-4" />
            Confirmar
          </Button>,
        )
        actions.push(
          <Button
            key="cancel"
            size="sm"
            variant="destructive"
            onClick={() => setIsCancellationModalOpen(true)}
            disabled={isUpdating}
          >
            <XCircle className="mr-1 h-4 w-4" />
            Cancelar
          </Button>,
        )
        break
      case "confirmado":
        actions.push(
          <Button
            key="start"
            size="sm"
            className="bg-yellow-600 hover:bg-yellow-700"
            onClick={() => handleStatusChange("em_andamento")}
            disabled={isUpdating}
          >
            <PlayCircle className="mr-1 h-4 w-4" />
            Iniciar
          </Button>,
        )
        actions.push(
          <Button
            key="cancel"
            size="sm"
            variant="destructive"
            onClick={() => setIsCancellationModalOpen(true)}
            disabled={isUpdating}
          >
            <XCircle className="mr-1 h-4 w-4" />
            Cancelar
          </Button>,
        )
        break
      case "em_andamento":
        actions.push(
          <Button
            key="complete"
            size="sm"
            className="bg-green-600 hover:bg-green-700"
            onClick={() => handleStatusChange("concluido")}
            disabled={isUpdating}
          >
            <CheckCircle className="mr-1 h-4 w-4" />
            Concluir
          </Button>,
        )
        break
    }

    return actions
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <StatusIcon className="h-5 w-5" />
            Detalhes do Agendamento
            <Badge variant="secondary" className={`${statusInfo.color} text-white`}>
              {statusInfo.label}
            </Badge>
          </DialogTitle>
          <DialogDescription>Informações completas do agendamento</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Cliente Information */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <User className="h-5 w-5" />
              Cliente
            </h3>
            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{appointment.cliente_nome || "Nome não informado"}</span>
              </div>
              {appointment.cliente_telefone && (
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{appointment.cliente_telefone}</span>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Date and Time */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Data e Horário
            </h3>
            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>{formatDate(appointment.data_agendada)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>{appointment.hora_agendada}</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Location */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Localização
            </h3>
            <div className="grid gap-2">
              <div>
                <span className="text-sm text-muted-foreground">Origem:</span>
                <p className="font-medium">{appointment.endereco_origem || "Não informado"}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Destino:</span>
                <p className="font-medium">{appointment.endereco_destino || "Não informado"}</p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Driver and Vehicle */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Truck className="h-5 w-5" />
              Motorista e Veículo
            </h3>
            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span>{appointment.motorista?.nome || "Motorista não atribuído"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 text-muted-foreground" />
                <span>
                  {appointment.veiculo
                    ? `${appointment.veiculo.modelo} - ${appointment.veiculo.placa}`
                    : "Veículo não atribuído"}
                </span>
              </div>
            </div>

            {/* Driver Assignment */}
            <div className="pt-2">
              <DriverSelector
                agendamento={appointment}
                onDriverAssigned={() => {
                  onUpdate()
                  onClose()
                }}
              />
            </div>
          </div>

          <Separator />

          {/* Service and Value */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Serviço e Valor
            </h3>
            <div className="grid gap-2">
              {appointment.tipo_servico && (
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span>{appointment.tipo_servico}</span>
                </div>
              )}
              {appointment.valor_servico && (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium text-lg">{formatCurrency(appointment.valor_servico)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Observations */}
          {appointment.observacoes && (
            <>
              <Separator />
              <div className="space-y-3">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Observações
                </h3>
                <p className="text-sm bg-muted p-3 rounded-lg">{appointment.observacoes}</p>
              </div>
            </>
          )}

          {/* Orçamento */}
          {appointment.orcamento && (
            <>
              <Separator />
              <div className="space-y-3">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Orçamento
                </h3>
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span>{appointment.orcamento.numero_orcamento}</span>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-2 pt-4 border-t">
          <Button variant="outline" size="sm">
            <Edit className="mr-1 h-4 w-4" />
            Editar
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={() => setIsDeleteModalOpen(true)}
            disabled={isUpdating}
          >
            <Trash2 className="mr-1 h-4 w-4" />
            Excluir
          </Button>
          {getStatusActions()}
        </div>
        <SimpleCancellationModal
          appointment={appointment}
          isOpen={isCancellationModalOpen}
          onClose={() => setIsCancellationModalOpen(false)}
          onCancelled={() => {
            onUpdate()
            onClose()
          }}
        />
      </DialogContent>
    </Dialog>\
    <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <Trash2 className="h-5 w-5" />
            Excluir Agendamento
          </DialogTitle>
          <DialogDescription>
            Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-red-50 p-3 rounded-lg">
            <p className="text-sm text-red-800">
              <strong>Cliente:</strong> {appointment.cliente_nome || "Não informado"}
            </p>
            <p className="text-sm text-red-800">
              <strong>Data:</strong> {formatDate(appointment.data_agendada)} às {appointment.hora_agendada}
            </p>
          </div>
          
          <div className="flex gap-2 justify-end">
            <Button
              variant="outline"
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={isDeleting}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteAppointment}
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Excluindo...
                </>
              ) : (
                <>
                  <Trash2 className="mr-1 h-4 w-4" />
                  Excluir
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
