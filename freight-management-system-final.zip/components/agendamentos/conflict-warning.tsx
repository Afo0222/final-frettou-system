"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Clock, User, CheckCircle, XCircle, Info, RefreshCw, Lightbulb } from "lucide-react"
import {
  SchedulingConflictService,
  type SchedulingConflict,
  type AppointmentSlot,
} from "@/lib/services/scheduling-conflicts"

interface ConflictWarningProps {
  appointment: AppointmentSlot
  driverConstraints: any
  onConflictsChecked: (conflicts: SchedulingConflict[]) => void
  excludeAppointmentId?: string
}

export function ConflictWarning({
  appointment,
  driverConstraints,
  onConflictsChecked,
  excludeAppointmentId,
}: ConflictWarningProps) {
  const [conflicts, setConflicts] = useState<SchedulingConflict[]>([])
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [isChecking, setIsChecking] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)

  useEffect(() => {
    if (appointment.motorista_id && appointment.date && appointment.start_time && appointment.end_time) {
      checkConflicts()
    }
  }, [appointment.motorista_id, appointment.date, appointment.start_time, appointment.end_time])

  const checkConflicts = async () => {
    try {
      setIsChecking(true)
      const detectedConflicts = await SchedulingConflictService.checkConflicts(
        appointment,
        driverConstraints,
        excludeAppointmentId,
      )
      setConflicts(detectedConflicts)
      onConflictsChecked(detectedConflicts)

      // If there are conflicts, get suggestions
      if (detectedConflicts.some((c) => c.severity === "error" || c.severity === "warning")) {
        const alternativeTimes = await SchedulingConflictService.suggestAlternativeTimes(
          appointment,
          driverConstraints,
          5,
        )
        setSuggestions(alternativeTimes)
      } else {
        setSuggestions([])
      }
    } catch (error) {
      console.error("Erro ao verificar conflitos:", error)
    } finally {
      setIsChecking(false)
    }
  }

  const getConflictIcon = (severity: string) => {
    switch (severity) {
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case "info":
        return <Info className="h-4 w-4 text-blue-500" />
      default:
        return <Info className="h-4 w-4" />
    }
  }

  const getConflictColor = (severity: string) => {
    switch (severity) {
      case "error":
        return "destructive"
      case "warning":
        return "default"
      case "info":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const hasBlockingConflicts = conflicts.some((c) => c.severity === "error")
  const hasWarnings = conflicts.some((c) => c.severity === "warning")

  if (isChecking) {
    return (
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
            <span className="text-sm text-blue-700">Verificando conflitos de agendamento...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (conflicts.length === 0) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="text-sm text-green-700">Nenhum conflito detectado. Agendamento disponível!</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Conflicts List */}
      <Card
        className={`border-${hasBlockingConflicts ? "red" : "yellow"}-200 bg-${hasBlockingConflicts ? "red" : "yellow"}-50`}
      >
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            {hasBlockingConflicts ? (
              <XCircle className="h-4 w-4 text-red-600" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
            )}
            {hasBlockingConflicts ? "Conflitos Detectados" : "Avisos de Agendamento"}
            <Badge variant={hasBlockingConflicts ? "destructive" : "default"} className="ml-2">
              {conflicts.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {conflicts.map((conflict, index) => (
            <Alert key={index} variant={getConflictColor(conflict.severity) as any}>
              <div className="flex items-start gap-2">
                {getConflictIcon(conflict.severity)}
                <div className="flex-1">
                  <AlertDescription className="text-sm">{conflict.message}</AlertDescription>
                  {conflict.conflicting_appointment && (
                    <div className="mt-2 text-xs text-muted-foreground">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {conflict.conflicting_appointment.cliente_nome}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {conflict.conflicting_appointment.hora_agendada}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Alert>
          ))}
        </CardContent>
      </Card>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-blue-600" />
              Horários Alternativos Sugeridos
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSuggestions(!showSuggestions)}
                className="ml-auto h-6 px-2"
              >
                {showSuggestions ? "Ocultar" : "Mostrar"}
              </Button>
            </CardTitle>
          </CardHeader>
          {showSuggestions && (
            <CardContent className="space-y-2">
              <div className="grid grid-cols-3 gap-2">
                {suggestions.map((time, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="justify-start text-blue-700 border-blue-300 hover:bg-blue-100"
                    onClick={() => {
                      // Here you would update the appointment time
                      console.log("Sugestão selecionada:", time)
                    }}
                  >
                    <Clock className="mr-1 h-3 w-3" />
                    {time}
                  </Button>
                ))}
              </div>
              <p className="text-xs text-blue-600 mt-2">Clique em um horário para aplicá-lo automaticamente</p>
            </CardContent>
          )}
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={checkConflicts}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Verificar Novamente
        </Button>
        {hasBlockingConflicts && (
          <Button variant="outline" size="sm" onClick={() => setShowSuggestions(true)}>
            <Lightbulb className="mr-2 h-4 w-4" />
            Ver Sugestões
          </Button>
        )}
      </div>
    </div>
  )
}
