"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Truck,
  Home,
  Zap,
  Building,
  Car,
  Clock,
  DollarSign,
  Users,
  Edit,
  Trash2,
  Eye,
  Copy,
  RotateCcw,
  MoreHorizontal,
  TrendingUp,
  Calculator,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import type { TipoServico } from "@/lib/types/tipos-servico"

interface ServiceTypeCardProps {
  tipoServico: TipoServico
  onEdit?: (tipoServico: TipoServico) => void
  onDelete?: (id: string) => void
  onView?: (tipoServico: TipoServico) => void
  onDuplicate?: (tipoServico: TipoServico) => void
  onReactivate?: (id: string) => void
  onCalculate?: (tipoServico: TipoServico) => void
  showActions?: boolean
  usageCount?: number
}

const iconMap = {
  truck: Truck,
  home: Home,
  zap: Zap,
  building: Building,
  car: Car,
}

export function ServiceTypeCard({
  tipoServico,
  onEdit,
  onDelete,
  onView,
  onDuplicate,
  onReactivate,
  onCalculate,
  showActions = true,
  usageCount = 0,
}: ServiceTypeCardProps) {
  const IconComponent = iconMap[tipoServico.icone as keyof typeof iconMap] || Truck

  const formatCurrency = (value?: number) => {
    if (!value) return "R$ 0,00"
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatTime = (minutes?: number) => {
    if (!minutes) return "N/A"
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return hours > 0 ? `${hours}h ${mins}min` : `${mins}min`
  }

  return (
    <Card className={`h-full transition-all hover:shadow-md ${!tipoServico.ativo ? "opacity-60" : ""}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-lg"
              style={{
                backgroundColor: `${tipoServico.cor}20`,
                color: tipoServico.cor,
              }}
            >
              <IconComponent className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-lg">{tipoServico.nome}</CardTitle>
              <CardDescription className="text-sm line-clamp-2">{tipoServico.descricao}</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {usageCount > 0 && (
              <Badge variant="outline" className="text-xs">
                <TrendingUp className="h-3 w-3 mr-1" />
                {usageCount}
              </Badge>
            )}
            {tipoServico.ativo ? (
              <Badge variant="default" className="bg-green-100 text-green-800">
                Ativo
              </Badge>
            ) : (
              <Badge variant="secondary">Inativo</Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Preços */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <DollarSign className="h-3 w-3" />
              Preço Base
            </div>
            <p className="font-semibold text-sm">{formatCurrency(tipoServico.preco_base)}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <DollarSign className="h-3 w-3" />
              Por KM
            </div>
            <p className="font-semibold text-sm">{formatCurrency(tipoServico.preco_km)}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Clock className="h-3 w-3" />
              Por Hora
            </div>
            <p className="font-semibold text-sm">{formatCurrency(tipoServico.preco_hora)}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Users className="h-3 w-3" />
              Ajudante
            </div>
            <p className="font-semibold text-sm">{formatCurrency(tipoServico.preco_ajudante)}</p>
          </div>
        </div>

        {/* Tempo médio */}
        {tipoServico.tempo_medio_minutos && (
          <div className="flex items-center justify-between p-2 bg-muted rounded-lg">
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-muted-foreground" />
              Tempo médio
            </div>
            <span className="font-medium text-sm">{formatTime(tipoServico.tempo_medio_minutos)}</span>
          </div>
        )}

        {/* Actions */}
        {showActions && (
          <div className="flex gap-2 pt-2">
            {onView && (
              <Button variant="outline" size="sm" onClick={() => onView(tipoServico)}>
                <Eye className="h-4 w-4 mr-1" />
                Ver
              </Button>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {onCalculate && (
                  <DropdownMenuItem onClick={() => onCalculate(tipoServico)}>
                    <Calculator className="h-4 w-4 mr-2" />
                    Calcular Preço
                  </DropdownMenuItem>
                )}
                {onEdit && tipoServico.ativo && (
                  <DropdownMenuItem onClick={() => onEdit(tipoServico)}>
                    <Edit className="h-4 w-4 mr-2" />
                    Editar
                  </DropdownMenuItem>
                )}
                {onDuplicate && (
                  <DropdownMenuItem onClick={() => onDuplicate(tipoServico)}>
                    <Copy className="h-4 w-4 mr-2" />
                    Duplicar
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                {!tipoServico.ativo && onReactivate ? (
                  <DropdownMenuItem onClick={() => onReactivate(tipoServico.id)}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reativar
                  </DropdownMenuItem>
                ) : (
                  onDelete && (
                    <DropdownMenuItem
                      onClick={() => onDelete(tipoServico.id)}
                      className="text-red-600 focus:text-red-600"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Desativar
                    </DropdownMenuItem>
                  )
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
