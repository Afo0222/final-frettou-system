"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Truck,
  Home,
  Zap,
  Building,
  Car,
  Clock,
  DollarSign,
  Users,
  Package,
  Settings,
  TrendingUp,
  Edit,
} from "lucide-react"
import { TipoServicoRealService } from "@/lib/services/tipos-servico-real"
import type { TipoServico, VariavelCusto, ServicoExtra } from "@/lib/types/tipos-servico"

interface ServiceTypeDetailsProps {
  isOpen: boolean
  onClose: () => void
  tipoServico: TipoServico | null
  onEdit?: (tipoServico: TipoServico) => void
}

const iconMap = {
  truck: Truck,
  home: Home,
  zap: Zap,
  building: Building,
  car: Car,
}

export function ServiceTypeDetails({ isOpen, onClose, tipoServico, onEdit }: ServiceTypeDetailsProps) {
  const [variaveisCusto, setVariaveisCusto] = useState<VariavelCusto[]>([])
  const [servicosExtras, setServicosExtras] = useState<ServicoExtra[]>([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (isOpen && tipoServico) {
      loadDetails()
    }
  }, [isOpen, tipoServico])

  const loadDetails = async () => {
    if (!tipoServico) return

    setIsLoading(true)
    try {
      const [variaveis, extras] = await Promise.all([
        TipoServicoRealService.getAllVariaveisCusto(tipoServico.id),
        TipoServicoRealService.getAllServicosExtras(tipoServico.id),
      ])
      setVariaveisCusto(variaveis)
      setServicosExtras(extras.filter((e) => e.tipo_servico_id === tipoServico.id))
    } catch (error) {
      console.error("Erro ao carregar detalhes:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (!tipoServico) return null

  const IconComponent = iconMap[tipoServico.icone as keyof typeof iconMap] || Truck

  const formatCurrency = (value?: number) => {
    if (!value) return "R$ 0,00"
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatTime = (minutes?: number) => {
    if (!minutes) return "N/A"
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return hours > 0 ? `${hours}h ${mins}min` : `${mins}min`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-lg"
              style={{
                backgroundColor: `${tipoServico.cor}20`,
                color: tipoServico.cor,
              }}
            >
              <IconComponent className="h-6 w-6" />
            </div>
            <div>
              <DialogTitle className="text-xl">{tipoServico.nome}</DialogTitle>
              <DialogDescription>{tipoServico.descricao}</DialogDescription>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {tipoServico.ativo ? (
                <Badge variant="default" className="bg-green-100 text-green-800">
                  Ativo
                </Badge>
              ) : (
                <Badge variant="secondary">Inativo</Badge>
              )}
              {onEdit && (
                <Button variant="outline" size="sm" onClick={() => onEdit(tipoServico)}>
                  <Edit className="h-4 w-4 mr-1" />
                  Editar
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="geral" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="geral">Geral</TabsTrigger>
            <TabsTrigger value="precos">Preços</TabsTrigger>
            <TabsTrigger value="variaveis">Variáveis</TabsTrigger>
            <TabsTrigger value="extras">Extras</TabsTrigger>
          </TabsList>

          <TabsContent value="geral" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Informações Básicas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Nome</label>
                    <p className="font-semibold">{tipoServico.nome}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Descrição</label>
                    <p className="text-sm">{tipoServico.descricao || "Sem descrição"}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Ícone</label>
                      <p className="text-sm capitalize">{tipoServico.icone}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Cor</label>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded border" style={{ backgroundColor: tipoServico.cor }} />
                        <span className="text-sm">{tipoServico.cor}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Tempo e Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Tempo Médio</label>
                    <p className="font-semibold">{formatTime(tipoServico.tempo_medio_minutos)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Status</label>
                    <p className="font-semibold">{tipoServico.ativo ? "Ativo" : "Inativo"}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Criado em</label>
                    <p className="text-sm">{formatDate(tipoServico.created_at)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Atualizado em</label>
                    <p className="text-sm">{formatDate(tipoServico.updated_at)}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="precos" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Estrutura de Preços
                </CardTitle>
                <CardDescription>Configuração de preços base e variáveis para cálculo de orçamentos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Preço Base</span>
                      </div>
                      <p className="text-2xl font-bold text-green-600">{formatCurrency(tipoServico.preco_base)}</p>
                      <p className="text-sm text-muted-foreground">Valor fixo inicial</p>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Por Quilômetro</span>
                      </div>
                      <p className="text-2xl font-bold text-blue-600">{formatCurrency(tipoServico.preco_km)}</p>
                      <p className="text-sm text-muted-foreground">Multiplicado pela distância</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Por Hora</span>
                      </div>
                      <p className="text-2xl font-bold text-orange-600">{formatCurrency(tipoServico.preco_hora)}</p>
                      <p className="text-sm text-muted-foreground">Multiplicado pelo tempo</p>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Por Ajudante</span>
                      </div>
                      <p className="text-2xl font-bold text-purple-600">{formatCurrency(tipoServico.preco_ajudante)}</p>
                      <p className="text-sm text-muted-foreground">Por ajudante adicional</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Exemplo de Cálculo</h4>
                  <div className="text-sm space-y-1">
                    <p>• Preço Base: {formatCurrency(tipoServico.preco_base)}</p>
                    <p>
                      • 10 km × {formatCurrency(tipoServico.preco_km)} ={" "}
                      {formatCurrency((tipoServico.preco_km || 0) * 10)}
                    </p>
                    <p>
                      • 2 horas × {formatCurrency(tipoServico.preco_hora)} ={" "}
                      {formatCurrency((tipoServico.preco_hora || 0) * 2)}
                    </p>
                    <p>
                      • 1 ajudante × {formatCurrency(tipoServico.preco_ajudante)} ={" "}
                      {formatCurrency(tipoServico.preco_ajudante)}
                    </p>
                    <div className="border-t pt-2 mt-2">
                      <p className="font-semibold">
                        Total:{" "}
                        {formatCurrency(
                          (tipoServico.preco_base || 0) +
                            (tipoServico.preco_km || 0) * 10 +
                            (tipoServico.preco_hora || 0) * 2 +
                            (tipoServico.preco_ajudante || 0),
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="variaveis" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Variáveis de Custo
                </CardTitle>
                <CardDescription>Custos adicionais aplicados automaticamente a este tipo de serviço</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : variaveisCusto.length > 0 ? (
                  <div className="space-y-3">
                    {variaveisCusto.map((variavel) => (
                      <div key={variavel.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{variavel.nome}</h4>
                            {!variavel.ativo && (
                              <Badge variant="secondary" className="text-xs">
                                Inativo
                              </Badge>
                            )}
                          </div>
                          {variavel.descricao && <p className="text-sm text-muted-foreground">{variavel.descricao}</p>}
                          <p className="text-xs text-muted-foreground">Unidade: {variavel.unidade}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-lg">{formatCurrency(variavel.valor)}</p>
                        </div>
                      </div>
                    ))}
                    <div className="mt-4 p-3 bg-muted rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Total das Variáveis:</span>
                        <span className="font-bold text-lg">
                          {formatCurrency(
                            variaveisCusto.filter((v) => v.ativo).reduce((total, v) => total + v.valor, 0),
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Nenhuma variável de custo configurada</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="extras" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Serviços Extras
                </CardTitle>
                <CardDescription>Serviços adicionais disponíveis para este tipo de serviço</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : servicosExtras.length > 0 ? (
                  <div className="grid gap-3 md:grid-cols-2">
                    {servicosExtras.map((servico) => (
                      <div key={servico.id} className="p-4 border rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-medium">{servico.nome}</h4>
                          <div className="flex gap-1">
                            {!servico.ativo && (
                              <Badge variant="secondary" className="text-xs">
                                Inativo
                              </Badge>
                            )}
                            {servico.disponivel_todos_tipos && (
                              <Badge variant="outline" className="text-xs">
                                Global
                              </Badge>
                            )}
                          </div>
                        </div>
                        {servico.descricao && <p className="text-sm text-muted-foreground mb-2">{servico.descricao}</p>}
                        <p className="font-semibold text-green-600">{formatCurrency(servico.valor)}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Nenhum serviço extra configurado</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
