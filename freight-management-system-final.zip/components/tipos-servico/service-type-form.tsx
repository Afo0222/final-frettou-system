"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Plus, Trash2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { TipoServicoRealService } from "@/lib/services/tipos-servico-real"
import type { TipoServico, VariavelCusto, ServicoExtra } from "@/lib/types/tipos-servico"

interface ServiceTypeFormProps {
  isOpen: boolean
  onClose: () => void
  onSave: (tipoServico: TipoServico) => void
  tipoServico?: TipoServico | null
}

const iconOptions = [
  { value: "truck", label: "Caminhão", icon: "🚛" },
  { value: "home", label: "Casa", icon: "🏠" },
  { value: "zap", label: "Raio", icon: "⚡" },
  { value: "building", label: "Prédio", icon: "🏢" },
  { value: "car", label: "Carro", icon: "🚗" },
]

const colorOptions = [
  { value: "#3b82f6", label: "Azul", color: "#3b82f6" },
  { value: "#10b981", label: "Verde", color: "#10b981" },
  { value: "#ef4444", label: "Vermelho", color: "#ef4444" },
  { value: "#f59e0b", label: "Amarelo", color: "#f59e0b" },
  { value: "#8b5cf6", label: "Roxo", color: "#8b5cf6" },
  { value: "#06b6d4", label: "Ciano", color: "#06b6d4" },
  { value: "#84cc16", label: "Lima", color: "#84cc16" },
  { value: "#f97316", label: "Laranja", color: "#f97316" },
]

export function ServiceTypeForm({ isOpen, onClose, onSave, tipoServico }: ServiceTypeFormProps) {
  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    icone: "truck",
    cor: "#3b82f6",
    tempo_medio_minutos: 120,
    preco_base: 0,
    preco_km: 0,
    preco_hora: 0,
    preco_ajudante: 0,
    ativo: true,
  })

  const [variaveisCusto, setVariaveisCusto] = useState<VariavelCusto[]>([])
  const [servicosExtras, setServicosExtras] = useState<ServicoExtra[]>([])
  const [novaVariavel, setNovaVariavel] = useState({ nome: "", descricao: "", valor: 0, unidade: "fixo" })
  const [novoServico, setNovoServico] = useState({
    nome: "",
    descricao: "",
    valor: 0,
    disponivel_todos_tipos: false,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (isOpen) {
      if (tipoServico) {
        // Edit mode
        setFormData({
          nome: tipoServico.nome,
          descricao: tipoServico.descricao || "",
          icone: tipoServico.icone || "truck",
          cor: tipoServico.cor || "#3b82f6",
          tempo_medio_minutos: tipoServico.tempo_medio_minutos || 120,
          preco_base: tipoServico.preco_base || 0,
          preco_km: tipoServico.preco_km || 0,
          preco_hora: tipoServico.preco_hora || 0,
          preco_ajudante: tipoServico.preco_ajudante || 0,
          ativo: tipoServico.ativo,
        })
        loadRelatedData(tipoServico.id)
      } else {
        // Create mode
        resetForm()
      }
      setErrors({})
    }
  }, [isOpen, tipoServico])

  const resetForm = () => {
    setFormData({
      nome: "",
      descricao: "",
      icone: "truck",
      cor: "#3b82f6",
      tempo_medio_minutos: 120,
      preco_base: 0,
      preco_km: 0,
      preco_hora: 0,
      preco_ajudante: 0,
      ativo: true,
    })
    setVariaveisCusto([])
    setServicosExtras([])
    setNovaVariavel({ nome: "", descricao: "", valor: 0, unidade: "fixo" })
    setNovoServico({ nome: "", descricao: "", valor: 0, disponivel_todos_tipos: false })
  }

  const loadRelatedData = async (tipoServicoId: string) => {
    try {
      const [variaveis, extras] = await Promise.all([
        TipoServicoRealService.getAllVariaveisCusto(tipoServicoId),
        TipoServicoRealService.getAllServicosExtras(tipoServicoId),
      ])
      setVariaveisCusto(variaveis)
      setServicosExtras(extras.filter((e) => e.tipo_servico_id === tipoServicoId))
    } catch (error) {
      console.error("Erro ao carregar dados relacionados:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados relacionados",
        variant: "destructive",
      })
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.nome.trim()) {
      newErrors.nome = "Nome é obrigatório"
    }

    if (formData.preco_base < 0) {
      newErrors.preco_base = "Preço base não pode ser negativo"
    }

    if (formData.preco_km < 0) {
      newErrors.preco_km = "Preço por km não pode ser negativo"
    }

    if (formData.preco_hora < 0) {
      newErrors.preco_hora = "Preço por hora não pode ser negativo"
    }

    if (formData.preco_ajudante < 0) {
      newErrors.preco_ajudante = "Preço por ajudante não pode ser negativo"
    }

    if (formData.tempo_medio_minutos <= 0) {
      newErrors.tempo_medio_minutos = "Tempo médio deve ser maior que zero"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Erro de validação",
        description: "Verifique os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      let result: TipoServico
      if (tipoServico) {
        result = await TipoServicoRealService.update(tipoServico.id, formData)
      } else {
        result = await TipoServicoRealService.create(formData)
      }

      onSave(result)
      onClose()
    } catch (error) {
      console.error("Erro ao salvar tipo de serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar o tipo de serviço",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const adicionarVariavel = async () => {
    if (!novaVariavel.nome.trim() || !tipoServico) return

    try {
      const variavel = await TipoServicoRealService.createVariavelCusto({
        tipo_servico_id: tipoServico.id,
        nome: novaVariavel.nome,
        descricao: novaVariavel.descricao,
        valor: novaVariavel.valor,
        unidade: novaVariavel.unidade,
        ativo: true,
      })
      setVariaveisCusto([...variaveisCusto, variavel])
      setNovaVariavel({ nome: "", descricao: "", valor: 0, unidade: "fixo" })
      toast({
        title: "Sucesso",
        description: "Variável de custo adicionada",
      })
    } catch (error) {
      console.error("Erro ao adicionar variável:", error)
      toast({
        title: "Erro",
        description: "Não foi possível adicionar a variável",
        variant: "destructive",
      })
    }
  }

  const removerVariavel = async (id: string) => {
    try {
      await TipoServicoRealService.deleteVariavelCusto(id)
      setVariaveisCusto(variaveisCusto.filter((v) => v.id !== id))
      toast({
        title: "Sucesso",
        description: "Variável de custo removida",
      })
    } catch (error) {
      console.error("Erro ao remover variável:", error)
      toast({
        title: "Erro",
        description: "Não foi possível remover a variável",
        variant: "destructive",
      })
    }
  }

  const adicionarServico = async () => {
    if (!novoServico.nome.trim() || !tipoServico) return

    try {
      const servico = await TipoServicoRealService.createServicoExtra({
        nome: novoServico.nome,
        descricao: novoServico.descricao,
        valor: novoServico.valor,
        tipo_servico_id: tipoServico.id,
        disponivel_todos_tipos: novoServico.disponivel_todos_tipos,
        ativo: true,
      })
      setServicosExtras([...servicosExtras, servico])
      setNovoServico({ nome: "", descricao: "", valor: 0, disponivel_todos_tipos: false })
      toast({
        title: "Sucesso",
        description: "Serviço extra adicionado",
      })
    } catch (error) {
      console.error("Erro ao adicionar serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível adicionar o serviço",
        variant: "destructive",
      })
    }
  }

  const removerServico = async (id: string) => {
    try {
      await TipoServicoRealService.deleteServicoExtra(id)
      setServicosExtras(servicosExtras.filter((s) => s.id !== id))
      toast({
        title: "Sucesso",
        description: "Serviço extra removido",
      })
    } catch (error) {
      console.error("Erro ao remover serviço:", error)
      toast({
        title: "Erro",
        description: "Não foi possível remover o serviço",
        variant: "destructive",
      })
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{tipoServico ? "Editar Tipo de Serviço" : "Novo Tipo de Serviço"}</DialogTitle>
          <DialogDescription>Configure os detalhes do tipo de serviço, preços e custos associados.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Informações Básicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    className={errors.nome ? "border-red-500" : ""}
                    required
                  />
                  {errors.nome && <p className="text-sm text-red-500">{errors.nome}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tempo_medio_minutos">Tempo Médio (minutos)</Label>
                  <Input
                    id="tempo_medio_minutos"
                    type="number"
                    min="1"
                    value={formData.tempo_medio_minutos}
                    onChange={(e) => setFormData({ ...formData, tempo_medio_minutos: Number(e.target.value) })}
                    className={errors.tempo_medio_minutos ? "border-red-500" : ""}
                  />
                  {errors.tempo_medio_minutos && <p className="text-sm text-red-500">{errors.tempo_medio_minutos}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  rows={3}
                  placeholder="Descreva o tipo de serviço..."
                />
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="icone">Ícone</Label>
                  <Select value={formData.icone} onValueChange={(value) => setFormData({ ...formData, icone: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {iconOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <span>{option.icon}</span>
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cor">Cor</Label>
                  <Select value={formData.cor} onValueChange={(value) => setFormData({ ...formData, cor: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {colorOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 rounded" style={{ backgroundColor: option.color }} />
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ativo">Status</Label>
                  <div className="flex items-center space-x-2 pt-2">
                    <Switch
                      id="ativo"
                      checked={formData.ativo}
                      onCheckedChange={(checked) => setFormData({ ...formData, ativo: checked })}
                    />
                    <Label htmlFor="ativo">{formData.ativo ? "Ativo" : "Inativo"}</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pricing Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Configuração de Preços</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="preco_base">Preço Base (R$)</Label>
                  <Input
                    id="preco_base"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.preco_base}
                    onChange={(e) => setFormData({ ...formData, preco_base: Number(e.target.value) })}
                    className={errors.preco_base ? "border-red-500" : ""}
                  />
                  {errors.preco_base && <p className="text-sm text-red-500">{errors.preco_base}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="preco_km">Preço por KM (R$)</Label>
                  <Input
                    id="preco_km"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.preco_km}
                    onChange={(e) => setFormData({ ...formData, preco_km: Number(e.target.value) })}
                    className={errors.preco_km ? "border-red-500" : ""}
                  />
                  {errors.preco_km && <p className="text-sm text-red-500">{errors.preco_km}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="preco_hora">Preço por Hora (R$)</Label>
                  <Input
                    id="preco_hora"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.preco_hora}
                    onChange={(e) => setFormData({ ...formData, preco_hora: Number(e.target.value) })}
                    className={errors.preco_hora ? "border-red-500" : ""}
                  />
                  {errors.preco_hora && <p className="text-sm text-red-500">{errors.preco_hora}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="preco_ajudante">Preço por Ajudante (R$)</Label>
                  <Input
                    id="preco_ajudante"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.preco_ajudante}
                    onChange={(e) => setFormData({ ...formData, preco_ajudante: Number(e.target.value) })}
                    className={errors.preco_ajudante ? "border-red-500" : ""}
                  />
                  {errors.preco_ajudante && <p className="text-sm text-red-500">{errors.preco_ajudante}</p>}
                </div>
              </div>

              {/* Price Preview */}
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Exemplo de Cálculo (10km, 2h, 1 ajudante)</h4>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span>Preço Base:</span>
                    <span>{formatCurrency(formData.preco_base)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>10 km × {formatCurrency(formData.preco_km)}:</span>
                    <span>{formatCurrency(formData.preco_km * 10)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>2 horas × {formatCurrency(formData.preco_hora)}:</span>
                    <span>{formatCurrency(formData.preco_hora * 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>1 ajudante × {formatCurrency(formData.preco_ajudante)}:</span>
                    <span>{formatCurrency(formData.preco_ajudante)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold">
                    <span>Total:</span>
                    <span>
                      {formatCurrency(
                        formData.preco_base +
                          formData.preco_km * 10 +
                          formData.preco_hora * 2 +
                          formData.preco_ajudante,
                      )}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Cost Variables - only show if editing */}
          {tipoServico && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Variáveis de Custo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {variaveisCusto.map((variavel) => (
                  <div key={variavel.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium">{variavel.nome}</p>
                      {variavel.descricao && <p className="text-sm text-muted-foreground">{variavel.descricao}</p>}
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">{formatCurrency(variavel.valor)}</Badge>
                        <Badge variant="secondary">{variavel.unidade}</Badge>
                        {!variavel.ativo && <Badge variant="destructive">Inativo</Badge>}
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removerVariavel(variavel.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                <div className="grid gap-2 md:grid-cols-5">
                  <Input
                    placeholder="Nome da variável"
                    value={novaVariavel.nome}
                    onChange={(e) => setNovaVariavel({ ...novaVariavel, nome: e.target.value })}
                  />
                  <Input
                    placeholder="Descrição"
                    value={novaVariavel.descricao}
                    onChange={(e) => setNovaVariavel({ ...novaVariavel, descricao: e.target.value })}
                  />
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="Valor"
                    value={novaVariavel.valor}
                    onChange={(e) => setNovaVariavel({ ...novaVariavel, valor: Number(e.target.value) })}
                  />
                  <Select
                    value={novaVariavel.unidade}
                    onValueChange={(value) => setNovaVariavel({ ...novaVariavel, unidade: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixo">Fixo</SelectItem>
                      <SelectItem value="percentual">Percentual</SelectItem>
                      <SelectItem value="por_km">Por KM</SelectItem>
                      <SelectItem value="por_hora">Por Hora</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button type="button" onClick={adicionarVariavel} disabled={!novaVariavel.nome.trim()}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Extra Services - only show if editing */}
          {tipoServico && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Serviços Extras</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {servicosExtras.map((servico) => (
                  <div key={servico.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium">{servico.nome}</p>
                      {servico.descricao && <p className="text-sm text-muted-foreground">{servico.descricao}</p>}
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">{formatCurrency(servico.valor)}</Badge>
                        {servico.disponivel_todos_tipos && <Badge variant="secondary">Global</Badge>}
                        {!servico.ativo && <Badge variant="destructive">Inativo</Badge>}
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removerServico(servico.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                <div className="grid gap-2 md:grid-cols-5">
                  <Input
                    placeholder="Nome do serviço"
                    value={novoServico.nome}
                    onChange={(e) => setNovoServico({ ...novoServico, nome: e.target.value })}
                  />
                  <Input
                    placeholder="Descrição"
                    value={novoServico.descricao}
                    onChange={(e) => setNovoServico({ ...novoServico, descricao: e.target.value })}
                  />
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="Valor"
                    value={novoServico.valor}
                    onChange={(e) => setNovoServico({ ...novoServico, valor: Number(e.target.value) })}
                  />
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={novoServico.disponivel_todos_tipos}
                      onCheckedChange={(checked) => setNovoServico({ ...novoServico, disponivel_todos_tipos: checked })}
                    />
                    <Label className="text-sm">Global</Label>
                  </div>
                  <Button type="button" onClick={adicionarServico} disabled={!novoServico.nome.trim()}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Salvando..." : tipoServico ? "Atualizar" : "Criar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
