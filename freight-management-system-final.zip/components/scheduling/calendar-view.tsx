"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Clock, User, MapPin, Plus } from "lucide-react"
import { AgendamentoService, type Agendamento, type Motorista } from "@/lib/services/agendamentos"
import { format, startOfWeek, endOfWeek, eachDayOfInterval, addWeeks, subWeeks, isSameDay } from "date-fns"
import { ptBR } from "date-fns/locale"

interface CalendarViewProps {
  onAppointmentClick?: (appointment: Agendamento) => void
  onNewAppointment?: (date: Date, motorista?: Motorista) => void
}

export function CalendarView({ onAppointmentClick, onNewAppointment }: CalendarViewProps) {
  const [currentWeek, setCurrentWeek] = useState(new Date())
  const [appointments, setAppointments] = useState<Agendamento[]>([])
  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [selectedMotorista, setSelectedMotorista] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)

  const weekStart = startOfWeek(currentWeek, { locale: ptBR })
  const weekEnd = endOfWeek(currentWeek, { locale: ptBR })
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd })

  useEffect(() => {
    loadData()
  }, [currentWeek, selectedMotorista])

  const loadData = async () => {
    try {
      setIsLoading(true)
      const [appointmentsData, motoristasData] = await Promise.all([
        AgendamentoService.getByDateRange(format(weekStart, "yyyy-MM-dd"), format(weekEnd, "yyyy-MM-dd")),
        AgendamentoService.getMotoristas(),
      ])

      let filteredAppointments = appointmentsData
      if (selectedMotorista !== "all") {
        filteredAppointments = appointmentsData.filter((apt) => apt.motorista_id === selectedMotorista)
      }

      setAppointments(filteredAppointments)
      setMotoristas(motoristasData)
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getAppointmentsForDay = (date: Date) => {
    return appointments.filter((apt) => isSameDay(new Date(apt.data_agendada), date))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "agendado":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "confirmado":
        return "bg-green-100 text-green-800 border-green-200"
      case "em_andamento":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "concluido":
        return "bg-gray-100 text-gray-800 border-gray-200"
      case "cancelado":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (prioridade?: string) => {
    switch (prioridade) {
      case "urgente":
        return "border-l-4 border-l-red-500"
      case "alta":
        return "border-l-4 border-l-orange-500"
      case "normal":
        return "border-l-4 border-l-blue-500"
      case "baixa":
        return "border-l-4 border-l-gray-500"
      default:
        return "border-l-4 border-l-blue-500"
    }
  }

  const formatTime = (time?: string) => {
    if (!time) return ""
    return time.slice(0, 5) // Remove seconds
  }

  const AppointmentCard = ({ appointment }: { appointment: Agendamento }) => (
    <div
      className={`p-2 mb-2 rounded-lg border cursor-pointer hover:shadow-md transition-shadow ${getStatusColor(
        appointment.status,
      )} ${getPriorityColor(appointment.prioridade)}`}
      onClick={() => onAppointmentClick?.(appointment)}
    >
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          <span className="text-xs font-medium">
            {formatTime(appointment.hora_inicio)} - {formatTime(appointment.hora_fim)}
          </span>
        </div>
        <Badge variant="outline" className="text-xs">
          {appointment.duracao_estimada_minutos}min
        </Badge>
      </div>

      <div className="space-y-1">
        <div className="flex items-center gap-1">
          <User className="h-3 w-3" />
          <span className="text-xs font-medium">{appointment.cliente_nome || "Cliente não informado"}</span>
        </div>

        {appointment.motorista && (
          <div className="flex items-center gap-1">
            <User className="h-3 w-3 text-blue-600" />
            <span className="text-xs text-blue-600">{appointment.motorista.nome}</span>
          </div>
        )}

        <div className="flex items-center gap-1">
          <MapPin className="h-3 w-3" />
          <span className="text-xs truncate">
            {appointment.endereco_origem?.split(",")[0] || "Origem"} →{" "}
            {appointment.endereco_destino?.split(",")[0] || "Destino"}
          </span>
        </div>

        {appointment.tipo_servico && (
          <Badge variant="outline" className="text-xs">
            {appointment.tipo_servico}
          </Badge>
        )}
      </div>
    </div>
  )

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Calendário de Agendamentos
          </CardTitle>
          <div className="flex items-center gap-2">
            <Select value={selectedMotorista} onValueChange={setSelectedMotorista}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por motorista" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os motoristas</SelectItem>
                {motoristas.map((motorista) => (
                  <SelectItem key={motorista.id} value={motorista.id}>
                    {motorista.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <h3 className="text-lg font-semibold">
              {format(weekStart, "dd MMM", { locale: ptBR })} - {format(weekEnd, "dd MMM yyyy", { locale: ptBR })}
            </h3>
            <Button variant="outline" size="sm" onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <Button onClick={() => onNewAppointment?.(new Date())} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Novo Agendamento
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="grid grid-cols-7 gap-4">
            {weekDays.map((day) => {
              const dayAppointments = getAppointmentsForDay(day)
              const isToday = isSameDay(day, new Date())

              return (
                <div key={day.toISOString()} className="min-h-[300px]">
                  <div
                    className={`p-2 text-center border-b-2 mb-2 ${
                      isToday ? "border-primary bg-primary/5" : "border-gray-200"
                    }`}
                  >
                    <div className="font-semibold">{format(day, "EEE", { locale: ptBR })}</div>
                    <div className={`text-lg ${isToday ? "text-primary font-bold" : ""}`}>{format(day, "dd")}</div>
                  </div>

                  <div className="space-y-1">
                    {dayAppointments.length > 0 ? (
                      dayAppointments.map((appointment) => (
                        <AppointmentCard key={appointment.id} appointment={appointment} />
                      ))
                    ) : (
                      <div
                        className="p-4 border-2 border-dashed border-gray-200 rounded-lg text-center text-gray-500 cursor-pointer hover:border-primary hover:text-primary transition-colors"
                        onClick={() =>
                          onNewAppointment?.(
                            day,
                            motoristas.find((m) => m.id === selectedMotorista),
                          )
                        }
                      >
                        <Plus className="h-4 w-4 mx-auto mb-1" />
                        <span className="text-xs">Adicionar agendamento</span>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
