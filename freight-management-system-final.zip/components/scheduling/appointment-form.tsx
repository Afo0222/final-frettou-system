"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Calendar, AlertTriangle, CheckCircle } from "lucide-react"
import { AgendamentoService, type Agendamento, type Motorista, type ConflictCheck } from "@/lib/services/agendamentos"
import { format } from "date-fns"

interface AppointmentFormProps {
  isOpen: boolean
  onClose: () => void
  onSave: (appointment: Agendamento) => void
  appointment?: Agendamento | null
  initialDate?: Date
  initialMotorista?: Motorista
}

export function AppointmentForm({
  isOpen,
  onClose,
  onSave,
  appointment,
  initialDate,
  initialMotorista,
}: AppointmentFormProps) {
  const [formData, setFormData] = useState({
    data_agendada: "",
    hora_inicio: "",
    hora_fim: "",
    motorista_id: "",
    veiculo_id: "",
    cliente_nome: "",
    cliente_telefone: "",
    endereco_origem: "",
    endereco_destino: "",
    tipo_servico: "",
    valor_servico: "",
    duracao_estimada_minutos: "120",
    prioridade: "normal",
    observacoes: "",
    status: "agendado",
  })

  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [veiculos, setVeiculos] = useState<any[]>([])
  const [conflictCheck, setConflictCheck] = useState<ConflictCheck | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isCheckingConflict, setIsCheckingConflict] = useState(false)

  useEffect(() => {
    if (isOpen) {
      loadData()
      resetForm()
    }
  }, [isOpen, appointment, initialDate, initialMotorista])

  const loadData = async () => {
    try {
      const [motoristasData, veiculosData] = await Promise.all([
        AgendamentoService.getMotoristas(),
        AgendamentoService.getVeiculos(),
      ])
      setMotoristas(motoristasData)
      setVeiculos(veiculosData)
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
    }
  }

  const resetForm = () => {
    if (appointment) {
      // Edit mode
      setFormData({
        data_agendada: appointment.data_agendada,
        hora_inicio: appointment.hora_inicio || "",
        hora_fim: appointment.hora_fim || "",
        motorista_id: appointment.motorista_id || "",
        veiculo_id: appointment.veiculo_id || "",
        cliente_nome: appointment.cliente_nome || "",
        cliente_telefone: appointment.cliente_telefone || "",
        endereco_origem: appointment.endereco_origem || "",
        endereco_destino: appointment.endereco_destino || "",
        tipo_servico: appointment.tipo_servico || "",
        valor_servico: appointment.valor_servico?.toString() || "",
        duracao_estimada_minutos: appointment.duracao_estimada_minutos?.toString() || "120",
        prioridade: appointment.prioridade || "normal",
        observacoes: appointment.observacoes || "",
        status: appointment.status,
      })
    } else {
      // Create mode
      setFormData({
        data_agendada: initialDate ? format(initialDate, "yyyy-MM-dd") : "",
        hora_inicio: "",
        hora_fim: "",
        motorista_id: initialMotorista?.id || "",
        veiculo_id: "",
        cliente_nome: "",
        cliente_telefone: "",
        endereco_origem: "",
        endereco_destino: "",
        tipo_servico: "",
        valor_servico: "",
        duracao_estimada_minutos: "120",
        prioridade: "normal",
        observacoes: "",
        status: "agendado",
      })
    }
    setConflictCheck(null)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))

    // Auto-calculate end time when start time or duration changes
    if (field === "hora_inicio" || field === "duracao_estimada_minutos") {
      const startTime = field === "hora_inicio" ? value : formData.hora_inicio
      const duration =
        field === "duracao_estimada_minutos"
          ? Number.parseInt(value)
          : Number.parseInt(formData.duracao_estimada_minutos)

      if (startTime && duration) {
        const [hours, minutes] = startTime.split(":").map(Number)
        const startDate = new Date()
        startDate.setHours(hours, minutes, 0, 0)

        const endDate = new Date(startDate.getTime() + duration * 60000)
        const endTime = `${endDate.getHours().toString().padStart(2, "0")}:${endDate.getMinutes().toString().padStart(2, "0")}`

        setFormData((prev) => ({ ...prev, hora_fim: endTime }))
      }
    }
  }

  const checkConflicts = async () => {
    if (!formData.motorista_id || !formData.data_agendada || !formData.hora_inicio || !formData.hora_fim) {
      setConflictCheck(null)
      return
    }

    try {
      setIsCheckingConflict(true)
      const result = await AgendamentoService.checkDriverAvailability(
        formData.motorista_id,
        formData.data_agendada,
        formData.hora_inicio,
        formData.hora_fim,
        appointment?.id,
      )
      setConflictCheck(result)
    } catch (error) {
      console.error("Erro ao verificar conflitos:", error)
    } finally {
      setIsCheckingConflict(false)
    }
  }

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      checkConflicts()
    }, 500)

    return () => clearTimeout(timeoutId)
  }, [formData.motorista_id, formData.data_agendada, formData.hora_inicio, formData.hora_fim])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate required fields
    if (!formData.cliente_nome.trim()) {
      alert("Nome do cliente é obrigatório")
      return
    }

    if (!formData.data_agendada) {
      alert("Data é obrigatória")
      return
    }

    if (!formData.hora_inicio) {
      alert("Hora de início é obrigatória")
      return
    }

    if (!formData.hora_fim) {
      alert("Hora de fim é obrigatória")
      return
    }

    if (!formData.motorista_id) {
      alert("Motorista é obrigatório")
      return
    }

    if (!formData.endereco_origem.trim()) {
      alert("Endereço de origem é obrigatório")
      return
    }

    if (!formData.endereco_destino.trim()) {
      alert("Endereço de destino é obrigatório")
      return
    }

    if (conflictCheck?.hasConflict) {
      alert("Existe conflito de horário. Por favor, escolha outro horário.")
      return
    }

    try {
      setIsLoading(true)

      // Properly handle UUID fields - convert empty strings to undefined
      const appointmentData = {
        ...formData,
        valor_servico: formData.valor_servico ? Number.parseFloat(formData.valor_servico) : undefined,
        duracao_estimada_minutos: Number.parseInt(formData.duracao_estimada_minutos),
        // Convert empty strings to undefined for UUID fields
        motorista_id: formData.motorista_id || undefined,
        veiculo_id: formData.veiculo_id || undefined,
        orcamento_id: formData.orcamento_id || undefined,
      }

      let result: Agendamento
      if (appointment) {
        result = await AgendamentoService.update(appointment.id, appointmentData)
      } else {
        result = await AgendamentoService.create(appointmentData)
      }

      onSave(result)
      onClose()
    } catch (error) {
      console.error("Erro ao salvar agendamento:", error)
      alert("Erro ao salvar agendamento: " + (error as Error).message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            {appointment ? "Editar Agendamento" : "Novo Agendamento"}
          </DialogTitle>
          <DialogDescription>
            {appointment
              ? "Edite as informações do agendamento"
              : "Preencha as informações para criar um novo agendamento"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Conflict Warning */}
          {conflictCheck?.hasConflict && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-red-700">
                  <AlertTriangle className="h-4 w-4" />
                  Conflito de Horário Detectado
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-red-600 mb-3">
                  O motorista já possui agendamento(s) no horário selecionado:
                </p>
                {conflictCheck.conflictingAppointments?.map((conflict) => (
                  <div key={conflict.id} className="bg-white p-2 rounded border text-sm">
                    <div className="font-medium">{conflict.cliente_nome}</div>
                    <div className="text-gray-600">
                      {conflict.hora_inicio} - {conflict.hora_fim} | {conflict.tipo_servico}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Success Indicator */}
          {conflictCheck && !conflictCheck.hasConflict && formData.motorista_id && formData.hora_inicio && (
            <Card className="border-green-200 bg-green-50">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm">Horário disponível!</span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Date and Time */}
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="data_agendada">Data *</Label>
              <Input
                id="data_agendada"
                type="date"
                value={formData.data_agendada}
                onChange={(e) => handleInputChange("data_agendada", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hora_inicio">Hora Início *</Label>
              <Input
                id="hora_inicio"
                type="time"
                value={formData.hora_inicio}
                onChange={(e) => handleInputChange("hora_inicio", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hora_fim">Hora Fim *</Label>
              <Input
                id="hora_fim"
                type="time"
                value={formData.hora_fim}
                onChange={(e) => handleInputChange("hora_fim", e.target.value)}
                required
              />
            </div>
          </div>

          {/* Driver and Vehicle */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="motorista_id">Motorista *</Label>
              <Select
                value={formData.motorista_id}
                onValueChange={(value) => handleInputChange("motorista_id", value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um motorista" />
                </SelectTrigger>
                <SelectContent>
                  {motoristas.map((motorista) => (
                    <SelectItem key={motorista.id} value={motorista.id}>
                      {motorista.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="veiculo_id">Veículo</Label>
              <Select value={formData.veiculo_id} onValueChange={(value) => handleInputChange("veiculo_id", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um veículo" />
                </SelectTrigger>
                <SelectContent>
                  {veiculos.map((veiculo) => (
                    <SelectItem key={veiculo.id} value={veiculo.id}>
                      {veiculo.modelo} - {veiculo.placa}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Client Information */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="cliente_nome">Nome do Cliente *</Label>
              <Input
                id="cliente_nome"
                value={formData.cliente_nome}
                onChange={(e) => handleInputChange("cliente_nome", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cliente_telefone">Telefone do Cliente</Label>
              <Input
                id="cliente_telefone"
                value={formData.cliente_telefone}
                onChange={(e) => handleInputChange("cliente_telefone", e.target.value)}
              />
            </div>
          </div>

          {/* Addresses */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="endereco_origem">Endereço de Origem *</Label>
              <Input
                id="endereco_origem"
                value={formData.endereco_origem}
                onChange={(e) => handleInputChange("endereco_origem", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endereco_destino">Endereço de Destino *</Label>
              <Input
                id="endereco_destino"
                value={formData.endereco_destino}
                onChange={(e) => handleInputChange("endereco_destino", e.target.value)}
                required
              />
            </div>
          </div>

          {/* Service Details */}
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="tipo_servico">Tipo de Serviço</Label>
              <Select value={formData.tipo_servico} onValueChange={(value) => handleInputChange("tipo_servico", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mudanca">Mudança</SelectItem>
                  <SelectItem value="frete">Frete</SelectItem>
                  <SelectItem value="entrega">Entrega</SelectItem>
                  <SelectItem value="coleta">Coleta</SelectItem>
                  <SelectItem value="expresso">Expresso</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duracao_estimada_minutos">Duração (minutos)</Label>
              <Input
                id="duracao_estimada_minutos"
                type="number"
                value={formData.duracao_estimada_minutos}
                onChange={(e) => handleInputChange("duracao_estimada_minutos", e.target.value)}
                min="30"
                step="30"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="valor_servico">Valor do Serviço</Label>
              <Input
                id="valor_servico"
                type="number"
                step="0.01"
                value={formData.valor_servico}
                onChange={(e) => handleInputChange("valor_servico", e.target.value)}
              />
            </div>
          </div>

          {/* Priority and Status */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="prioridade">Prioridade</Label>
              <Select value={formData.prioridade} onValueChange={(value) => handleInputChange("prioridade", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="baixa">Baixa</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="urgente">Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="agendado">Agendado</SelectItem>
                  <SelectItem value="confirmado">Confirmado</SelectItem>
                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                  <SelectItem value="cancelado">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Observations */}
          <div className="space-y-2">
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => handleInputChange("observacoes", e.target.value)}
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading || isCheckingConflict || conflictCheck?.hasConflict}>
              {isLoading ? "Salvando..." : appointment ? "Atualizar" : "Criar Agendamento"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
