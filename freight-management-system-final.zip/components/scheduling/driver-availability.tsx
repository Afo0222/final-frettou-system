"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { User, Clock, CheckCircle, XCircle, Calendar } from "lucide-react"
import { AgendamentoService, type Motorista, type TimeSlot } from "@/lib/services/agendamentos"
import { format, addDays } from "date-fns"
import { ptBR } from "date-fns/locale"

interface DriverAvailabilityProps {
  onTimeSlotSelect?: (motorista: Motorista, date: string, time: string) => void
}

export function DriverAvailability({ onTimeSlotSelect }: DriverAvailabilityProps) {
  const [motoristas, setMotoristas] = useState<Motorista[]>([])
  const [selectedMotorista, setSelectedMotorista] = useState<string>("")
  const [selectedDate, setSelectedDate] = useState<string>(format(new Date(), "yyyy-MM-dd"))
  const [availability, setAvailability] = useState<TimeSlot[]>([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    loadMotoristas()
  }, [])

  useEffect(() => {
    if (selectedMotorista && selectedDate) {
      loadAvailability()
    }
  }, [selectedMotorista, selectedDate])

  const loadMotoristas = async () => {
    try {
      const data = await AgendamentoService.getMotoristas()
      setMotoristas(data)
      if (data.length > 0) {
        setSelectedMotorista(data[0].id)
      }
    } catch (error) {
      console.error("Erro ao carregar motoristas:", error)
    }
  }

  const loadAvailability = async () => {
    if (!selectedMotorista || !selectedDate) return

    try {
      setIsLoading(true)
      const data = await AgendamentoService.getDriverAvailability(selectedMotorista, selectedDate, selectedDate)
      setAvailability(data)
    } catch (error) {
      console.error("Erro ao carregar disponibilidade:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleTimeSlotClick = (timeSlot: TimeSlot) => {
    if (!timeSlot.disponivel) return

    const motorista = motoristas.find((m) => m.id === selectedMotorista)
    if (motorista && onTimeSlotSelect) {
      onTimeSlotSelect(motorista, timeSlot.data, timeSlot.hora_inicio)
    }
  }

  const getTimeSlotsByHour = () => {
    const grouped: { [hour: string]: TimeSlot[] } = {}

    availability.forEach((slot) => {
      const hour = slot.hora_inicio.slice(0, 2)
      if (!grouped[hour]) {
        grouped[hour] = []
      }
      grouped[hour].push(slot)
    })

    return grouped
  }

  const selectedMotoristaData = motoristas.find((m) => m.id === selectedMotorista)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Disponibilidade dos Motoristas
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Controls */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Motorista</Label>
            <Select value={selectedMotorista} onValueChange={setSelectedMotorista}>
              <SelectTrigger>
                <SelectValue placeholder="Selecionar motorista" />
              </SelectTrigger>
              <SelectContent>
                {motoristas.map((motorista) => (
                  <SelectItem key={motorista.id} value={motorista.id}>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      {motorista.nome}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Data</Label>
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              min={format(new Date(), "yyyy-MM-dd")}
              max={format(addDays(new Date(), 30), "yyyy-MM-dd")}
            />
          </div>
        </div>

        {/* Quick Date Selection */}
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setSelectedDate(format(new Date(), "yyyy-MM-dd"))}>
            Hoje
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedDate(format(addDays(new Date(), 1), "yyyy-MM-dd"))}
          >
            Amanhã
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedDate(format(addDays(new Date(), 7), "yyyy-MM-dd"))}
          >
            Próxima Semana
          </Button>
        </div>

        {/* Driver Info */}
        {selectedMotoristaData && (
          <div className="p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <User className="h-4 w-4 text-blue-600" />
              <span className="font-medium">{selectedMotoristaData.nome}</span>
            </div>
            {selectedMotoristaData.telefone && (
              <p className="text-sm text-muted-foreground">Telefone: {selectedMotoristaData.telefone}</p>
            )}
            <p className="text-sm text-muted-foreground">
              Data: {format(new Date(selectedDate), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </p>
          </div>
        )}

        {/* Availability Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : availability.length > 0 ? (
          <div className="space-y-4">
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-100 border border-green-300 rounded"></div>
                <span>Disponível</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-red-100 border border-red-300 rounded"></div>
                <span>Ocupado</span>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {availability.map((slot) => (
                <Button
                  key={`${slot.data}-${slot.hora_inicio}`}
                  variant={slot.disponivel ? "outline" : "secondary"}
                  size="sm"
                  className={`h-12 ${
                    slot.disponivel
                      ? "border-green-300 bg-green-50 hover:bg-green-100 text-green-800"
                      : "border-red-300 bg-red-50 text-red-800 cursor-not-allowed"
                  }`}
                  onClick={() => handleTimeSlotClick(slot)}
                  disabled={!slot.disponivel}
                >
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-medium">{slot.hora_inicio.slice(0, 5)}</span>
                    <span className="text-xs">{slot.hora_fim.slice(0, 5)}</span>
                    {slot.disponivel ? <CheckCircle className="h-3 w-3 mt-1" /> : <XCircle className="h-3 w-3 mt-1" />}
                  </div>
                </Button>
              ))}
            </div>

            {/* Summary */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {availability.filter((slot) => slot.disponivel).length}
                </div>
                <div className="text-sm text-muted-foreground">Horários Disponíveis</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {availability.filter((slot) => !slot.disponivel).length}
                </div>
                <div className="text-sm text-muted-foreground">Horários Ocupados</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Selecione um motorista e data para ver a disponibilidade</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
