-- Verificar e ajustar a estrutura da tabela de agendamentos
-- baseada no esquema existente do projeto

-- Primeiro, vamos verificar se a tabela existe e criar se necessário
CREATE TABLE IF NOT EXISTS agendamentos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    orcamento_id UUID REFERENCES orcamentos(id) ON DELETE SET NULL,
    motorista_id UUID REFERENCES motoristas(id) ON DELETE SET NULL,
    veiculo_id UUID REFERENCES veiculos(id) ON DELETE SET NULL,
    data_agendada DATE NOT NULL,
    hora_agendada TIME,
    hora_inicio TIME,
    hora_coleta TIME,
    hora_entrega TIME,
    hora_conclusao TIME,
    status VARCHAR(20) DEFAULT 'pendente' CHECK (status IN ('pendente', 'em_coleta', 'em_rota', 'entregue', 'concluida', 'cancelada', 'agendado', 'confirmado', 'em_andamento', 'concluido')),
    endereco_origem TEXT,
    endereco_destino TEXT,
    distancia_km DECIMAL(10,2),
    tempo_real_minutos INTEGER,
    localizacao_atual JSONB,
    observacoes_motorista TEXT,
    assinatura_cliente TEXT,
    fotos JSONB,
    avaliacao_cliente INTEGER CHECK (avaliacao_cliente >= 1 AND avaliacao_cliente <= 5),
    comentario_cliente TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Adicionar colunas que podem estar faltando (se não existirem)
DO $$ 
BEGIN
    -- Verificar e adicionar coluna endereco_origem se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'agendamentos' AND column_name = 'endereco_origem') THEN
        ALTER TABLE agendamentos ADD COLUMN endereco_origem TEXT;
    END IF;

    -- Verificar e adicionar coluna endereco_destino se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'agendamentos' AND column_name = 'endereco_destino') THEN
        ALTER TABLE agendamentos ADD COLUMN endereco_destino TEXT;
    END IF;

    -- Verificar e adicionar coluna hora_agendada se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'agendamentos' AND column_name = 'hora_agendada') THEN
        ALTER TABLE agendamentos ADD COLUMN hora_agendada TIME;
    END IF;

    -- Verificar e adicionar coluna tempo_real_minutos se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'agendamentos' AND column_name = 'tempo_real_minutos') THEN
        ALTER TABLE agendamentos ADD COLUMN tempo_real_minutos INTEGER;
    END IF;

    -- Verificar e adicionar coluna observacoes_motorista se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'agendamentos' AND column_name = 'observacoes_motorista') THEN
        ALTER TABLE agendamentos ADD COLUMN observacoes_motorista TEXT;
    END IF;

END $$;

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_agendamentos_data_agendada ON agendamentos(data_agendada);
CREATE INDEX IF NOT EXISTS idx_agendamentos_motorista_id ON agendamentos(motorista_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_orcamento_id ON agendamentos(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status ON agendamentos(status);
CREATE INDEX IF NOT EXISTS idx_agendamentos_data_motorista ON agendamentos(data_agendada, motorista_id);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_agendamentos_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_agendamentos_updated_at ON agendamentos;
CREATE TRIGGER trigger_update_agendamentos_updated_at
    BEFORE UPDATE ON agendamentos
    FOR EACH ROW
    EXECUTE FUNCTION update_agendamentos_updated_at();

-- Inserir dados de exemplo para motoristas se não existirem
INSERT INTO motoristas (nome, cpf, cnh, categoria_cnh, vencimento_cnh, telefone, email, ativo)
SELECT 'João Silva', '123.456.789-01', '12345678901', 'D', '2025-12-31', '(11) 99999-1111', 'joao@exemplo.com', true
WHERE NOT EXISTS (SELECT 1 FROM motoristas WHERE cpf = '123.456.789-01');

INSERT INTO motoristas (nome, cpf, cnh, categoria_cnh, vencimento_cnh, telefone, email, ativo)
SELECT 'Maria Santos', '987.654.321-02', '10987654321', 'C', '2025-06-30', '(11) 99999-2222', 'maria@exemplo.com', true
WHERE NOT EXISTS (SELECT 1 FROM motoristas WHERE cpf = '987.654.321-02');

INSERT INTO motoristas (nome, cpf, cnh, categoria_cnh, vencimento_cnh, telefone, email, ativo)
SELECT 'Pedro Costa', '111.222.333-03', '11122233344', 'E', '2025-08-15', '(11) 99999-3333', 'pedro@exemplo.com', true
WHERE NOT EXISTS (SELECT 1 FROM motoristas WHERE cpf = '111.222.333-03');

-- Habilitar RLS (Row Level Security) se necessário
ALTER TABLE agendamentos ENABLE ROW LEVEL SECURITY;

-- Política para permitir todas as operações (ajustar conforme necessário)
DROP POLICY IF EXISTS "Permitir todas as operações em agendamentos" ON agendamentos;
CREATE POLICY "Permitir todas as operações em agendamentos" ON agendamentos
    FOR ALL USING (true);

-- Criar view para agendamentos com informações completas
CREATE OR REPLACE VIEW agendamentos_completos AS
SELECT 
    a.*,
    m.nome as motorista_nome,
    m.telefone as motorista_telefone,
    o.numero_orcamento,
    o.valor_total as valor_orcamento,
    c.nome as cliente_nome,
    c.telefone as cliente_telefone,
    ts.nome as tipo_servico_nome
FROM agendamentos a
LEFT JOIN motoristas m ON a.motorista_id = m.id
LEFT JOIN orcamentos o ON a.orcamento_id = o.id
LEFT JOIN clientes c ON o.cliente_id = c.id
LEFT JOIN tipos_servico ts ON o.tipo_servico_id = ts.id;
