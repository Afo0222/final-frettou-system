-- This script adds missing columns to the agendamentos table if they don't exist

-- Check if hora_inicio column exists and add it if not
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'agendamentos' 
        AND column_name = 'hora_inicio'
    ) THEN
        ALTER TABLE agendamentos ADD COLUMN hora_inicio TIME;
    END IF;
END $$;

-- Check if hora_fim column exists and add it if not
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'agendamentos' 
        AND column_name = 'hora_fim'
    ) THEN
        ALTER TABLE agendamentos ADD COLUMN hora_fim TIME;
    END IF;
END $$;

-- Refresh the schema cache
COMMENT ON TABLE agendamentos IS 'Tabela de agendamentos com colunas hora_inicio e hora_fim';

-- Add index for better performance when filtering by status
CREATE INDEX IF NOT EXISTS idx_agendamentos_status_filter ON agendamentos(status);

-- Update any existing records that have null hora_inicio/hora_fim
UPDATE agendamentos 
SET hora_inicio = hora_agendada 
WHERE hora_inicio IS NULL AND status IN ('em_andamento', 'concluido');

UPDATE agendamentos 
SET hora_fim = hora_agendada + INTERVAL '2 hours'
WHERE hora_fim IS NULL AND status = 'concluido';
