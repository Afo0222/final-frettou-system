-- Insert sample clients data
INSERT INTO clientes (
    nome, telefone, email, documento, endereco, cep, cidade, estado, 
    bairro, numero, complemento, observacoes
) VALUES 
(
    'João Silva Santos',
    '(11) 99999-1234',
    'joao.silva@email.com',
    '12345678901',
    'Rua das Flores, 123',
    '01234-567',
    'São Paulo',
    'SP',
    'Centro',
    '123',
    'Apto 45',
    'Cliente preferencial, sempre pontual nos pagamentos'
),
(
    'Transportadora ABC Ltda',
    '(11) 3333-4444',
    'contato@transportadoraabc.com.br',
    '12345678000195',
    'Av. Industrial, 1000',
    '08500-000',
    'Ferraz de Vasconcelos',
    'SP',
    'Industrial',
    '1000',
    'Galpão 5',
    'Empresa parceira, volumes grandes, pagamento à vista'
),
(
    'Maria Oliveira',
    '(21) 98888-7777',
    'maria.oliveira@gmail.com',
    '98765432100',
    'Rua Copacabana, 456',
    '22070-001',
    'Rio de Janeiro',
    'RJ',
    'Copacabana',
    '456',
    NULL,
    'Mudanças residenciais frequentes'
),
(
    'Comércio XYZ Eireli',
    '(31) 2222-3333',
    'vendas@comercioxyz.com.br',
    '98765432000123',
    'Rua do Comércio, 789',
    '30112-000',
    'Belo Horizonte',
    'MG',
    'Centro',
    '789',
    'Loja 12',
    'Entregas semanais, produtos frágeis'
),
(
    'Carlos Pereira',
    '(85) 97777-6666',
    NULL,
    '11122233344',
    'Av. Beira Mar, 321',
    '60165-121',
    'Fortaleza',
    'CE',
    'Meireles',
    '321',
    'Casa',
    'Prefere contato por WhatsApp'
),
(
    'Indústria Beta S.A.',
    '(47) 3444-5555',
    'logistica@industriabeta.com.br',
    '11223344000156',
    'Distrito Industrial, 2000',
    '89010-500',
    'Blumenau',
    'SC',
    'Industrial',
    '2000',
    'Portão 3',
    'Cargas pesadas, necessita equipamento especial'
),
(
    'Ana Costa Lima',
    '(62) 96666-5555',
    'ana.costa@hotmail.com',
    '55566677788',
    'Quadra 15, Lote 8',
    '74000-000',
    'Goiânia',
    'GO',
    'Setor Central',
    '8',
    NULL,
    'Cliente novo, primeira mudança'
),
(
    'Distribuidora Gama Ltda',
    '(81) 3111-2222',
    'operacional@distribuidoragama.com.br',
    '22334455000167',
    'BR-101, Km 15',
    '52000-000',
    'Recife',
    'PE',
    'Distrito Industrial',
    'Km 15',
    'Galpão A',
    'Distribuição para todo nordeste'
);

-- Update statistics
ANALYZE clientes;
