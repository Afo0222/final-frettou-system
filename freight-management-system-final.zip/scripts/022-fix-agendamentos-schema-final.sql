-- SCRIPT FINAL PARA CORRIGIR SCHEMA DOS AGENDAMENTOS

-- 1. Forçar a exclusão da tabela agendamentos se existir
DROP TABLE IF EXISTS agendamentos CASCADE;

-- 2. Criar tabela agendamentos com estrutura simples e sem foreign keys
CREATE TABLE agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_numero VARCHAR(255),
    motorista_nome VARCHAR(255),
    veiculo_info VARCHAR(255),
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL,
    status VARCHAR(50) DEFAULT 'agendado' CHECK (status IN ('agendado', 'confirmado', 'em_andamento', 'concluido', 'cancelado', 'reagendado')),
    endereco_origem TEXT,
    endereco_destino TEXT,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Criar índices para melhor performance
CREATE INDEX idx_agendamentos_data ON agendamentos(data_agendada);
CREATE INDEX idx_agendamentos_status ON agendamentos(status);
CREATE INDEX idx_agendamentos_orcamento ON agendamentos(orcamento_numero);

-- 4. Garantir que as tabelas de motoristas e veículos existem
CREATE TABLE IF NOT EXISTS motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(255),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Inserir dados padrão
INSERT INTO motoristas (id, nome, telefone, email, ativo)
VALUES ('11111111-1111-1111-1111-111111111111', 'Motorista Padrão', '(11) 99999-9999', 'motorista@exemplo.com', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO veiculos (id, modelo, placa, ativo)
VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Veículo Padrão', 'AAA-0000', true)
ON CONFLICT (id) DO NOTHING;

-- 6. Inserir um agendamento de exemplo para testar
INSERT INTO agendamentos (
    orcamento_numero,
    motorista_nome,
    veiculo_info,
    data_agendada,
    hora_agendada,
    status,
    cliente_nome,
    observacoes
) VALUES (
    'ORC-EXEMPLO',
    'Motorista Padrão',
    'Veículo Padrão - AAA-0000',
    CURRENT_DATE + INTERVAL '1 day',
    '08:00',
    'agendado',
    'Cliente Exemplo',
    'Agendamento de exemplo criado pelo sistema'
);

-- 7. Verificar estrutura criada
SELECT 
    'Tabela agendamentos criada com ' || COUNT(*) || ' registros' as resultado
FROM agendamentos
UNION ALL
SELECT 
    'Motoristas: ' || COUNT(*) || ' registros' as resultado
FROM motoristas
UNION ALL
SELECT 
    'Veículos: ' || COUNT(*) || ' registros' as resultado
FROM veiculos;

-- 8. Mostrar colunas da tabela agendamentos
SELECT 
    column_name, 
    data_type, 
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'agendamentos'
ORDER BY ordinal_position;
