-- Adicionar campo status_cancelamento à tabela agendamentos se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'agendamentos' AND column_name = 'status_cancelamento') THEN
        ALTER TABLE agendamentos ADD COLUMN status_cancelamento VARCHAR(50);
    END IF;
END$$;
