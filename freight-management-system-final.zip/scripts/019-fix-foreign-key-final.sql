-- SOLUÇÃO DEFINITIVA PARA O ERRO DE FOREIGN KEY

-- 1. Remover todas as constraints existentes para limpar o ambiente
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_motorista_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_veiculo_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_motorista;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_veiculo;

-- 2. Limpar dados existentes para evitar conflitos
DELETE FROM agendamentos WHERE true;

-- 3. Verificar e criar tabela de motoristas se não existir
CREATE TABLE IF NOT EXISTS motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14),
    cnh VARCHAR(20),
    telefone VARCHAR(20),
    email VARCHAR(255),
    endereco TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Verificar e criar tabela de veículos se não existir
CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    ano INTEGER,
    cor VARCHAR(50),
    capacidade_peso DECIMAL(10,2),
    capacidade_volume DECIMAL(10,2),
    tipo_veiculo VARCHAR(100),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Verificar e criar tabela de agendamentos se não existir
CREATE TABLE IF NOT EXISTS agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_id UUID,
    motorista_id UUID,
    veiculo_id UUID,
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL,
    hora_inicio TIME,
    hora_fim TIME,
    duracao_estimada_minutos INTEGER DEFAULT 120,
    status VARCHAR(50) DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    distancia_km DECIMAL(10,2),
    tempo_viagem_minutos INTEGER,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(255),
    prioridade VARCHAR(50) DEFAULT 'normal',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Inserir motorista padrão com ID fixo (se não existir)
INSERT INTO motoristas (id, nome, cpf, telefone, email, ativo)
SELECT 
    '11111111-1111-1111-1111-111111111111', 
    'Motorista Padrão', 
    '123.456.789-00', 
    '(11) 99999-9999', 
    'motorista@exemplo.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '11111111-1111-1111-1111-111111111111'
);

-- 7. Inserir veículo padrão com ID fixo (se não existir)
INSERT INTO veiculos (id, modelo, placa, ano, cor, ativo)
SELECT 
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 
    'Veículo Padrão', 
    'AAA-0000', 
    2023, 
    'Branco', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM veiculos WHERE id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
);

-- 8. Inserir mais alguns motoristas para garantir (se não existirem)
INSERT INTO motoristas (id, nome, cpf, telefone, email, ativo)
SELECT 
    '22222222-2222-2222-2222-222222222222', 
    'Maria Santos', 
    '234.567.890-12', 
    '(11) 99999-2222', 
    'maria@email.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '22222222-2222-2222-2222-222222222222'
);

INSERT INTO motoristas (id, nome, cpf, telefone, email, ativo)
SELECT 
    '33333333-3333-3333-3333-333333333333', 
    'Carlos Oliveira', 
    '345.678.901-23', 
    '(11) 99999-3333', 
    'carlos@email.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '33333333-3333-3333-3333-333333333333'
);

-- 9. Verificar se os dados foram inseridos
SELECT 'Motoristas:' as tabela, COUNT(*) as total FROM motoristas
UNION ALL
SELECT 'Veículos:' as tabela, COUNT(*) as total FROM veiculos
UNION ALL
SELECT 'Agendamentos:' as tabela, COUNT(*) as total FROM agendamentos;

-- 10. Mostrar IDs dos motoristas para debug
SELECT id, nome FROM motoristas ORDER BY nome;
