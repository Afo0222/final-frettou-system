-- Criar tabela de agendamentos se não existir
CREATE TABLE IF NOT EXISTS agendamentos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  orcamento_id UUID REFERENCES orcamentos(id) ON DELETE CASCADE,
  cliente_id UUID REFERENCES clientes(id),
  motorista_id UUID REFERENCES motoristas(id),
  tipo_servico_id UUID REFERENCES tipos_servico(id),
  data_agendada DATE NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fim TIME,
  duracao_estimada_minutos INTEGER DEFAULT 120,
  status VARCHAR(20) DEFAULT 'agendado' CHECK (status IN ('agendado', 'em_andamento', 'concluido', 'cancelado')),
  endereco_origem TEXT NOT NULL,
  endereco_destino TEXT NOT NULL,
  valor_servico DECIMAL(10,2),
  observacoes TEXT,
  prioridade VARCHAR(10) DEFAULT 'normal' CHECK (prioridade IN ('baixa', 'normal', 'alta', 'urgente')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de motoristas se não existir
CREATE TABLE IF NOT EXISTS motoristas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(255),
  cnh VARCHAR(20),
  categoria_cnh VARCHAR(5),
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir dados de exemplo para motoristas
INSERT INTO motoristas (nome, telefone, email, cnh, categoria_cnh, ativo) 
VALUES 
  ('João Silva', '(11) 99999-1111', 'joao@empresa.com', '12345678901', 'D', true),
  ('Maria Santos', '(11) 99999-2222', 'maria@empresa.com', '12345678902', 'D', true),
  ('Pedro Costa', '(11) 99999-3333', 'pedro@empresa.com', '12345678903', 'E', true)
ON CONFLICT DO NOTHING;

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_agendamentos_data ON agendamentos(data_agendada);
CREATE INDEX IF NOT EXISTS idx_agendamentos_motorista ON agendamentos(motorista_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_orcamento ON agendamentos(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status ON agendamentos(status);

-- Função para verificar conflitos de horário
CREATE OR REPLACE FUNCTION verificar_conflito_agendamento(
  p_motorista_id UUID,
  p_data_agendada DATE,
  p_hora_inicio TIME,
  p_hora_fim TIME,
  p_agendamento_id UUID DEFAULT NULL
) RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM agendamentos 
    WHERE motorista_id = p_motorista_id 
    AND data_agendada = p_data_agendada
    AND status NOT IN ('cancelado', 'concluido')
    AND (p_agendamento_id IS NULL OR id != p_agendamento_id)
    AND (
      (hora_inicio <= p_hora_inicio AND hora_fim > p_hora_inicio) OR
      (hora_inicio < p_hora_fim AND hora_fim >= p_hora_fim) OR
      (hora_inicio >= p_hora_inicio AND hora_fim <= p_hora_fim)
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_agendamentos_updated_at 
  BEFORE UPDATE ON agendamentos 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Criar view para agendamentos com informações completas
CREATE OR REPLACE VIEW agendamentos_completos AS
SELECT 
  a.*,
  c.nome as cliente_nome,
  c.telefone as cliente_telefone,
  c.email as cliente_email,
  m.nome as motorista_nome,
  m.telefone as motorista_telefone,
  ts.nome as tipo_servico_nome,
  o.numero_orcamento
FROM agendamentos a
LEFT JOIN clientes c ON a.cliente_id = c.id
LEFT JOIN motoristas m ON a.motorista_id = m.id
LEFT JOIN tipos_servico ts ON a.tipo_servico_id = ts.id
LEFT JOIN orcamentos o ON a.orcamento_id = o.id;
