-- Verificar se a coluna hora_agendada existe e adicioná-la se necessário
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'agendamentos' 
        AND column_name = 'hora_agendada'
    ) THEN
        ALTER TABLE agendamentos ADD COLUMN hora_agendada TIME DEFAULT '08:00:00';
    END IF;
END $$;

-- Atualizar registros existentes que podem ter hora_agendada nula
UPDATE agendamentos 
SET hora_agendada = '08:00:00' 
WHERE hora_agendada IS NULL;

-- Tornar a coluna NOT NULL após atualizar os valores
ALTER TABLE agendamentos ALTER COLUMN hora_agendada SET NOT NULL;

-- Verificar se outras colunas essenciais existem
DO $$ 
BEGIN
    -- Adicionar coluna status se não existir
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'agendamentos' 
        AND column_name = 'status'
    ) THEN
        ALTER TABLE agendamentos ADD COLUMN status VARCHAR(20) DEFAULT 'agendado';
    END IF;

    -- Adicionar coluna endereco_origem se não existir
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'agendamentos' 
        AND column_name = 'endereco_origem'
    ) THEN
        ALTER TABLE agendamentos ADD COLUMN endereco_origem TEXT;
    END IF;

    -- Adicionar coluna endereco_destino se não existir
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'agendamentos' 
        AND column_name = 'endereco_destino'
    ) THEN
        ALTER TABLE agendamentos ADD COLUMN endereco_destino TEXT;
    END IF;
END $$;

-- Criar índices se não existirem
CREATE INDEX IF NOT EXISTS idx_agendamentos_orcamento_id ON agendamentos(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_motorista_id ON agendamentos(motorista_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_data_agendada ON agendamentos(data_agendada);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status ON agendamentos(status);

-- Inserir motorista de exemplo se não existir nenhum
INSERT INTO motoristas (id, nome, cpf, telefone, email, ativo, created_at, updated_at)
SELECT 
    gen_random_uuid(), 
    'João Silva', 
    '123.456.789-00', 
    '(11) 98765-4321', 
    'joao.silva@exemplo.com', 
    true,
    NOW(),
    NOW()
WHERE 
    NOT EXISTS (SELECT 1 FROM motoristas WHERE ativo = true LIMIT 1);

-- Inserir mais motoristas de exemplo
INSERT INTO motoristas (id, nome, cpf, telefone, email, ativo, created_at, updated_at)
SELECT 
    gen_random_uuid(), 
    'Maria Santos', 
    '987.654.321-00', 
    '(11) 91234-5678', 
    'maria.santos@exemplo.com', 
    true,
    NOW(),
    NOW()
WHERE 
    (SELECT COUNT(*) FROM motoristas WHERE ativo = true) < 2;

-- Verificar estrutura final da tabela
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns 
WHERE table_name = 'agendamentos' 
ORDER BY ordinal_position;
