-- Create appointment cancellations table for historical tracking
CREATE TABLE IF NOT EXISTS appointment_cancellations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    appointment_id UUID NOT NULL,
    reason_id VARCHAR(50) NOT NULL,
    reason_category VARCHAR(20) NOT NULL,
    reason_text TEXT NOT NULL,
    cancellation_notes TEXT,
    cancelled_by VARCHAR(100) NOT NULL,
    cancelled_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    refund_amount DECIMAL(10,2),
    reschedule_requested BOOLEAN DEFAULT FALSE,
    client_notified BOOLEAN DEFAULT FALSE,
    driver_notified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create system logs table for fallback logging
CREATE TABLE IF NOT EXISTS system_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    appointment_id UUID,
    event_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_appointment_cancellations_appointment_id 
ON appointment_cancellations(appointment_id);

CREATE INDEX IF NOT EXISTS idx_appointment_cancellations_cancelled_at 
ON appointment_cancellations(cancelled_at);

CREATE INDEX IF NOT EXISTS idx_appointment_cancellations_reason_category 
ON appointment_cancellations(reason_category);

CREATE INDEX IF NOT EXISTS idx_system_logs_event_type 
ON system_logs(event_type);

CREATE INDEX IF NOT EXISTS idx_system_logs_appointment_id 
ON system_logs(appointment_id);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_appointment_cancellations_updated_at 
    BEFORE UPDATE ON appointment_cancellations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample cancellation reasons data (optional)
INSERT INTO appointment_cancellations (
    appointment_id, 
    reason_id, 
    reason_category, 
    reason_text, 
    cancelled_by,
    cancellation_notes
) VALUES 
(
    '00000000-0000-0000-0000-000000000000'::UUID,
    'sample-cancellation',
    'company',
    'Exemplo de cancelamento para teste',
    'system',
    'Este é um registro de exemplo para demonstrar o sistema de cancelamento'
) ON CONFLICT DO NOTHING;

-- Create view for cancellation statistics
CREATE OR REPLACE VIEW cancellation_stats AS
SELECT 
    DATE_TRUNC('month', cancelled_at) as month,
    reason_category,
    COUNT(*) as total_cancellations,
    SUM(COALESCE(refund_amount, 0)) as total_refunds,
    AVG(COALESCE(refund_amount, 0)) as avg_refund
FROM appointment_cancellations
GROUP BY DATE_TRUNC('month', cancelled_at), reason_category
ORDER BY month DESC, reason_category;

-- Grant necessary permissions (adjust as needed for your setup)
-- GRANT SELECT, INSERT, UPDATE ON appointment_cancellations TO your_app_user;
-- GRANT SELECT, INSERT ON system_logs TO your_app_user;
-- GRANT SELECT ON cancellation_stats TO your_app_user;

COMMENT ON TABLE appointment_cancellations IS 'Stores detailed information about cancelled appointments for historical tracking and analytics';
COMMENT ON TABLE system_logs IS 'General system event logging table for fallback storage';
COMMENT ON VIEW cancellation_stats IS 'Provides monthly cancellation statistics grouped by reason category';
