-- Criar tabela de comprovantes de entrega se não existir
CREATE TABLE IF NOT EXISTS comprovantes_entrega (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  rota_id TEXT NOT NULL,
  cliente_nome TEXT NOT NULL,
  endereco_retirada TEXT NOT NULL,
  endereco_entrega TEXT NOT NULL,
  tipo_servico TEXT NOT NULL,
  data_entrega DATE NOT NULL,
  hora_entrega TIME NOT NULL,
  motorista_id TEXT,
  motorista_nome TEXT NOT NULL,
  assinatura_cliente TEXT,
  fotos TEXT,
  observacoes TEXT,
  avaliacao_cliente INTEGER CHECK (avaliacao_cliente >= 0 AND avaliacao_cliente <= 5),
  comentario_cliente TEXT,
  valor_total DECIMAL(10,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de financeiro de rotas se não existir
CREATE TABLE IF NOT EXISTS financeiro_rotas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  rota_id TEXT NOT NULL,
  valor_total DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendente',
  data_conclusao DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_comprovantes_rota_id ON comprovantes_entrega(rota_id);
CREATE INDEX IF NOT EXISTS idx_comprovantes_data ON comprovantes_entrega(data_entrega);
CREATE INDEX IF NOT EXISTS idx_financeiro_rotas_rota_id ON financeiro_rotas(rota_id);
CREATE INDEX IF NOT EXISTS idx_financeiro_rotas_status ON financeiro_rotas(status);
