-- Criar tabela de motoristas se não existir
CREATE TABLE IF NOT EXISTS motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14),
    rg VARCHAR(20),
    cnh VARCHAR(20),
    telefone VARCHAR(20),
    email VARCHAR(255),
    endereco TEXT,
    status VARCHAR(50) DEFAULT 'ativo',
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de veículos se não existir
CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL UNIQUE,
    ano INTEGER,
    cor VARCHAR(50),
    capacidade_peso DECIMAL(10,2),
    capacidade_volume DECIMAL(10,2),
    tipo_veiculo VARCHAR(100),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de agendamentos se não existir
CREATE TABLE IF NOT EXISTS agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_id UUID,
    motorista_id UUID,
    veiculo_id UUID,
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL,
    hora_inicio TIME,
    hora_fim TIME,
    duracao_estimada_minutos INTEGER DEFAULT 120,
    status VARCHAR(50) DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    distancia_km DECIMAL(10,2),
    tempo_viagem_minutos INTEGER,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(255),
    prioridade VARCHAR(50) DEFAULT 'normal',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign keys (apenas se as tabelas referenciadas existirem)
    CONSTRAINT fk_agendamentos_motorista 
        FOREIGN KEY (motorista_id) 
        REFERENCES motoristas(id) 
        ON DELETE SET NULL,
    
    CONSTRAINT fk_agendamentos_veiculo 
        FOREIGN KEY (veiculo_id) 
        REFERENCES veiculos(id) 
        ON DELETE SET NULL
);

-- Adicionar foreign key para orçamentos se a tabela existir
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'orcamentos') THEN
        -- Tentar adicionar a constraint se não existir
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.table_constraints 
            WHERE constraint_name = 'fk_agendamentos_orcamento'
        ) THEN
            ALTER TABLE agendamentos 
            ADD CONSTRAINT fk_agendamentos_orcamento 
            FOREIGN KEY (orcamento_id) 
            REFERENCES orcamentos(id) 
            ON DELETE CASCADE;
        END IF;
    END IF;
END $$;

-- Limpar dados existentes para evitar conflitos
DELETE FROM agendamentos;
DELETE FROM veiculos;
DELETE FROM motoristas;

-- Inserir motoristas de exemplo
INSERT INTO motoristas (id, nome, cpf, cnh, telefone, email, endereco, status, ativo) VALUES
('11111111-1111-1111-1111-111111111111', 'João Silva', '123.456.789-01', 'CNH123456', '(11) 99999-1111', 'joao@email.com', 'Rua A, 123 - São Paulo/SP', 'ativo', true),
('22222222-2222-2222-2222-222222222222', 'Maria Santos', '234.567.890-12', 'CNH234567', '(11) 99999-2222', 'maria@email.com', 'Rua B, 456 - São Paulo/SP', 'ativo', true),
('33333333-3333-3333-3333-333333333333', 'Carlos Oliveira', '345.678.901-23', 'CNH345678', '(11) 99999-3333', 'carlos@email.com', 'Rua C, 789 - São Paulo/SP', 'ativo', true),
('44444444-4444-4444-4444-444444444444', 'Ana Costa', '456.789.012-34', 'CNH456789', '(11) 99999-4444', 'ana@email.com', 'Rua D, 101 - São Paulo/SP', 'ativo', true),
('55555555-5555-5555-5555-555555555555', 'Pedro Lima', '567.890.123-45', 'CNH567890', '(11) 99999-5555', 'pedro@email.com', 'Rua E, 202 - São Paulo/SP', 'ativo', true);

-- Inserir veículos de exemplo
INSERT INTO veiculos (id, modelo, placa, ano, cor, capacidade_peso, capacidade_volume, tipo_veiculo, ativo) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Fiat Fiorino', 'ABC-1234', 2020, 'Branco', 650.00, 2.5, 'Van', true),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Ford Transit', 'DEF-5678', 2021, 'Prata', 1200.00, 8.0, 'Van', true),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'Mercedes Sprinter', 'GHI-9012', 2022, 'Branco', 1500.00, 12.0, 'Van', true),
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'Iveco Daily', 'JKL-3456', 2019, 'Azul', 2000.00, 15.0, 'Caminhão', true),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'Volkswagen Delivery', 'MNO-7890', 2020, 'Branco', 3000.00, 20.0, 'Caminhão', true);

-- Inserir alguns agendamentos de exemplo
INSERT INTO agendamentos (
    id, 
    motorista_id, 
    veiculo_id, 
    data_agendada, 
    hora_agendada, 
    hora_inicio, 
    hora_fim, 
    duracao_estimada_minutos,
    status, 
    endereco_origem, 
    endereco_destino, 
    cliente_nome, 
    cliente_telefone, 
    valor_servico, 
    tipo_servico, 
    prioridade,
    observacoes
) VALUES
(
    'f1111111-1111-1111-1111-111111111111',
    '11111111-1111-1111-1111-111111111111',
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    CURRENT_DATE + INTERVAL '1 day',
    '08:00:00',
    '08:00:00',
    '10:00:00',
    120,
    'agendado',
    'Rua das Flores, 123 - Centro, São Paulo/SP',
    'Av. Paulista, 456 - Bela Vista, São Paulo/SP',
    'Cliente Exemplo 1',
    '(11) 98765-4321',
    250.00,
    'Frete Padrão',
    'normal',
    'Agendamento de exemplo'
),
(
    'f2222222-2222-2222-2222-222222222222',
    '22222222-2222-2222-2222-222222222222',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    CURRENT_DATE + INTERVAL '2 days',
    '14:00:00',
    '14:00:00',
    '18:00:00',
    240,
    'confirmado',
    'Rua dos Jardins, 789 - Vila Madalena, São Paulo/SP',
    'Rua Augusta, 321 - Consolação, São Paulo/SP',
    'Cliente Exemplo 2',
    '(11) 98765-1234',
    450.00,
    'Mudança Residencial',
    'alta',
    'Mudança completa'
),
(
    'f3333333-3333-3333-3333-333333333333',
    '33333333-3333-3333-3333-333333333333',
    'cccccccc-cccc-cccc-cccc-cccccccccccc',
    CURRENT_DATE + INTERVAL '3 days',
    '09:30:00',
    '09:30:00',
    '11:00:00',
    90,
    'agendado',
    'Av. Faria Lima, 100 - Itaim Bibi, São Paulo/SP',
    'Rua Oscar Freire, 200 - Jardins, São Paulo/SP',
    'Cliente Exemplo 3',
    '(11) 98765-5678',
    180.00,
    'Frete Expresso',
    'urgente',
    'Entrega urgente'
);

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_agendamentos_data_agendada ON agendamentos(data_agendada);
CREATE INDEX IF NOT EXISTS idx_agendamentos_motorista_id ON agendamentos(motorista_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status ON agendamentos(status);
CREATE INDEX IF NOT EXISTS idx_motoristas_ativo ON motoristas(ativo);
CREATE INDEX IF NOT EXISTS idx_veiculos_ativo ON veiculos(ativo);

-- Criar função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Criar triggers para atualizar updated_at
DROP TRIGGER IF EXISTS update_motoristas_updated_at ON motoristas;
CREATE TRIGGER update_motoristas_updated_at 
    BEFORE UPDATE ON motoristas 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_veiculos_updated_at ON veiculos;
CREATE TRIGGER update_veiculos_updated_at 
    BEFORE UPDATE ON veiculos 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_agendamentos_updated_at ON agendamentos;
CREATE TRIGGER update_agendamentos_updated_at 
    BEFORE UPDATE ON agendamentos 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Verificar se os dados foram inseridos corretamente
SELECT 'Motoristas inseridos:' as info, COUNT(*) as total FROM motoristas;
SELECT 'Veículos inseridos:' as info, COUNT(*) as total FROM veiculos;
SELECT 'Agendamentos inseridos:' as info, COUNT(*) as total FROM agendamentos;
