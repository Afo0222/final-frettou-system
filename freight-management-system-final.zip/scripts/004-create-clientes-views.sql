-- Create view for active clients with formatted data
CREATE OR REPLACE VIEW vw_clientes_ativos AS
SELECT 
    id,
    nome,
    telefone,
    email,
    documento,
    tipo_documento,
    CASE 
        WHEN tipo_documento = 'cpf' THEN 
            REGEXP_REPLACE(documento, '(\d{3})(\d{3})(\d{3})(\d{2})', '\1.\2.\3-\4')
        WHEN tipo_documento = 'cnpj' THEN 
            REGEXP_REPLACE(documento, '(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})', '\1.\2.\3/\4-\5')
        ELSE documento
    END as documento_formatado,
    endereco,
    CONCAT_WS(', ', 
        NULLIF(endereco, ''),
        NULLIF(bairro, ''),
        NULLIF(cidade, ''),
        NULLIF(estado, '')
    ) as endereco_completo,
    cep,
    cidade,
    estado,
    bairro,
    numero,
    complemento,
    observacoes,
    created_at,
    updated_at,
    CASE 
        WHEN tipo_documento = 'cnpj' THEN 'Pessoa Jurídica'
        WHEN tipo_documento = 'cpf' THEN 'Pessoa Física'
        ELSE 'Não Informado'
    END as tipo_pessoa
FROM clientes 
WHERE ativo = true
ORDER BY nome;

-- Create view for client statistics
CREATE OR REPLACE VIEW vw_clientes_estatisticas AS
SELECT 
    COUNT(*) as total_clientes,
    COUNT(*) FILTER (WHERE ativo = true) as clientes_ativos,
    COUNT(*) FILTER (WHERE ativo = false) as clientes_inativos,
    COUNT(*) FILTER (WHERE tipo_documento = 'cpf') as pessoas_fisicas,
    COUNT(*) FILTER (WHERE tipo_documento = 'cnpj') as pessoas_juridicas,
    COUNT(*) FILTER (WHERE email IS NOT NULL AND email != '') as com_email,
    COUNT(*) FILTER (WHERE documento IS NOT NULL AND documento != '') as com_documento,
    ROUND(
        (COUNT(*) FILTER (WHERE email IS NOT NULL AND email != '') * 100.0) / 
        NULLIF(COUNT(*), 0), 2
    ) as percentual_com_email
FROM clientes;

-- Create view for recent clients
CREATE OR REPLACE VIEW vw_clientes_recentes AS
SELECT 
    id,
    nome,
    telefone,
    email,
    tipo_documento,
    created_at,
    EXTRACT(DAYS FROM NOW() - created_at) as dias_cadastro
FROM clientes 
WHERE ativo = true
ORDER BY created_at DESC
LIMIT 10;
