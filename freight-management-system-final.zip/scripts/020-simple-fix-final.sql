-- SOLUÇÃO SIMPLES E DEFINITIVA PARA O ERRO DE FOREIGN KEY

-- 1. Remover todas as constraints existentes
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_motorista_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_veiculo_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_motorista;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_veiculo;

-- 2. Limpar dados existentes
DELETE FROM agendamentos WHERE true;

-- 3. Criar tabela de motoristas simples
CREATE TABLE IF NOT EXISTS motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(255),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Criar tabela de veículos simples
CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Criar tabela de agendamentos simples
CREATE TABLE IF NOT EXISTS agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_id UUID,
    motorista_id UUID,
    veiculo_id UUID,
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL,
    status VARCHAR(50) DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Inserir motorista padrão (se não existir)
INSERT INTO motoristas (id, nome, telefone, email, ativo)
SELECT 
    '11111111-1111-1111-1111-111111111111', 
    'Motorista Padrão', 
    '(11) 99999-9999', 
    'motorista@exemplo.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '11111111-1111-1111-1111-111111111111'
);

-- 7. Inserir veículo padrão (se não existir)
INSERT INTO veiculos (id, modelo, placa, ativo)
SELECT 
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 
    'Veículo Padrão', 
    'AAA-0000', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM veiculos WHERE id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
);

-- 8. Inserir mais motoristas
INSERT INTO motoristas (id, nome, telefone, email, ativo)
SELECT 
    '22222222-2222-2222-2222-222222222222', 
    'Maria Santos', 
    '(11) 99999-2222', 
    'maria@email.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '22222222-2222-2222-2222-222222222222'
);

INSERT INTO motoristas (id, nome, telefone, email, ativo)
SELECT 
    '33333333-3333-3333-3333-333333333333', 
    'Carlos Oliveira', 
    '(11) 99999-3333', 
    'carlos@email.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '33333333-3333-3333-3333-333333333333'
);

-- 9. Inserir mais veículos
INSERT INTO veiculos (id, modelo, placa, ativo)
SELECT 
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 
    'Fiat Fiorino', 
    'ABC-1234', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM veiculos WHERE id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
);

INSERT INTO veiculos (id, modelo, placa, ativo)
SELECT 
    'cccccccc-cccc-cccc-cccc-cccccccccccc', 
    'Ford Transit', 
    'DEF-5678', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM veiculos WHERE id = 'cccccccc-cccc-cccc-cccc-cccccccccccc'
);

-- 10. Verificar dados inseridos
SELECT 'Motoristas:' as tabela, COUNT(*) as total FROM motoristas
UNION ALL
SELECT 'Veículos:' as tabela, COUNT(*) as total FROM veiculos
UNION ALL
SELECT 'Agendamentos:' as tabela, COUNT(*) as total FROM agendamentos;

-- 11. Mostrar dados para debug
SELECT 'MOTORISTAS:' as tipo, id, nome FROM motoristas
UNION ALL
SELECT 'VEÍCULOS:' as tipo, id, modelo FROM veiculos
ORDER BY tipo, nome;
