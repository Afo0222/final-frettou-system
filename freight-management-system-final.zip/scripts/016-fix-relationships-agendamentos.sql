-- Remover tabelas existentes se houver problemas de estrutura
DROP TABLE IF EXISTS agendamentos CASCADE;
DROP TABLE IF EXISTS motoristas CASCADE;
DROP TABLE IF EXISTS veiculos CASCADE;

-- Criar tabela de motoristas primeiro
CREATE TABLE motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE,
    rg VARCHAR(20),
    cnh VARCHAR(20),
    categoria_cnh VARCHAR(2) DEFAULT 'B',
    vencimento_cnh DATE,
    telefone VARCHAR(20),
    email VARCHAR(255),
    endereco TEXT,
    data_nascimento DATE,
    data_admissao DATE,
    salario DECIMAL(10,2),
    comissao_percentual DECIMAL(5,2),
    banco VARCHAR(100),
    agencia VARCHAR(20),
    conta VARCHAR(30),
    pix VARCHAR(255),
    observacoes TEXT,
    status VARCHAR(20) DEFAULT 'ativo',
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de veículos
CREATE TABLE veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    marca VARCHAR(100),
    placa VARCHAR(10) NOT NULL UNIQUE,
    ano INTEGER,
    cor VARCHAR(50),
    chassi VARCHAR(50),
    renavam VARCHAR(20),
    capacidade_peso DECIMAL(10,2),
    capacidade_volume DECIMAL(10,2),
    tipo_veiculo VARCHAR(50) DEFAULT 'van',
    categoria_cnh VARCHAR(2) DEFAULT 'B',
    combustivel VARCHAR(20) DEFAULT 'flex',
    consumo_medio DECIMAL(5,2),
    motorista_id UUID REFERENCES motoristas(id) ON DELETE SET NULL,
    proprietario VARCHAR(20) DEFAULT 'empresa',
    valor_fipe DECIMAL(12,2),
    seguro_vigente BOOLEAN DEFAULT false,
    vencimento_seguro DATE,
    ipva_pago BOOLEAN DEFAULT false,
    vencimento_ipva DATE,
    licenciamento_vigente BOOLEAN DEFAULT false,
    vencimento_licenciamento DATE,
    manutencao_preventiva DATE,
    proxima_revisao DATE,
    km_atual INTEGER DEFAULT 0,
    observacoes TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de agendamentos com relacionamentos corretos
CREATE TABLE agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_id UUID,
    motorista_id UUID,
    veiculo_id UUID,
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL DEFAULT '08:00:00',
    hora_inicio TIME,
    hora_fim TIME,
    duracao_estimada_minutos INTEGER DEFAULT 120,
    status VARCHAR(20) NOT NULL DEFAULT 'agendado' CHECK (status IN ('agendado', 'confirmado', 'em_andamento', 'concluido', 'cancelado', 'reagendado')),
    endereco_origem TEXT,
    endereco_destino TEXT,
    distancia_km DECIMAL(10,2),
    tempo_viagem_minutos INTEGER,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(100),
    prioridade VARCHAR(20) DEFAULT 'normal' CHECK (prioridade IN ('baixa', 'normal', 'alta', 'urgente')),
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign keys
    CONSTRAINT fk_agendamentos_motorista FOREIGN KEY (motorista_id) REFERENCES motoristas(id) ON DELETE SET NULL,
    CONSTRAINT fk_agendamentos_veiculo FOREIGN KEY (veiculo_id) REFERENCES veiculos(id) ON DELETE SET NULL
);

-- Adicionar foreign key para orçamentos se a tabela existir
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'orcamentos') THEN
        ALTER TABLE agendamentos ADD CONSTRAINT fk_agendamentos_orcamento 
        FOREIGN KEY (orcamento_id) REFERENCES orcamentos(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Criar índices para performance
CREATE INDEX idx_agendamentos_orcamento_id ON agendamentos(orcamento_id);
CREATE INDEX idx_agendamentos_motorista_id ON agendamentos(motorista_id);
CREATE INDEX idx_agendamentos_veiculo_id ON agendamentos(veiculo_id);
CREATE INDEX idx_agendamentos_data_agendada ON agendamentos(data_agendada);
CREATE INDEX idx_agendamentos_status ON agendamentos(status);
CREATE INDEX idx_agendamentos_created_at ON agendamentos(created_at);
CREATE INDEX idx_motoristas_ativo ON motoristas(ativo);
CREATE INDEX idx_veiculos_ativo ON veiculos(ativo);

-- Inserir motoristas de exemplo
INSERT INTO motoristas (nome, cpf, telefone, email, cnh, categoria_cnh, ativo) VALUES
('João Silva', '123.456.789-00', '(11) 98765-4321', 'joao.silva@exemplo.com', '12345678901', 'D', true),
('Maria Santos', '987.654.321-00', '(11) 91234-5678', 'maria.santos@exemplo.com', '10987654321', 'C', true),
('Carlos Oliveira', '456.789.123-00', '(11) 95555-1234', 'carlos.oliveira@exemplo.com', '11223344556', 'D', true),
('Ana Costa', '321.654.987-00', '(11) 94444-5678', 'ana.costa@exemplo.com', '99887766554', 'B', true),
('Pedro Almeida', '654.321.987-00', '(11) 93333-9876', 'pedro.almeida@exemplo.com', '55443322110', 'C', true);

-- Inserir veículos de exemplo
INSERT INTO veiculos (modelo, marca, placa, ano, cor, capacidade_peso, tipo_veiculo, categoria_cnh, ativo) VALUES
('Fiorino', 'Fiat', 'ABC-1234', 2020, 'Branco', 650.00, 'van', 'B', true),
('Transit', 'Ford', 'DEF-5678', 2021, 'Branco', 1200.00, 'van', 'B', true),
('Sprinter', 'Mercedes', 'GHI-9012', 2022, 'Branco', 1500.00, 'van', 'D', true),
('HR', 'Hyundai', 'JKL-3456', 2019, 'Branco', 1000.00, 'caminhao', 'C', true),
('Ducato', 'Fiat', 'MNO-7890', 2023, 'Branco', 1300.00, 'van', 'B', true);

-- Atribuir alguns veículos aos motoristas
UPDATE veiculos SET motorista_id = (SELECT id FROM motoristas WHERE nome = 'João Silva' LIMIT 1) WHERE placa = 'ABC-1234';
UPDATE veiculos SET motorista_id = (SELECT id FROM motoristas WHERE nome = 'Maria Santos' LIMIT 1) WHERE placa = 'DEF-5678';
UPDATE veiculos SET motorista_id = (SELECT id FROM motoristas WHERE nome = 'Carlos Oliveira' LIMIT 1) WHERE placa = 'GHI-9012';

-- Inserir alguns agendamentos de exemplo
INSERT INTO agendamentos (
    data_agendada, 
    hora_agendada, 
    hora_inicio, 
    hora_fim,
    status, 
    endereco_origem, 
    endereco_destino, 
    cliente_nome, 
    cliente_telefone, 
    valor_servico, 
    tipo_servico,
    motorista_id,
    veiculo_id,
    duracao_estimada_minutos
) VALUES
(
    CURRENT_DATE + INTERVAL '1 day',
    '08:00:00',
    '08:00:00',
    '10:00:00',
    'agendado',
    'Rua das Flores, 123 - São Paulo, SP',
    'Av. Paulista, 456 - São Paulo, SP',
    'Cliente Exemplo 1',
    '(11) 99999-1111',
    250.00,
    'Mudança Residencial',
    (SELECT id FROM motoristas WHERE nome = 'João Silva' LIMIT 1),
    (SELECT id FROM veiculos WHERE placa = 'ABC-1234' LIMIT 1),
    120
),
(
    CURRENT_DATE + INTERVAL '2 days',
    '14:00:00',
    '14:00:00',
    '16:30:00',
    'confirmado',
    'Rua do Comércio, 789 - São Paulo, SP',
    'Rua Industrial, 321 - São Paulo, SP',
    'Cliente Exemplo 2',
    '(11) 88888-2222',
    180.00,
    'Frete Comercial',
    (SELECT id FROM motoristas WHERE nome = 'Maria Santos' LIMIT 1),
    (SELECT id FROM veiculos WHERE placa = 'DEF-5678' LIMIT 1),
    150
),
(
    CURRENT_DATE,
    '10:00:00',
    '10:00:00',
    '12:00:00',
    'em_andamento',
    'Centro Empresarial, 555 - São Paulo, SP',
    'Zona Norte, 777 - São Paulo, SP',
    'Cliente Exemplo 3',
    '(11) 77777-3333',
    320.00,
    'Transporte Executivo',
    (SELECT id FROM motoristas WHERE nome = 'Carlos Oliveira' LIMIT 1),
    (SELECT id FROM veiculos WHERE placa = 'GHI-9012' LIMIT 1),
    120
);

-- Função para verificar disponibilidade do motorista
CREATE OR REPLACE FUNCTION check_driver_availability(
    p_motorista_id UUID,
    p_data DATE,
    p_hora_inicio TIME,
    p_hora_fim TIME,
    p_agendamento_id UUID DEFAULT NULL
) RETURNS BOOLEAN AS $$
BEGIN
    RETURN NOT EXISTS (
        SELECT 1 FROM agendamentos
        WHERE motorista_id = p_motorista_id
        AND data_agendada = p_data
        AND status NOT IN ('cancelado', 'reagendado')
        AND (p_agendamento_id IS NULL OR id != p_agendamento_id)
        AND (
            (hora_inicio <= p_hora_inicio AND hora_fim > p_hora_inicio) OR
            (hora_inicio < p_hora_fim AND hora_fim >= p_hora_fim) OR
            (hora_inicio >= p_hora_inicio AND hora_fim <= p_hora_fim)
        )
    );
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar triggers
DROP TRIGGER IF EXISTS update_agendamentos_updated_at ON agendamentos;
DROP TRIGGER IF EXISTS update_motoristas_updated_at ON motoristas;
DROP TRIGGER IF EXISTS update_veiculos_updated_at ON veiculos;

CREATE TRIGGER update_agendamentos_updated_at
    BEFORE UPDATE ON agendamentos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_motoristas_updated_at
    BEFORE UPDATE ON motoristas
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_veiculos_updated_at
    BEFORE UPDATE ON veiculos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Verificar se as tabelas foram criadas corretamente
SELECT 
    'agendamentos' as tabela,
    COUNT(*) as registros
FROM agendamentos
UNION ALL
SELECT 
    'motoristas' as tabela,
    COUNT(*) as registros
FROM motoristas
UNION ALL
SELECT 
    'veiculos' as tabela,
    COUNT(*) as registros
FROM veiculos;
