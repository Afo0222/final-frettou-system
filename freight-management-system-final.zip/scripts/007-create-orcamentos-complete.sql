-- Criar tabelas completas para o sistema de orçamentos

-- Tabela de orçamentos (se não existir)
CREATE TABLE IF NOT EXISTS orcamentos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    numero_orcamento VARCHAR(50) UNIQUE NOT NULL,
    cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
    tipo_servico_id UUID REFERENCES tipos_servico(id) ON DELETE RESTRICT,
    endereco_origem TEXT NOT NULL,
    endereco_destino TEXT NOT NULL,
    data_agendada DATE,
    hora_agendada TIME,
    descricao_itens TEXT,
    peso_estimado DECIMAL(10,2),
    volume_estimado DECIMAL(10,2),
    veiculo_recomendado VARCHAR(100),
    tempo_estimado INTEGER, -- em horas
    ajudantes_adicionais INTEGER DEFAULT 0,
    servicos_extras JSONB DEFAULT '[]',
    valor_total DECIMAL(12,2) NOT NULL,
    detalhes_calculo JSONB,
    status VARCHAR(20) DEFAULT 'rascunho' CHECK (status IN ('rascunho', 'enviado', 'aprovado', 'rejeitado', 'expirado')),
    valido_ate DATE,
    observacoes TEXT,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_orcamentos_cliente_id ON orcamentos(cliente_id);
CREATE INDEX IF NOT EXISTS idx_orcamentos_tipo_servico_id ON orcamentos(tipo_servico_id);
CREATE INDEX IF NOT EXISTS idx_orcamentos_status ON orcamentos(status);
CREATE INDEX IF NOT EXISTS idx_orcamentos_data_agendada ON orcamentos(data_agendada);
CREATE INDEX IF NOT EXISTS idx_orcamentos_created_at ON orcamentos(created_at);
CREATE INDEX IF NOT EXISTS idx_orcamentos_numero ON orcamentos(numero_orcamento);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_orcamentos_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_orcamentos_updated_at ON orcamentos;
CREATE TRIGGER trigger_update_orcamentos_updated_at
    BEFORE UPDATE ON orcamentos
    FOR EACH ROW
    EXECUTE FUNCTION update_orcamentos_updated_at();

-- Função para gerar número de orçamento automaticamente
CREATE OR REPLACE FUNCTION generate_orcamento_number()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.numero_orcamento IS NULL OR NEW.numero_orcamento = '' THEN
        NEW.numero_orcamento := 'ORC-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(NEXTVAL('orcamento_sequence')::TEXT, 4, '0');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar sequência para numeração
CREATE SEQUENCE IF NOT EXISTS orcamento_sequence START 1;

-- Trigger para gerar número automaticamente
DROP TRIGGER IF EXISTS trigger_generate_orcamento_number ON orcamentos;
CREATE TRIGGER trigger_generate_orcamento_number
    BEFORE INSERT ON orcamentos
    FOR EACH ROW
    EXECUTE FUNCTION generate_orcamento_number();

-- Políticas de segurança RLS (Row Level Security)
ALTER TABLE orcamentos ENABLE ROW LEVEL SECURITY;

-- Política para permitir todas as operações para usuários autenticados
CREATE POLICY IF NOT EXISTS "Usuários autenticados podem gerenciar orçamentos" ON orcamentos
    FOR ALL USING (auth.role() = 'authenticated');

-- View para orçamentos com dados relacionados
CREATE OR REPLACE VIEW orcamentos_completos AS
SELECT 
    o.*,
    c.nome as cliente_nome,
    c.telefone as cliente_telefone,
    c.email as cliente_email,
    ts.nome as tipo_servico_nome,
    ts.descricao as tipo_servico_descricao,
    CASE 
        WHEN o.valido_ate < CURRENT_DATE AND o.status = 'enviado' THEN 'expirado'
        ELSE o.status
    END as status_atual
FROM orcamentos o
LEFT JOIN clientes c ON o.cliente_id = c.id
LEFT JOIN tipos_servico ts ON o.tipo_servico_id = ts.id;

-- Função para buscar orçamentos com filtros
CREATE OR REPLACE FUNCTION buscar_orcamentos(
    p_search TEXT DEFAULT NULL,
    p_status TEXT DEFAULT NULL,
    p_cliente_id UUID DEFAULT NULL,
    p_tipo_servico_id UUID DEFAULT NULL,
    p_data_inicio DATE DEFAULT NULL,
    p_data_fim DATE DEFAULT NULL,
    p_valor_min DECIMAL DEFAULT NULL,
    p_valor_max DECIMAL DEFAULT NULL,
    p_limit INTEGER DEFAULT 50,
    p_offset INTEGER DEFAULT 0
)
RETURNS TABLE (
    id UUID,
    numero_orcamento VARCHAR,
    cliente_nome TEXT,
    cliente_telefone VARCHAR,
    tipo_servico_nome VARCHAR,
    endereco_origem TEXT,
    endereco_destino TEXT,
    valor_total DECIMAL,
    status VARCHAR,
    data_agendada DATE,
    created_at TIMESTAMP WITH TIME ZONE,
    total_count BIGINT
) AS $$
BEGIN
    RETURN QUERY
    WITH filtered_orcamentos AS (
        SELECT o.*
        FROM orcamentos_completos o
        WHERE 
            (p_search IS NULL OR (
                o.numero_orcamento ILIKE '%' || p_search || '%' OR
                o.cliente_nome ILIKE '%' || p_search || '%' OR
                o.cliente_telefone ILIKE '%' || p_search || '%' OR
                o.endereco_origem ILIKE '%' || p_search || '%' OR
                o.endereco_destino ILIKE '%' || p_search || '%'
            ))
            AND (p_status IS NULL OR o.status_atual = p_status)
            AND (p_cliente_id IS NULL OR o.cliente_id = p_cliente_id)
            AND (p_tipo_servico_id IS NULL OR o.tipo_servico_id = p_tipo_servico_id)
            AND (p_data_inicio IS NULL OR o.created_at::DATE >= p_data_inicio)
            AND (p_data_fim IS NULL OR o.created_at::DATE <= p_data_fim)
            AND (p_valor_min IS NULL OR o.valor_total >= p_valor_min)
            AND (p_valor_max IS NULL OR o.valor_total <= p_valor_max)
    ),
    counted AS (
        SELECT COUNT(*) as total FROM filtered_orcamentos
    )
    SELECT 
        fo.id,
        fo.numero_orcamento,
        fo.cliente_nome,
        fo.cliente_telefone,
        fo.tipo_servico_nome,
        fo.endereco_origem,
        fo.endereco_destino,
        fo.valor_total,
        fo.status_atual,
        fo.data_agendada,
        fo.created_at,
        c.total
    FROM filtered_orcamentos fo
    CROSS JOIN counted c
    ORDER BY fo.created_at DESC
    LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql;

-- Função para estatísticas de orçamentos
CREATE OR REPLACE FUNCTION estatisticas_orcamentos()
RETURNS TABLE (
    total_orcamentos BIGINT,
    orcamentos_aprovados BIGINT,
    orcamentos_pendentes BIGINT,
    valor_total_aprovados DECIMAL,
    valor_medio_orcamento DECIMAL,
    taxa_aprovacao DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*) as total_orcamentos,
        COUNT(*) FILTER (WHERE status = 'aprovado') as orcamentos_aprovados,
        COUNT(*) FILTER (WHERE status IN ('enviado', 'rascunho')) as orcamentos_pendentes,
        COALESCE(SUM(valor_total) FILTER (WHERE status = 'aprovado'), 0) as valor_total_aprovados,
        COALESCE(AVG(valor_total), 0) as valor_medio_orcamento,
        CASE 
            WHEN COUNT(*) > 0 THEN 
                ROUND((COUNT(*) FILTER (WHERE status = 'aprovado')::DECIMAL / COUNT(*)) * 100, 2)
            ELSE 0 
        END as taxa_aprovacao
    FROM orcamentos
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- Inserir dados de exemplo se não existirem
INSERT INTO orcamentos (
    numero_orcamento,
    cliente_id,
    tipo_servico_id,
    endereco_origem,
    endereco_destino,
    data_agendada,
    hora_agendada,
    descricao_itens,
    peso_estimado,
    volume_estimado,
    veiculo_recomendado,
    tempo_estimado,
    ajudantes_adicionais,
    valor_total,
    status,
    valido_ate,
    observacoes
)
SELECT 
    'ORC-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(generate_random_between(1, 9999)::TEXT, 4, '0'),
    c.id,
    ts.id,
    'Rua das Flores, 123 - Centro, São Paulo - SP',
    'Av. Paulista, 456 - Bela Vista, São Paulo - SP',
    CURRENT_DATE + (generate_random_between(1, 30) || ' days')::INTERVAL,
    '08:00:00',
    'Mudança residencial completa: móveis da sala, quarto e cozinha',
    800.00,
    15.00,
    'Caminhão Baú',
    4,
    2,
    1500.00,
    (ARRAY['rascunho', 'enviado', 'aprovado'])[generate_random_between(1, 3)],
    CURRENT_DATE + INTERVAL '15 days',
    'Cliente preferencial - cuidado especial com móveis antigos'
FROM clientes c
CROSS JOIN tipos_servico ts
WHERE c.nome LIKE '%João%' 
  AND ts.nome LIKE '%Mudança%'
  AND NOT EXISTS (SELECT 1 FROM orcamentos WHERE cliente_id = c.id)
LIMIT 1;

-- Função auxiliar para gerar números aleatórios
CREATE OR REPLACE FUNCTION generate_random_between(min_val INTEGER, max_val INTEGER)
RETURNS INTEGER AS $$
BEGIN
    RETURN floor(random() * (max_val - min_val + 1) + min_val);
END;
$$ LANGUAGE plpgsql;

COMMIT;
