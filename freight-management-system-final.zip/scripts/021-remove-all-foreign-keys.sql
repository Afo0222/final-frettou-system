-- SOLUÇÃO RADICAL: REMOVER TODAS AS FOREIGN KEYS E CRIAR AGENDAMENTOS SEM RELACIONAMENTOS

-- 1. Remover todas as constraints existentes
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_motorista_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_veiculo_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_motorista;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_veiculo;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_orcamento_id_fkey;

-- 2. Verificar se as tabelas existem e criar se necessário
CREATE TABLE IF NOT EXISTS motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(255),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Modificar a tabela de agendamentos para remover as colunas de foreign key
-- Primeiro, verificar se a tabela existe
DO $$
BEGIN
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'agendamentos') THEN
        -- A tabela existe, vamos excluí-la e recriar
        DROP TABLE agendamentos;
    END IF;
END
$$;

-- 4. Criar tabela de agendamentos SEM foreign keys
CREATE TABLE agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_numero VARCHAR(255),
    motorista_nome VARCHAR(255),
    veiculo_info VARCHAR(255),
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL,
    status VARCHAR(50) DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Inserir motorista padrão (se não existir)
INSERT INTO motoristas (id, nome, telefone, email, ativo)
SELECT 
    '11111111-1111-1111-1111-111111111111', 
    'Motorista Padrão', 
    '(11) 99999-9999', 
    'motorista@exemplo.com', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM motoristas WHERE id = '11111111-1111-1111-1111-111111111111'
);

-- 6. Inserir veículo padrão (se não existir)
INSERT INTO veiculos (id, modelo, placa, ativo)
SELECT 
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 
    'Veículo Padrão', 
    'AAA-0000', 
    true
WHERE NOT EXISTS (
    SELECT 1 FROM veiculos WHERE id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
);

-- 7. Verificar dados inseridos
SELECT 'Motoristas:' as tabela, COUNT(*) as total FROM motoristas
UNION ALL
SELECT 'Veículos:' as tabela, COUNT(*) as total FROM veiculos
UNION ALL
SELECT 'Agendamentos:' as tabela, COUNT(*) as total FROM agendamentos;

-- 8. Mostrar estrutura da tabela agendamentos
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'agendamentos'
ORDER BY ordinal_position;
