-- Function to search clients with flexible criteria
CREATE OR REPLACE FUNCTION search_clientes(
    search_term TEXT DEFAULT NULL,
    limit_count INTEGER DEFAULT 50,
    offset_count INTEGER DEFAULT 0
)
RETURNS TABLE (
    id UUID,
    nome VARCHAR,
    telefone VARCHAR,
    email VARCHAR,
    documento VARCHAR,
    tipo_documento VARCHAR,
    endereco_completo TEXT,
    created_at TIMESTAMP WITH TIME ZONE,
    relevance_score INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id,
        c.nome,
        c.telefone,
        c.email,
        c.documento,
        c.tipo_documento,
        CONCAT_WS(', ', 
            NULLIF(c.endereco, ''),
            NULLIF(c.bairro, ''),
            NULLIF(c.cidade, ''),
            NULLIF(c.estado, '')
        ) as endereco_completo,
        c.created_at,
        CASE 
            WHEN search_term IS NULL THEN 0
            WHEN c.nome ILIKE '%' || search_term || '%' THEN 3
            WHEN c.telefone ILIKE '%' || search_term || '%' THEN 2
            WHEN c.email ILIKE '%' || search_term || '%' THEN 2
            WHEN c.documento ILIKE '%' || search_term || '%' THEN 1
            ELSE 0
        END as relevance_score
    FROM clientes c
    WHERE c.ativo = true
    AND (
        search_term IS NULL OR
        c.nome ILIKE '%' || search_term || '%' OR
        c.telefone ILIKE '%' || search_term || '%' OR
        c.email ILIKE '%' || search_term || '%' OR
        c.documento ILIKE '%' || search_term || '%'
    )
    ORDER BY 
        CASE WHEN search_term IS NULL THEN c.nome ELSE NULL END,
        relevance_score DESC,
        c.nome
    LIMIT limit_count
    OFFSET offset_count;
END;
$$ LANGUAGE plpgsql;

-- Function to validate CPF
CREATE OR REPLACE FUNCTION validate_cpf(cpf_input TEXT)
RETURNS BOOLEAN AS $$
DECLARE
    cpf TEXT;
    sum1 INTEGER := 0;
    sum2 INTEGER := 0;
    i INTEGER;
BEGIN
    -- Remove non-numeric characters
    cpf := REGEXP_REPLACE(cpf_input, '[^0-9]', '', 'g');
    
    -- Check length
    IF LENGTH(cpf) != 11 THEN
        RETURN FALSE;
    END IF;
    
    -- Check for known invalid CPFs
    IF cpf IN ('00000000000', '11111111111', '22222222222', '33333333333', 
               '44444444444', '55555555555', '66666666666', '77777777777',
               '88888888888', '99999999999') THEN
        RETURN FALSE;
    END IF;
    
    -- Calculate first check digit
    FOR i IN 1..9 LOOP
        sum1 := sum1 + (SUBSTRING(cpf, i, 1)::INTEGER * (11 - i));
    END LOOP;
    
    sum1 := 11 - (sum1 % 11);
    IF sum1 >= 10 THEN sum1 := 0; END IF;
    
    -- Calculate second check digit
    FOR i IN 1..10 LOOP
        sum2 := sum2 + (SUBSTRING(cpf, i, 1)::INTEGER * (12 - i));
    END LOOP;
    
    sum2 := 11 - (sum2 % 11);
    IF sum2 >= 10 THEN sum2 := 0; END IF;
    
    -- Validate check digits
    RETURN (SUBSTRING(cpf, 10, 1)::INTEGER = sum1) AND 
           (SUBSTRING(cpf, 11, 1)::INTEGER = sum2);
END;
$$ LANGUAGE plpgsql;

-- Function to validate CNPJ
CREATE OR REPLACE FUNCTION validate_cnpj(cnpj_input TEXT)
RETURNS BOOLEAN AS $$
DECLARE
    cnpj TEXT;
    sum1 INTEGER := 0;
    sum2 INTEGER := 0;
    weights1 INTEGER[] := ARRAY[5,4,3,2,9,8,7,6,5,4,3,2];
    weights2 INTEGER[] := ARRAY[6,5,4,3,2,9,8,7,6,5,4,3,2];
    i INTEGER;
BEGIN
    -- Remove non-numeric characters
    cnpj := REGEXP_REPLACE(cnpj_input, '[^0-9]', '', 'g');
    
    -- Check length
    IF LENGTH(cnpj) != 14 THEN
        RETURN FALSE;
    END IF;
    
    -- Calculate first check digit
    FOR i IN 1..12 LOOP
        sum1 := sum1 + (SUBSTRING(cnpj, i, 1)::INTEGER * weights1[i]);
    END LOOP;
    
    sum1 := sum1 % 11;
    IF sum1 < 2 THEN sum1 := 0; ELSE sum1 := 11 - sum1; END IF;
    
    -- Calculate second check digit
    FOR i IN 1..13 LOOP
        sum2 := sum2 + (SUBSTRING(cnpj, i, 1)::INTEGER * weights2[i]);
    END LOOP;
    
    sum2 := sum2 % 11;
    IF sum2 < 2 THEN sum2 := 0; ELSE sum2 := 11 - sum2; END IF;
    
    -- Validate check digits
    RETURN (SUBSTRING(cnpj, 13, 1)::INTEGER = sum1) AND 
           (SUBSTRING(cnpj, 14, 1)::INTEGER = sum2);
END;
$$ LANGUAGE plpgsql;
