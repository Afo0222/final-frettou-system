-- Tabela para armazenar rotas calculadas
CREATE TABLE IF NOT EXISTS rotas_calculadas (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    orcamento_id UUID REFERENCES orcamentos(id) ON DELETE CASCADE,
    endereco_origem TEXT NOT NULL,
    endereco_destino TEXT NOT NULL,
    coordenadas_origem JSONB, -- {lat: number, lng: number}
    coordenadas_destino JSONB,
    waypoints TEXT[], -- Array de endereços intermediários
    distancia_metros INTEGER NOT NULL,
    duracao_segundos INTEGER NOT NULL,
    polyline TEXT, -- Encoded polyline do Google Maps
    custo_estimado DECIMAL(10,2),
    otimizada BOOLEAN DEFAULT false,
    dados_rota JSONB, -- Dados completos da rota do Google Maps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_rotas_calculadas_orcamento ON rotas_calculadas(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_rotas_calculadas_origem ON rotas_calculadas USING GIN(coordenadas_origem);
CREATE INDEX IF NOT EXISTS idx_rotas_calculadas_destino ON rotas_calculadas USING GIN(coordenadas_destino);
CREATE INDEX IF NOT EXISTS idx_rotas_calculadas_created ON rotas_calculadas(created_at);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_rotas_calculadas_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_rotas_calculadas_updated_at
    BEFORE UPDATE ON rotas_calculadas
    FOR EACH ROW
    EXECUTE FUNCTION update_rotas_calculadas_updated_at();

-- Tabela para cache de geocodificação
CREATE TABLE IF NOT EXISTS geocoding_cache (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    endereco TEXT NOT NULL UNIQUE,
    endereco_formatado TEXT NOT NULL,
    coordenadas JSONB NOT NULL, -- {lat: number, lng: number}
    componentes JSONB, -- Componentes do endereço (cidade, estado, etc.)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '30 days')
);

-- Índices para cache de geocodificação
CREATE INDEX IF NOT EXISTS idx_geocoding_cache_endereco ON geocoding_cache(endereco);
CREATE INDEX IF NOT EXISTS idx_geocoding_cache_expires ON geocoding_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_geocoding_cache_coordenadas ON geocoding_cache USING GIN(coordenadas);

-- Função para limpar cache expirado
CREATE OR REPLACE FUNCTION clean_expired_geocoding_cache()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM geocoding_cache WHERE expires_at < NOW();
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Tabela para histórico de otimizações de rota
CREATE TABLE IF NOT EXISTS otimizacoes_rota (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    rota_original_id UUID REFERENCES rotas_calculadas(id) ON DELETE CASCADE,
    rota_otimizada_id UUID REFERENCES rotas_calculadas(id) ON DELETE CASCADE,
    economia_distancia INTEGER, -- Em metros
    economia_tempo INTEGER, -- Em segundos
    economia_custo DECIMAL(10,2),
    algoritmo_usado TEXT DEFAULT 'google_maps_optimize',
    parametros JSONB, -- Parâmetros usados na otimização
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para otimizações
CREATE INDEX IF NOT EXISTS idx_otimizacoes_rota_original ON otimizacoes_rota(rota_original_id);
CREATE INDEX IF NOT EXISTS idx_otimizacoes_rota_otimizada ON otimizacoes_rota(rota_otimizada_id);
CREATE INDEX IF NOT EXISTS idx_otimizacoes_rota_created ON otimizacoes_rota(created_at);

-- View para estatísticas de rotas
CREATE OR REPLACE VIEW estatisticas_rotas AS
SELECT 
    COUNT(*) as total_rotas,
    COUNT(*) FILTER (WHERE otimizada = true) as rotas_otimizadas,
    AVG(distancia_metros) as distancia_media,
    AVG(duracao_segundos) as duracao_media,
    AVG(custo_estimado) as custo_medio,
    SUM(distancia_metros) as distancia_total,
    SUM(duracao_segundos) as duracao_total,
    SUM(custo_estimado) as custo_total
FROM rotas_calculadas
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days';

-- Função para buscar rota em cache
CREATE OR REPLACE FUNCTION buscar_rota_cache(
    p_origem TEXT,
    p_destino TEXT,
    p_waypoints TEXT[] DEFAULT NULL
)
RETURNS TABLE(
    id UUID,
    distancia_metros INTEGER,
    duracao_segundos INTEGER,
    custo_estimado DECIMAL(10,2),
    polyline TEXT,
    dados_rota JSONB
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.id,
        r.distancia_metros,
        r.duracao_segundos,
        r.custo_estimado,
        r.polyline,
        r.dados_rota
    FROM rotas_calculadas r
    WHERE r.endereco_origem = p_origem
      AND r.endereco_destino = p_destino
      AND (
          (p_waypoints IS NULL AND r.waypoints IS NULL) OR
          (p_waypoints IS NOT NULL AND r.waypoints = p_waypoints)
      )
      AND r.created_at > NOW() - INTERVAL '7 days'
    ORDER BY r.created_at DESC
    LIMIT 1;
END;
$$ LANGUAGE plpgsql;

-- Comentários nas tabelas
COMMENT ON TABLE rotas_calculadas IS 'Armazena rotas calculadas com Google Maps API';
COMMENT ON TABLE geocoding_cache IS 'Cache de geocodificação para otimizar performance';
COMMENT ON TABLE otimizacoes_rota IS 'Histórico de otimizações de rota realizadas';
COMMENT ON VIEW estatisticas_rotas IS 'Estatísticas agregadas das rotas dos últimos 30 dias';
