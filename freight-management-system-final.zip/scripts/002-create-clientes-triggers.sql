-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
DROP TRIGGER IF EXISTS update_clientes_updated_at ON clientes;
CREATE TRIGGER update_clientes_updated_at
    BEFORE UPDATE ON clientes
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create function to automatically detect document type
CREATE OR REPLACE FUNCTION detect_document_type()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.documento IS NOT NULL THEN
        -- Remove all non-numeric characters for validation
        NEW.documento = REGEXP_REPLACE(NEW.documento, '[^0-9]', '', 'g');
        
        -- Detect document type based on length
        IF LENGTH(NEW.documento) = 11 THEN
            NEW.tipo_documento = 'cpf';
        ELSIF LENGTH(NEW.documento) = 14 THEN
            NEW.tipo_documento = 'cnpj';
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically detect document type
DROP TRIGGER IF EXISTS detect_clientes_document_type ON clientes;
CREATE TRIGGER detect_clientes_document_type
    BEFORE INSERT OR UPDATE ON clientes
    FOR EACH ROW
    EXECUTE FUNCTION detect_document_type();
