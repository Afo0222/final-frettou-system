-- Add cancellation tracking fields to agendamentos table
ALTER TABLE agendamentos 
ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS cancelled_by VARCHAR(255),
ADD COLUMN IF NOT EXISTS cancellation_reason TEXT,
ADD COLUMN IF NOT EXISTS cancellation_notes TEXT,
ADD COLUMN IF NOT EXISTS original_status VARCHAR(50);

-- Create index for better performance on cancelled appointments
CREATE INDEX IF NOT EXISTS idx_agendamentos_cancelled_at ON agendamentos(cancelled_at);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status_cancelled ON agendamentos(status) WHERE status = 'cancelado';

-- Create a view for active (non-cancelled) appointments
CREATE OR REPLACE VIEW agendamentos_ativos AS
SELECT * FROM agendamentos 
WHERE status != 'cancelado' OR status IS NULL;

-- Create a view for cancelled appointments with full history
CREATE OR REPLACE VIEW agendamentos_cancelados AS
SELECT 
  *,
  CASE 
    WHEN cancelled_at IS NOT NULL THEN cancelled_at
    ELSE updated_at
  END as data_cancelamento
FROM agendamentos 
WHERE status = 'cancelado';

-- Create function to get available time slots for a specific date and driver
CREATE OR REPLACE FUNCTION get_available_slots(
  p_motorista_nome TEXT,
  p_data DATE,
  p_hora_inicio TIME DEFAULT '08:00',
  p_hora_fim TIME DEFAULT '18:00',
  p_intervalo_minutos INTEGER DEFAULT 60
)
RETURNS TABLE(
  hora_slot TIME,
  disponivel BOOLEAN,
  agendamento_id UUID
) AS $$
DECLARE
  slot_time TIME;
  current_slot TIME;
BEGIN
  current_slot := p_hora_inicio;
  
  WHILE current_slot < p_hora_fim LOOP
    SELECT 
      current_slot,
      NOT EXISTS(
        SELECT 1 FROM agendamentos 
        WHERE motorista_nome = p_motorista_nome 
        AND data_agendada = p_data 
        AND hora_agendada = current_slot::TEXT
        AND status != 'cancelado'
      ),
      (SELECT id FROM agendamentos 
       WHERE motorista_nome = p_motorista_nome 
       AND data_agendada = p_data 
       AND hora_agendada = current_slot::TEXT
       AND status != 'cancelado'
       LIMIT 1)
    INTO hora_slot, disponivel, agendamento_id;
    
    RETURN NEXT;
    current_slot := current_slot + (p_intervalo_minutos || ' minutes')::INTERVAL;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create function to check schedule conflicts
CREATE OR REPLACE FUNCTION check_schedule_conflicts(
  p_motorista_nome TEXT,
  p_data DATE,
  p_hora TIME,
  p_duracao_minutos INTEGER DEFAULT 60,
  p_agendamento_id UUID DEFAULT NULL
)
RETURNS TABLE(
  tem_conflito BOOLEAN,
  agendamentos_conflitantes JSON
) AS $$
DECLARE
  conflitos JSON;
BEGIN
  SELECT json_agg(
    json_build_object(
      'id', id,
      'cliente_nome', cliente_nome,
      'hora_agendada', hora_agendada,
      'status', status
    )
  )
  INTO conflitos
  FROM agendamentos
  WHERE motorista_nome = p_motorista_nome
  AND data_agendada = p_data
  AND status != 'cancelado'
  AND (p_agendamento_id IS NULL OR id != p_agendamento_id)
  AND (
    -- Check for time overlap
    (hora_agendada::TIME <= p_hora AND (hora_agendada::TIME + INTERVAL '1 hour') > p_hora)
    OR
    (hora_agendada::TIME < (p_hora + (p_duracao_minutos || ' minutes')::INTERVAL) AND hora_agendada::TIME >= p_hora)
  );

  RETURN QUERY SELECT 
    CASE WHEN conflitos IS NOT NULL THEN true ELSE false END,
    COALESCE(conflitos, '[]'::JSON);
END;
$$ LANGUAGE plpgsql;

-- Add comments for documentation
COMMENT ON COLUMN agendamentos.cancelled_at IS 'Timestamp when the appointment was cancelled';
COMMENT ON COLUMN agendamentos.cancelled_by IS 'User who cancelled the appointment';
COMMENT ON COLUMN agendamentos.cancellation_reason IS 'Reason for cancellation';
COMMENT ON COLUMN agendamentos.cancellation_notes IS 'Additional notes about the cancellation';
COMMENT ON COLUMN agendamentos.original_status IS 'Status before cancellation for historical tracking';
