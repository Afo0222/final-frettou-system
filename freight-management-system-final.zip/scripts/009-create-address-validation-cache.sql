-- Tabela para cache de validações de endereço
CREATE TABLE IF NOT EXISTS address_validation_cache (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    original_address TEXT NOT NULL,
    validated_address TEXT,
    is_valid BOOLEAN NOT NULL DEFAULT false,
    confidence TEXT CHECK (confidence IN ('high', 'medium', 'low')),
    coordinates JSONB,
    components JSONB,
    warnings TEXT[],
    errors TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '30 days'),
    
    -- Índices para performance
    UNIQUE(original_address)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_address_validation_cache_original ON address_validation_cache(original_address);
CREATE INDEX IF NOT EXISTS idx_address_validation_cache_expires ON address_validation_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_address_validation_cache_valid ON address_validation_cache(is_valid);

-- Função para limpar cache expirado
CREATE OR REPLACE FUNCTION clean_expired_address_cache()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM address_validation_cache 
    WHERE expires_at < NOW();
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Tabela para cache de rotas
CREATE TABLE IF NOT EXISTS route_cache (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    origin_address TEXT NOT NULL,
    destination_address TEXT NOT NULL,
    distance_km DECIMAL(10,2),
    duration_hours DECIMAL(10,2),
    is_feasible BOOLEAN DEFAULT true,
    route_data JSONB,
    warnings TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '7 days'),
    
    -- Índice único para combinação origem-destino
    UNIQUE(origin_address, destination_address)
);

-- Índices para rotas
CREATE INDEX IF NOT EXISTS idx_route_cache_origin ON route_cache(origin_address);
CREATE INDEX IF NOT EXISTS idx_route_cache_destination ON route_cache(destination_address);
CREATE INDEX IF NOT EXISTS idx_route_cache_expires ON route_cache(expires_at);

-- Função para limpar cache de rotas expirado
CREATE OR REPLACE FUNCTION clean_expired_route_cache()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM route_cache 
    WHERE expires_at < NOW();
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Trigger para limpeza automática (executar diariamente)
CREATE OR REPLACE FUNCTION schedule_cache_cleanup()
RETURNS void AS $$
BEGIN
    -- Esta função pode ser chamada por um cron job
    PERFORM clean_expired_address_cache();
    PERFORM clean_expired_route_cache();
END;
$$ LANGUAGE plpgsql;

-- Comentários
COMMENT ON TABLE address_validation_cache IS 'Cache de validações de endereço para melhorar performance';
COMMENT ON TABLE route_cache IS 'Cache de cálculos de rota para reduzir chamadas à API';
COMMENT ON FUNCTION clean_expired_address_cache() IS 'Remove entradas expiradas do cache de endereços';
COMMENT ON FUNCTION clean_expired_route_cache() IS 'Remove entradas expiradas do cache de rotas';
