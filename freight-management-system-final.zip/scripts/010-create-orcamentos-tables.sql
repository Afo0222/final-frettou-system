-- Verificar se a tabela de orçamentos já existe
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'orcamentos') THEN
        -- Criar tabela de orçamentos
        CREATE TABLE public.orcamentos (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            numero_orcamento VARCHAR(50) NOT NULL,
            cliente_id UUID REFERENCES public.clientes(id),
            tipo_servico_id UUID REFERENCES public.tipos_servico(id),
            endereco_origem TEXT NOT NULL,
            endereco_destino TEXT NOT NULL,
            data_agendada DATE,
            hora_agendada VARCHAR(5),
            descricao_itens TEXT,
            peso_estimado NUMERIC(10,2),
            volume_estimado NUMERIC(10,2),
            veiculo_recomendado VARCHAR(100),
            tempo_estimado NUMERIC(10,2),
            ajudantes_adicionais INTEGER DEFAULT 0,
            servicos_extras JSONB,
            valor_total NUMERIC(10,2) NOT NULL,
            detalhes_custo JSONB,
            status VARCHAR(20) NOT NULL DEFAULT 'rascunho',
            valido_ate DATE,
            observacoes TEXT,
            created_by UUID,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Criar índices
        CREATE INDEX idx_orcamentos_cliente_id ON public.orcamentos(cliente_id);
        CREATE INDEX idx_orcamentos_tipo_servico_id ON public.orcamentos(tipo_servico_id);
        CREATE INDEX idx_orcamentos_status ON public.orcamentos(status);
        CREATE INDEX idx_orcamentos_created_at ON public.orcamentos(created_at);
        
        -- Adicionar comentários
        COMMENT ON TABLE public.orcamentos IS 'Tabela de orçamentos para serviços de frete e mudança';
        COMMENT ON COLUMN public.orcamentos.numero_orcamento IS 'Número único do orçamento para referência';
        COMMENT ON COLUMN public.orcamentos.status IS 'Status do orçamento: rascunho, enviado, aprovado, rejeitado, expirado';
    END IF;
    
    -- Verificar se a tabela de cálculos de orçamentos já existe
    IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'orcamentos_calculos') THEN
        -- Criar tabela de cálculos de orçamentos
        CREATE TABLE public.orcamentos_calculos (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            orcamento_id UUID REFERENCES public.orcamentos(id),
            tipo_servico_id UUID REFERENCES public.tipos_servico(id),
            distancia_km NUMERIC(10,2) NOT NULL,
            tempo_estimado_horas NUMERIC(10,2) NOT NULL,
            subtotal_base NUMERIC(10,2) NOT NULL,
            subtotal_distancia NUMERIC(10,2) NOT NULL,
            subtotal_tempo NUMERIC(10,2) NOT NULL,
            subtotal_ajudantes NUMERIC(10,2) NOT NULL,
            subtotal_variaveis NUMERIC(10,2) NOT NULL,
            subtotal_extras NUMERIC(10,2) NOT NULL,
            valor_total NUMERIC(10,2) NOT NULL,
            detalhes JSONB,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
        
        -- Criar índices
        CREATE INDEX idx_orcamentos_calculos_orcamento_id ON public.orcamentos_calculos(orcamento_id);
    END IF;
    
    -- Verificar se a tabela de serviços extras já existe
    IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'servicos_extras') THEN
        -- Criar tabela de serviços extras
        CREATE TABLE public.servicos_extras (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            codigo VARCHAR(50) NOT NULL UNIQUE,
            nome VARCHAR(100) NOT NULL,
            descricao TEXT,
            valor NUMERIC(10,2) NOT NULL,
            ativo BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
        
        -- Inserir serviços extras padrão
        INSERT INTO public.servicos_extras (codigo, nome, descricao, valor)
        VALUES 
            ('embalagem', 'Embalagem', 'Serviço de embalagem de itens', 50.00),
            ('desmontagem', 'Desmontagem de Móveis', 'Serviço de desmontagem de móveis', 80.00),
            ('montagem', 'Montagem de Móveis', 'Serviço de montagem de móveis', 80.00),
            ('limpeza', 'Limpeza Pós-Mudança', 'Serviço de limpeza após a mudança', 100.00),
            ('guarda-moveis', 'Guarda Móveis', 'Serviço de armazenamento temporário de móveis', 150.00);
    END IF;
    
    -- Verificar se a tabela de relacionamento entre orçamentos e serviços extras já existe
    IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'orcamentos_servicos_extras') THEN
        -- Criar tabela de relacionamento entre orçamentos e serviços extras
        CREATE TABLE public.orcamentos_servicos_extras (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            orcamento_id UUID REFERENCES public.orcamentos(id),
            servico_extra_id UUID REFERENCES public.servicos_extras(id),
            quantidade INTEGER DEFAULT 1,
            valor_unitario NUMERIC(10,2) NOT NULL,
            valor_total NUMERIC(10,2) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
        
        -- Criar índices
        CREATE INDEX idx_orcamentos_servicos_extras_orcamento_id ON public.orcamentos_servicos_extras(orcamento_id);
        CREATE INDEX idx_orcamentos_servicos_extras_servico_extra_id ON public.orcamentos_servicos_extras(servico_extra_id);
    END IF;
END$$;

-- Criar ou atualizar a função para atualizar o timestamp de updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para atualizar o timestamp de updated_at na tabela de orçamentos
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_orcamentos_updated_at') THEN
        CREATE TRIGGER update_orcamentos_updated_at
        BEFORE UPDATE ON public.orcamentos
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    END IF;
END$$;

-- Criar trigger para atualizar o timestamp de updated_at na tabela de serviços extras
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_servicos_extras_updated_at') THEN
        CREATE TRIGGER update_servicos_extras_updated_at
        BEFORE UPDATE ON public.servicos_extras
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    END IF;
END$$;
