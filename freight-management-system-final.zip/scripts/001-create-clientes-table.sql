-- Create clientes table with comprehensive fields
CREATE TABLE IF NOT EXISTS clientes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    documento VARCHAR(20),
    tipo_documento VARCHAR(10) CHECK (tipo_documento IN ('cpf', 'cnpj')),
    endereco TEXT,
    cep VARCHAR(10),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    bairro VARCHAR(100),
    numero VARCHAR(20),
    complemento VARCHAR(100),
    observacoes TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_clientes_nome ON clientes(nome);
CREATE INDEX IF NOT EXISTS idx_clientes_telefone ON clientes(telefone);
CREATE INDEX IF NOT EXISTS idx_clientes_email ON clientes(email);
CREATE INDEX IF NOT EXISTS idx_clientes_documento ON clientes(documento);
CREATE INDEX IF NOT EXISTS idx_clientes_ativo ON clientes(ativo);
CREATE INDEX IF NOT EXISTS idx_clientes_created_at ON clientes(created_at);

-- Create unique constraint for documento when not null
CREATE UNIQUE INDEX IF NOT EXISTS idx_clientes_documento_unique 
ON clientes(documento) WHERE documento IS NOT NULL;

-- Create unique constraint for email when not null
CREATE UNIQUE INDEX IF NOT EXISTS idx_clientes_email_unique 
ON clientes(email) WHERE email IS NOT NULL;

-- Add comments for documentation
COMMENT ON TABLE clientes IS 'Tabela de clientes do sistema de gestão de fretes';
COMMENT ON COLUMN clientes.id IS 'Identificador único do cliente';
COMMENT ON COLUMN clientes.nome IS 'Nome completo ou razão social do cliente';
COMMENT ON COLUMN clientes.telefone IS 'Telefone principal do cliente';
COMMENT ON COLUMN clientes.email IS 'Email do cliente (opcional)';
COMMENT ON COLUMN clientes.documento IS 'CPF ou CNPJ do cliente';
COMMENT ON COLUMN clientes.tipo_documento IS 'Tipo do documento: cpf ou cnpj';
COMMENT ON COLUMN clientes.endereco IS 'Endereço completo do cliente';
COMMENT ON COLUMN clientes.observacoes IS 'Observações e notas sobre o cliente';
COMMENT ON COLUMN clientes.ativo IS 'Indica se o cliente está ativo no sistema';
