-- Remover constraints existentes se houver problemas
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_motorista_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS agendamentos_veiculo_id_fkey;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_motorista;
ALTER TABLE IF EXISTS agendamentos DROP CONSTRAINT IF EXISTS fk_agendamentos_veiculo;

-- Limpar dados existentes
DELETE FROM agendamentos WHERE true;
DELETE FROM veiculos WHERE true;
DELETE FROM motoristas WHERE true;

-- Recriar tabela de motoristas com estrutura simples
DROP TABLE IF EXISTS motoristas CASCADE;
CREATE TABLE motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14),
    cnh VARCHAR(20),
    telefone VARCHAR(20),
    email VARCHAR(255),
    endereco TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Recriar tabela de veículos com estrutura simples
DROP TABLE IF EXISTS veiculos CASCADE;
CREATE TABLE veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    ano INTEGER,
    cor VARCHAR(50),
    capacidade_peso DECIMAL(10,2),
    capacidade_volume DECIMAL(10,2),
    tipo_veiculo VARCHAR(100),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Recriar tabela de agendamentos sem foreign keys primeiro
DROP TABLE IF EXISTS agendamentos CASCADE;
CREATE TABLE agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_id UUID,
    motorista_id UUID,
    veiculo_id UUID,
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL,
    hora_inicio TIME,
    hora_fim TIME,
    duracao_estimada_minutos INTEGER DEFAULT 120,
    status VARCHAR(50) DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    distancia_km DECIMAL(10,2),
    tempo_viagem_minutos INTEGER,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(255),
    prioridade VARCHAR(50) DEFAULT 'normal',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir motoristas com IDs específicos
INSERT INTO motoristas (id, nome, cpf, cnh, telefone, email, ativo) VALUES
('11111111-1111-1111-1111-111111111111', 'João Silva', '123.456.789-01', 'CNH123456', '(11) 99999-1111', 'joao@email.com', true),
('22222222-2222-2222-2222-222222222222', 'Maria Santos', '234.567.890-12', 'CNH234567', '(11) 99999-2222', 'maria@email.com', true),
('33333333-3333-3333-3333-333333333333', 'Carlos Oliveira', '345.678.901-23', 'CNH345678', '(11) 99999-3333', 'carlos@email.com', true),
('44444444-4444-4444-4444-444444444444', 'Ana Costa', '456.789.012-34', 'CNH456789', '(11) 99999-4444', 'ana@email.com', true),
('55555555-5555-5555-5555-555555555555', 'Pedro Lima', '567.890.123-45', 'CNH567890', '(11) 99999-5555', 'pedro@email.com', true);

-- Inserir veículos com IDs específicos
INSERT INTO veiculos (id, modelo, placa, ano, cor, capacidade_peso, capacidade_volume, tipo_veiculo, ativo) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Fiat Fiorino', 'ABC-1234', 2020, 'Branco', 650.00, 2.5, 'Van', true),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Ford Transit', 'DEF-5678', 2021, 'Prata', 1200.00, 8.0, 'Van', true),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'Mercedes Sprinter', 'GHI-9012', 2022, 'Branco', 1500.00, 12.0, 'Van', true),
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'Iveco Daily', 'JKL-3456', 2019, 'Azul', 2000.00, 15.0, 'Caminhão', true),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'Volkswagen Delivery', 'MNO-7890', 2020, 'Branco', 3000.00, 20.0, 'Caminhão', true);

-- Agora adicionar as foreign keys APÓS inserir os dados
ALTER TABLE agendamentos 
ADD CONSTRAINT fk_agendamentos_motorista 
FOREIGN KEY (motorista_id) REFERENCES motoristas(id) ON DELETE SET NULL;

ALTER TABLE agendamentos 
ADD CONSTRAINT fk_agendamentos_veiculo 
FOREIGN KEY (veiculo_id) REFERENCES veiculos(id) ON DELETE SET NULL;

-- Inserir agendamentos de exemplo
INSERT INTO agendamentos (
    id, 
    motorista_id, 
    veiculo_id, 
    data_agendada, 
    hora_agendada, 
    hora_inicio, 
    hora_fim, 
    duracao_estimada_minutos,
    status, 
    endereco_origem, 
    endereco_destino, 
    cliente_nome, 
    cliente_telefone, 
    valor_servico, 
    tipo_servico, 
    prioridade,
    observacoes
) VALUES
(
    'f1111111-1111-1111-1111-111111111111',
    '11111111-1111-1111-1111-111111111111',
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    CURRENT_DATE + INTERVAL '1 day',
    '08:00:00',
    '08:00:00',
    '10:00:00',
    120,
    'agendado',
    'Rua das Flores, 123 - Centro, São Paulo/SP',
    'Av. Paulista, 456 - Bela Vista, São Paulo/SP',
    'Cliente Exemplo 1',
    '(11) 98765-4321',
    250.00,
    'Frete Padrão',
    'normal',
    'Agendamento de exemplo'
);

-- Verificar se os dados foram inseridos
SELECT 'Motoristas:' as tabela, COUNT(*) as total FROM motoristas
UNION ALL
SELECT 'Veículos:' as tabela, COUNT(*) as total FROM veiculos
UNION ALL
SELECT 'Agendamentos:' as tabela, COUNT(*) as total FROM agendamentos;

-- Mostrar IDs dos motoristas para debug
SELECT 'Motorista:' as tipo, id, nome FROM motoristas ORDER BY nome;
