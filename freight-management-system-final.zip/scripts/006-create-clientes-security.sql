-- Enable Row Level Security (RLS) for clientes table
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users to view all active clients
CREATE POLICY "Users can view active clients" ON clientes
    FOR SELECT USING (ativo = true);

-- Create policy for authenticated users to insert clients
CREATE POLICY "Users can insert clients" ON clientes
    FOR INSERT WITH CHECK (true);

-- Create policy for authenticated users to update clients
CREATE POLICY "Users can update clients" ON clientes
    FOR UPDATE USING (true);

-- Create policy for soft delete (update ativo to false)
CREATE POLICY "Users can soft delete clients" ON clientes
    FOR UPDATE USING (true)
    WITH CHECK (ativo IN (true, false));

-- Grant necessary permissions to authenticated users
GRANT SELECT, INSERT, UPDATE ON clientes TO authenticated;
GRANT USAGE ON SEQUENCE clientes_id_seq TO authenticated;

-- Grant permissions on views
GRANT SELECT ON vw_clientes_ativos TO authenticated;
GRANT SELECT ON vw_clientes_estatisticas TO authenticated;
GRANT SELECT ON vw_clientes_recentes TO authenticated;

-- Grant execute permissions on functions
GRANT EXECUTE ON FUNCTION search_clientes(TEXT, INTEGER, INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION validate_cpf(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION validate_cnpj(TEXT) TO authenticated;
