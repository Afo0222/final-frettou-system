-- Criar tabela de agendamentos se não existir
CREATE TABLE IF NOT EXISTS agendamentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orcamento_id UUID REFERENCES orcamentos(id) ON DELETE CASCADE,
    motorista_id UUID REFERENCES motoristas(id) ON DELETE SET NULL,
    veiculo_id UUID REFERENCES veiculos(id) ON DELETE SET NULL,
    data_agendada DATE NOT NULL,
    hora_agendada TIME NOT NULL DEFAULT '08:00:00',
    hora_inicio TIME,
    hora_fim TIME,
    duracao_estimada_minutos INTEGER DEFAULT 120,
    status VARCHAR(20) NOT NULL DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    distancia_km DECIMAL(10,2),
    tempo_viagem_minutos INTEGER,
    observacoes TEXT,
    cliente_nome VARCHAR(255),
    cliente_telefone VARCHAR(20),
    valor_servico DECIMAL(10,2),
    tipo_servico VARCHAR(100),
    prioridade VARCHAR(20) DEFAULT 'normal',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de motoristas se não existir
CREATE TABLE IF NOT EXISTS motoristas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14),
    rg VARCHAR(20),
    cnh VARCHAR(20),
    telefone VARCHAR(20),
    email VARCHAR(255),
    endereco TEXT,
    status VARCHAR(20) DEFAULT 'ativo',
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de veículos se não existir
CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    modelo VARCHAR(255) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    ano INTEGER,
    cor VARCHAR(50),
    capacidade_kg DECIMAL(10,2),
    capacidade_m3 DECIMAL(10,2),
    tipo VARCHAR(50),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_agendamentos_orcamento_id ON agendamentos(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_motorista_id ON agendamentos(motorista_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_data_agendada ON agendamentos(data_agendada);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status ON agendamentos(status);
CREATE INDEX IF NOT EXISTS idx_agendamentos_created_at ON agendamentos(created_at);

-- Inserir motoristas de exemplo se não existirem
INSERT INTO motoristas (nome, cpf, telefone, email, ativo)
SELECT 'João Silva', '123.456.789-00', '(11) 98765-4321', 'joao.silva@exemplo.com', true
WHERE NOT EXISTS (SELECT 1 FROM motoristas WHERE nome = 'João Silva');

INSERT INTO motoristas (nome, cpf, telefone, email, ativo)
SELECT 'Maria Santos', '987.654.321-00', '(11) 91234-5678', 'maria.santos@exemplo.com', true
WHERE NOT EXISTS (SELECT 1 FROM motoristas WHERE nome = 'Maria Santos');

INSERT INTO motoristas (nome, cpf, telefone, email, ativo)
SELECT 'Carlos Oliveira', '456.789.123-00', '(11) 95555-1234', 'carlos.oliveira@exemplo.com', true
WHERE NOT EXISTS (SELECT 1 FROM motoristas WHERE nome = 'Carlos Oliveira');

-- Inserir veículos de exemplo se não existirem
INSERT INTO veiculos (modelo, placa, ano, cor, capacidade_kg, tipo, ativo)
SELECT 'Fiat Fiorino', 'ABC-1234', 2020, 'Branco', 650.00, 'Van', true
WHERE NOT EXISTS (SELECT 1 FROM veiculos WHERE placa = 'ABC-1234');

INSERT INTO veiculos (modelo, placa, ano, cor, capacidade_kg, tipo, ativo)
SELECT 'Ford Transit', 'DEF-5678', 2021, 'Branco', 1200.00, 'Van', true
WHERE NOT EXISTS (SELECT 1 FROM veiculos WHERE placa = 'DEF-5678');

INSERT INTO veiculos (modelo, placa, ano, cor, capacidade_kg, tipo, ativo)
SELECT 'Mercedes Sprinter', 'GHI-9012', 2022, 'Branco', 1500.00, 'Van', true
WHERE NOT EXISTS (SELECT 1 FROM veiculos WHERE placa = 'GHI-9012');

-- Função para verificar disponibilidade do motorista
CREATE OR REPLACE FUNCTION check_driver_availability(
    p_motorista_id UUID,
    p_data DATE,
    p_hora_inicio TIME,
    p_hora_fim TIME,
    p_agendamento_id UUID DEFAULT NULL
) RETURNS BOOLEAN AS $$
BEGIN
    RETURN NOT EXISTS (
        SELECT 1 FROM agendamentos
        WHERE motorista_id = p_motorista_id
        AND data_agendada = p_data
        AND status NOT IN ('cancelado', 'reagendado')
        AND (p_agendamento_id IS NULL OR id != p_agendamento_id)
        AND (
            (hora_inicio <= p_hora_inicio AND hora_fim > p_hora_inicio) OR
            (hora_inicio < p_hora_fim AND hora_fim >= p_hora_fim) OR
            (hora_inicio >= p_hora_inicio AND hora_fim <= p_hora_fim)
        )
    );
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_agendamentos_updated_at
    BEFORE UPDATE ON agendamentos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_motoristas_updated_at
    BEFORE UPDATE ON motoristas
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_veiculos_updated_at
    BEFORE UPDATE ON veiculos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
