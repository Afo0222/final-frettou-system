-- Criar tabela de agendamentos com estrutura mínima
CREATE TABLE IF NOT EXISTS agendamentos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    orcamento_id UUID REFERENCES orcamentos(id) ON DELETE SET NULL,
    motorista_id UUID REFERENCES motoristas(id) ON DELETE SET NULL,
    data_agendada DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'agendado',
    endereco_origem TEXT,
    endereco_destino TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_agendamentos_orcamento_id ON agendamentos(orcamento_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_motorista_id ON agendamentos(motorista_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_data_agendada ON agendamentos(data_agendada);

-- Inserir dados de exemplo para motoristas se não existirem
INSERT INTO motoristas (id, nome, cpf, telefone, email, ativo)
SELECT 
    gen_random_uuid(), 
    'João Motorista', 
    '123.456.789-00', 
    '(11) 98765-4321', 
    'joao@exemplo.com', 
    true
WHERE 
    NOT EXISTS (SELECT 1 FROM motoristas LIMIT 1);
